
package com.bel.mailApplication.network;

import java.util.Observable;
import java.util.Observer;

import mail.awan.networkAutoCheck.NetworkAutoReachabilityCheck;
//import awan.desktop.networkAutoCheck.NetworkAutoReachabilityCheck;
import javafx.application.Platform;
import org.controlsfx.control.Notifications;
/**
 * @File Name : NetworkObserver
 * @author : Vimal M
 * @Description: For Network Checking
 * @Package : com.bel.mailApplication.controller
 * @Created : 5th May 2017
 * @Modification History:NA
 */
public class NetworkObserver implements Observer {
	
	// Fields
	
	private String networkChangeIndicator;
	@SuppressWarnings("unused")
	private Observable subject;

	
	public String getNetworkChangeIndicator() {
		return networkChangeIndicator;
	}
	public void setNetworkChangeIndicator(String networkChangeIndicator) {
		this.networkChangeIndicator = networkChangeIndicator;
	}
	public NetworkObserver(Observable subject) {
		this.subject = subject;		
		subject.addObserver(this);
	}
	// Methods
	public void update(Observable subject, Object arg) {
		if (subject instanceof NetworkAutoReachabilityCheck) {
			NetworkAutoReachabilityCheck subj = (NetworkAutoReachabilityCheck)subject;
			networkChangeIndicator = subj.getNetworkChangeIndicator();
                        Platform.runLater(() -> {
                    Notifications.create().text(networkChangeIndicator).showInformation();
                });
			
		}
	}
}
