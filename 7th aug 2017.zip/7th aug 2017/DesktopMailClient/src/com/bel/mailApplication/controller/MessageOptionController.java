package com.bel.mailApplication.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextArea;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
/**
 * ******************************************************************
 * @File Name           : MessageOptionController.
 * @Author              : Ram Krishna Paul.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display window  for  BCC.
 * @Created Date	:15-MAY-2017
 * @Modification History:NA. 
*******************************************************************
 */
public class MessageOptionController implements Initializable {
    @FXML
    private JFXButton btnMsgType;
    @FXML
    private JFXTextArea txtMsgInstruction;
    @FXML
    public JFXComboBox<String> combBoxMsgType;
    public static String messageType;
    public static String messageInstruction;
    public ObservableList<String> MsgType = FXCollections.observableArrayList("Exercise", "Operation", "Project", "Drill");
  /**
     * ******************************************************************
     * @Function Name           :initialize
     * @Description             : Method to call initialization function.
     * @Input Parameter         : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
      * @Author                 : Ram Krishna Paul.
     * @Created Date            :15-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        combBoxMsgType.setItems(MsgType);
    }
 /**
     * ******************************************************************
     * @Function Name           :ClickbtnMsgType
     * @Description             : Method to add Message type to ComboBox.
     * @Input Parameter         : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ram Krishna Paul.
     * @Created Date            :15-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @FXML
    private void clickbtnMsgType(ActionEvent event) {
        messageType = combBoxMsgType.getSelectionModel().getSelectedItem().toString();
        messageInstruction = txtMsgInstruction.getText().toString();
    }

}
