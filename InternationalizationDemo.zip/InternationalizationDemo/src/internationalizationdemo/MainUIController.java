/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package internationalizationdemo;

import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;

/**
 *
 * @author krish
 */
public class MainUIController implements Initializable {

    @FXML
    private Label label;
    @FXML
    private Button buttonEN;
    @FXML
    private Button buttonRU;
    @FXML
    private Button buttonTR;
    @FXML
    private Button buttonAZ;
    @FXML
    private MenuBar menuBar;
    @FXML
    private Menu menuFile;
    @FXML
    private MenuItem menuItmClose;
    @FXML
    private Menu menuEdit;
    @FXML
    private MenuItem menuitmDelete;
    @FXML
    private Menu menuHelp;
    @FXML
    private MenuItem menuItmAbt;
    private ResourceBundle bundle;
    private Locale local;

    private void loadingLang(String lang) {
        local = new Locale(lang);
        bundle = ResourceBundle.getBundle("lang.lang", local);
        label.setText(bundle.getString("label"));
        menuFile.setText(bundle.getString("menuFile"));
        menuItmClose.setText(bundle.getString("menuItmClose"));
        menuEdit.setText(bundle.getString("menuEdit"));
        menuitmDelete.setText(bundle.getString("menuitmDelete"));
        menuHelp.setText(bundle.getString("menuHelp"));
        menuItmAbt.setText(bundle.getString("menuItmAbt"));
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    @FXML
    private void handleButtonActionEN(ActionEvent event) {
        loadingLang("en");
    }

    @FXML
    private void handleButtonActionRU(ActionEvent event) {
        loadingLang("ru");
    }

    @FXML
    private void handleButtonActionTR(ActionEvent event) {
        loadingLang("tr");
    }

    @FXML
    private void handleButtonActionAZ(ActionEvent event) {
        loadingLang("az");
    }

}
