/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.services;

/**
 *
 * @author Admin
 */
public class TcsOffice {
    
String ou="";
	String DesignatedUser="";
	String AlternateDesignatedUser="";
	
	public String getOu() {
		return ou;
	}
	public void setOu(String ou) {
		this.ou = ou;
	}
	public String getDesignatedUser() {
		return DesignatedUser;
	}
	public void setDesignatedUser(String designatedUser) {
		DesignatedUser = designatedUser;
	}
	public String getAlternateDesignatedUser() {
		return AlternateDesignatedUser;
	}
	public void setAlternateDesignatedUser(String alternateDesignatedUser) {
		AlternateDesignatedUser = alternateDesignatedUser;
	}
	@Override
	public String toString() {
		return "TcsOffice [ou=" + ou + ", DesignatedUser=" + DesignatedUser
				+ ", AlternateDesignatedUser=" + AlternateDesignatedUser + "]";
	}
	
	
}