/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import mail.awan.messageHandler.MessageHandler;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import javafx.scene.Node;
import javafx.stage.Stage;
import mail.awan.util.AuthorisationCheck;

/**
 *
 * @author admin
 */
public class AuthorisationController implements Initializable {

    private Label label;
    @FXML
    private TextField txtuname;
    @FXML
    private TextField txtOTP;
    @FXML
    private PasswordField txtpassword;
    @FXML
    private Button btnAuthorize;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        txtuname.setText(sm_name);
    }

    @FXML
    private void clickbtnAuthorize(ActionEvent event) {
        String uname = txtuname.getText();
        String password = txtpassword.getText();

        MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
        String status = messageHandler.getAuthorisation(uname, password);
        if (status.equalsIgnoreCase("true")) {
            final Node Source = (Node) event.getSource();
            final Stage stage = (Stage) Source.getScene().getWindow();
            stage.close();
//            AuthorisationCheck.getAuthorisationCheckInstance().setAuthorisationChangeIndicator("Authorized");
        } else {

        }

    }

}
