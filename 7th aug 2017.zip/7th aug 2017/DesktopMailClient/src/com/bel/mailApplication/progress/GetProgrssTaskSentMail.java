package com.bel.mailApplication.progress;

import static com.bel.mailApplication.controller.FXMLDocumentController.mail_table_list;
import com.bel.mailApplication.model.SentMailList;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;

/**
 * @File Name : GetProgrssTaskSentMail
 * @author : Ram Krishna Paul
 * @Description: For Getting progresTask in sent mail
 * @Package : com.bel.mailApplication.progress
 * @Created : 17th june 2017
 * @Modification History: NA
 */
public class GetProgrssTaskSentMail extends Task<ObservableList<SentMailList>> {

    @Override
    protected ObservableList<SentMailList> call() throws Exception {
//        for (int i = 0; i < 100; i++) {
        updateProgress(0, 0);
        Thread.sleep(14);
//    }
        return mail_table_list;

    }
}
