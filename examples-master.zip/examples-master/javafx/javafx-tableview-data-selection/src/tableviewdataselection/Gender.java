/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tableviewdataselection;

/**
 *
 * @author Narayan G. Maharjan <me@ngopal.com.np>
 */
public enum Gender {
    MALE, FEMALE, OTHER;
}
