/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.model;

import com.mchange.v2.codegen.bean.SimpleProperty;

/**
 *
 * @author Ram krishna paul
 */
public class Modelpojo {

    private String list1;
    private String list2;
    
    public Modelpojo(String list1, String list2) {
       
        this.list2 = list2;
    }
    

    public String getList1() {
        return list1;
        
    }

    public void setList1(String list1) {
        this.list1 = list1;
    }

    public Modelpojo(String list1) {
        this.list1 = list1;
    }

    public Modelpojo() {
    }


    

    public String getList2() {
        return list2;
    }

    public void setList2(String list2) {
        this.list2 = list2;
    }

    
}

