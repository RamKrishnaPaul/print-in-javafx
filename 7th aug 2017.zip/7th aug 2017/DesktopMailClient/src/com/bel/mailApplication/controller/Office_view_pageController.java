package com.bel.mailApplication.controller;

import static com.bel.mailApplication.controller.FXMLDocumentController.mail_id;
import static com.bel.mailApplication.controller.FXMLDocumentController.read_officeemail;
import static com.bel.mailApplication.controller.LoginFXMLController.securityStatusFlag;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import com.entity.MailDTO;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.web.HTMLEditor;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import mail.awan.beans.AlarmProfilesDTO;
import mail.awan.beans.DeleteInput;
import mail.awan.beans.GroupMailInfo;
import mail.awan.beans.ReceiveMailInputDTO;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.Notifications;

/**
 * ******************************************************************
 * @File Name : Office_view_pageController.java
 * @Author : Ravikiran Bhat.
 * @Package : com.bel.mailApplication.controller
 * @Purpose : Display Office In box Mail Page
 * @Created Date	:5-MAY-2017
 * @Modification History: NA.
 * ******************************************************************
 */
public class Office_view_pageController implements Initializable {

    @FXML
    private ComboBox combBoxMsgType;
    @FXML
    private TextArea txtMsgInstruction;
    @FXML
    private JFXButton btnBCC, btn_modify, cancel_mail;
    @FXML
    private Label lblBCC;
    @FXML
    private Label from_name;
    @FXML
    private JFXButton Compose_to_btn;
    @FXML
    private Label to_mail;
    @FXML
    private JFXButton IntendeTo;
    @FXML
    private Label lblIntendeTo, lblRecivDate;
    @FXML
    private JFXButton btncc;
    @FXML
    private Label lblcc;
    @FXML
    private JFXButton btnintendedcc;
    @FXML
    private Label lblintendedcc;
    @FXML
    private JFXButton btnintendedBCC;
    @FXML
    private Label lblintendedBCC;
    @FXML
    private TextField txtSubject;
    @FXML
    private ComboBox txtSIC;
    @FXML
    private HTMLEditor msgBody;
    @FXML
    private Label lblattachfile;
    @FXML
    private ComboBox<String> Combobox_precednce;
    @FXML
    private JFXButton attch_file;
    @FXML
    private JFXButton btnMsgOptionType;
    @FXML
    private JFXButton btnSignedReceipt;
    @FXML
    private JFXCheckBox chkReadReceipt;
    @FXML
    private JFXCheckBox checkSignedReceipt;
    @FXML
    private JFXCheckBox chkEncryption;
    @FXML
    private JFXButton send_mail;
    @FXML
    private JFXButton save_mail;
    @FXML
    private ComboBox<String> Combobox_category;
    @FXML
    private TextField txtPrivacy;
    @FXML
    private ComboBox<String> Combobox_classification;
    @FXML
    private Tooltip m_tooltipIntendedTo;
    @FXML
    private Tooltip m_tooltipIntendedCC;
    @FXML
    private Tooltip m_tooltipIntendedBCC;
    @FXML
    private ComboBox<String> Combobox_policy;
    @FXML
    private GridPane m_attachLabel;
    int i = 0;
    int j = 0;
    MenuItem m_attachmentDownload = new MenuItem("DownLoad");
    MenuItem m_attachmentRemove = new MenuItem("Remove");
    @FXML
    private Label change_lable;
    private static final AudioClip ALERT_AUDIOCLIP1 = new AudioClip(Office_view_pageController.class.getResource("/sounds/sound1.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP2 = new AudioClip(Office_view_pageController.class.getResource("/sounds/sound2.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP4 = new AudioClip(Office_view_pageController.class.getResource("/sounds/sound4.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP5 = new AudioClip(Office_view_pageController.class.getResource("/sounds/sound5.wav").toString());
    public String attach_file;
    String groupMailIdTo = "";
    String GroupMailIdCc = "";
    String GroupMailIdBcc = "";
    MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
    AlarmProfilesDTO alarmProfilesDTO = msghndlr.getAlarmProfiles(sm_name);
    public String m_successAlarmFlag;
    public String m_errorAlarmFlag;
    public String m_infoAlarmFlag;
    public String m_warningFlag;

    /**
     * ******************************************************************
     * @Function Name :loadFile
     * @Description : Method to read file.
     * @Input Parameter : File.
     * @Output Parameter	: Return Byte.
     * @Author : Ravikiran Bhat.
     * @Created Date :5-MAY-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    private static byte[] loadFile(File file) throws IOException {
        InputStream is = new FileInputStream(file);

        long length = file.length();
        if (length > Integer.MAX_VALUE) {
            // File is too large
        }
        byte[] bytes = new byte[(int) length];

        int offset = 0;
        int numRead = 0;
        while (offset < bytes.length
                && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
            offset += numRead;
        }

        if (offset < bytes.length) {
            throw new IOException("Could not completely read file " + file.getName());
        }

        is.close();
        return bytes;
    }
    String fromOffice = "";
    String bccOfficeDU = "";
    String OriginalReceiver = "";
    String ccOffice = "";
    String bccOffice = "";
    String Read_Receipt = "";
    String sic = "";
    String precedence = "";
    String OriginalSender = "";
    String OriginalBcc = "";
    String receiverOfficeDesignatedUser = "";
    String encryption = "";
    String signed_receipt_receiptfrom = "";
    String ccOfficeDU = "";
    String security_category = "";
    String Approver = "";
    String To = "";
    String DSN = "";
    String ContentType = "";
    String DSNTo = "";
    String ReturnPath = "";
    String XOriginalTo = "";
    String security_policy = "";
    String OriginalCc = "";
    String DeliveredTo = "";
    String Received = "";
    String From = "";
    String MsgType = "";
    String messageType = "";
    String msgInstruction = "";
    String Reviewer = "";
    String Date = "";
    String Subject = "";
    String MIME_Version = "";
    String security_level = "";
    String signed_receipt = "";
    String mailMsgType = "";
    String RecDate="";
    String security_privacy_mark="";

    /**
     * ******************************************************************
     * @Function Name :initialization
     * @Description : Method to initialize when loading page.
     * @Input Parameter : NA.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :5-MAY-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    public void initialization() {
        ContextMenu menu = new ContextMenu();
        menu.getItems().addAll(m_attachmentDownload, m_attachmentRemove);

        MailDTO outputDTO;
        try {

            int c = Integer.parseInt(mail_id);

            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID(c);
            inputDTO.setFolder("inbox");

            outputDTO = msghndlr.readSpecificeMail(inputDTO);
            if (outputDTO.getHeaderMap().get("uid") != null) {
                System.out.println("UID: " + outputDTO.getHeaderMap().get("uid"));
            }
            System.out.println("Attachment: " + outputDTO.getAttachment());
            System.out.println("Bcc Recepient: " + outputDTO.getBccRecipient());
            System.out.println("Cc Recepient: " + outputDTO.getCcRecipient());
            System.out.println("Content: " + outputDTO.getContent());
            System.out.println("From: " + outputDTO.getFrom());
            System.out.println("Msg Type: " + outputDTO.getMsgType());
            System.out.println("Subject: " + outputDTO.getSubject());
            System.out.println("To Recepient: " + outputDTO.getToRecipient());
            System.out.println("====================================================");
            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
            if ((String) headers.get("fromOffice") != null) {
                fromOffice = (String) headers.get("fromOffice");
            }
            System.out.println(fromOffice);
            if ((String) headers.get("bccOfficeDU") != null) {
                bccOfficeDU = (String) headers.get("bccOfficeDU");
            }
            System.out.println(bccOfficeDU);

            String split[];
            if (headers.get("attachedFileName") != null) {
                attach_file = (String) headers.get("attachedFileName");
                String Split[] = attach_file.split(",");
                while (i < Split.length) {
                    for (j = 0; j < Split.length; j++) {
                        Label labl = new Label();

                        labl.setText(Split[j] + " ");
                        labl.setContextMenu(menu);
                        m_attachLabel.add(labl, i, 0);
                        labl.setOnMouseClicked((e) -> {                   // <-- I tried this way,

//       m_attachmentDownload.setOnAction(new EventHandler<ActionEvent>(){
//      public void handle(ActionEvent e) {
                            System.out.println("Attach FIle Name download:" + labl.getText());
                            // file_download(labl.getText());
                            //            
//      }
//    });  
//
//           
                        });
                        i++;
                        labl.setOnMouseEntered(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent e) {
                                labl.setStyle("-fx-font-weight:BOLD;-fx-text-fill:#090E00;-fx-background-color:#EEF6FF;-fx-font-size:13");

                            }
                        });

                        labl.setOnMouseExited(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent e) {
                                labl.setStyle("-fx-background-color:#F4F4F4;");

                            }
                        });

                    }
                }

            }
//            System.out.println("replyRequested"+replyRequested);

            if ((String) headers.get("sic") != null) {
                sic = (String) headers.get("sic");
            }
            if ((String) headers.get("precedence") != null) {
                precedence = (String) headers.get("precedence");
            }
            if ((String) headers.get("originalSender") != null) {
                OriginalSender = (String) headers.get("originalSender");
            }
            if ((String) headers.get("originalBcc") != null) {
                OriginalBcc = (String) headers.get("originalBcc");
            }
            if ((String) headers.get("receiverOfficeDesignatedUser") != null) {
                receiverOfficeDesignatedUser = (String) headers.get("receiverOfficeDesignatedUser");
            }
            if ((String) headers.get("encryption") != null) {
                encryption = (String) headers.get("encryption");
            }
            if ((String) headers.get("signed_receipt_receiptfrom") != null) {
                signed_receipt_receiptfrom = (String) headers.get("signed_receipt_receiptfrom");
            }
            if ((String) headers.get("ccOfficeDU") != null) {
                ccOfficeDU = (String) headers.get("ccOfficeDU");
            }
            if ((String) headers.get("security_category") != null) {
                security_category = (String) headers.get("security_category");
            }
            if ((String) headers.get("Approver") != null) {
                Approver = (String) headers.get("Approver");
            }
            if ((String) headers.get("toOffice") != null) {
                To = (String) headers.get("toOffice");
            }
            if ((String) headers.get("DSN") != null) {
                DSN = (String) headers.get("DSN");
            }
            if ((String) headers.get("Content-Type") != null) {
                ContentType = (String) headers.get("Content-Type");
            }
            if ((String) headers.get("DSNTo") != null) {
                DSNTo = (String) headers.get("DSNTo");
            }
            if ((String) headers.get("Return-Path") != null) {
                ReturnPath = (String) headers.get("Return-Path");
            }
            if ((String) headers.get("X-Original-To") != null) {
                XOriginalTo = (String) headers.get("X-Original-To");
            }
            if ((String) headers.get("originalReceiver") != null) {
                OriginalReceiver = (String) headers.get("originalReceiver");
            }
            System.out.println("Intended User" + OriginalReceiver);
            if ((String) headers.get("security_policy") != null) {
                security_policy = (String) headers.get("security_policy");
            }
            if ((String) headers.get("Received") != null) {
                Received = (String) headers.get("Received");
            }
            if ((String) headers.get("From") != null) {
                From = (String) headers.get("From");
            }
            if ((String) headers.get("MsgType") != null) {
                MsgType = (String) headers.get("MsgType");
            }
            if ((String) headers.get("messageType") != null) {
                messageType = (String) headers.get("messageType");
            }
            if ((String) headers.get("messageInstructions") != null) {
                msgInstruction = (String) headers.get("messageInstructions");
            }
            if ((String) headers.get("Reviewer") != null) {
                Reviewer = (String) headers.get("Reviewer");
            }
            if ((String) headers.get("Date") != null) {
                Date = (String) headers.get("Date");
            }
            if ((String) headers.get("Subject") != null) {
                Subject = (String) headers.get("Subject");
            }
            if ((String) headers.get("MIME-Version") != null) {
                MIME_Version = (String) headers.get("MIME-Version");
            }
            if ((String) headers.get("security_level") != null) {
                security_level = (String) headers.get("security_level");
            }
            if ((String) headers.get("signed_receipt") != null) {
                signed_receipt = (String) headers.get("signed_receipt");
            }
            if ((String) headers.get("mailMsgType") != null) {
                mailMsgType = (String) headers.get("mailMsgType");
            }
            if ((String) headers.get("read_receipt") != null) {
                Read_Receipt = (String) headers.get("read_receipt");
            }
            if((String) headers.get("security_privacy_mark")!=null){
            security_privacy_mark = (String) headers.get("security_privacy_mark");
            }
            if ((String) headers.get("originalCc") != null) {
                OriginalCc = (String) headers.get("originalCc");
            }
            if ((String) headers.get("Delivered-To") != null) {
                DeliveredTo = (String) headers.get("Delivered-To");
            }
//            String signed_receipt_receiptto = (String) headers.get("signed_receipt_receiptto");
            if ((String) headers.get("groupMailIdTo") != null) {
                groupMailIdTo = (String) headers.get("groupMailIdTo");
            }
            if ((String) headers.get("groupMailIdCc") != null) {
                GroupMailIdCc = (String) headers.get("groupMailIdCc");
            }
            if ((String) headers.get("groupMailIdBcc") != null) {
                GroupMailIdBcc = (String) headers.get("groupMailIdBcc");
            }
            if ((String) headers.get("ccOffice") != null) {
                ccOffice = (String) headers.get("ccOffice");
            }
            if ((String) headers.get("bccOffice") != null) {
                bccOffice = (String) headers.get("bccOffice");
            }
            if ((String) headers.get("Date") != null) {
                RecDate = (String) headers.get("Date");
            }
            ObservableList<String> Policy_value = FXCollections.observableArrayList(security_policy);
            ObservableList<String> Category_value = FXCollections.observableArrayList(security_level);
            ObservableList<String> combobox_category = FXCollections.observableArrayList(security_category);
            ObservableList<String> combobox_precednc = FXCollections.observableArrayList(precedence);
            from_name.setText(outputDTO.getFrom());
            to_mail.setText(To);
            lblcc.setText(ccOffice);
            lblBCC.setText(bccOffice);

//            System.out.println("REVIEWER OROGINAL Reciver" + OriginalReceiver);
            lblIntendeTo.setText(OriginalReceiver + " " + groupMailIdTo);
            lblintendedcc.setText(OriginalCc + " " + GroupMailIdCc);
            lblintendedBCC.setText(OriginalBcc + " " + GroupMailIdBcc);
            if (groupMailIdTo.length() != 0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(groupMailIdTo);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedTo.setText(str.toString());
            }
            if (GroupMailIdCc.length() != 0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(GroupMailIdCc);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedCC.setText(str.toString());
            }
            if (GroupMailIdBcc.length() != 0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(GroupMailIdBcc);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedBCC.setText(str.toString());
            }
//            txtSubject.setText(outputDTO.getSubject());
            msgBody.setHtmlText(outputDTO.getContent());

            msgBody.setAccessibleText(outputDTO.getContent());
            txtSubject.setText(Subject);

            Combobox_classification.setPromptText(security_level);

            txtPrivacy.setText(security_privacy_mark);

            Combobox_precednce.setPromptText(precedence);
            Combobox_category.setPromptText(security_category);
            Combobox_policy.setPromptText(security_policy);
            lblRecivDate.setText(RecDate);
            txtMsgInstruction.setText(msgInstruction);
            combBoxMsgType.setPromptText(messageType);
            if (Read_Receipt.equalsIgnoreCase("true")) {
                chkReadReceipt.setSelected(true);
            }
            if (security_level.equalsIgnoreCase("TopSecret")) {
                change_lable.setText("TOP-SECRET");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: red;");
            } else if (security_level.equalsIgnoreCase("Secret")) {
                change_lable.setText("SECRET");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: orange;");
            } else if (security_level.equalsIgnoreCase("Confidential")) {
                System.out.println("Entered the confidential..........");
                change_lable.setText("CONFIDENTIAL");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: blue;");
            } else if (security_level.equalsIgnoreCase("Restricted")) {
                change_lable.setText("RESTRICTED");
                change_lable.setTextFill(Color.web("Black"));
                change_lable.setStyle("-fx-background-color: yellow;");
            } else if (security_level.equalsIgnoreCase("Unclassified")) {
                change_lable.setText("UNCLASSIFIED");
                change_lable.setTextFill(Color.web("black"));
                change_lable.setStyle("-fx-background-color: white;");
            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception is :" + e);
        }

        Node node = msgBody.lookup(".top-toolbar");
        if (node instanceof ToolBar) {
            ToolBar bar = (ToolBar) node;
            Button smurfButton = new Button("Insert Table");
            Label row = new Label();
            row.setText("Row:");
            TextField rowField = new TextField("0");
            rowField.setPrefWidth(30);
            Label column = new Label();
            column.setText("Column:");
            TextField columnField = new TextField("0");
            columnField.setPrefWidth(30);
            Button insertImage = new Button("Insert Image");
            bar.getItems().addAll(smurfButton, row, rowField, column, columnField, insertImage);
            smurfButton.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent arg0) {
                    StringBuilder tableContent = new StringBuilder();
                    tableContent.append("<table style='border-collapse:collapse; border: 1px solid black;'>");
                    for (int i = 0; i < Integer.parseInt(rowField.getText()); i++) {
                        tableContent.append("<tr >");
                        for (int j = 0; j < Integer.parseInt(columnField.getText()); j++) {
                            tableContent.append("<td width='100px' height='30px' style='border-collapse:collapse; border: 1px solid black;'>").append("</td>");
                        }
                        tableContent.append("</tr >");
                    }
                    tableContent.append("</table ><br>");
                    msgBody.setHtmlText(msgBody.getHtmlText() + tableContent);
                }
            });
            insertImage.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent arg0) {
                    FileChooser fileChooser = new FileChooser();
                    fileChooser.setTitle("Select Image");
                    FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("All images", new String[]{"*.JPEG", "*.PNG", "*.png", "*.jpg", "*.JPG", "*.gif"});
                    fileChooser.getExtensionFilters().add(extFilter);
                    File file = fileChooser.showOpenDialog(new Stage());
                    try {
                        byte[] bytes = loadFile(file);
                        byte[] encoded = Base64.getEncoder().encode(bytes);
                        String encodedString = new String(encoded);
                        System.out.println("encodedString" + encodedString);
                        msgBody.setHtmlText(
                                msgBody.getHtmlText()
                                + "<img src='data:image/png;base64," + encodedString + "'>");
                    } catch (IOException ex) {
                        Logger.getLogger(ComposePageContrller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
        }

    }

    /**
     * ******************************************************************
     * @Function Name :initialize
     * @Description : Method to call initialization function.
     * @Input Parameter : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :5-MAY-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        txtMsgInstruction.setEditable(false);
        msgBody.setDisable(true);
        initialization();
    }

    @FXML
    private void onClickbtnBCC(ActionEvent event) {
    }

    @FXML
    private void compose_to(ActionEvent event) {
    }

    @FXML
    private void openIntendeTo(ActionEvent event) {
    }

    @FXML
    private void clickBtnCC(ActionEvent event) {
    }

    @FXML
    private void onClickIntendedCC(ActionEvent event) {
    }

    @FXML
    private void clickbtnintendedBCC(ActionEvent event) {
    }

    @FXML
    private void onPrecedenceSelectaction(ActionEvent event) {
    }

    @FXML
    private void attach_action_btn(ActionEvent event) {
    }

    @FXML
    private void selectbtnSignedReceipt(ActionEvent event) {
    }

    @FXML
    private void on_selection_classification(ActionEvent event) {
    }

    /**
     * ******************************************************************
     * @Function Name :on_click_cancel
     * @Description : Method to close mail window.
     * @Input Parameter : ActionEvent-provided by JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :5-MAY-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    private void on_click_cancel(ActionEvent event) {
        read_officeemail.close();

    }

    /**
     * ******************************************************************
     * @Function Name :clickBtnSendMail
     * @Description : Method to send message to next node.
     * @Input Parameter : ActionEvent -provided by -JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :5-MAY-2017.
     * @Modification History :12-MAY-2017.
     * ******************************************************************
     */
    @FXML
    private void clickBtnSendMail(ActionEvent event) {

        System.out.println("SEND mail");
        Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
        alert1.setTitle("Confirmation-Forward Mail");
        alert1.setHeaderText(null);
        alert1.setContentText("Are you sure to Forward the Mail");
        //  alert.setContentText("Are you sure want to LOg Out!");
        Optional<ButtonType> result = alert1.showAndWait();
        if (result.get() == ButtonType.OK) {
            MailDTO outputDTO;
            try {
                Long c = Long.parseLong(mail_id);

                ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
                inputDTO.setMsgUID(c.intValue());
                inputDTO.setFolder("inbox");

                outputDTO = msghndlr.readSpecificeMail(inputDTO);
                HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();

                HashMap<Object, Object> headersStore = (HashMap<Object, Object>) outputDTO.getHeaderMap();
                String msgType1 = (String) headersStore.get("msgType");
                String ccoficeDU = (String) headersStore.get("ccOfficeDU");
                System.out.println("ccOFFICE DU:" + ccoficeDU);
                String bccoficeDU = (String) headersStore.get("bccOfficeDU");
                System.out.println("BccOFFICE DU:" + bccoficeDU);

                boolean loop = false;
                String loopStr = null;

                if (headersStore.get("loop") != null) {
                    loopStr = headersStore.get("loop").toString();
                    if (loopStr.equalsIgnoreCase("FALSE")) {
                        loop = false;
                    } else if (loopStr.equalsIgnoreCase("TRUE")) {
                        loop = true;
                    }
                }
                headersStore.put("loop", loop);

                System.out.println("loop: " + headersStore.get("loop"));

                outputDTO.setHeaderMap(headersStore);
                System.out.println("LOGIN " + sm_name);
                outputDTO.setFrom(msghndlr.preCheck(sm_name).getMailId());
                String sendVal = "false";
                if (msgType1.equalsIgnoreCase("SENDTODESIGNATEDUSER")) {
                    if (headersStore.get("Received") != null) {
                        headersStore.remove("Received");
                    }
                    if (headersStore.get("From") != null) {
                        headersStore.remove("From");
                    }

                    if (headersStore.get("To") != null) {
                        headersStore.remove("To");
                    }

                    if (headersStore.get("Content-Type") != null) {
                        headersStore.remove("Content-Type");
                    }

                    if (headersStore.get("DSN") != null) {
                        headersStore.remove("DSN");
                    }
                    if (headersStore.get("DSNTo") != null) {
                        headersStore.remove("DSNTo");
                    }
                    if (headersStore.get("X-Original-To") != null) {
                        headersStore.remove("X-Original-To");
                    }

                    if (headersStore.get("sentDT") != null) {
                        headersStore.remove("sentDT");
                    }

                    if (headersStore.get("Message-ID") != null) {
                        headersStore.remove("Message-ID");
                    }
                    if (headersStore.get("MIME-Version") != null) {
                        headersStore.remove("MIME-Version");
                    }
                    if (headersStore.get("attachedFileName") != null) {
                        headersStore.remove("attachedFileName");
                    }
                    if (headersStore.get("Return-Path") != null) {
                        headersStore.remove("Return-Path");
                    }
                    if (headersStore.get("Date") != null) {
                        headersStore.remove("Date");
                    }
                    if (headersStore.get("Delivered-To") != null) {
                        headersStore.remove("Delivered-To");
                    }
                    if (headersStore.get("toRecipient") != null) {
                        headersStore.remove("toRecipient");
                    }
                    if (headersStore.get("Content-Transfer-Encoding") != null) {
                        headersStore.remove("Content-Transfer-Encoding");
                    }
//                           if(headersStore.get("attachedFileName")!=null)
//                         {
                    headersStore.put("fileToForward", attach_file);
                    //   }

                    System.out.println("to send to antther office from DU");

                    headersStore.put("msgType", "FORWARDTOANOTHEROFFICE");
                    outputDTO.setHeaderMap(headersStore);
                    System.out.println("msg FORWARDTOANOTHEROFFICE " + headersStore.get("msgType"));

                } else if (msgType1.equalsIgnoreCase("FORWARDTOANOTHEROFFICE")) {
                    if (headersStore.get("Received") != null) {
                        headersStore.remove("Received");
                    }
                    if (headersStore.get("From") != null) {
                        headersStore.remove("From");
                    }

                    if (headersStore.get("To") != null) {
                        headersStore.remove("To");
                    }

                    if (headersStore.get("Content-Type") != null) {
                        headersStore.remove("Content-Type");
                    }

                    if (headersStore.get("DSN") != null) {
                        headersStore.remove("DSN");
                    }
                    if (headersStore.get("DSNTo") != null) {
                        headersStore.remove("DSNTo");
                    }
                    if (headersStore.get("X-Original-To") != null) {
                        headersStore.remove("X-Original-To");
                    }
                    if (headersStore.get("attachedFileName") != null) {
                        headersStore.remove("attachedFileName");
                    }
                    if (headersStore.get("sentDT") != null) {
                        headersStore.remove("sentDT");
                    }

                    if (headersStore.get("Message-ID") != null) {
                        headersStore.remove("Message-ID");
                    }
                    if (headersStore.get("MIME-Version") != null) {
                        headersStore.remove("MIME-Version");
                    }
                    if (headersStore.get("Content-Transfer-Encoding") != null) {
                        headersStore.remove("Content-Transfer-Encoding");
                    }
//                         if(headersStore.get("attachedFileName")!=null)
//                         {
                    headersStore.put("fileToForward", attach_file);
                    // }
                    System.out.println("to send to same office from DU");

                    headersStore.put("msgType", "FORWARDTOSAMEOFFICE");

                    outputDTO.setHeaderMap(headersStore);

                    System.out.println("msg FORWARDTOANOTHEROFFICE " + headersStore.get("msgType"));
                }

                try {
                    if (securityStatusFlag) {
                        System.out.println("before send mail");

                        System.out.println("Set Header value:" + outputDTO.getHeaderMap().get("msgType"));
                        //System.out.println("OutputDto:"+outputDTO.toString());
                        Stage stageSecurity = new Stage();
                        Parent rootSecurity;
                        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/Security.fxml"));
                        rootSecurity = (Parent) fXMLLoader.load();
                        SecurityController securityController = fXMLLoader.getController();
                        stageSecurity.setScene(new Scene(rootSecurity));
                        stageSecurity.setTitle("Security");
                        stageSecurity.initModality(Modality.APPLICATION_MODAL);
//                stageTo.initOwner(OK.getScene().getWindow());
                        stageSecurity.toFront();
                        stageSecurity.getIcons().add(new Image("/img/Mail-icon.png"));
                        stageSecurity.showAndWait();
                        stageSecurity.setResizable(false);
                        if (securityController.sendSecurityFlag) {
                            sendVal = msghndlr.sendMailWthAtchmnt(outputDTO, null, securityStatusFlag);
                        }
                    } else {
                        sendVal = msghndlr.sendMailWthAtchmnt(outputDTO, null, securityStatusFlag);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    System.err.println("review send mail exception is" + e);
                }

                if (sendVal.equalsIgnoreCase("true")) {
                    if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                        m_infoAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                        if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                            Office_view_pageController.ALERT_AUDIOCLIP1.play();
                        }
                    }

                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Information-Forward Mail");
                    alert.setHeaderText(null);
                    alert.setContentText("Mail Forwarded SuccessFully");
                    alert.showAndWait();

                    final Node Source = (Node) event.getSource();
                    final Stage stage = (Stage) Source.getScene().getWindow();
                    stage.close();
                    ArrayList<Long> list = new ArrayList<Long>();
                    list.add(c);
                    DeleteInput dto = new DeleteInput();
                    dto.setFolder("inbox");
                    dto.setMsgUID(list);
                    String status = msghndlr.deleteMail(dto);
                    System.out.println(status);
                } else if (sendVal.equalsIgnoreCase("false")) {
                    if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                        m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                        if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                            Office_view_pageController.ALERT_AUDIOCLIP5.play();
                        }
                    }

                    Platform.runLater(() -> {
                        Notifications.create().text("Forward Mail-" + "\nFailed To Forward Mail").showError();
                    });
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Error-Forward Mail");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to Forward Mail..");
                    alert.showAndWait();

                } else if (sendVal.equalsIgnoreCase("StoredInOutBox")) {
                    if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                        m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                        if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                            Office_view_pageController.ALERT_AUDIOCLIP5.play();
                        }
                    }
                    Platform.runLater(() -> {
                        Notifications.create().text("Send Mail-" + "\nFailed To Forward Mail").showError();
                    });
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Error-Forward Mail");
                    alert.setHeaderText(null);
                    alert.setContentText("Stored In OutBox");
                    alert.showAndWait();

                } else if (sendVal.equalsIgnoreCase("No Sic List Found")) {
                    if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                        m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                        if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                            Office_view_pageController.ALERT_AUDIOCLIP5.play();
                        }
                    }
                    Platform.runLater(() -> {
                        Notifications.create().text("Send Mail-" + "\nFailed To Forward Mail").showError();
                    });
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Error-Forward Mail");
                    alert.setHeaderText(null);
                    alert.setContentText("No Sic List Found");
                    alert.showAndWait();

                } else if (sendVal.equalsIgnoreCase("No Profile found")) {
                    if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                        m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                        if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                            Office_view_pageController.ALERT_AUDIOCLIP5.play();
                        }
                    }
                    Platform.runLater(() -> {
                        Notifications.create().text("Send Mail-" + "\nFailed To Forward Mail").showError();
                    });
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Error-Forward Mail");
                    alert.setHeaderText(null);
                    alert.setContentText("No Profile found");
                    alert.showAndWait();

                }

            } catch (Exception e) {
                System.out.println(e.getStackTrace());
                e.printStackTrace();
                System.out.println("No email to display..!!");
            }
            read_officeemail.close();
        }

    }

    @FXML
    private void on_click_attach(MouseEvent event) {
        System.out.println("Attache file Clicked");

    }
}
