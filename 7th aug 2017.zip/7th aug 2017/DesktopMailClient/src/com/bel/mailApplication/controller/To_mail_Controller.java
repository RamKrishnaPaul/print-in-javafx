/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.controller;

import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.cell.CheckBoxListCell;

import javafx.stage.Stage;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.CheckListView;
/**
 * ******************************************************************
 * @File Name           : To_mail_Controller.
 * @Author              : Ram Krishna Paul.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display window  for  To office.
 * @Created Date	:8-APR-2017
 * @Modification History:NA. 
*******************************************************************
 */
public class To_mail_Controller implements Initializable {
    @FXML
    private Button add_to_btn;
    @FXML
    public CheckListView add_list;
    @FXML
    private ObservableList<String> data;
    public List<String> selectedToOffice;
    @FXML
    public static String officename = null;
  MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
                 /**
     * ******************************************************************
     * @Function Name           :initialize
     * @Description             : Method to call initialization function.
     * @Input Parameter         : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
      * @Author                 : Ram Krishna Paul.
     * @Created Date            :8-APR-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        add_list.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        officename = msghndlr.ldapUserOffice(sm_name);
        data = FXCollections.observableArrayList();

        msghndlr.getAllRemoteOfficeNames(officename).toString();

        for (String office : msghndlr.getAllRemoteOfficeNames(officename)) {

            data.addAll(office);
            add_list.setItems(data);

            add_list.getCheckModel().getCheckedItems().addListener(new ListChangeListener<String>() {
                @Override
                public void onChanged(ListChangeListener.Change<? extends String> c) {

                    selectedToOffice = add_list.getCheckModel().getCheckedItems();

                }
            });

        }

    }
 /**
     * ******************************************************************
     * @Function Name           :chooseItemforAdd
     * @Description             : Method to add CC office to list.
     * @Input Parameter         : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ram Krishna Paul.
     * @Created Date            :8-APR-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @FXML
    public void chooseItemforAdd(ActionEvent event) throws Exception {
        String officeselected;
         List<String> data = add_list.getSelectionModel().getSelectedItems();
        for (String d : data) {
            System.out.println("selected office is" + d);
            officename = d;
        }
         final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();

    }
}
