package com.bel.mailApplication.controller;

import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.SelectionMode;
import javafx.stage.Stage;
import org.controlsfx.control.CheckListView;

/**
 * ******************************************************************
 * @File Name           : ReceiptFromController.
 * @Author              : Ram Krishna Paul.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display window  for  ReceiptFrom.
 * @Created Date	:18-MAY-2017
 * @Modification History:NA. 
*******************************************************************
 */
public class ReceiptFromController implements Initializable {

    @FXML
    private JFXButton btnAddReceiptFrom;
     @FXML
    private ObservableList<String> data;
    @FXML
    public CheckListView<String> listReceiptFrom;
                 /**
     * ******************************************************************
     * @Function Name           :initialize
     * @Description             : Method to call initialization function.
     * @Input Parameter         : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
      * @Author                 : Ram Krishna Paul.
     * @Created Date            :18-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        listReceiptFrom.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        data = FXCollections.observableArrayList();
        List<String> li = new ArrayList<String>();
        li = ComposePageContrller.dataListIntendedTO();
        System.out.println("lists are" + li);
        for (String datareceiptfrom : li) {
            data.addAll(datareceiptfrom);
        }
        listReceiptFrom.setItems(data);
    }
 /**
     * ******************************************************************
     * @Function Name           :clickbtnAddReceiptFrom
     * @Description             : Method to add ReceiptFrom to list.
     * @Input Parameter         : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ram Krishna Paul.
     * @Created Date            :18-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @FXML
    private void clickbtnAddReceiptFrom(ActionEvent event) {
        List<String> data = listReceiptFrom.getSelectionModel().getSelectedItems();
        for (String dataListReciptFrom : data) {
        }
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();

    }

}
