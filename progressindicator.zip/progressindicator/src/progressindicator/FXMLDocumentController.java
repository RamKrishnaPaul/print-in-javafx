/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progressindicator;

import static java.awt.Color.blue;
import static java.awt.Color.green;
import static java.awt.Color.red;
import static java.lang.ProcessBuilder.Redirect.from;
import static java.lang.ProcessBuilder.Redirect.to;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.HBox;
import javafx.scene.paint.LinearGradient;
import static jdk.nashorn.internal.objects.NativeJava.to;

/**
 *
 * @author Ram Krishna Paul
 */
public class FXMLDocumentController implements Initializable {

   @FXML
    private HBox hBox;
    
    @FXML Label greenLbl;
    
    @FXML Label yellowLbl;
    
    @FXML Label redLbl;
    
    @FXML Label percentage;
    

    double dbl = 1;
    double newval = 0.4;
    int widthOfHbox=200;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
     yellowLbl.setStyle("-fx-background-color: yellow;");
        greenLbl.setStyle("-fx-background-color: green;");
     redLbl.setStyle("-fx-background-color: red;");
     greenLbl.setPrefWidth(0);
     yellowLbl.setPrefWidth(0);
     redLbl.setPrefWidth(0);
     hBox.setPrefWidth(200);
     hBox.setStyle("-fx-border-color:red;");
     percentage.setText(String.valueOf(newval*100)+"%");
     
        if (newval <= 0.6) {
            greenLbl.setPrefWidth(widthOfHbox*newval);
        } else if (newval>0.6 && newval<=0.8) {
            greenLbl.setPrefWidth(widthOfHbox*0.6);
            yellowLbl.setPrefWidth((newval-0.6)*widthOfHbox);
        } else if (newval > 0.8 && newval<=1) {
         greenLbl.setPrefWidth(widthOfHbox*0.6);
         yellowLbl.setPrefWidth(widthOfHbox*0.2);
         redLbl.setPrefWidth((newval-0.8)*widthOfHbox);
        }
    }

}
