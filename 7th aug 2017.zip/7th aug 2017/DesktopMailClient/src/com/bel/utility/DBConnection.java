/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.AuthenticationNotSupportedException;
import javax.naming.Context;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

/**
 *
 * @author Ram Krishna Paul
 */
public class DBConnection {
    
public Connection Connect() throws SQLException{
    try {
        
        //172.195.121.42
        String url = "jdbc:mysql://localhost:3306/newaddrbook";
        String username="root";
        String password="root";
        Class.forName("com.mysql.jdbc.Driver");
        Connection conn = DriverManager.getConnection(url, username , password);
        System.out.println("connection estab");
        return conn;
    } catch (ClassNotFoundException ex) {
        Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, null, ex);
    }
        

 return null;
}
//public static void main(String args[])
//{}
}
   
//    public DBConnection connect()
//            
//    {        {
//            try {
//                String url = "jdbc:mysql://172.195.121.218:3306/awan_address_book_mst";
//                String user="root";
//                String password ="root";
//                Class.forName("com.mysql.jdbc.Driver");
//                connect conn = DriverManager.getConnection(url,user,password);
//                return conn;
//            } catch (ClassNotFoundException ex) {
//                Logger.getLogger(DBConnection.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        
//    
//    } 
//    return null;
//    }