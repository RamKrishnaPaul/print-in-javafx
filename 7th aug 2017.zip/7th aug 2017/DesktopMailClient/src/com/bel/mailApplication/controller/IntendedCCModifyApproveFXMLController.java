package com.bel.mailApplication.controller;

import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import static com.bel.mailApplication.controller.Approve_view_pageController.classificationvaleforIntendedTo;
import static com.bel.mailApplication.controller.Approve_view_pageController.precedencevaleforIntendedTo;
import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.SelectionMode;
import javafx.stage.Stage;
import mail.awan.beans.CheckClearenceDTO;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.CheckListView;
/**
 * ******************************************************************
 * @File Name           : BCCController.
 * @Author              : Ram Krishna Paul.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display window  for  IntendedCCModifyApprove List.
 * @Created Date	:8-MAY-2017
 * @Modification History:NA. 
*******************************************************************
 */
public class IntendedCCModifyApproveFXMLController implements Initializable {
    @FXML
    private Button AddIntendedCC;
     @FXML
    private ObservableList<String> data;
    @FXML
    public CheckListView<String> ListIntendedCC;
    public List<String>selectedIntendedccOffice;
  MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
                /**
     * ******************************************************************
     * @Function Name           :initialize
     * @Description             : Method to call initialization function.
     * @Input Parameter         : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
      * @Author                 : Ram Krishna Paul.
     * @Created Date            :8-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ListIntendedCC.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        data = FXCollections.observableArrayList();
        String officename = msghndlr.ldapUserOffice(sm_name);
        List<String> li = new ArrayList<String>();
        li = Approve_view_pageController.dataccList();
//        System.out.println("list is " + li);
        String[] obj = li.toArray(new String[0]);
//        System.out.println("list of object is" + obj);
//        String maxAtchSize = msghndlr.getMaxAttachmentSizeOfTcsUser(name, officename);
        CheckClearenceDTO dto = new CheckClearenceDTO();
        dto.setOffice(obj);
        dto.setMaxSecurityClassificationView(classificationvaleforIntendedTo);
        dto.setAttachmentSize(0);
        dto.setMaxMessagePrecedence(precedencevaleforIntendedTo);
        List<String> list = msghndlr.checkClearence(dto);
        System.out.println("In FX Object: " + list);
        for (String OfficeUserNames : list) {
//            System.out.println("Clearance Check data: " + OfficeUserNames);
            data.addAll(OfficeUserNames);
            ListIntendedCC.setItems(data);
              ListIntendedCC.getCheckModel().getCheckedItems().addListener(new ListChangeListener<String>() {
                @Override
                public void onChanged(ListChangeListener.Change<? extends String> c) {
                    selectedIntendedccOffice = ListIntendedCC.getCheckModel().getCheckedItems();
                   
                }
            });
        }
    }
  /**
     * ******************************************************************
     * @Function Name           :SelectAddIntendedCC
     * @Description             : Method to add IntendedCC to list.
     * @Input Parameter         : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ram Krishna Paul.
     * @Created Date            :8-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @FXML
    private void selectAddIntendedCC(ActionEvent event) {
        List<String> dataemailIntendedCC = ListIntendedCC.getSelectionModel().getSelectedItems();
        for (String emailIntendedCC : dataemailIntendedCC) {
        }
      
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
    }
    
}
