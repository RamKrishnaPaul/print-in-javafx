/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.controller;


import static com.bel.mailApplication.controller.FXMLDocumentController.mail_id;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import com.entity.MailDTO;
import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import mail.awan.beans.ReceiveMailInputDTO;
import mail.awan.messageHandler.MessageHandler;

/**
 * FXML Controller class
 *
 * @author Root
 */
public class RejectMailTrashController implements Initializable {

    @FXML
    private Label from_name;
    @FXML
    private Label to_mail;
    @FXML
    private JFXButton cancel_btn_notification;
    @FXML
    private JFXButton ok_btn_notification;
    @FXML
    private Label m_to;
    @FXML
    private Label m_dateTime;
    @FXML
    private TextArea m_msgBody;
    @FXML
 
    private String Read_Receipt;
    private String From;
    private String m_from;
    private String Subject;
    private String Content;
    private String m_date;
    MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         MailDTO outputDTO;
        try {
            int c = Integer.parseInt(mail_id);

            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID(c);
            inputDTO.setFolder("trash");

            outputDTO = msghndlr.readSpecificeMail(inputDTO);
            System.out.println("UID: " + outputDTO.getMailUID());
            System.out.println("Attachment: " + outputDTO.getAttachment());
            System.out.println("Bcc Recepient: " + outputDTO.getBccRecipient());
            System.out.println("Cc Recepient: " + outputDTO.getCcRecipient());
            System.out.println("Content: " + outputDTO.getContent());
            System.out.println("From: " + outputDTO.getFrom());
            System.out.println("Msg Type: " + outputDTO.getMsgType());
            System.out.println("Subject: " + outputDTO.getSubject());
            System.out.println("To Recepient: " + outputDTO.getToRecipient());
            System.out.println("====================================================");
            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
            Content = outputDTO.getContent();
            m_from=outputDTO.getToRecipient().trim();
          
            From = outputDTO.getFrom();
            String MsgType = (String) headers.get("msgType");
            Subject = (String) headers.get("Subject");
            Read_Receipt = (String) headers.get("read_receipt");
            m_date = (String) headers.get("Date");

        } catch (Exception e) {
            System.out.println("View mmail working");
        }
        to_mail.setText(Subject);
        from_name.setText(m_from);
        m_dateTime.setText(m_date);
        m_to.setText(From);
        m_msgBody.setText("Mail Rejection Reason : "+Content);
    }    
    
}
