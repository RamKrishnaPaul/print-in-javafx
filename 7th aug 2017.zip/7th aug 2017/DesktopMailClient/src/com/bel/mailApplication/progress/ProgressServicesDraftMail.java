package com.bel.mailApplication.progress;

import com.bel.mailApplication.model.DraftTabList;
import javafx.collections.ObservableList;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
/**
 * @File Name : ProgressServicesDraftMail
 * @author : Ram Krishna Paul
 * @Description: For creating task of Draft mail
 * @Package : com.bel.mailApplication.progress
 * @Created : 17th june 2017
 * @Modification History: NA
 */
public class ProgressServicesDraftMail extends Service<ObservableList<DraftTabList>> {

    @Override
    protected Task createTask() {
        return new GetProgrssTaskDraftMail();
    }
}
