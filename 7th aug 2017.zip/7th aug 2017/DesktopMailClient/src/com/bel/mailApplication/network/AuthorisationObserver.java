package Test;

import java.util.Observable;
import java.util.Observer;

import mail.awan.util.AuthorisationCheck;

public class AuthorisationObserver implements Observer {

    private static AuthorisationObserver authorisationObserver;

    private AuthorisationObserver(Observable subject) {
        super();
         this.subject = subject;
        subject.addObserver(this);
    }

    public static AuthorisationObserver getAuthorisationObserverInstance(Observable subject) {
        if (authorisationObserver == null) {
            authorisationObserver = new AuthorisationObserver(subject);
        }
        return authorisationObserver;
    }
    // Fields
    private String authorisationChangeIndicator;
    @SuppressWarnings("unused")
    private Observable subject;

    public String getAuthorisationChangeIndicator() {
        return authorisationChangeIndicator;
    }

    public void setAuthorisationChangeIndicator(String networkChangeIndicator) {
        this.authorisationChangeIndicator = networkChangeIndicator;
    }

    //Methods
    public void update(Observable subject, Object arg) {
        if (subject instanceof AuthorisationCheck) {
            AuthorisationCheck subj = (AuthorisationCheck) subject;
            authorisationChangeIndicator = subj.getAuthorisationChangeIndicator();
            System.out.printf("Hello i'm Vimal observer Authorisation status changed to:" + authorisationChangeIndicator);
             
        }
    }
}
