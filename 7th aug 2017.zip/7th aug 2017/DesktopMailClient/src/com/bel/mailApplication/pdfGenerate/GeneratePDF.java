 package com.bel.mailApplication.pdfGenerate;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BarcodeQRCode;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.File;

/**
 * @File Name : GeneratePDF
 * @author : Ram Krishna Paul
 * @Description: For Generating of PDF and print Mail
 * @Package : com.bel.mailApplication.controller
 * @Created : 20th May 2017
 * @Modification History:NA
 */
public class GeneratePDF {

    private static Font TIME_ROMAN_1
            = new Font(Font.FontFamily.TIMES_ROMAN, 14);
    private static Font TIME_ROMAN
            = new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD);
    private static Font TIME_ROMAN_NEW
            = new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.UNDERLINE);
    private static Font TIME_ROMAN_SMALL
            = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);
 /**
     * ******************************************************************
     * @Function Name : createPDF
     * @Description : For Create PDF
     * @Input Parameter :String waterMark, String from, String To, String Intendedto, String CC, String IntendedCC, String BCC, String IntendedBCC, String Subject, String SIC, String Attachment, String precedence, String SceurityClassification, String MailBody, String Time, String SceurityCategory, String SceurityPolicy, String SceurityMark, String pdfpath
     * @Output Parameter	: document
     * @Author : Ram Krishna Paul
     * @Created Date : 20th May 2017
     * @Modification History:NA
     * ******************************************************************
     */
    public static Document createPDF(String waterMark, String from, String To, String Intendedto, String CC, String IntendedCC, String BCC, String IntendedBCC, String Subject, String SIC, String Attachment, String precedence, String SceurityClassification, String MailBody, String Time, String SceurityCategory, String SceurityPolicy, String SceurityMark, String pdfpath) {

        Document document = null;
        File f = null;
        boolean bool = false;

        try {
            document = new Document();
            f = new File("dist"+System.getProperty("file.separator")+"PDF");
            bool = f.mkdir();
            PdfWriter pdf = PdfWriter.getInstance(document, new FileOutputStream(pdfpath));
            System.out.println("value:" + waterMark);
            int nWatermark = 1;
            if (waterMark != null) {
                nWatermark = Integer.parseInt(waterMark);
            }

            String waterMarkTxt = "";

            if (nWatermark <= 1) {
                waterMarkTxt = "Original";
            } else {
                nWatermark = nWatermark - 1;
                waterMarkTxt = "Duplicate " + nWatermark;//"Bharat Electronics Limited";
            }
            document.open();
            addMetaData(document);
            addTitlePage(document);
            addBarcode(document, from, To, Intendedto, SceurityClassification, precedence, Time);
            createTable(document, from, To, Intendedto, CC, IntendedCC, BCC, IntendedBCC, Subject, SIC, Attachment, precedence, SceurityClassification, SceurityCategory, SceurityPolicy, SceurityMark);
            addWatermark(pdf, document, waterMarkTxt);

            addData(document, MailBody);

            document.close();

        } catch (FileNotFoundException | DocumentException e) {

            e.printStackTrace();
        }
        return document;
    }
 /**
     * ******************************************************************
     * @Function Name : addMetaData
     * @Description : For Adding Title and Heading
     * @Input Parameter :document
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 20th May 2017
     * @Modification History:NA
     * ******************************************************************
     */
    private static void addMetaData(Document document) {
        document.addTitle("Generate PDF report");
        document.addSubject("Generate PDF report");
        document.addAuthor("BEL");
        document.addCreator("BEL");
    }
/**
     * ******************************************************************
     * @Function Name : addTitlePage
     * @Description : For Adding Title and Heading
     * @Input Parameter :document
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 20th May 2017
     * @Modification History:NA
     * ******************************************************************
     */
    private static void addTitlePage(Document document)
            throws DocumentException {
        Paragraph preface = new Paragraph();
        creteEmptyLine(preface, 1);

        preface.add(new Paragraph("Mail Print", TIME_ROMAN));
        preface.setAlignment(Paragraph.ALIGN_JUSTIFIED);

        creteEmptyLine(preface, 1);
        SimpleDateFormat simpleDateFormat
                = new SimpleDateFormat("MM/dd/yyyy");
        preface.add(new Paragraph(
                "Report created on " + simpleDateFormat
                        .format(new Date()), TIME_ROMAN_SMALL));
        document.add(preface);
    }
/**
     * ******************************************************************
     * @Function Name : creteEmptyLine
     * @Description : For Creating Empty Lines in PDF
     * @Input Parameter :paragraph,number
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 20th May 2017
     * @Modification History:NA
     * ******************************************************************
     */
    private static void creteEmptyLine(Paragraph paragraph,int number) {
        for (int i = 0; i < number; i++) {
            paragraph.add(new Paragraph(" "));
        }
    }
/**
     * ******************************************************************
     * @Function Name : createTable
     * @Description : For Creating Table CELL in PDF
     * @Input Parameter :document,from,To,Intendedto,CC,IntendedCC,BCC,IntendedBCC,Subject,SIC,Attachment
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 20th May 2017
     * @Modification History:NA
     * ******************************************************************
     */
    private static void createTable(Document document, String from, String To, String Intendedto, String CC, String IntendedCC, String BCC, String IntendedBCC, String Subject, String SIC, String Attachment, String precedence, String SceurityClassification, String SceurityCategory, String SceurityPolicy, String SceurityMark)
            throws DocumentException {
        try {
            Paragraph paragraph = new Paragraph();
            creteEmptyLine(paragraph, 2);
            document.add(paragraph);

            PdfPTable table = new PdfPTable(2);
//            table.getDefaultCell().setBorder(PdfPCell.NO_BORDER);

            PdfPCell c1 = new PdfPCell();
            c1.setVerticalAlignment(Element.ALIGN_CENTER);
            c1.setFixedHeight(50);
            table.addCell("From : ");
            table.addCell(from);

            PdfPCell c2 = new PdfPCell(new Phrase());
            c2.setHorizontalAlignment(Element.ALIGN_CENTER);
            //c2.setVerticalAlignment(Element.ALIGN_BOTTOM);
            c2.setFixedHeight(50);
            table.addCell("To : ");
            table.addCell(To);

            PdfPCell c3 = new PdfPCell(new Phrase());
            c3.setVerticalAlignment(Element.ALIGN_CENTER);
            c3.setFixedHeight(50);
            table.addCell("Intended To : ");
            table.addCell(Intendedto);

            PdfPCell c4 = new PdfPCell(new Phrase());
            c4.setVerticalAlignment(Element.ALIGN_CENTER);
            c4.setFixedHeight(50);
            table.addCell("CC : ");
            table.addCell(CC);

            PdfPCell c5 = new PdfPCell(new Phrase());
            c5.setVerticalAlignment(Element.ALIGN_CENTER);
            c5.setFixedHeight(50);
            table.addCell("Intended CC : ");
            table.addCell(IntendedCC);

            PdfPCell c6 = new PdfPCell(new Phrase());
            c6.setVerticalAlignment(Element.ALIGN_CENTER);
            c6.setFixedHeight(50);
            table.addCell("BCC : ");;
            table.addCell(BCC);

            PdfPCell c7 = new PdfPCell(new Phrase());
            c7.setVerticalAlignment(Element.ALIGN_CENTER);
            c7.setFixedHeight(50);
            table.addCell("Intended BCC : ");
            table.addCell(IntendedBCC);

            PdfPCell c8 = new PdfPCell(new Phrase());
            c8.setVerticalAlignment(Element.ALIGN_CENTER);
            c8.setFixedHeight(50);
            table.addCell("Subject : ");
            table.addCell(Subject);

            PdfPCell c9 = new PdfPCell(new Phrase());
            c9.setVerticalAlignment(Element.ALIGN_CENTER);
            c9.setFixedHeight(50);
            table.addCell("SIC : ");
            table.addCell(SIC);

            PdfPCell c10 = new PdfPCell(new Phrase());
            c10.setVerticalAlignment(Element.ALIGN_CENTER);
            c10.setFixedHeight(50);
            table.addCell("Attachment : ");
            table.addCell(Attachment);

            PdfPCell c11 = new PdfPCell(new Phrase());
            c11.setVerticalAlignment(Element.ALIGN_CENTER);
            c11.setFixedHeight(50);
            table.addCell("Precedence : ");
            table.addCell(precedence);

            PdfPCell c12 = new PdfPCell(new Phrase());
            c12.setVerticalAlignment(Element.ALIGN_CENTER);
            c12.setFixedHeight(50);
            table.addCell("Security Classification : ");
            table.addCell(SceurityClassification);

            PdfPCell c13 = new PdfPCell(new Phrase());
            c13.setVerticalAlignment(Element.ALIGN_CENTER);
            c13.setFixedHeight(50);
            table.addCell("Security Category : ");
            table.addCell(SceurityCategory);

            PdfPCell c14 = new PdfPCell(new Phrase());
            c14.setVerticalAlignment(Element.ALIGN_CENTER);
            c14.setFixedHeight(50);
            table.addCell("Security Policy : ");
            table.addCell(SceurityPolicy);

            PdfPCell c15 = new PdfPCell(new Phrase());
            c15.setVerticalAlignment(Element.ALIGN_CENTER);
            c15.setFixedHeight(50);
            table.addCell("Privacy Mark : ");
            table.addCell(SceurityMark);

            table.setHeaderRows(1);
            table.setWidthPercentage(100);
            table.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
            table.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);

            document.add(table);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
/**
     * ******************************************************************
     * @Function Name : addData
     * @Description : For Adding Data in PDF
     * @Input Parameter :addData,MailBody
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 20th May 2017
     * @Modification History:NA
     * ******************************************************************
     */
    public static void addData(Document document, String MailBody) throws DocumentException {

        Paragraph preface = new Paragraph();
        preface.add(new Paragraph("Mail Content", TIME_ROMAN_NEW));
        PdfPTable table = new PdfPTable(1);
        PdfPCell c = new PdfPCell(new Phrase());
        creteEmptyLine(preface, 1);
        c.setVerticalAlignment(Element.ALIGN_CENTER);
        c.setFixedHeight(50);
        table.addCell(MailBody);
        preface.add(new Paragraph(MailBody, TIME_ROMAN_1));

        table.setHeaderRows(1);
        table.setWidthPercentage(100);
        table.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);
        table.getDefaultCell().setVerticalAlignment(Element.ALIGN_LEFT);

        document.add(table);
        creteEmptyLine(preface, 1);
        document.add(preface);
        PdfPCell cell = new PdfPCell(new Phrase());

        document.add(table);

    }
/**
     * ******************************************************************
     * @Function Name : addBarcode
     * @Description : For Adding BarCode In PDF
     * @Input Parameter :document,from,To,Intendedto,SceurityClassification,precedence,Time
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 20th May 2017
     * @Modification History:NA
     * ******************************************************************
     */
    public static void addBarcode(Document document, String from, String To, String Intendedto, String SceurityClassification, String precedence, String Time) {
        try {

            //BarcodeQRCode will take String content,int width,int height as arguments.
            BarcodeQRCode qrcode = new BarcodeQRCode(from + To + Intendedto + SceurityClassification + precedence + Time, 60, 60, null);
            Image qrcodeImage = qrcode.getImage();
            qrcodeImage.setAlignment(50);
            qrcodeImage.scalePercent(200);
            document.add(qrcodeImage);

        } catch (Exception e) {
            System.out.println("exception is" + e);
        }
    }
/**
     * ******************************************************************
     * @Function Name : addWatermark
     * @Description : For Adding Watermark In PDF
     * @Input Parameter :pdf,document,txtwatermark.
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 20th May 2017
     * @Modification History:NA
     * ******************************************************************
     */
    public static void addWatermark(PdfWriter pdf, Document document, String txtwatermark) {

        try {

            PdfContentByte pdf1 = pdf.getDirectContentUnder();
            Phrase p = new Phrase(txtwatermark, new Font(FontFamily.HELVETICA, 60, Font.ITALIC, BaseColor.LIGHT_GRAY));
            ColumnText.showTextAligned(pdf1, Element.ALIGN_CENTER, p, 300f, 500f, 45f);

        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
