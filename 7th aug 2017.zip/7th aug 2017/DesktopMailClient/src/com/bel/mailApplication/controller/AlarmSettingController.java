/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.controller;


import com.jfoenix.controls.JFXToggleButton;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import mail.awan.beans.AlarmProfilesDTO;
import mail.awan.messageHandler.MessageHandler;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;

/**
 *
 * @author admin
 */
public class AlarmSettingController implements Initializable {

    @FXML
    private Button m_btnConfig;
    @FXML
    private Button m_btnSetDefault;
    @FXML
    private Button m_btnSave;
    @FXML
    private Button m_btnCancel;
    @FXML
    private TextField m_txtErrorAlram;
    @FXML
    private TextField m_txtInfoAlram;
    @FXML
    private TextField m_txtSuccessAlram;
    @FXML
    private TextField m_txtWarningAlarm;
    @FXML
    private JFXToggleButton m_toggleErrorAlarm;
    @FXML
    private JFXToggleButton m_toggleWarningAlarm;
    @FXML
    private JFXToggleButton m_toggleInfoAlarm;
    @FXML
    private JFXToggleButton m_toggleSuccessAlarm;
    AlarmProfilesDTO alarmProfilesDTO;
    MessageHandler messageHandler;
    boolean onClick_ToggleInfoAlarm;
    boolean onClick_toggleSuccessAlarm;
    boolean onClick_WarningAlram;
    boolean onClick_ErrorAlarm;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        m_toggleErrorAlarm.setDisable(true);
        m_toggleWarningAlarm.setDisable(true);
        m_toggleInfoAlarm.setDisable(true);
        m_toggleSuccessAlarm.setDisable(true);
        m_btnSave.setVisible(false);
        m_btnCancel.setVisible(false);
        
        messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
        alarmProfilesDTO = messageHandler.getAlarmProfiles(sm_name);
        String errorFlagInString = alarmProfilesDTO.getErrorAlarm();
        boolean errorFlag;
        if(alarmProfilesDTO.getErrorAlarm()!=null)
        {
        if (errorFlagInString.equalsIgnoreCase("true")) {
            errorFlag = true;
            m_toggleErrorAlarm.setSelected(errorFlag);
        } else {
            errorFlag = false;
            m_toggleErrorAlarm.setSelected(errorFlag);
        }
        }
        String infoFlagInstring = alarmProfilesDTO.getInfoAlarm();
        boolean infoFlag;
        if(alarmProfilesDTO.getInfoAlarm()!=null){
        if (infoFlagInstring.equalsIgnoreCase("true")) {
            infoFlag = true;
            m_toggleInfoAlarm.setSelected(infoFlag);
        } else {
            infoFlag = false;
            m_toggleInfoAlarm.setSelected(infoFlag);
        }
        }
        String successFlagInString = alarmProfilesDTO.getSuccessAlarm();
        boolean successFlag;
        if(alarmProfilesDTO.getSuccessAlarm()!=null){
        if (successFlagInString.equalsIgnoreCase("true")) {
            successFlag = true;
            m_toggleSuccessAlarm.setSelected(successFlag);
        } else {
            successFlag = false;
        }
        }
        String warningFlagInString = alarmProfilesDTO.getWarningAlarm();
        boolean warningFlag;
        if(alarmProfilesDTO.getWarningAlarm()!=null){
        if (warningFlagInString.equalsIgnoreCase("true")) {

            warningFlag = true;
            m_toggleWarningAlarm.setSelected(warningFlag);
        } else {
            warningFlag = false;
            m_toggleWarningAlarm.setSelected(warningFlag);
        }
        } 
    }

    @FXML
    private void onClick_Config(ActionEvent event) {
        m_toggleErrorAlarm.setDisable(false);
        m_toggleWarningAlarm.setDisable(false);
        m_toggleInfoAlarm.setDisable(false);
        m_toggleSuccessAlarm.setDisable(false);
        m_btnSetDefault.setDisable(true);
        m_btnSave.setVisible(true);
        m_btnCancel.setVisible(true);
    }

    @FXML
    private void onClick_SetDefault(ActionEvent event) {
        m_toggleErrorAlarm.setDisable(true);
        m_toggleWarningAlarm.setDisable(true);
        m_toggleInfoAlarm.setDisable(true);
        m_toggleSuccessAlarm.setDisable(true);
        m_btnConfig.setDisable(true);
        m_btnSave.setVisible(true);
        m_btnCancel.setVisible(true);
        m_toggleErrorAlarm.setSelected(true);
        m_toggleInfoAlarm.setSelected(true);
        m_toggleSuccessAlarm.setSelected(true);
        m_toggleWarningAlarm.setSelected(true);
    }

    @FXML
    private void onClick_btnSave(ActionEvent event) {

        messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
        alarmProfilesDTO = new AlarmProfilesDTO();

        if (m_toggleInfoAlarm.isSelected()) {
            System.out.println("INFO True");
            alarmProfilesDTO.setInfoAlarm("true");
            m_toggleInfoAlarm.setSelected(true);
        } else {
              System.out.println("INFO false");
            alarmProfilesDTO.setInfoAlarm("false");
            m_toggleInfoAlarm.setSelected(false);
        }

        if (m_toggleSuccessAlarm.isSelected()) {
                    System.out.println("Success true");
            alarmProfilesDTO.setSuccessAlarm("true");
             m_toggleSuccessAlarm.setSelected(true);
        } else {
                  System.out.println("Success false");
            alarmProfilesDTO.setSuccessAlarm("false");
              m_toggleSuccessAlarm.setSelected(false);
        }

        if (m_toggleErrorAlarm.isSelected()) {
                 System.out.println("Error true");
            alarmProfilesDTO.setErrorAlarm("true");
             m_toggleErrorAlarm.setSelected(true);
        } else {
             System.out.println("Error false");
            alarmProfilesDTO.setErrorAlarm("false");
             m_toggleErrorAlarm.setSelected(false);
        }

        if (m_toggleWarningAlarm.isSelected()) {
            System.out.println("Warning true");
            alarmProfilesDTO.setWarningAlarm("true");
             m_toggleWarningAlarm.setSelected(true);
        } else {
             System.out.println("Warning false");
            alarmProfilesDTO.setWarningAlarm("false");
             m_toggleWarningAlarm.setSelected(false);
        }
        messageHandler.setAlarmProfiles(alarmProfilesDTO);
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void onClick_btnCancel(ActionEvent event) {
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void onClick_ErrorAlarm(ActionEvent event) {

        onClick_ErrorAlarm = m_toggleErrorAlarm.isSelected();

    }

    @FXML
    private void onClick_WarningAlram(ActionEvent event) {

        messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
        alarmProfilesDTO = new AlarmProfilesDTO();

        onClick_WarningAlram = m_toggleWarningAlarm.isSelected();

    }

    @FXML
    private void onClick_txtInfoAlram(ActionEvent event) {
    }

    @FXML
    private void onClick_txtSuccessAlram(ActionEvent event) {
    }

    @FXML
    private void onClick_ToggleErrorAlarm(ActionEvent event) {
    }

    @FXML
    private void onClick_ToggleWarningAlarm(ActionEvent event) {
    }

    @FXML
    private void onClick_ToggleInfoAlarm(ActionEvent event) {

        onClick_ToggleInfoAlarm = m_toggleInfoAlarm.isSelected();
    }

    @FXML
    private void onClick_toggleSuccessAlarm(ActionEvent event) {
        onClick_toggleSuccessAlarm = m_toggleSuccessAlarm.isSelected();
    }
}
