/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.model;

import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author Root
 */
public class MailHeader {

    public static Object getSelectionModel() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private final SimpleStringProperty getfrom;
    private final SimpleStringProperty getsubject;
    private final SimpleStringProperty getdate;

    public MailHeader(String gfrom, String gSubj, String gDate) {

        this.getfrom = new SimpleStringProperty(gfrom);
        this.getsubject = new SimpleStringProperty(gSubj);
        this.getdate = new SimpleStringProperty(gDate);
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getGetfrom() {
        return getfrom.get();
    }

    public void setGetfrom(String gfrom) {
        getfrom.set(gfrom);
    }

    public String getGetsubject() {
        return getsubject.get();
    }

    public void setGetsubject(String gSubj) {
        getsubject.set(gSubj);
    }

    public String getGetdate() {
        return getdate.get();
    }

    public void setGetdate(String gDate) {
        getdate.set(gDate);
    }

    @Override
    public String toString() {

        return "Mail header {\n"
                + "\t getfrom=" + getfrom + ",\n" + "}";
    }

  

}
