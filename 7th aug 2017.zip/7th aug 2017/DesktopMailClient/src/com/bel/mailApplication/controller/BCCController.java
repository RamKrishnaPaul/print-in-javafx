 package com.bel.mailApplication.controller;

import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.stage.Stage;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.CheckListView;

/**
 * ******************************************************************
 * @File Name           : BCCController.
 * @Author              : Ram Krishna Paul.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display window  for  BCC.
 * @Created Date	:8-APR-2017
 * @Modification History:NA. 
*******************************************************************
 */
public class BCCController implements Initializable {
    @FXML
    private Button btnBCC;
    @FXML
    public CheckListView<String> ListBCC;
    private ObservableList<String> dataBCC;
    private String officename;
    List<String>selectedBccOffice;
     MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
                  /**
     * ******************************************************************
     * @Function Name           :initialize
     * @Description             : Method to call initialization function.
     * @Input Parameter         : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
      * @Author                 : Ram Krishna Paul.
     * @Created Date            :8-APR-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ListBCC.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        officename = msghndlr.ldapUserOffice(sm_name);
        System.out.println("office name is :" + officename);
        dataBCC = FXCollections.observableArrayList();
//        try {
        msghndlr.getAllRemoteOfficeNames(officename).toString();
        System.out.println("remaining name is " + msghndlr.getAllRemoteOfficeNames(officename));
        for (String office : msghndlr.getAllRemoteOfficeNames(officename)) {
            System.out.println("" + office);
            dataBCC.addAll(office);
            ListBCC.setItems(dataBCC);
                 ListBCC.getCheckModel().getCheckedItems().addListener(new ListChangeListener<String>() {
                @Override
                public void onChanged(ListChangeListener.Change<? extends String> c) {
                    selectedBccOffice = ListBCC.getCheckModel().getCheckedItems();
                   
                }
            });
        }
    }
   /**
     * ******************************************************************
     * @Function Name           :AddbtnBCC
     * @Description             : Method to add BCC to list.
     * @Input Parameter         : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ram Krishna Paul.
     * @Created Date            :8-APR-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @FXML
    private void addbtnBCC(ActionEvent event) {
         List<String> data = ListBCC.getSelectionModel().getSelectedItems();
        for (String BCCOfficeName : data) {
            System.out.println("selected office is" + BCCOfficeName);
//             officename=d;
        }
      
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
    }

}
