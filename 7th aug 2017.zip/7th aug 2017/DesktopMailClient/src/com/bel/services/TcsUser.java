package com.bel.services;
import java.util.Arrays;

public class TcsUser {
	String cn="";
	String sn="";
	String uid="";
	String AltAddress="";
	String Appointment="";
	String Approver="";
	String AttachmentMaxSize="";
	String AttachmentReceiveAuth="";
	String AttachmentSendAuth="";
	String IPAddress="";
	String mailHost="";
	String MailId="";
	String mailLocalAddress="";
	String MaxMessagePrecedence="";
	String MaxSecurityClassificationSend="";
	String MaxSecurityClassificationView="";
	String Reviwer="";
	String Role="";	
	byte[] userCertificate;
	String userPassword="";
	String userPKCS12="";
	
	
	
	public String getAltAddress() {
		return AltAddress;
	}
	public void setAltAddress(String altAddress) {
		AltAddress = altAddress;
	}
	public String getCn() {
		return cn;
	}
	public void setCn(String cn) {
		this.cn = cn;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getAppointment() {
		return Appointment;
	}
	public void setAppointment(String appointment) {
		Appointment = appointment;
	}
	public String getApprover() {
		return Approver;
	}
	public void setApprover(String approver) {
		Approver = approver;
	}
	public String getAttachmentMaxSize() {
		return AttachmentMaxSize;
	}
	public void setAttachmentMaxSize(String attachmentMaxSize) {
		AttachmentMaxSize = attachmentMaxSize;
	}
	public String getAttachmentReceiveAuth() {
		return AttachmentReceiveAuth;
	}
	public void setAttachmentReceiveAuth(String attachmentReceiveAuth) {
		AttachmentReceiveAuth = attachmentReceiveAuth;
	}
	public String getAttachmentSendAuth() {
		return AttachmentSendAuth;
	}
	public void setAttachmentSendAuth(String attachmentSendAuth) {
		AttachmentSendAuth = attachmentSendAuth;
	}
	public String getIPAddress() {
		return IPAddress;
	}
	public void setIPAddress(String iPAddress) {
		IPAddress = iPAddress;
	}
	public String getMailHost() {
		return mailHost;
	}
	public void setMailHost(String mailHost) {
		this.mailHost = mailHost;
	}
	public String getMailId() {
		return MailId;
	}
	public void setMailId(String mailId) {
		MailId = mailId;
	}
	public String getMailLocalAddress() {
		return mailLocalAddress;
	}
	public void setMailLocalAddress(String mailLocalAddress) {
		this.mailLocalAddress = mailLocalAddress;
	}
	public String getMaxMessagePrecedence() {
		return MaxMessagePrecedence;
	}
	public void setMaxMessagePrecedence(String maxMessagePrecedence) {
		MaxMessagePrecedence = maxMessagePrecedence;
	}
	public String getMaxSecurityClassificationSend() {
		return MaxSecurityClassificationSend;
	}
	public void setMaxSecurityClassificationSend(
			String maxSecurityClassificationSend) {
		MaxSecurityClassificationSend = maxSecurityClassificationSend;
	}
	public String getMaxSecurityClassificationView() {
		return MaxSecurityClassificationView;
	}
	public void setMaxSecurityClassificationView(
			String maxSecurityClassificationView) {
		MaxSecurityClassificationView = maxSecurityClassificationView;
	}
	public String getReviwer() {
		return Reviwer;
	}
	public void setReviwer(String reviwer) {
		Reviwer = reviwer;
	}
	public String getRole() {
		return Role;
	}
	public void setRole(String role) {
		Role = role;
	}
	public byte[] getUserCertificate() {
		return userCertificate;
	}
	public void setUserCertificate(byte[] userCertificate) {
		this.userCertificate = userCertificate;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public String getUserPKCS12() {
		return userPKCS12;
	}
	public void setUserPKCS12(String userPKCS12) {
		this.userPKCS12 = userPKCS12;
	}
	@Override
	public String toString() {
		return "TcsUser [cn=" + cn + ", sn=" + sn + ", uid=" + uid
				+ ", AltAddress=" + AltAddress + ", Appointment=" + Appointment
				+ ", Approver=" + Approver + ", AttachmentMaxSize="
				+ AttachmentMaxSize + ", AttachmentReceiveAuth="
				+ AttachmentReceiveAuth + ", AttachmentSendAuth="
				+ AttachmentSendAuth + ", IPAddress=" + IPAddress
				+ ", mailHost=" + mailHost + ", MailId=" + MailId
				+ ", mailLocalAddress=" + mailLocalAddress
				+ ", MaxMessagePrecedence=" + MaxMessagePrecedence
				+ ", MaxSecurityClassificationSend="
				+ MaxSecurityClassificationSend
				+ ", MaxSecurityClassificationView="
				+ MaxSecurityClassificationView + ", Reviwer=" + Reviwer
				+ ", Role=" + Role + ", userCertificate="
				+ Arrays.toString(userCertificate) + ", userPassword="
				+ userPassword + ", userPKCS12=" + userPKCS12 + "]";
	}

    

}
