package com.bel.mailApplication.controller;

//import awan.desktop.networkAutoCheck.NetworkAutoReachabilityCheck;
import mail.awan.networkAutoCheck.NetworkAutoReachabilityCheck;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import static com.bel.mailApplication.controller.FXMLDocumentController.comp_mail_stage;
import static com.bel.mailApplication.controller.FXMLDocumentController.address_book;
import static com.bel.mailApplication.controller.FXMLDocumentController.modify_add_bk;
import com.bel.mailApplication.network.NetworkObserver;
import com.jfoenix.controls.JFXToggleButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.geometry.Rectangle2D;
import javafx.scene.control.PasswordField;
import javafx.scene.input.KeyCode;
import javafx.stage.Screen;
import javafx.stage.StageStyle;
import mail.awan.beans.GetAllPrecedenceConfigDTO;
import mail.awan.beans.GetAllSecurityClassConfigDTO;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.Notifications;

/**
 * ******************************************************************
 * @File Name           : LoginFXMLController.
 * @Author              : Ravikiran Bhat.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display Login Page
 * @Created Date	:16-FEB-2017
 * @Modification History:NA.
 * ******************************************************************
 */
public class LoginFXMLController implements Initializable, ActionListener {

    @FXML
    private Button logincancelbtn;
    @FXML
    private ImageView m_imageview;
    @FXML
    private ImageView m_pwdimageview;
    @FXML
    private ImageView m_otpimageview;
    @FXML
    private PasswordField m_inputOtp;
    @FXML
    private TextField m_inputUsername;
    @FXML
    private TextField m_inputPassword;
    public static String sm_name = null;
    public static String sm_pass = null;
    public static String sm_netStatus;
    @FXML
    public Timer invalidationTimer_main_stage;
    @FXML
    public static Stage mainStage = new Stage();
    @FXML
    public static Parent root1;
    static String session_id;
    static long s_time_out;
    public static List<GetAllPrecedenceConfigDTO> prcedenceList;
    public static List<GetAllSecurityClassConfigDTO> SecurityClssificationConfigList;
    Alert alert;

    /**
     * ******************************************************************
     * @Function Name           :onclickLoginByMouse
     * @Description             : Method to login with mouse event button.
     * @Input Parameter         : ActionEvent -provide by -JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ravikiran Bhat.AND Ram Krishna Paul.
     * @Created Date            :16-FEB-2017
     * @Modification History    :NA.
     * ******************************************************************
     */
    @FXML
    public void onclickLoginByMouse(ActionEvent event) {
        try {
            onclickLogin();
        } catch (Exception ex) {
            Logger.getLogger(LoginFXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * ******************************************************************
     * @Function Name           :onclickLoginByEnter
     * @Description             : Method to login with Key board event.
     * @Input Parameter         : ActionEvent -provide by -JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ravikiran Bhat.AND Ram Krishna Paul.
     * @Created Date            :20-FEB-2017
     * @Modification History    :NA.
     * ******************************************************************
     */
    @FXML
    public void onclickLoginByEnter(KeyEvent event) {
        if (event.getCode() == KeyCode.ENTER) {
            try {
                onclickLogin();
            } catch (Exception ex) {
                Logger.getLogger(LoginFXMLController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * ******************************************************************
     * @Function Name            :onclickLogin
     * @Description              :Method to check for Authentication.
     * @Input Parameter          : NA.
     * @Output Parameter	 : NA.
     * @Author                   : Ravikiran Bhat AND Ram Krishna Paul.
     * @Created Date             :21-FEB-2017
     * @Modification History     :24-MAY-2017.
     * ******************************************************************
     */
    public void onclickLogin() throws Exception {
        sm_name = m_inputUsername.getText();
        sm_pass = m_inputPassword.getText();
        MessageHandler obj = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
        if (m_inputUsername.getText().length() >= 1 || m_inputPassword.getText().length() >= 1) {
          try {
                String OTP_value = m_inputOtp.getText();
                String uname = sm_name + "@tcs.mil.in";
                boolean retv = true;
               /*   if (uname.contains("Cdr")) {
                    OTP_CLIENT_TCP clreqobj = new OTP_CLIENT_TCP();
                    retv = clreqobj.isValidOTP(uname, OTP_value);
                    if (!retv) {
                         System.out.println("Invalid otp");
                        Platform.runLater(() -> {
                            Notifications.create().text("Login Information" + "\ninvaild OTP !").showError();
                        });
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.initStyle(StageStyle.UTILITY);
                        alert.setTitle("Login Information");
                        alert.setHeaderText(null);
                        alert.setContentText("invaild OTP !");
                        alert.showAndWait();
                    }
                    else
                    {
                        System.out.println("valid otp");
                    }
                }
                if (retv) {*/
                    if (obj.authenticate(sm_name, sm_pass)) {
                        NetworkAutoReachabilityCheck networkAutoReachabilityCheck = NetworkAutoReachabilityCheck.getNetworkAutoReachabilityCheckImplInstance();
                        NetworkObserver observer = new NetworkObserver(networkAutoReachabilityCheck);
                        networkAutoReachabilityCheck.getStatus();
                        boolean networkStatus = networkAutoReachabilityCheck.getStatus();
                        Runnable runnable1 = new Runnable() {
                            String PreviousState = observer.getNetworkChangeIndicator();

                            @Override
                            public void run() {
                                try {
                                    sm_netStatus = networkAutoReachabilityCheck.getNetworkChangeIndicator();
                                    if (sm_netStatus != null) {
                                        
                                        if (!PreviousState.equalsIgnoreCase(sm_netStatus)) {
                                            Platform.runLater(() -> {
                                                Notifications.create().text(sm_netStatus).showInformation();
                                            });
                                            PreviousState = sm_netStatus;
                                        }
                                    }

                                    return;
                                } catch (Exception e) {
                                }

                            }
                        };
                        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
                        executor.scheduleAtFixedRate(runnable1, 0, 3, TimeUnit.SECONDS);

                        //storing data in Db and starting background threads.
                            obj.backGroudProcess(sm_name, sm_pass);                        
                            prcedenceList = obj.getAllPrecedenceConfig();
                            SecurityClssificationConfigList = obj.getAllSecurityClassConfig();
                        
                        Screen screen = Screen.getPrimary();
                        Rectangle2D bounds = screen.getVisualBounds();
                        root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/FXMLDocument.fxml"));
                        Scene scene = new Scene(root1);
                        mainStage = (Stage) m_inputUsername.getScene().getWindow();
                        mainStage.setScene(scene);
                        mainStage.maximizedProperty();
                        mainStage.setX(bounds.getMinX());
                        mainStage.setX(bounds.getMinY());
                        mainStage.setWidth(bounds.getWidth());
                        mainStage.setHeight(bounds.getHeight());
                        mainStage.show();
                        EventHandler<MouseEvent> eventHandler = new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent e) {
                                invalidationTimer_main_stage.restart();
                            }
                        };
                        EventHandler<KeyEvent> eventHandlerTextField = new EventHandler<KeyEvent>() {
                            @Override
                            public void handle(KeyEvent event) {
                                invalidationTimer_main_stage.restart();
                            }
                        };
                        mainStage.addEventHandler(KeyEvent.KEY_TYPED, eventHandlerTextField);
                        mainStage.addEventHandler(KeyEvent.KEY_RELEASED, eventHandlerTextField);
                        //Compose page
                        comp_mail_stage.addEventHandler(KeyEvent.KEY_TYPED, eventHandlerTextField);
                        comp_mail_stage.addEventHandler(KeyEvent.KEY_RELEASED, eventHandlerTextField);
                        //Address book
                        address_book.addEventHandler(KeyEvent.KEY_TYPED, eventHandlerTextField);
                        address_book.addEventHandler(KeyEvent.KEY_RELEASED, eventHandlerTextField);
                        //Modify Address book
                        modify_add_bk.addEventHandler(KeyEvent.KEY_TYPED, eventHandlerTextField);
                        modify_add_bk.addEventHandler(KeyEvent.KEY_RELEASED, eventHandlerTextField);
                        //Main page mouse listner
                        System.out.println("mouse stage");
                        mainStage.addEventFilter(MouseEvent.MOUSE_CLICKED, eventHandler);
                        mainStage.addEventFilter(MouseEvent.MOUSE_DRAGGED, eventHandler);
                        mainStage.addEventFilter(MouseEvent.MOUSE_MOVED, eventHandler);
                        mainStage.addEventFilter(MouseEvent.MOUSE_RELEASED, eventHandler);
                        mainStage.addEventFilter(MouseEvent.ANY, eventHandler);
                        //Compose page
                        comp_mail_stage.addEventFilter(MouseEvent.MOUSE_CLICKED, eventHandler);
                        comp_mail_stage.addEventFilter(MouseEvent.MOUSE_DRAGGED, eventHandler);
                        comp_mail_stage.addEventFilter(MouseEvent.MOUSE_MOVED, eventHandler);
                        comp_mail_stage.addEventFilter(MouseEvent.MOUSE_RELEASED, eventHandler);
                        comp_mail_stage.addEventFilter(MouseEvent.ANY, eventHandler);
                        //Address book 
                        address_book.addEventFilter(MouseEvent.MOUSE_CLICKED, eventHandler);
                        address_book.addEventFilter(MouseEvent.MOUSE_DRAGGED, eventHandler);
                        address_book.addEventFilter(MouseEvent.MOUSE_MOVED, eventHandler);
                        address_book.addEventFilter(MouseEvent.MOUSE_RELEASED, eventHandler);
                        address_book.addEventFilter(MouseEvent.ANY, eventHandler);
                        //Modify address book
                        modify_add_bk.addEventFilter(MouseEvent.MOUSE_CLICKED, eventHandler);
                        modify_add_bk.addEventFilter(MouseEvent.MOUSE_DRAGGED, eventHandler);
                        modify_add_bk.addEventFilter(MouseEvent.MOUSE_MOVED, eventHandler);
                        modify_add_bk.addEventFilter(MouseEvent.MOUSE_RELEASED, eventHandler);
                        modify_add_bk.addEventFilter(MouseEvent.ANY, eventHandler);
                        /**
                         * ******************************************************************
                         * @Function Name       :getSessionConfiguration
                         * @Description         :Method to getting session management  time from LDAP.
                         * @Input Parameter     : NA.
                         * @Output Parameter	: Session time.
                         * @Author              : Ravikiran Bhat.
                         * @Created Date        :20-MAR-2017
                         * @Modification History:NA.
                         * *****************************************************************
                         */
                        try {
//                            String str = obj.getSessionConfiguration();
//                            System.out.println("Session Timout value:" + str);
//                            int min = Integer.parseInt(str);
                            s_time_out = 10 * 60 * 1000;
                            invalidationTimer_main_stage = new Timer((int) s_time_out, this);
                            System.out.println(s_time_out);
                        } catch (Exception e) {
                            System.out.println("session time");
                        }

                    } else {
                        Platform.runLater(() -> {
                            Notifications.create().text("Login Information" + "\nLogin Failed Please Enter vailid Credentials!").showError();
                        });
                        alert = new Alert(Alert.AlertType.ERROR);
                        alert.initStyle(StageStyle.UTILITY);
                        alert.setTitle("Login Information");
                        alert.setHeaderText(null);
                        alert.setContentText("Login Failed Please Enter vailid Credentials !");
                        alert.showAndWait();
                        m_inputUsername.clear();
                        m_inputPassword.clear();
                        m_inputOtp.clear();
                        return;
                    }
            //   }
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        } else {
            Platform.runLater(() -> {
                Notifications.create().text("Login Information" + "\nPlease Enter Valid Credentials for Login!!").showError();
            });
            alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Login Error");
            alert.setHeaderText(null);
            alert.setContentText("Please Enter Valid Credentials for Login !! ");
            alert.showAndWait();
        }
        m_inputUsername.clear();
        m_inputPassword.clear();
        m_inputOtp.clear();
    }

    /**
     * ******************************************************************
     * @Function Name           :handle
     * @Description             :Method to change login user icon when mouse click
     * @Input Parameter         : MouseEvent -Provided by JavaFX.
     * @Output Parameter	: NA.
        * @Author               : Jasmeen.
     * @Created Date            :20-FEB-2017
     * @Modification History    :NA.
     * *****************************************************************
     */
    @FXML
    public void handle(MouseEvent event
    ) {
        m_imageview.setImage(new Image("img/User-Profile-48.png"));
        System.out.println("Appointment Id");
        event.consume();
    }

    /**
     * ******************************************************************
     * @Function Name        :handlepwd
     * @Description          :Method to change password icon when mouse click.
     * @Input Parameter      : MouseEvent -Provided by JavaFX.
     * @Output Parameter     : NA.
     * @Author               : Jasmeen
     * @Created Date         :20-FEB-2017
     * @Modification History :NA.
     * *****************************************************************
     */
    @FXML
    public void handlepwd(MouseEvent event
    ) {
        m_pwdimageview.setImage(new Image("img/lock-open.png"));
        System.out.println("Password");
        event.consume();
    }

    /**
     * ******************************************************************
     * @Function Name        :handleotp
     * @Description          :Method to change OTP icon when mouse click.
     * @Input Parameter      : MouseEvent -Provided by JavaFX.
     * @Output Parameter     : NA.
     * @Author               : Jasmeen.
     * @Created Date         :21-FEB-2017
     * @Modification History :NA.
     * *****************************************************************
     */
    @FXML
    public void handleotp(MouseEvent event
    ) {
        m_otpimageview.setImage(new Image("img/otp.png"));
        System.out.println("OTP");
        event.consume();
    }
   /**
     * ******************************************************************
     * @Function Name       :initialize
     * @Description         : Method to call initialization function.
     * @Input Parameter     : URL url, ResourceBundle rb.
     * @Output Parameter    : NA.
     * @Author              : Ravikiran Bhat.
     * @Created Date        :15-FEB-2017
     * @Modification History:NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    /**
     * ******************************************************************
     * @Function Name        :actionPerformed
     * @Description          :Method to display message when session time over.
     * @Input Parameter      : ActionEvent -Provided by JavaAWT.
     * @Output Parameter     : NA.
     * @Author               : Ravikiran Bhat.
     * @Created Date         :25-FEB-2017
     * @Modification History :NA.
     * *****************************************************************
     */
    @Override
    public void actionPerformed(java.awt.event.ActionEvent e) {
        try {
            JOptionPane.showMessageDialog(null, "Your Main session is invalid");
            System.exit(0);
            invalidationTimer_main_stage.stop();
        } catch (Exception e3) {
            e3.printStackTrace();
        }
    }
    @FXML
    private JFXToggleButton m_toggleSecurity;

    public boolean toggleSecurity() {

        boolean isSelect = m_toggleSecurity.isSelected();
        if (isSelect) {
            m_toggleSecurity.setSelected(true);
        } else {
            m_toggleSecurity.setSelected(false);
        }
        return isSelect;

    }
    public static boolean securityStatusFlag = true;

    @FXML
    public void clickm_toggleSecurity(ActionEvent event) throws IOException {
        securityStatusFlag = toggleSecurity();
        System.out.println("security is :" + securityStatusFlag);
    }

}
