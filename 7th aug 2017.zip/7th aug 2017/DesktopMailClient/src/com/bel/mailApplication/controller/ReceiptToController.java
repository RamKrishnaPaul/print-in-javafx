package com.bel.mailApplication.controller;

import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.SelectionMode;
import javafx.stage.Stage;
import org.controlsfx.control.CheckListView;
/**
 * ******************************************************************
 * @File Name           : ReceiptToController.
 * @Author              : Ram Krishna Paul.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display window  for  ReceiptTo.
 * @Created Date	:18-MAY-2017
 * @Modification History:NA. 
*******************************************************************
 */
public class ReceiptToController implements Initializable {
    @FXML
    private JFXButton btnAddReceiptTo;
    @FXML
    private ObservableList<String> data;
    @FXML
    public CheckListView<String> listReceiptTo;
  
                 /**
     * ******************************************************************
     * @Function Name           :initialize
     * @Description             : Method to call initialization function.
     * @Input Parameter         : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
      * @Author                 : Ram Krishna Paul.
     * @Created Date            :18-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       listReceiptTo.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        data = FXCollections.observableArrayList();
        List<String> li = new ArrayList<String>();
        li = ComposePageContrller.dataListIntendedTO();
       // System.out.println("lists are" + li);
        for (String datareceiptfrom : li) {
            data.addAll(datareceiptfrom);
        }
        listReceiptTo.setItems(data);
    }
/**
     * ******************************************************************
     * @Function Name           :clickbtnAddReceiptTo
     * @Description             : Method to add ReceiptTo to list.
     * @Input Parameter         : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ram Krishna Paul.
     * @Created Date            :18-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @FXML
    private void clickbtnAddReceiptTo(ActionEvent event) {
        List<String> data = listReceiptTo.getSelectionModel().getSelectedItems();
        for (String dataListRecipTo:  data) {
        }
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
        
    }

}
