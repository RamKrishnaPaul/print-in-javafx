package com.bel.mailApplication.controller;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.controlsfx.control.Notifications;

/**
 * ******************************************************************
 * @File Name           : SignedReceiptController.
 * @Author              : Ram Krishna Paul.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display window  for  BCC.
 * @Created Date	:13-MAY-2017
 * @Modification History:NA. 
*******************************************************************
 */
public class SignedReceiptController implements Initializable {

    @FXML
    private JFXButton btnOkSignedReceipt;
    @FXML
    private JFXButton btnReceiptFrom;
    @FXML
    private JFXButton btnReceiptTo;
    @FXML
    private Label lblReceiptFrom;
    @FXML
    private Label lblReceiptTo;
    public static List<String> datareciptFrom;
    public static StringBuilder listdataReceiptFrom = new StringBuilder();
    public static List<String> datareciptTo;
    public static StringBuilder listDataReceiptTo = new StringBuilder();
             /**
     * ******************************************************************
     * @Function Name           :initialize
     * @Description             : Method to call initialization function.
     * @Input Parameter         : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
      * @Author                 : Ram Krishna Paul.
     * @Created Date            :13-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
  /**
     * ******************************************************************
     * @Function Name           :clickbtnOkSignedReceipt
     * @Description             : Method to SignedReceipt Confirmation.
     * @Input Parameter         : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ram Krishna Paul.
     * @Created Date            :13-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @FXML
    private void clickbtnOkSignedReceipt(ActionEvent event) {
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
    }
   /**
     * ******************************************************************
     * @Function Name           :clickbtnReceiptFrom
     * @Description             : Method to display ReceiptFrom window.
     * @Input Parameter         : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ram Krishna Paul.
     * @Created Date            :13-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */

    @FXML
    private void clickbtnReceiptFrom(ActionEvent event) throws IOException {
            Stage stageReceiptFrom = new Stage();
            Parent rootReceiptFrom;
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/ReceiptFrom.fxml"));
            rootReceiptFrom = (Parent) fXMLLoader.load();
            ReceiptFromController receiptFromController = fXMLLoader.getController();
            stageReceiptFrom.setScene(new Scene(rootReceiptFrom));
            stageReceiptFrom.setTitle("Receipt From");
            stageReceiptFrom.initModality(Modality.APPLICATION_MODAL);
            stageReceiptFrom.initOwner(btnReceiptFrom.getScene().getWindow());
            stageReceiptFrom.toFront();
            stageReceiptFrom.showAndWait();
            stageReceiptFrom.setResizable(false);
            datareciptFrom = receiptFromController.listReceiptFrom.getSelectionModel().getSelectedItems();

            datareciptFrom.stream().map((recDataFromReceiptFrom) -> {
                listdataReceiptFrom.append(recDataFromReceiptFrom).append(",");
                return recDataFromReceiptFrom;
            }).forEachOrdered((recDataFromReceiptFrom) -> {
                //  System.out.println("datas are:" + recDataFromCC);
            });
            lblReceiptFrom.setText(listdataReceiptFrom.toString());
//        }
    }

 /**
     * ******************************************************************
     * @Function Name           :clickbtnReceiptTo
     * @Description             : Method to display ReceiptTo window.
     * @Input Parameter         : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ram Krishna Paul.
     * @Created Date            :13-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @FXML
    private void clickbtnReceiptTo(ActionEvent event) throws IOException {
            Stage stageReceiptTo = new Stage();
            Parent rootReceiptTo;
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/ReceiptTo.fxml"));
            rootReceiptTo = (Parent) fXMLLoader.load();
            ReceiptToController receiptToController = fXMLLoader.getController();
            stageReceiptTo.setScene(new Scene(rootReceiptTo));
            stageReceiptTo.setTitle("Receipt To");
            stageReceiptTo.initModality(Modality.APPLICATION_MODAL);
            stageReceiptTo.initOwner(btnReceiptFrom.getScene().getWindow());
            stageReceiptTo.toFront();
            stageReceiptTo.showAndWait();
            stageReceiptTo.setResizable(false);
            datareciptTo = receiptToController.listReceiptTo.getSelectionModel().getSelectedItems();

            datareciptTo.stream().map((recDataFromReceiptTo) -> {
                listDataReceiptTo.append(recDataFromReceiptTo).append(",");
                return recDataFromReceiptTo;
            }).forEachOrdered((recDataFromReceiptTo) -> {
                //  System.out.println("datas are:" + recDataFromCC);
            });
            lblReceiptTo.setText(listDataReceiptTo.toString());
//        }
    }
}
