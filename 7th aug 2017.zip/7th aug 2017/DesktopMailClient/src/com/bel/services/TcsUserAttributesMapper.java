/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.services;

/**
 *
 * @author Admin
 */
import java.io.ByteArrayInputStream;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;



public class TcsUserAttributesMapper {

	public TcsUser mapFromAttributes(Attributes attributes) throws NamingException {

		TcsUser userObject = new TcsUser();

		String cn = "";
		String sn = ""; 
		String uid = ""; 
		String AltAddress="";
		String Appointment = ""; 
		String Approver = ""; 
		String AttachmentMaxSize = ""; 
		String AttachmentReceiveAuth = ""; 
		String AttachmentSendAuth = ""; 
		String IPAddress = ""; 
		String mailHost = ""; 
		String MailId = ""; 
		String mailLocalAddress = ""; 
		String MaxMessagePrecedence = ""; 
		String MaxSecurityClassificationSend = ""; 
		String MaxSecurityClassificationView = ""; 
		String Reviwer = ""; 	
		String Role = "";
		String userPassword=""; 
		byte[] userCertificate = null;

		try{
			cn = (String)attributes.get("cn").get();
		}
		catch(Exception ex){
			cn = "";
		}
		try{
			sn = (String)attributes.get("sn").get();
		}
		catch(Exception ex){
			sn = ""; 
		}
		try{
			uid = (String)attributes.get("uid").get();
		}
		catch(Exception ex){
			uid = ""; 
		}
		try{
			AltAddress = (String)attributes.get("AltAddress").get();	
		}
		catch(Exception ex){
			AltAddress = ""; 
		}
		try{
			Appointment = (String)attributes.get("Appointment").get();	
		}
		catch(Exception ex){
			Appointment = ""; 
		}
		try{
			Approver = (String)attributes.get("Approver").get();	
		}
		catch(Exception ex){
			Approver = "";
		}
		try{
			AttachmentMaxSize = (String)attributes.get("AttachmentMaxSize").get();
		}
		catch(Exception ex){
			AttachmentMaxSize = ""; 
		}
		try{
			AttachmentReceiveAuth = (String)attributes.get("AttachmentReceiveAuth").get();
		}
		catch(Exception ex){
			AttachmentReceiveAuth = ""; 
		}
		try{
			AttachmentSendAuth = (String)attributes.get("AttachmentSendAuth").get();
		}
		catch(Exception ex){
			AttachmentSendAuth = ""; 
		}
		try{
			IPAddress = (String)attributes.get("IPAddress").get();
		}
		catch(Exception ex){
			IPAddress = ""; 
		}
		try{
			mailHost = (String)attributes.get("mailHost").get();
		}
		catch(Exception ex){
			mailHost = ""; 
		}
		try{
			MailId = (String)attributes.get("MailId").get();
		}
		catch(Exception ex){
			MailId = ""; 
		}
		try{
			mailLocalAddress = (String)attributes.get("mailLocalAddress").get();
		}
		catch(Exception ex){
			mailLocalAddress="";
		}
		try{
			MaxMessagePrecedence = (String)attributes.get("MaxMessagePrecedence").get();
		}
		catch(Exception ex){
			MaxMessagePrecedence="";
		}
		try{
			MaxSecurityClassificationSend = (String)attributes.get("MaxSecurityClassificationSend").get();
		}
		catch(Exception ex){
			MaxSecurityClassificationSend="";
		}
		try{
			MaxSecurityClassificationView = (String)attributes.get("MaxSecurityClassificationView").get();
		}
		catch(Exception ex){
			MaxSecurityClassificationView="";
		}
		try{
			Reviwer = (String)attributes.get("Reviewer").get();	
		}
		catch(Exception ex){
			Reviwer="";
		}
		try{
			Role = (String)attributes.get("Role").get();		
		}
		catch(Exception ex){
			Role="";
		}
		try{
			Attribute password=attributes.get("userPassword");
			userPassword=new String((byte[])password.get()); 

		}
		catch(Exception ex){
			userPassword="";
		}
		////		Properties properties = System.getProperties();
		////		properties.setProperty("java.naming.ldap.attributes.binary", "userCertificate");

		//		Certificate cert;
		//		try {
		//			cert = X509Certificate.getInstance((byte[]) attributes.get("userCertificate").get());
		//			System.out.println("Public Key : "+cert.getPublicKey());
		//		} catch (CertificateException e) {
		//			// TODO Auto-generated catch block
		//			e.printStackTrace();
		//		}
		//

		//		Attribute pkcs=attributes.get("userPKCS12");
		//		String userPKCS12=new String((byte[])pkcs.get()); 
		X509Certificate cert = null;

		try {
			CertificateFactory certificateFactory=CertificateFactory.getInstance("X.509");
			cert=(X509Certificate) certificateFactory.generateCertificate(new ByteArrayInputStream((byte[])attributes.get("userCertificate;binary").get(0)));
			byte[] buf=cert.getEncoded();
			userCertificate=buf;
		} catch (Exception e) {

		}

		userObject.setCn(cn);
		userObject.setSn(sn);
		userObject.setUid(uid);
		userObject.setAltAddress(AltAddress);
		userObject.setAppointment(Appointment);
		userObject.setApprover(Approver);
		userObject.setAttachmentMaxSize(AttachmentMaxSize);
		userObject.setAttachmentReceiveAuth(AttachmentReceiveAuth);
		userObject.setAttachmentSendAuth(AttachmentSendAuth);
		userObject.setIPAddress(IPAddress);
		userObject.setMailHost(mailHost);
		userObject.setMailId(MailId);
		userObject.setMailLocalAddress(mailLocalAddress);
		userObject.setMaxMessagePrecedence(MaxMessagePrecedence);
		userObject.setMaxSecurityClassificationSend(MaxSecurityClassificationSend);
		userObject.setMaxSecurityClassificationView(MaxSecurityClassificationView);
		userObject.setReviwer(Reviwer);
		userObject.setRole(Role);
		userObject.setUserPassword(userPassword);
		userObject.setUserCertificate(userCertificate);
		//		userObject.setUserPKCS12(userPKCS12);
		//		System.out.println(userObject.toString());
                System.out.println("mail Id is : :::::::::"+userObject.getMailId());
		return userObject;
	}


}
