package com.bel.mailApplication.controller;

import static com.bel.mailApplication.controller.FXMLDocumentController.mail_id;
import static com.bel.mailApplication.controller.FXMLDocumentController.read_approvemail;
import static com.bel.mailApplication.controller.LoginFXMLController.securityStatusFlag;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import static com.bel.mailApplication.controller.Review_mail_PagelController.file;
import com.entity.MailDTO;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.awt.FileDialog;
import java.awt.Frame;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.TransferMode;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.web.HTMLEditor;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javax.swing.JOptionPane;
import mail.awan.beans.AlarmProfilesDTO;
import mail.awan.beans.AttachmentClearenceDTO;
import mail.awan.beans.DeleteInput;
import mail.awan.beans.GetAllPrecedenceConfigDTO;
import mail.awan.beans.GetAllSecurityClassConfigDTO;
import mail.awan.beans.GroupMailInfo;
import mail.awan.beans.MailSenderInfo;
import mail.awan.beans.ReceiveMailInputDTO;
import mail.awan.beans.ResultDTO;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.Notifications;

/**
 * @File Name : Approve_view_pageController
 * @author : Ram Krishna Paul
 * @Description: For viewing approve mail
 * @Package : com.bel.mailApplication.controller
 * @Created : 4th April 2017
 * @Modification History: NA
 */
public class Approve_view_pageController implements Initializable {

    private static final AudioClip sm_audioSound = new AudioClip(Approve_view_pageController.class.getResource("/sounds/sound1.wav").toString());
    private static final AudioClip sm_audioAlert = new AudioClip(Approve_view_pageController.class.getResource("/sounds/sound2.wav").toString());
     @FXML
    private ComboBox combBoxMsgType;
    @FXML
    private TextArea txtMsgInstruction;
    @FXML
    private JFXButton send_mail;
    @FXML
    private JFXButton btnBCC;
    @FXML
    private Label lblBCC;
    @FXML
    private Label from_name;
    @FXML
    private JFXButton Compose_to_btn;
    @FXML
    private Label to_mail;
    @FXML
    private JFXButton IntendeTo;
    @FXML
    private Label lblIntendeTo, lblRecivDate;
    @FXML
    private JFXButton btncc;
    @FXML
    private Label lblcc;
    @FXML
    private JFXButton btnintendedcc;
    @FXML
    private Label lblintendedcc;
    @FXML
    private JFXButton btnintendedBCC;
    @FXML
    private Label lblintendedBCC;
    @FXML
    private TextField txtSubject;
    @FXML
    private ComboBox txtSIC;
    @FXML
    private HTMLEditor msgBody;
    @FXML
    private Label lblattachfile;
    @FXML
    private ComboBox<String> Combobox_precednce;
    @FXML
    private JFXButton attch_file;
    @FXML
    private JFXButton btnSignedReceipt;
    @FXML
    private JFXCheckBox chkReadReceipt;
    @FXML
    private JFXCheckBox checkSignedReceipt;
    @FXML
    private JFXCheckBox chkEncryption;
    @FXML
    private JFXButton btnReject_mail;
    @FXML
    private JFXButton cancel_mail;
    @FXML
    private JFXButton btn_modify;
    @FXML
    private JFXButton btn_accept;
    @FXML
    private ComboBox<String> Combobox_category;
    @FXML
    private TextField txtPrivacy;
    @FXML
    private ComboBox<String> Combobox_classification;
    @FXML
    private ComboBox<String> Combobox_policy;
    @FXML
    private Label change_lable;
    @FXML
    private Button removeTo;
    @FXML
    private ImageView imgviewto;
    @FXML
    private Button removeIntendedTo;
    @FXML
    private ImageView imgviewintendedto;
    @FXML
    private JFXButton removeCC;
    @FXML
    private ImageView imgviewCC;
    @FXML
    private Button removeIntendedCC;
    @FXML
    private ImageView imgviewIntendedCC;
    @FXML
    private Button removeBCC;
    @FXML
    private ImageView imgviewBCC;
    @FXML
    private ImageView imgviewIntendedBCC;
    @FXML
    private Button removeIntendeBCC;
    @FXML
    private Button removeAttachment;
//    @FXML
//    private ScrollPane m_sp=new ScrollPane();
    
    @FXML
    private ImageView m_imageApproveForward;
    @FXML
    private ImageView m_approveModifyImg;
    @FXML
    private ImageView m_imageApproveAccept;
    @FXML
    private ImageView m_imageApproveReject;
    @FXML
    private GridPane m_attachLabel;
      @FXML
    private ImageView imgviewAttachment;
    @FXML
    private Tooltip m_tooltipIntendedTo;
    @FXML
    private Tooltip m_tooltipIntendedCC;
    @FXML
    private Tooltip m_tooltipIntendedBCC;
    @FXML
    private ScrollPane m_id;
         int i = 0;
        int j=0;
  
//        MenuItem m_attachmentDownload = new MenuItem("DownLoad");
//        MenuItem m_attachmentRemove = new MenuItem("Remove");
MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);  
AlarmProfilesDTO alarmProfilesDTO = msghndlr.getAlarmProfiles(sm_name);
 public String m_successAlarmFlag;
    public String m_errorAlarmFlag;
    public String m_infoAlarmFlag;
    public String m_warningFlag;
    protected static List<String> dataList() {
        return data;
    }

    protected static List<String> dataListIntendedTO() {
        return dataIntentedeTo;

    }

    protected static List<String> dataccList() {
        return datacc;

    }

    protected static List<String> databccList() {
        return databcc;

    }
    
    public static String messageType;
    public static String messageInstruction;
    public static List<String> dataIntentedeTo;
    public static String precedencevaleforIntendedTo = "";
    public static String classificationvaleforIntendedTo = "";
    public static List<String> datacc;
    public static List<String> dataIntendedCC;
    public static List<String> data;
    public static List<String> databcc;
    public static List<String> dataIntendedBCC;
    boolean Attachflag = false;
    ArrayList<File> m_fileList = new ArrayList<File>();
    File finalFilesArray[];
    
ArrayList<File> m_fileListFTP = new ArrayList<File>();
    File m_finalArrayFTP[];
    public static File file = null;
    public Boolean isAttachment = false;
    final BooleanProperty selectbtnSignedReceipt = new SimpleBooleanProperty();
    public String username = sm_name;
    public ObservableList<String> Category_value = FXCollections.observableArrayList("Restrictive", "Permissive", "Informative");
    public ObservableList<String> Policy_value = FXCollections.observableArrayList("NATO", "National");
//    public ObservableList<String> precedence_value = FXCollections.observableArrayList("Flash", "Emergency", "OpImmediate", "Priority", "Routine", "Deferred");
//    public ObservableList<String> Classification_value = FXCollections.observableArrayList("TopSecret", "Secret", "Confidential", "Restricted", "Unclassified");
     public List<String> m_precedenceList = new ArrayList<String>();
    public List<String> m_classificationValue = new ArrayList<String>();
    public ObservableList<String> precedence_value; 
    public ObservableList<String> Classification_value;
    public ObservableList<String> SicList = FXCollections.observableArrayList();
    public StringBuilder listdatBcc = new StringBuilder();

    public String FinalEmailIntendedBcc;
    public String fianlIntendedBCC;
    public StringBuilder toUser = new StringBuilder();
    public String intendedEmailList = "";
    public String FinalEmailCC = "";
    public String FinalEmailIntendedccmail = "";
    public StringBuilder listdatacc = new StringBuilder();
    public String newclassification;
    public String newprecedence;
    public String email1 = "";
    public String subject;
    public String body;
    public String senderOfficeName = "";
    public String getMailID = "";
    public String policyValue = "";
    public String categoryValue = "";
    public String precedence;
    public String security_level;
    public String From;
    public String OriginalSender;
    public String Read_Receipt;
    public String attach_file;
    public String split[];
    public String finalEmailList = "";
    public String securityMark;
    public String sicvalue = null;
    public List<String> AttchmntSuccessList;
    public List<String> AttchmntFailurList;
    public String encval = "";
    public int[] files;
    public int max_attch_size_allowed;
    public ArrayList<String> mailIds = new ArrayList<String>();
    public ObservableList<String> MsgType = FXCollections.observableArrayList("Exercise", "Operation", "Project", "Drill");
    ArrayList<String> m_array = new ArrayList<String>();
    String fromOffice = "";
    String bccOfficeDU = "";
    String OriginalReceiver = "";
    String ccOffice = "";
    String bccOffice = "";
    String sic = "";
    String OriginalBcc = "";
    String receiverOfficeDesignatedUser = "";
    String encryption = "";
    String signed_receipt_receiptfrom = "";
    String ccOfficeDU = "";
    String security_category = "";
    String Approver = "";
    String To = "";
    String DSN = "";
    String ContentType = "";
    String DSNTo = "";
    String ReturnPath = "";
    String XOriginalTo = "";
    String security_policy = "";
    String OriginalCc = "";
    String DeliveredTo = "";
    String Received = "";
    String msgInstruction = "";
    String Reviewer = "";
    String Date = "";
    String Subject = "";
    String MIME_Version = "";
    String signed_receipt = "";
    String mailMsgType = "";
    String RecDate = "";
    String groupMailIdTo = "";
    String GroupMailIdCc = "";
    String GroupMailIdBcc = "";
    String security_privacy_mark="";

    /**
     * ******************************************************************
     * @Function Name : initialize
     * @Description : initialize method of Approve window and load required
     * variables in initialize.
     * @Input Parameter :NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 4th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     //   combBoxMsgType.setDisable(true);
//        ContextMenu menu=new ContextMenu();
//        menu.getItems().addAll(m_attachmentDownload, m_attachmentRemove);
//        m_attachLabel.add(m_sp, 0, 1);
//        m_attachLabel.setHgrow(m_sp, Priority.ALWAYS);
        removeTo.setVisible(false);
        imgviewto.setVisible(false);
        removeIntendedTo.setVisible(false);
        imgviewintendedto.setVisible(false);
        removeCC.setVisible(false);
        imgviewCC.setVisible(false);
        removeIntendedCC.setVisible(false);
        imgviewIntendedCC.setVisible(false);
        imgviewBCC.setVisible(false);
        removeBCC.setVisible(false);
        imgviewIntendedBCC.setVisible(false);
        removeIntendeBCC.setVisible(false);
        removeAttachment.setVisible(false);
        imgviewAttachment.setVisible(false);
        txtMsgInstruction.setEditable(false);
        btn_accept.setDisable(false);
        btnReject_mail.setDisable(false);
        send_mail.setVisible(false);
        txtSubject.setEditable(false);
        btnBCC.setDisable(true);
        Compose_to_btn.setDisable(true);
        IntendeTo.setDisable(true);
        btncc.setDisable(true);
        txtPrivacy.setEditable(false);
        btnintendedcc.setDisable(true);
        btnintendedBCC.setDisable(true);
        attch_file.setDisable(true);
        chkReadReceipt.setDisable(true);
        checkSignedReceipt.setDisable(true);
        txtSIC.setEditable(false);
        chkEncryption.setDisable(true);
        msgBody.setDisable(true);
        m_imageApproveForward.setVisible(false);
       
//          if (send_mail.isVisible() == true) {
//          dragdrop();
//      }
      // m_attachmentRemove.setVisible(false);
        MailDTO outputDTO;
        
        try {
            int c = Integer.parseInt(mail_id);

            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID(c);
            inputDTO.setFolder("inbox");

            outputDTO = msghndlr.readSpecificeMail(inputDTO);
            if (outputDTO.getHeaderMap().get("uid") != null) {
                System.out.println("UID: " + outputDTO.getHeaderMap().get("uid"));
            }

            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
            String fromOffice = (String) headers.get("fromOffice");
            String bccOfficeDU = (String) headers.get("bccOfficeDU");
            String split[];
            if (headers.get("attachedFileName") != null) {
                
                attach_file = (String) headers.get("attachedFileName");
                System.out.println("ATTACHMENT FILE"+attach_file);
                String Split[]=attach_file.split(",");
                        for(int i=0;i<Split.length;i++)
	{
		m_array.add(Split[i]);
	}
             while(i<Split.length){
            for(j=0;j<Split.length;j++){
            Label labl=new Label();
            Button closeButton = new Button("X");
             labl.setText(Split[j]+" ");   
           
             closeButton.setStyle("-fx-font-size:5pt;-fx-background-color:white;-fx-text-fill:red;-fx-font-weight:bold;");
           //  labl.setContextMenu(menu);
              m_attachLabel.add(labl,i,0);
                   
                    i++;
          
           labl.setOnMouseEntered(new EventHandler<MouseEvent>() {
          @Override
          public void handle(MouseEvent e) {
            labl.setStyle("-fx-font-weight:BOLD;-fx-text-fill:#090E00;-fx-background-color:#EEF6FF;-fx-font-size:13");
              if(send_mail.isVisible()==true) 
          {
            closeButton.setVisible(true);
            labl.setGraphic(closeButton);
          labl.setContentDisplay(ContentDisplay.TOP.RIGHT);
            closeButton.setOnMouseClicked(e1 -> {
             m_attachLabel.getChildren().remove(labl);
              m_array.remove(labl.getText().trim());
             System.out.println("Array values After"+m_array);
                        });
          }
        
      }}); 
         
        labl.setOnMouseExited(new EventHandler<MouseEvent>() {
          @Override
          public void handle(MouseEvent e) {
              labl.setStyle("-fx-background-color:#F4F4F4;");
              
      if(send_mail.isVisible()==true) 
          {
               closeButton.setVisible(true);
          }
    else
    {
       closeButton.setVisible(false); 
    }
          }
        });
           labl.setOnMousePressed((e ) -> {                   // <-- I tried this way,
          
//       m_attachmentDownload.setOnAction(new EventHandler<ActionEvent>(){
//      public void handle(ActionEvent e) {
     System.out.println("Attach FIle Name download:"+labl.getText()); 
    String m_downloadFileName=labl.getText().trim();
           file_download(m_downloadFileName);
//          
//                     
//      }
//    });  
// m_attachmentRemove.setOnAction(new EventHandler<ActionEvent>(){
//      public void handle(ActionEvent e) {
//       System.out.println("Attach FIle Name download:"+labl.getText()); 
//         labl.setText(null);
//                     
//      }
//    });  
           
            });

           }
     }
            }

            if ((String) headers.get("sic") != null) {
                sic = (String) headers.get("sic");
            }
            if ((String) headers.get("precedence") != null) {
                precedence = (String) headers.get("precedence");
            }
            if ((String) headers.get("originalSender") != null) {
                OriginalSender = (String) headers.get("originalSender");
            }
            if ((String) headers.get("originalBcc") != null) {
                OriginalBcc = (String) headers.get("originalBcc");
            }
            if ((String) headers.get("receiverOfficeDesignatedUser") != null) {
                receiverOfficeDesignatedUser = (String) headers.get("receiverOfficeDesignatedUser");
            }
            if ((String) headers.get("encryption") != null) {
                encryption = (String) headers.get("encryption");
            }
            if ((String) headers.get("signed_receipt_receiptfrom") != null) {
                signed_receipt_receiptfrom = (String) headers.get("signed_receipt_receiptfrom");
            }
            if ((String) headers.get("ccOfficeDU") != null) {
                ccOfficeDU = (String) headers.get("ccOfficeDU");
            }
            if ((String) headers.get("security_category") != null) {
                security_category = (String) headers.get("security_category");
            }
            if ((String) headers.get("Approver") != null) {
                Approver = (String) headers.get("Approver");
            }
            if ((String) headers.get("toOffice") != null) {
                To = (String) headers.get("toOffice");
            }
            if ((String) headers.get("DSN") != null) {
                DSN = (String) headers.get("DSN");
            }
            if ((String) headers.get("Content-Type") != null) {
                ContentType = (String) headers.get("Content-Type");
            }
            if ((String) headers.get("DSNTo") != null) {
                DSNTo = (String) headers.get("DSNTo");
            }
            if ((String) headers.get("Return-Path") != null) {
                ReturnPath = (String) headers.get("Return-Path");
            }
            if ((String) headers.get("X-Original-To") != null) {
                XOriginalTo = (String) headers.get("X-Original-To");
            }
            if ((String) headers.get("originalReceiver") != null) {
                OriginalReceiver = (String) headers.get("originalReceiver");
            }
            System.out.println("Intended User" + OriginalReceiver);
            if ((String) headers.get("security_policy") != null) {
                security_policy = (String) headers.get("security_policy");
            }
            if ((String) headers.get("Received") != null) {
                Received = (String) headers.get("Received");
            }
            if ((String) headers.get("From") != null) {
                From = (String) headers.get("From");
            }
            if ((String) headers.get("MsgType") != null) {
                MsgType = (ObservableList<String>) headers.get("MsgType");
            }
            if ((String) headers.get("messageType") != null) {
                messageType = (String) headers.get("messageType");
            }
            if ((String) headers.get("messageInstructions") != null) {
                msgInstruction = (String) headers.get("messageInstructions");
            }
            if ((String) headers.get("Reviewer") != null) {
                Reviewer = (String) headers.get("Reviewer");
            }
            if ((String) headers.get("Date") != null) {
                Date = (String) headers.get("Date");
            }
            if ((String) headers.get("Subject") != null) {
                Subject = (String) headers.get("Subject");
            }
            if ((String) headers.get("MIME-Version") != null) {
                MIME_Version = (String) headers.get("MIME-Version");
            }
            if ((String) headers.get("security_level") != null) {
                security_level = (String) headers.get("security_level");
            }
            if ((String) headers.get("signed_receipt") != null) {
                signed_receipt = (String) headers.get("signed_receipt");
            }
            if ((String) headers.get("mailMsgType") != null) {
                mailMsgType = (String) headers.get("mailMsgType");
            }
            if ((String) headers.get("read_receipt") != null) {
                Read_Receipt = (String) headers.get("read_receipt");
            }
           if((String) headers.get("security_privacy_mark")!=null){
            security_privacy_mark = (String) headers.get("security_privacy_mark");
            }
            if ((String) headers.get("originalCc") != null) {
                OriginalCc = (String) headers.get("originalCc");
            }
            if ((String) headers.get("Delivered-To") != null) {
                DeliveredTo = (String) headers.get("Delivered-To");
            }
//            String signed_receipt_receiptto = (String) headers.get("signed_receipt_receiptto");
            if ((String) headers.get("groupMailIdTo") != null) {
                groupMailIdTo = (String) headers.get("groupMailIdTo");
            }
            if ((String) headers.get("groupMailIdCc") != null) {
                GroupMailIdCc = (String) headers.get("groupMailIdCc");
            }
            if ((String) headers.get("groupMailIdBcc") != null) {
                GroupMailIdBcc = (String) headers.get("groupMailIdBcc");
            }
            if ((String) headers.get("ccOffice") != null) {
                ccOffice = (String) headers.get("ccOffice");
            }
            if ((String) headers.get("bccOffice") != null) {
                bccOffice = (String) headers.get("bccOffice");
            }
            if ((String) headers.get("Date") != null) {
                RecDate = (String) headers.get("Date");
            }
            ObservableList<String> Policy_value = FXCollections.observableArrayList(security_policy);
            ObservableList<String> Category_value = FXCollections.observableArrayList(security_level);
            ObservableList<String> combobox_category = FXCollections.observableArrayList(security_category);
            ObservableList<String> combobox_precednc = FXCollections.observableArrayList(precedence);

            from_name.setText(outputDTO.getFrom());
            to_mail.setText(To);
            lblcc.setText(ccOffice);
            lblBCC.setText(bccOffice);
            //lblintendedBCC.setText(data.get);security_level)
            System.out.println("REVIEWER OROGINAL Reciver" + OriginalReceiver);
            lblIntendeTo.setText(OriginalReceiver + " " + groupMailIdTo);
            lblintendedcc.setText(OriginalCc + " " + GroupMailIdCc);
            lblintendedBCC.setText(OriginalBcc + " " + GroupMailIdBcc);
                if (groupMailIdTo.length()!=0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(groupMailIdTo);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedTo.setText(str.toString());
            }
            if (GroupMailIdCc.length()!=0 ) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(GroupMailIdCc);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedCC.setText(str.toString());
            }
            if (GroupMailIdBcc.length()!=0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(GroupMailIdBcc);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedBCC.setText(str.toString());
            }
            txtSubject.setText(outputDTO.getSubject());
            msgBody.setHtmlText(outputDTO.getContent());
            Combobox_classification.setPromptText(security_level);
            txtSIC.setPromptText(sic);
            txtPrivacy.setText(security_privacy_mark);
            Combobox_precednce.setPromptText(precedence);
            Combobox_category.setPromptText(security_category);
            Combobox_policy.setPromptText(security_policy);
            lblRecivDate.setText(RecDate);
            txtSIC.setPromptText(sic);
            txtMsgInstruction.setText(msgInstruction);
            combBoxMsgType.setPromptText(messageType);
            if (Read_Receipt.equalsIgnoreCase("true")) {
                chkReadReceipt.setSelected(true);
            }
            if (security_level.equalsIgnoreCase("TopSecret")) {
                change_lable.setText("TOP-SECRET");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: red;");
            } else if (security_level.equalsIgnoreCase("Secret")) {
                change_lable.setText("SECRET");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: orange;");
            } else if (security_level.equalsIgnoreCase("Confidential")) {
                System.out.println("Entered the confidential..........");
                change_lable.setText("CONFIDENTIAL");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: blue;");
            } else if (security_level.equalsIgnoreCase("Restricted")) {
                change_lable.setText("RESTRICTED");
                change_lable.setTextFill(Color.web("Black"));
                change_lable.setStyle("-fx-background-color: yellow;");
            } else if (security_level.equalsIgnoreCase("Unclassified")) {
                change_lable.setText("UNCLASSIFIED");
                change_lable.setTextFill(Color.web("black"));
                change_lable.setStyle("-fx-background-color: white;");
            }

        } catch (Exception e) {
            System.out.println("View mmail working");
        }

        Node node = msgBody.lookup(".top-toolbar");
        if (node instanceof ToolBar) {
            ToolBar bar = (ToolBar) node;
            Button smurfButton = new Button("Insert Table");
            Label row = new Label();
            row.setText("Row:");
            TextField rowField = new TextField("0");
            rowField.setPrefWidth(30);
            Label column = new Label();
            column.setText("Column:");
            TextField columnField = new TextField("0");
            columnField.setPrefWidth(30);
            Button insertImage = new Button("Insert Image");
            bar.getItems().addAll(smurfButton, row, rowField, column, columnField, insertImage);
            smurfButton.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent arg0) {
                    StringBuilder tableContent = new StringBuilder();
                    tableContent.append("<table style='border-collapse:collapse; border: 1px solid black;'>");
                    for (int i = 0; i < Integer.parseInt(rowField.getText()); i++) {
                        tableContent.append("<tr >");
                        for (int j = 0; j < Integer.parseInt(columnField.getText()); j++) {
                            tableContent.append("<td width='100px' height='30px' style='border-collapse:collapse; border: 1px solid black;'>").append("</td>");
                        }
                        tableContent.append("</tr >");
                    }
                    tableContent.append("</table ><br>");
                    msgBody.setHtmlText(msgBody.getHtmlText() + tableContent);
                }
            });
            insertImage.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent arg0) {
                    FileChooser fileChooser = new FileChooser();
                    fileChooser.setTitle("Select Image");
                    FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("All images", new String[]{"*.JPEG", "*.PNG", "*.png", "*.jpg", "*.JPG", "*.gif"});
                    fileChooser.getExtensionFilters().add(extFilter);
                    File file = fileChooser.showOpenDialog(new Stage());
                    try {
                        byte[] bytes = loadFile(file);
                        byte[] encoded = Base64.getEncoder().encode(bytes);
                        String encodedString = new String(encoded);
                        System.out.println("encodedString" + encodedString);
                        msgBody.setHtmlText(
                                msgBody.getHtmlText()
                                + "<img src='data:image/png;base64," + encodedString + "'>");
                    } catch (IOException ex) {
                        Logger.getLogger(ComposePageContrller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
        }
    }

    /**
     * ******************************************************************
     * @Function Name : loadFile
     * @Description : for importing image in mail body.
     * @Input Parameter :File file
     * @Output Parameter	:return bytes
     * @Author : Manoj Kumar Meghwal
     * @Created Date :18 May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    private static byte[] loadFile(File file) throws IOException {
        InputStream is = new FileInputStream(file);

        long length = file.length();
        if (length > Integer.MAX_VALUE) {
            // File is too large
        }
        byte[] bytes = new byte[(int) length];

        int offset = 0;
        int numRead = 0;
        while (offset < bytes.length
                && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
            offset += numRead;
        }

        if (offset < bytes.length) {
            throw new IOException("Could not completely read file " + file.getName());
        }

        is.close();
        return bytes;
    }
    MailSenderInfo obj = msghndlr.preCheck(username);

    /**
     * ******************************************************************
     * @Function Name : sendmailPrecheck
     * @Description : for checking or validating before sending mail.
     * @Input Parameter : NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 12th may 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public void sendmailPrecheck() {

        senderOfficeName = obj.getOfficeName();
        getMailID = obj.getMailId();
    }
        public  ObservableList<String> getPescedenceValue(){ 
            final ObservableList<String> PescedenceValueList = FXCollections.<String>observableArrayList();
            List<GetAllPrecedenceConfigDTO> allPrecedenceConfig = msghndlr.getAllPrecedenceConfig();
    for(GetAllPrecedenceConfigDTO data: allPrecedenceConfig){
            PescedenceValueList.add(data.getPrecvalue());
    }
     return PescedenceValueList;
    
}
 public  ObservableList<String> getClassificationValue(){ 
            final ObservableList<String> classificationValueList = FXCollections.<String>observableArrayList();
            List<GetAllSecurityClassConfigDTO> allPrecedenceConfig = msghndlr.getAllSecurityClassConfig();
    for(GetAllSecurityClassConfigDTO data: allPrecedenceConfig){
            classificationValueList.add(data.getSecclassvalue());
    }
     return classificationValueList;
    
}

    /**
     * ******************************************************************
     * @Function Name : checkboxrecept
     * @Description : for getting value from checkBox read receipt
     * @Input Parameter : NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date :13th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public boolean checkboxrecept() {
        boolean isSelect = chkReadReceipt.isSelected();
        if (isSelect) {
            chkReadReceipt.setSelected(true);
        } else {
            chkReadReceipt.setSelected(false);
        }
        System.out.println("isSelect" + isSelect);
        return isSelect;

    }

    /**
     * ******************************************************************
     * @Function Name : encryptionCheck
     * @Description : for getting value from checkBox encryption.
     * @Input Parameter : NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 13th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public boolean encryptionCheck() {
        boolean isSelect = chkEncryption.isSelected();
        if (isSelect) {
            chkEncryption.setSelected(true);
        } else {
            chkEncryption.setSelected(false);
        }
        System.out.println("isSelect" + isSelect);
        return isSelect;

    }

    /**
     * ******************************************************************
     * @Function Name : stripHTMLTags
     * @Description : for extracting exact mail body from html tags.
     * @Input Parameter : String htmlText
     * @Output Parameter	: sb.toString().trim()
     * @Author : Ram Krishna Paul
     * @Created Date : 13th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    private String stripHTMLTags(String htmlText) {

        Pattern pattern = Pattern.compile("<[^>]*>");
        Matcher matcher = pattern.matcher(htmlText);
        final StringBuffer sb = new StringBuffer(htmlText.length());
        while (matcher.find()) {
            matcher.appendReplacement(sb, " ");
        }
        matcher.appendTail(sb);
        System.out.println(sb.toString().trim());
        return sb.toString().trim();
    }

    /**
     * ******************************************************************
     * @Function Name : clickBtnSendMail
     * @Description : for sending mail
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date :15th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public Boolean clickBtnSendMail(ActionEvent event) throws Exception {

        MailDTO outputDTO;
        String retVal = "false";
        subject = txtSubject.getText();
        body = msgBody.getHtmlText();
        if (Combobox_policy.getSelectionModel().getSelectedItem() != null) {
            policyValue = Combobox_policy.getSelectionModel().getSelectedItem().toString();
        }
        if (Combobox_category.getSelectionModel().getSelectedItem() != null) {
            categoryValue = Combobox_category.getSelectionModel().getSelectedItem().toString();
        }
        String msgTypee ="";
        if(combBoxMsgType.getSelectionModel().getSelectedItem()!=null){
        msgTypee=combBoxMsgType.getSelectionModel().getSelectedItem().toString();
        }
        
        String txtmessageInstruction = "";
        if(txtMsgInstruction.getText()!=null){
        txtmessageInstruction=txtMsgInstruction.getText();
        }
       
        Long c = Long.parseLong(mail_id);

        ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
        inputDTO.setMsgUID(c.intValue());
        inputDTO.setFolder("inbox");

        outputDTO = msghndlr.readSpecificeMail(inputDTO);
        HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
        String msgType1 = (String) headers.get("msgType");

        headers.put("msgType", "SENDTODESIGNATEDUSER");

        String FinalIntendedTO = "";
        if (dataIntentedeTo != null) {
            for (int i = 0; i < dataIntentedeTo.size(); i++) {
                String temp = dataIntentedeTo.get(i).toString();

                if (i >= 0 && i < dataIntentedeTo.size() - 1) {
                    FinalIntendedTO = FinalIntendedTO + temp + ",";
                } else {
                    FinalIntendedTO = FinalIntendedTO + temp;
                }
            }
        }
        String FinalTO = "";
        if (data != null) {
            for (int i = 0; i < data.size(); i++) {
                String temp = data.get(i).toString();

                if (i >= 0 && i < data.size() - 1) {
                    FinalTO = FinalTO + temp + ",";
                } else {
                    FinalTO = FinalTO + temp;
                }

            }
        }
        boolean readFlag = checkboxrecept();
        String readVal = "";
        if (readFlag) {
            readVal = "true";
        } else {
            readVal = "false";
        }

        boolean encryptFlag = encryptionCheck();

        if (encryptFlag) {
            encval = "true";
        } else {
            encval = "false";
        }

        String tempStr = "";
        String htmlText = msgBody.getHtmlText();

        tempStr = stripHTMLTags(htmlText);
        if (tempStr == null || tempStr.isEmpty()) {
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Enter Message Body for the mail").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Enter Message Body for the mail ");
            alert.showAndWait();
            return false;
        }
        securityMark = txtPrivacy.getText();
        outputDTO.setSubject(subject);
        outputDTO.setContent(body);

        if (!FinalTO.isEmpty()) {
            headers.put("toOffice", FinalTO);
        }

        if (listdatacc.length() != 0) {
            headers.put("ccOffice", listdatacc);
        }

        if (listdatBcc.length() != 0) {
            headers.put("bccOffice", listdatBcc);
        }

        headers.put("originalSender", From);

        if (!FinalIntendedTO.isEmpty()) {
            headers.put("originalReceiver", FinalIntendedTO);
        }
        if (!FinalEmailIntendedccmail.isEmpty()) {
            headers.put("originalCc", FinalEmailIntendedccmail);
        }

        if (fianlIntendedBCC != null) {
            headers.put("originalBcc", fianlIntendedBCC);
        }

        if (!precedencevaleforIntendedTo.isEmpty()) {
            headers.put("precedence", precedencevaleforIntendedTo);
        }
        if (!policyValue.isEmpty()) {
            headers.put("security_policy", policyValue);
        }
        if (!classificationvaleforIntendedTo.isEmpty()) {
            headers.put("security_level", classificationvaleforIntendedTo);
        }
        if (!securityMark.isEmpty()) {
            headers.put("security_privacy_mark", securityMark);
        }
        if (!categoryValue.isEmpty()) {
            headers.put("security_category", categoryValue);
        }
        if (msgTypee != null) {
            headers.put("messageType", msgTypee);
        }
        if (txtmessageInstruction != null) {
            headers.put("messageInstructions", txtmessageInstruction);
        }
        headers.put("msgType", "SENDTODESIGNATEDUSER");

        outputDTO.setMsgType("SENDTODESIGNATEDUSER");
        outputDTO.setHeaderMap(headers);
        boolean inteto = true;
//        if (dataIntentedeTo == null || dataIntentedeTo.isEmpty()) {
//            Approve_view_pageController.ALERT_AUDIOCLIP2.play();
//            Platform.runLater(() -> {
//                Notifications.create().text("Compose Mail-" + "\nAre you sure want to send mail without Intended To Users !").showWarning();
//            });
//            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
//            alert.setTitle("Confirmation - Compose Mail");
//            alert.setHeaderText(null);
//            alert.setContentText("Are you sure want to send mail without Intended To Users !");
//            Optional<ButtonType> result = alert.showAndWait();
//            if (result.get() == ButtonType.OK) {
//                inteto = true;
//            } else if (result.get() == ButtonType.CANCEL) {
//                inteto = false;
//                return false;
//            }
//        }

        if (inteto) {

            String strReceiverOffice = "";
            if (dataIntentedeTo != null) {
                for (int i = 0; i < dataIntentedeTo.size(); i++) {
                    String temp = dataIntentedeTo.get(i).toString();
                    //strReceiverOffice = data.get(i).toString();
                    if (i >= 0 && i < dataIntentedeTo.size() - 1) {
                        strReceiverOffice = strReceiverOffice + temp + ";";
                    } else {
                        strReceiverOffice = strReceiverOffice + temp;
                    }

                }
            }

            if (isAttachment) {
              if (m_attachLabel.contains(Point2D.ZERO)) {
                 
                    mailIds.clear();
                    if(!strReceiverOffice.equals(""))
                    {
                        OriginalReceiver=strReceiverOffice;
                    }
                    StringTokenizer stMailId = new StringTokenizer(OriginalReceiver, ";");
                    while (stMailId.hasMoreTokens()) {
                        mailIds.add(stMailId.nextToken());
                    }
                    System.out.println("Mail Ids List: " + mailIds.toString());
                    AttachmentClearenceDTO dto = new AttachmentClearenceDTO();
                    if (file.length() != 0) {
                        dto.setAttachmentSize((long) file.length());
                    } else {
                        dto.setAttachmentSize((long) 0);
                    }
                    dto.setUserMailIds(mailIds.toArray(new String[0]));
                    Attachflag = true;

                    ResultDTO dtoAttachClearance = (ResultDTO) msghndlr.checkAttachmentClearence(dto);
                    AttchmntSuccessList = dtoAttachClearance.getSuccess();
                    AttchmntFailurList = dtoAttachClearance.getFailure();
                    System.out.println("list1" + AttchmntSuccessList);
                    System.out.println("list1" + AttchmntFailurList);

                    String filureListofAttach = "";
                    for (int i = 0; i < AttchmntFailurList.size(); i++) {
                        String temp = AttchmntFailurList.get(i).toString();
                        //strReceiverOffice = data.get(i).toString();
                        if (i >= 0 && i < AttchmntFailurList.size() - 1) {
                            filureListofAttach = filureListofAttach + temp + ",";
                        } else {
                            filureListofAttach = filureListofAttach + temp;
                        }

                    }

                    if (AttchmntFailurList.size() > 0) {

                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.initStyle(StageStyle.UTILITY);
                        alert.setTitle("Error- Attachment Clearence");
                        alert.setHeaderText(null);
                        alert.setContentText("The Following Users are not authorized to Receive Attachment in a mail -" + filureListofAttach);
                        alert.showAndWait();
                        return false;
                    }
                }
            }
            try {
                
            if(headers.get("Received")!=null)
                         {
                             headers.remove("Received");
                         }
                        if(headers.get("From")!=null)
                         {
                             headers.remove("From");
                         }
                        
                        if(headers.get("To")!=null)
                         {
                              headers.remove("To");
                         }
                        
                        if(headers.get("Content-Type")!=null)
                         {
                             headers.remove("Content-Type");
                         }
                        
                      if(headers.get("DSN")!=null)
                         {
                               headers.remove("DSN");
                         }
                        if(headers.get("DSNTo")!=null)
                         {
                          headers.remove("DSNTo");
                         }
                        if(headers.get("X-Original-To")!=null)
                         {
                              headers.remove("X-Original-To");
                         }
                        
                        if(headers.get("sentDT")!=null)
                         {
                              headers.remove("sentDT");
                         }
                                                                   
                        if(headers.get("Message-ID")!=null)
                         {
                              headers.remove("Message-ID");
                         }
                          if(headers.get("MIME-Version")!=null)
                         {
                              headers.remove("MIME-Version");
                         }
                             if(headers.get("attachedFileName")!=null)
                         {
                              headers.remove("attachedFileName");
                         }
                                if(headers.get("Return-Path")!=null)
                         {
                              headers.remove("Return-Path");
                         }
                         if(headers.get("Date")!=null)
                         {
                              headers.remove("Date");
                         }
                         if(headers.get("Delivered-To")!=null)
                         {
                              headers.remove("Delivered-To");
                         }
                          if(headers.get("toRecipient")!=null)
                         {
                              headers.remove("toRecipient");
                         }
                        if(headers.get("Content-Transfer-Encoding")!=null)
                         {
                              headers.remove("Content-Transfer-Encoding");
                         }                                  
                        StringBuffer buffer = new StringBuffer();
             for (int i = 0; i < m_array.size(); i++) {
                    //arr[i] = m_array.get(i);
                    buffer.append(m_array.get(i) + ",");
                }
                headers.put("fileToForward", buffer);

                 //headers.put("fileToForward",lblattachfile.getText());
               outputDTO.setHeaderMap(headers);
                retVal = "false";
                retVal = "false";
                 finalFilesArray = new File[m_fileList.size()];
            for (int i = 0; i < m_fileList.size(); i++) {
                finalFilesArray[i] = m_fileList.get(i);
            }
              Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
            alert1.setTitle("Confirmation-Send Mail");
            alert1.setHeaderText(null);
            alert1.setContentText("Are you sure to Send Mail");
            Optional<ButtonType> result = alert1.showAndWait();
            if (result.get() == ButtonType.OK) {
                  if (securityStatusFlag) {
                 Stage stageSecurity = new Stage();
                    Parent rootSecurity;
                    FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/Security.fxml"));
                    rootSecurity = (Parent) fXMLLoader.load();
                    SecurityController securityController = fXMLLoader.getController();
                    stageSecurity.setScene(new Scene(rootSecurity));
                    stageSecurity.setTitle("Security");
                    stageSecurity.initModality(Modality.APPLICATION_MODAL);
//                stageTo.initOwner(OK.getScene().getWindow());
                    stageSecurity.toFront();
                    stageSecurity.getIcons().add(new Image("/img/Mail-icon.png"));
                    stageSecurity.showAndWait();
                    stageSecurity.setResizable(false);
                    if (securityController.sendSecurityFlag) {
                        retVal = msghndlr.sendMailWthAtchmnt(outputDTO, finalFilesArray,securityStatusFlag);
                    } 
                  }
                  else{
                      retVal = msghndlr.sendMailWthAtchmnt(outputDTO, finalFilesArray,securityStatusFlag); 
                  }
            }
            } catch (Exception e) {
                   retVal = "false";
                System.err.println("exception is" + e);
            }

            if (retVal.equalsIgnoreCase("true")) {
                if(msghndlr.getAlarmProfiles(sm_name).getSuccessAlarm()!=null)
                {
                m_successAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getSuccessAlarm();
                 if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                      Approve_view_pageController.sm_audioSound.play();
                    }
                }
                Platform.runLater(() -> {
                    Notifications.create().text("Send Mail-" + "\nMail Sent SuccessFully..").showInformation();
                });
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.initStyle(StageStyle.UTILITY);
                alert.setTitle("Information-Send Mail");
                alert.setHeaderText(null);
                alert.setContentText("Mail Sent SuccessFully..");
                alert.showAndWait();
                ArrayList<Long> list = new ArrayList<Long>();
                list.add(c);
                DeleteInput dto = new DeleteInput();
                dto.setFolder("inbox");
                dto.setMsgUID(list);
                String status = msghndlr.deleteMail(dto);
                System.out.println(status);
                final Node Source = (Node) event.getSource();
                final Stage stage = (Stage) Source.getScene().getWindow();
                stage.close();
            } else if (retVal.equalsIgnoreCase("false")) {
                if(msghndlr.getAlarmProfiles(sm_name).getErrorAlarm()!=null){
                m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                 if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                             Approve_view_pageController.sm_audioAlert.play();
                 }
                }
                Platform.runLater(() -> {
                    Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
                });
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.initStyle(StageStyle.UTILITY);
                alert.setTitle("Error-Send Mail");
                alert.setHeaderText(null);
                alert.setContentText("Failed to Send Mail..");
                alert.showAndWait();

            } else if (retVal.equalsIgnoreCase("StoredInOutBox")) {
                  if(msghndlr.getAlarmProfiles(sm_name).getErrorAlarm()!=null){
                m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                 if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                             Approve_view_pageController.sm_audioAlert.play();
                 }
                  }
                Platform.runLater(() -> {
                    Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
                });
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.initStyle(StageStyle.UTILITY);
                alert.setTitle("Error-Send Mail");
                alert.setHeaderText(null);
                alert.setContentText("Stored In Out Box");
                alert.showAndWait();

            } else if (retVal.equalsIgnoreCase("No Sic List Found")) {
                  if(msghndlr.getAlarmProfiles(sm_name).getErrorAlarm()!=null){
                 m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                 if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                             Approve_view_pageController.sm_audioAlert.play();
                 }
                  }
                Platform.runLater(() -> {
                    Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
                });
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.initStyle(StageStyle.UTILITY);
                alert.setTitle("Error-Send Mail");
                alert.setHeaderText(null);
                alert.setContentText("No Sic List Found");
                alert.showAndWait();

            } else if (retVal.equalsIgnoreCase("No Profile found")) {
                  if(msghndlr.getAlarmProfiles(sm_name).getErrorAlarm()!=null){
                  m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                 if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                             Approve_view_pageController.sm_audioAlert.play();
                 }
                  }
                Platform.runLater(() -> {
                    Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
                });
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.initStyle(StageStyle.UTILITY);
                alert.setTitle("Error-Send Mail");
                alert.setHeaderText(null);
                alert.setContentText("No Profile found");
                alert.showAndWait();

            }

        }
        return null;

    }

    /**
     * ******************************************************************
     * @Function Name : checkFileSize
     * @Description : for checking attachment in Approve mail window
     * @Input Parameter : NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 18th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public boolean checkFileSize() {
        boolean retVal = false;
        // max_attch_size_allowed=attachmentAuthentication();
        if (file.length() > max_attch_size_allowed) {
            String msg = "";
            int rem_siz = max_attch_size_allowed;
            int int_siz = rem_siz;
            if (int_siz < 1024) {
                msg = (rem_siz) + " Bytes ";
            } else if (int_siz >= 1024 && int_siz < (1024 * 1024)) {
                msg = rem_siz / 1024 + " KB ";
            } else if (int_siz >= (1024 * 1024) && int_siz < (1024 * 1024 * 1024)) {
                msg = rem_siz / 1024 / 1024 + " MB ";
            } else if (int_siz >= (1024 * 1024 * 1024)) {
                msg = rem_siz / 1024 / 1024 / 1024 + " GB ";
            }
            Platform.runLater(() -> {
                Notifications.create().text("Warning - Add Attachment" + "\nFile size is exceed.").showInformation();
            });
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Information - Add Attachment");
            alert.setHeaderText(null);
            alert.setContentText("File size is exceed.You can't send more than" + msg);
            alert.showAndWait();
//            System.out.println("The file must be less than " + msg);
//            file.length();
            retVal = false;
               m_fileListFTP.add(file);
             m_finalArrayFTP = new File[m_fileListFTP.size()];
            for (int i = 0; i < m_fileListFTP.size(); i++) {
                m_finalArrayFTP[i] = m_fileListFTP.get(i);
            }
            System.out.println("List of FTP files"+m_finalArrayFTP);
          List<String> flag = msghndlr.uploadFileToFTP(m_finalArrayFTP);
            
          msgBody.setHtmlText(flag.toString());
            System.out.println("FTP Upload FILE "+flag);

        }  else {
            System.out.println("File can able to send");
            retVal = true;
            m_fileList.add(file);
            
            
        }
        return retVal;
    }

    /**
     * ******************************************************************
     * @Function Name : Compose_to
     * @Description : for choosing office for To users
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 10th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    private void compose_to(ActionEvent event) throws IOException {
        if (lblIntendeTo != null) {
            lblIntendeTo.setText(null);
        }
        Stage stageTo = new Stage();
        Parent rootTo;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/To_mail.fxml"));
        rootTo = (Parent) fXMLLoader.load();
        To_mail_Controller to_mail_Controller = fXMLLoader.getController();
        stageTo.setScene(new Scene(rootTo));
        stageTo.setTitle("Send Mail To");
        stageTo.initModality(Modality.APPLICATION_MODAL);
        stageTo.initOwner(Compose_to_btn.getScene().getWindow());
        stageTo.toFront();
        stageTo.showAndWait();
        stageTo.setResizable(false);
        data = to_mail_Controller.add_list.getSelectionModel().getSelectedItems();
        data = to_mail_Controller.selectedToOffice;
        toUser = new StringBuilder();
        for (String userTo : data) {
            toUser.append(userTo + ",");
        }
        to_mail.setText(toUser.toString());
    }

    /**
     * ******************************************************************
     * @Function Name : textintendedto
     * @Description : for disabling and enabling of SIC value on selection of
     * intendedTo
     * @Input Parameter : null
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 10th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public void textintendedto() {

        if (lblIntendeTo.getText() == null || lblIntendeTo.getText().isEmpty()) {
            txtSIC.setDisable(false);
        } else {
            txtSIC.setDisable(true);
            txtSIC.setItems(null);
        }
    }

    /**
     * ******************************************************************
     * @Function Name : OpenIntendeTo
     * @Description : for adding intended to users
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 10th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void openIntendeTo(ActionEvent event) throws IOException {
        if (Combobox_precednce.getSelectionModel().getSelectedItem() == null || Combobox_classification.getSelectionModel().getSelectedItem() == null) {
            classificationvaleforIntendedTo = security_level;
            precedencevaleforIntendedTo = precedence;
        } else if (Combobox_precednce.getSelectionModel().getSelectedItem().toString() != null || Combobox_classification.getSelectionModel().getSelectedItem().toString() != null) {
            newclassification = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
            newprecedence = Combobox_classification.getSelectionModel().getSelectedItem().toString();
            classificationvaleforIntendedTo = newclassification;
            precedencevaleforIntendedTo = newprecedence;
        }

        Stage stageIntendedTo = new Stage();
        Parent rootIntendedTo;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/IntendedToModifyApprove.fxml"));
        rootIntendedTo = (Parent) fXMLLoader.load();
        IntendedToModifyApproveController intendedToController = fXMLLoader.getController();
        stageIntendedTo.setScene(new Scene(rootIntendedTo));
        stageIntendedTo.setTitle("Intended To");
        stageIntendedTo.initModality(Modality.APPLICATION_MODAL);
        stageIntendedTo.initOwner(IntendeTo.getScene().getWindow());
        stageIntendedTo.toFront();
        stageIntendedTo.showAndWait();
        stageIntendedTo.setResizable(false);
        stageIntendedTo.getIcons().add(new Image("/img/Mail-icon.png"));

        dataIntentedeTo = intendedToController.EmailIntendedTo.getSelectionModel().getSelectedItems();
        dataIntentedeTo = intendedToController.selectedIntendedToOffice;
        StringBuilder mailIdsList = new StringBuilder();

        for (String email : dataIntentedeTo) {
            mailIdsList.append(email + ",");
            email1 += email + ",";

        }
        StringBuilder finalEmail = mailIdsList;
        intendedEmailList = finalEmail.substring(0, finalEmail.length() - 1);
        lblIntendeTo.setText(intendedEmailList.toString());
        textintendedto();
    }

    /**
     * ******************************************************************
     * @Function Name : ClickBtnCC
     * @Description : for adding cc office name.
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 10th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void clickBtnCC(ActionEvent event) throws IOException {
        if (lblintendedcc != null) {
            lblintendedcc.setText(null);
        }
        if (lblIntendeTo.getText() == null || lblIntendeTo.getText().isEmpty()) {
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Intended To").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning-Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select Intended To ");
            alert.showAndWait();

        } else {
            Stage stageCC = new Stage();
            Parent root1;
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/CCFXML.fxml"));
            root1 = (Parent) fXMLLoader.load();
            CCFXMLController cCFXMLController = fXMLLoader.getController();
            stageCC.setScene(new Scene(root1));
            stageCC.setTitle("CC");
            stageCC.initModality(Modality.APPLICATION_MODAL);
            stageCC.initOwner(btncc.getScene().getWindow());
            stageCC.toFront();
            stageCC.showAndWait();
            stageCC.setResizable(false);
            stageCC.getIcons().add(new Image("/img/Mail-icon.png"));
            datacc = cCFXMLController.selectedccOffice;
            listdatacc = new StringBuilder();
            for (String recDataFromCC : datacc) {
                listdatacc.append(recDataFromCC + ",");
            }
            lblcc.setText(listdatacc.toString());
        }
    }

    /**
     * ******************************************************************
     * @Function Name : onClickIntendedCC
     * @Description : for adding intended CC users
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 10th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void onClickIntendedCC(ActionEvent event) throws IOException {
        if (Combobox_precednce.getSelectionModel().getSelectedItem() == null || Combobox_classification.getSelectionModel().getSelectedItem() == null) {
            classificationvaleforIntendedTo = security_level;
            precedencevaleforIntendedTo = precedence;
        } else if (Combobox_precednce.getSelectionModel().getSelectedItem().toString() != null || Combobox_classification.getSelectionModel().getSelectedItem().toString() != null) {
            newclassification = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
            newprecedence = Combobox_classification.getSelectionModel().getSelectedItem().toString();
            classificationvaleforIntendedTo = newclassification;
            precedencevaleforIntendedTo = newprecedence;
        }

        Stage stageIntendedCC = new Stage();
        Parent rootintendedCC;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/IntendedCCModifyApproveFXML.fxml"));
        rootintendedCC = (Parent) fXMLLoader.load();
        IntendedCCModifyApproveFXMLController intendedCCController = fXMLLoader.getController();
        stageIntendedCC.setScene(new Scene(rootintendedCC));
        stageIntendedCC.setTitle("Intended CC");
        stageIntendedCC.initModality(Modality.APPLICATION_MODAL);
        stageIntendedCC.initOwner(btnintendedcc.getScene().getWindow());
        stageIntendedCC.toFront();
        stageIntendedCC.showAndWait();
        stageIntendedCC.setResizable(false);
        dataIntendedCC = intendedCCController.ListIntendedCC.getSelectionModel().getSelectedItems();
        dataIntendedCC = intendedCCController.selectedIntendedccOffice;
        StringBuilder emailIntendedCC = new StringBuilder();
        for (String emailintendedCC : dataIntendedCC) {
            emailIntendedCC.append(emailintendedCC + ",");
            FinalEmailCC += emailintendedCC + ",";
        }
        StringBuilder finalEmailIntendedCC = emailIntendedCC;
        FinalEmailIntendedccmail = finalEmailIntendedCC.substring(0, finalEmailIntendedCC.length() - 1);
        lblintendedcc.setText(FinalEmailIntendedccmail);

    }

    /**
     * ******************************************************************
     * @Function Name : onClickbtnBCC
     * @Description : for adding BCC office
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 15th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public void onClickbtnBCC(ActionEvent event) throws IOException {
        if (lblintendedBCC != null) {
            lblintendedBCC.setText(null);
        }
        if (lblintendedcc.getText() == null || lblintendedcc.getText().isEmpty()) {
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Select Intended CC").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning-Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select Intended CC ");
            alert.showAndWait();

        } else {
            Stage stageBCC = new Stage();
            Parent rootBCC;
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/BCC.fxml"));
            rootBCC = (Parent) fXMLLoader.load();
            BCCController bCCController = fXMLLoader.getController();
            stageBCC.setScene(new Scene(rootBCC));
            stageBCC.setTitle("BCC");
            stageBCC.initModality(Modality.APPLICATION_MODAL);
            stageBCC.initOwner(btnBCC.getScene().getWindow());
            stageBCC.toFront();
            stageBCC.showAndWait();
            stageBCC.setResizable(false);
            databcc = bCCController.ListBCC.getSelectionModel().getSelectedItems();
            databcc = bCCController.selectedBccOffice;
            listdatBcc = new StringBuilder();
            for (String userBcc : databcc) {
                listdatBcc.append(userBcc + ",");
            }
            lblBCC.setText(listdatBcc.toString());
        }
    }

    /**
     * ******************************************************************
     * @Function Name : onClickbtnBCC
     * @Description : for adding BCC office
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 15th May 2017
     * @Modification History: NA
     * ******************************************************************
     */

    public void clickbtnintendedBCC(ActionEvent event) throws IOException {
        if (Combobox_precednce.getSelectionModel().getSelectedItem() == null || Combobox_classification.getSelectionModel().getSelectedItem() == null) {
            classificationvaleforIntendedTo = security_level;
            precedencevaleforIntendedTo = precedence;
        } else if (Combobox_precednce.getSelectionModel().getSelectedItem().toString() != null || Combobox_classification.getSelectionModel().getSelectedItem().toString() != null) {
            newclassification = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
            newprecedence = Combobox_classification.getSelectionModel().getSelectedItem().toString();
            classificationvaleforIntendedTo = newclassification;
            precedencevaleforIntendedTo = newprecedence;
        }
        Stage stageIntedBCC = new Stage();
        Parent rootIntendedBCC;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/IntendedBCCApproveModify.fxml"));
        rootIntendedBCC = (Parent) fXMLLoader.load();
        IntendedBCCApproveModifyController intendedBCCController = fXMLLoader.getController();
        stageIntedBCC.setScene(new Scene(rootIntendedBCC));
        stageIntedBCC.setTitle("Intended BCC");
        stageIntedBCC.initModality(Modality.APPLICATION_MODAL);
        stageIntedBCC.initOwner(btnintendedBCC.getScene().getWindow());
        stageIntedBCC.toFront();
        stageIntedBCC.showAndWait();
        stageIntedBCC.setResizable(false);
        dataIntendedBCC = intendedBCCController.ListIntendedBCC.getSelectionModel().getSelectedItems();
        dataIntendedBCC = intendedBCCController.selectedIntendedBccOffice;
        StringBuilder emailIntendedBCC = new StringBuilder();
        for (String IntendedBCC : dataIntendedBCC) {
            emailIntendedBCC.append(IntendedBCC + ",");
            FinalEmailIntendedBcc += IntendedBCC + ",";
        }
        StringBuilder finalIntendedBCCEmail = emailIntendedBCC;
        fianlIntendedBCC = finalIntendedBCCEmail.substring(0, finalIntendedBCCEmail.length() - 1);
        lblintendedBCC.setText(fianlIntendedBCC);

    }

    @FXML
    private void onPrecedenceSelectaction(ActionEvent event) {
    }

    @FXML
    private void attach_action_btn(ActionEvent event) {

             try {
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Open File");
           FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Files (*.txt,*.zip,*.rar,*.jpg,*.html,*.docx,*.pdf,*.pptx,*.png,*.gif,*.xlsx)", "*.txt", "*.rar", "*.zip","*.jpg","*.html","*.docx","*.pdf","*.pptx","*.png","*.gif","*.xlsx");
         //   FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.*)", "*.*");
            chooser.getExtensionFilters().add(extFilter);
            file = chooser.showOpenDialog(null);
            if (file.exists()) {
                double bytes = file.length();
                double kilobytes = (bytes / 1024);
                double megabytes = (kilobytes / 1024);
                double gigabyes = (megabytes / 1024);
                double roundOffbytes = Math.floor(bytes * 100) / 100;
                double roundOff = Math.floor(kilobytes * 100) / 100;
                double roundOff1 = Math.floor(megabytes * 100) / 100;
                double roundOffgb = Math.floor(gigabyes * 100) / 100;

                Label m_fileName = new Label();

                String filename = file.getName();

                if (file.length() < 1024) {
                    m_fileName.setText(filename + "(" + roundOffbytes + " bytes" + ")");

                } else if (file.length() >= 1024 && file.length() < (1024 * 1024)) {
                    m_fileName.setText(filename + "(" + roundOff + " KB" + ")");
                    //m_attachLabel.addRow(i, m_fileName);
                } else if (file.length() >= (1024 * 1024) && file.length() < (1024 * 1024 * 1024)) {
                    m_fileName.setText(filename + "(" + roundOff1 + " MB" + ")");
                    // m_attachLabel.addRow(i, m_fileName);
                } else if (file.length() >= (1024 * 1024 * 1024)) {
                    m_fileName.setText(filename + "(" + roundOffgb + " GB" + ")");
                    //m_attachLabel.addRow(i, m_fileName);
                }
                int i = 0;
                isAttachment = checkFileSize();
                if (isAttachment == true) {
                    Button closeButton = new Button("X");
                    closeButton.setStyle("-fx-font-size:3pt;-fx-background-color:white;-fx-text-fill:red;");
                    m_attachLabel.addRow(i, m_fileName);
                    m_fileName.setOnMouseEntered(new EventHandler<MouseEvent>() {
                        @Override
                        public void handle(MouseEvent e) {
                            m_fileName.setStyle("-fx-font-weight:BOLD;-fx-text-fill:#090E00;-fx-background-color:#EEF6FF;-fx-font-size:13");
                            closeButton.setVisible(true);
                            m_fileName.setGraphic(closeButton);
                            m_fileName.setContentDisplay(ContentDisplay.TOP.RIGHT);
                            closeButton.setOnMouseClicked(e1 -> {
                                System.out.println("Before remove " + m_fileList);
                                int rmVal = 0;
                                int removeIndexFile = -1;
                                for (File remove_file : m_fileList) {

                                    String name = m_fileName.getText();
                                    System.out.println("File name Clicked" + name);

                                    System.out.println("ArrayList:" + remove_file.getName());
                                    System.out.println("name:" + name.toString());

                                    int firstIndex = name.lastIndexOf("(");
                                    //int lastIndex = name.lastIndexOf(")");
                                    name = name.subSequence(0, firstIndex).toString();

                                    System.out.println("value:" + name);

                                    if (remove_file.getName().equalsIgnoreCase(name)) {

                                        System.out.println("Removed..................");
                                        removeIndexFile = rmVal;
                                        
                                    } else {
                                        System.out.println("Not Removed..................");
                                    }
                                    rmVal++;
                                }
                                if (removeIndexFile != -1) {
                                    System.out.println("Test..." + removeIndexFile);
                                    m_fileList.remove(removeIndexFile);
                                    m_attachLabel.getChildren().remove(m_fileName);
                                }
           System.out.println("After remove "+m_fileList);
                        });
                  
      }});
             m_fileName.setOnMouseExited(new EventHandler<MouseEvent>() {
          @Override
          public void handle(MouseEvent e) {
         m_fileName.setStyle("-fx-background-color:#F4F4F4;");
         closeButton.setVisible(false); 
    
          }
        });
                
            }
        } else {
            Platform.runLater(() -> {
                Notifications.create().text("Warning" + "File Not Exist").showWarning();
            });
            System.out.println("file not exist");
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning");
            alert.setHeaderText(null);
            alert.setContentText("File Not Exist");
            alert.showAndWait();
            isAttachment = false;
        }
         } catch (Exception e) {
            System.out.println("Error" + e);
        }
    }

    @FXML
    private void selectbtnSignedReceipt(ActionEvent event) {
    }

    /**
     * ******************************************************************
     * @Function Name : onApproverReject
     * @Description : This method is use to Reject Mail.
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : RaviKiran Bhatt
     * @Created Date : 10th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    private void onApproverReject(ActionEvent event) {
        boolean reject = false;
        System.out.println("reject clicked");
        Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
        alert1.setTitle("Confirmation-Reject Mail");
        alert1.setContentText("Are you sure to Reject the Mail");
        alert1.setHeaderText(null);
        Optional<ButtonType> result = alert1.showAndWait();
        if (result.get() == ButtonType.OK) {
            String MSG = JOptionPane.showInputDialog("Reason for Reject Mail").toString();

            try {
                MailDTO outputDTOReject;
                Long c = Long.parseLong(mail_id);
                ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
                inputDTO.setMsgUID(c.intValue());
                inputDTO.setFolder("inbox");
                outputDTOReject = msghndlr.readSpecificeMail(inputDTO);
                HashMap<Object, Object> headersget = (HashMap<Object, Object>) outputDTOReject.getHeaderMap();
                String msgType1 = (String) headersget.get("msgType");
                System.out.println("MESSAGE TYPE::" + msgType1);
                headersget.put("msgType", "REJECTMAIL");
                headersget.put("rejectedMailUid", mail_id);
                String msg = (String) headersget.get("msgType");

                String OriginalSender = (String) headersget.get("originalSender");
                MailDTO input = new MailDTO();
                input = outputDTOReject;

                input.setToRecipient(OriginalSender);
                input.setSubject("RejectedMail" + outputDTOReject.getSubject());
                input.setContent(MSG);
                input.setFrom(sm_name);
                input.setHeaderMap(headersget);
                reject = msghndlr.rejectMail(input);

                if (reject) {
                    if( msghndlr.getAlarmProfiles(sm_name).getSuccessAlarm()!=null){
                    m_successAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getSuccessAlarm();
                 if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                         Approve_view_pageController.sm_audioSound.play();
                    }
                    }
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Information-Reject Mail");
                    alert.setHeaderText(null);
                    alert.setContentText("Mail Rejected SuccessFully");
                    alert.showAndWait();

                    final Node Source = (Node) event.getSource();
                    final Stage stage = (Stage) Source.getScene().getWindow();
                    stage.close();
                    ArrayList<Long> list = new ArrayList<Long>();
                    list.add(c);
                    DeleteInput dto = new DeleteInput();
                    dto.setFolder("inbox");
                    dto.setMsgUID(list);
                    String status = msghndlr.deleteMail(dto);
                    System.out.println(status);
                } else {
                    if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                        m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                        if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                            Approve_view_pageController.sm_audioAlert.play();
                        }
                    }
                   
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Error -Reject Mail");
                    alert.setHeaderText(null);
                    alert.setContentText("Failed to Reject the Mail..");
                    alert.showAndWait();
                }
            } catch (Exception e) {
                //e.printStackTrace();
                System.out.println("Not able to reject mail");
            }
            read_approvemail.close();
        }

    }

    /**
     * ******************************************************************
     * @Function Name : on_click_cancel
     * @Description : for Canceling of approve mail window.
     * @Input Parameter :ActionEvent
     * @Output Parameter	:NA
     * @Author : Ram Krishna Paul
     * @Created Date : 16th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    private void on_click_cancel(ActionEvent event) {

        read_approvemail.close();
    }

    /**
     * ******************************************************************
     * @Function Name : onApproveModifyMail
     * @Description : for modifying of mail in approve mail window.
     * @Input Parameter :ActionEvent
     * @Output Parameter	:NA
     * @Author : Ram Krishna Paul
     * @Created Date : 16th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    private void onApproveModifyMail(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation-Modify Mail");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure  to Modify the Mail !");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            combBoxMsgType.setDisable(false);
            txtMsgInstruction.setDisable(false);
            txtMsgInstruction.setEditable(true);
            send_mail.setVisible(true);
            btn_accept.setVisible(false);
            btnReject_mail.setVisible(false);
            btn_modify.setVisible(false);
            txtSubject.setEditable(true);
            btnBCC.setDisable(false);
            lblBCC.setDisable(false);
            from_name.setDisable(false);
            Compose_to_btn.setDisable(false);
            to_mail.setDisable(false);
            IntendeTo.setDisable(false);
            lblIntendeTo.setDisable(false);
            btncc.setDisable(false);
            lblcc.setDisable(false);
            btnintendedcc.setDisable(false);
            lblintendedcc.setDisable(false);
            btnintendedBCC.setDisable(false);
            attch_file.setDisable(false);
            Combobox_precednce.setDisable(false);
            Combobox_policy.setDisable(false);
            Combobox_classification.setDisable(false);
            Combobox_category.setDisable(false);
            chkReadReceipt.setDisable(false);
            checkSignedReceipt.setDisable(false);
            chkEncryption.setDisable(false);
            txtSIC.setEditable(true);
            msgBody.setDisable(false);
            txtPrivacy.setEditable(true);
               m_imageApproveForward.setVisible(true);
            m_imageApproveAccept.setVisible(false);
            m_imageApproveReject.setVisible(false);
            m_approveModifyImg.setVisible(false);
          //  m_attachmentRemove.setVisible(true);
                    m_precedenceList=getPescedenceValue();
        precedence_value =FXCollections.observableArrayList(m_precedenceList); 
        m_classificationValue=getClassificationValue();
        Classification_value =FXCollections.observableArrayList(m_classificationValue);
            Combobox_category.setItems(Category_value);
            Combobox_classification.setItems(Classification_value);
            Combobox_policy.setItems(Policy_value);
            Combobox_precednce.setItems(precedence_value);
            combBoxMsgType.setItems(MsgType);
            dragdrop();
        }
    }
     public int attachmentAuthentication() {
        if (obj.getAttachmentSendAuth().equals("YES")) {
            String str = null;
            String str2 = null;
            if (obj.getAttachmentMaxSize().length() == 3) {
                str2 = (String) obj.getAttachmentMaxSize().substring(0, 1);
                System.out.println("size  1is: " + str2);
            } else if (obj.getAttachmentMaxSize().length() == 4) {
                str2 = (String) obj.getAttachmentMaxSize().substring(0, 2);
                System.out.println("in mb): " + str2);
            }

            if (obj.getAttachmentMaxSize().length() == 3) {
                str = (String) obj.getAttachmentMaxSize().substring(1, 3);
                System.out.println("size is: " + str);
            } else if (obj.getAttachmentMaxSize().length() == 4) {
                str = (String) obj.getAttachmentMaxSize().substring(2, 4);
                System.out.println("mb " + str);
            }

            if (str.equalsIgnoreCase("kb")) {

                int numKB = Integer.parseInt(str2);

                max_attch_size_allowed = numKB * 1024;

            } else if (str.equalsIgnoreCase("mb")) {
                int numMB = Integer.parseInt(str2);

                max_attch_size_allowed = numMB * 1024 * 1024;

            } else if (str.equalsIgnoreCase("gb")) {
                int numGB = Integer.parseInt(str2);
                max_attch_size_allowed = numGB * 1024 * 1024 * 1024;
            }

            attch_file.setDisable(false);
          
        } else {

            attch_file.setDisable(true);
        }
          return max_attch_size_allowed;
    }

    /**
     * ******************************************************************
     * @Function Name : onApproveAccptMail
     * @Description : for Approving accepted mail in approve mail window.
     * @Input Parameter :ActionEvent
     * @Output Parameter	:NA
     * @Author : RaviKiran Bhatt
     * @Created Date : 17th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    private void onApproveAccptMail(ActionEvent event) {
        System.out.println("Accept clicked");
        Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
        alert1.setTitle("Confirmation-Accept Mail");
        alert1.setHeaderText(null);
        alert1.setContentText("Are you sure to Accept the Mail");

        //  alert.setContentText("Are you sure want to LOg Out!");
        Optional<ButtonType> result = alert1.showAndWait();
        if (result.get() == ButtonType.OK) {
            MailDTO outputDTO;
            try {
                Long c = Long.parseLong(mail_id);

                ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
                inputDTO.setMsgUID(c.intValue());
                inputDTO.setFolder("inbox");

                outputDTO = msghndlr.readSpecificeMail(inputDTO);
                HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
                try {
                    System.out.println("Msg Type: " + outputDTO.getMsgType());
                    HashMap<Object, Object> headersStore = (HashMap<Object, Object>) outputDTO.getHeaderMap();
                    String msgType1 = (String) headersStore.get("msgType");
                    System.out.println("OFFICE MSG TYPE:" + msgType1);
                    String acceptval = "false";
                    if (msgType1.equalsIgnoreCase("REVIEWACCEPT")) {
                         if(headersStore.get("Received")!=null)
                         {
                             headersStore.remove("Received");
                         }
                        if(headersStore.get("From")!=null)
                         {
                             headersStore.remove("From");
                         }
                        
                        if(headersStore.get("To")!=null)
                         {
                              headersStore.remove("To");
                         }
                        
                        if(headersStore.get("Content-Type")!=null)
                         {
                             headersStore.remove("Content-Type");
                         }
                        
                      if(headersStore.get("DSN")!=null)
                         {
                               headersStore.remove("DSN");
                         }
                        if(headersStore.get("DSNTo")!=null)
                         {
                          headersStore.remove("DSNTo");
                         }
                        if(headersStore.get("X-Original-To")!=null)
                         {
                              headersStore.remove("X-Original-To");
                         }
                        
                        if(headersStore.get("sentDT")!=null)
                         {
                              headersStore.remove("sentDT");
                         }
                                                                   
                        if(headersStore.get("Message-ID")!=null)
                         {
                              headersStore.remove("Message-ID");
                         }
                          if(headersStore.get("MIME-Version")!=null)
                         {
                              headersStore.remove("MIME-Version");
                         }
                            if(headersStore.get("attachedFileName")!=null)
                         {
                              headersStore.remove("attachedFileName");
                         }
                            if(headersStore.get("Return-Path")!=null)
                         {
                              headersStore.remove("Return-Path");
                         }
                         if(headersStore.get("Date")!=null)
                         {
                              headersStore.remove("Date");
                         }
                         if(headersStore.get("Delivered-To")!=null)
                         {
                              headersStore.remove("Delivered-To");
                         }
                         if(headersStore.get("toRecipient")!=null)
                         {
                              headersStore.remove("toRecipient");
                         }
                          if(headersStore.get("Content-Transfer-Encoding")!=null)
                         {
                              headersStore.remove("Content-Transfer-Encoding");
                         }
//                         if(headersStore.get("attachedFileName")!=null)
//                         {
                               headersStore.put("fileToForward", attach_file);
                        // }
                        headersStore.put("msgType", "SENDTODESIGNATEDUSER");
                        outputDTO.setHeaderMap(headersStore);
                        outputDTO.setFrom(msghndlr.preCheck(sm_name).getMailId());
                        try {
                              if (securityStatusFlag) {
                            Stage stageSecurity = new Stage();
                            Parent rootSecurity;
                            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/Security.fxml"));
                            rootSecurity = (Parent) fXMLLoader.load();
                            SecurityController securityController = fXMLLoader.getController();
                            stageSecurity.setScene(new Scene(rootSecurity));
                            stageSecurity.setTitle("Security");
                            stageSecurity.initModality(Modality.APPLICATION_MODAL);
//                stageTo.initOwner(OK.getScene().getWindow());
                            stageSecurity.toFront();
                            stageSecurity.getIcons().add(new Image("/img/Mail-icon.png"));
                            stageSecurity.showAndWait();
                            stageSecurity.setResizable(false);
                            if (securityController.sendSecurityFlag) {
                                acceptval = msghndlr.sendMailWthAtchmnt(outputDTO, null,securityStatusFlag);
                            } 
                              }
                              else{
                                    acceptval = msghndlr.sendMailWthAtchmnt(outputDTO, null,securityStatusFlag);
                              }
                        } catch (Exception e) {
                            System.err.println("exception is" + e);
                        }

                        if (acceptval.equalsIgnoreCase("true")) {
                            if(msghndlr.getAlarmProfiles(sm_name).getSuccessAlarm()!=null)
                            {
                            m_successAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getSuccessAlarm();
                 if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                         Approve_view_pageController.sm_audioSound.play();
                    }
                            }   
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.initStyle(StageStyle.UTILITY);
                            alert.setTitle("Information - Send Mail");
                            alert.setHeaderText(null);
                            alert.setContentText("Mail Accepted SuccessFully");
                            alert.showAndWait();

                            final Node Source = (Node) event.getSource();
                            final Stage stage = (Stage) Source.getScene().getWindow();
                            stage.close();
                            ArrayList<Long> list = new ArrayList<Long>();
                            list.add(c);
                            DeleteInput dto = new DeleteInput();
                            dto.setFolder("inbox");
                            dto.setMsgUID(list);
                            String status = msghndlr.deleteMail(dto);
                            System.out.println(status);
                        } else if (acceptval.equalsIgnoreCase("false")) {
                            if(msghndlr.getAlarmProfiles(sm_name).getErrorAlarm()!=null)
                            {
                            m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                 if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                             Approve_view_pageController.sm_audioAlert.play();
                 }
                            }       Platform.runLater(() -> {
                                Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
                            });
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.initStyle(StageStyle.UTILITY);
                            alert.setTitle("Error-Send Mail");
                            alert.setHeaderText(null);
                            alert.setContentText("Failed to Accept the Mail..");
                            alert.showAndWait();

                        } else if (acceptval.equalsIgnoreCase("StoredInOutBox")) {
                              if(msghndlr.getAlarmProfiles(sm_name).getErrorAlarm()!=null)
                            {
                             m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                 if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                             Approve_view_pageController.sm_audioAlert.play();
                 }
                            }
                            Platform.runLater(() -> {
                                Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
                            });
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.initStyle(StageStyle.UTILITY);
                            alert.setTitle("Error-Send Mail");
                            alert.setHeaderText(null);
                            alert.setContentText("Stored In OutBox");
                            alert.showAndWait();

                        } else if (acceptval.equalsIgnoreCase("No Sic List Found")) {
                              if(msghndlr.getAlarmProfiles(sm_name).getErrorAlarm()!=null)
                            {
                          m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                 if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                             Approve_view_pageController.sm_audioAlert.play();
                 }
                            }
                            Platform.runLater(() -> {
                                Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
                            });
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.initStyle(StageStyle.UTILITY);
                            alert.setTitle("Error-Send Mail");
                            alert.setHeaderText(null);
                            alert.setContentText("No Sic List Found");
                            alert.showAndWait();

                        } else if (acceptval.equalsIgnoreCase("No Profile found")) {
                              if(msghndlr.getAlarmProfiles(sm_name).getErrorAlarm()!=null)
                            {
                            m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                 if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                             Approve_view_pageController.sm_audioAlert.play();
                 }
                            }
                            Platform.runLater(() -> {
                                Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
                            });
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.initStyle(StageStyle.UTILITY);
                            alert.setTitle("Error-Send Mail");
                            alert.setHeaderText(null);
                            alert.setContentText("No Profile found");
                            alert.showAndWait();

                        }

                    }
                } catch (Exception e) {
                    System.out.println(e.getStackTrace());
                    e.printStackTrace();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            read_approvemail.close();
        }

    }

    @FXML
    private void on_selection_classification(ActionEvent event) {
    }

    /**
     * ******************************************************************
     * @Function Name : on_attach_click
     * @Description : for downloading attachment in approve mail window.
     * @Input Parameter :ActionEvent
     * @Output Parameter	:NA
     * @Author : RaviKiran Bhatt
     * @Created Date : 17th May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    
    public void file_download(String file_name)
    {               
  
            FileDialog fd2 = new FileDialog(new Frame(), "SAVE FILE", FileDialog.SAVE);
            fd2.setFile(file_name);
            fd2.setVisible(true);
            String dir = fd2.getDirectory();
            fd2.setAlwaysOnTop(true);
            if (dir != null) {

            //    File downloadFile = msghndlr.downloadFile(attach_file.substring(0, attach_file.length() - 1));
            
              File downloadFile = msghndlr.downloadFile(file_name);
                if (downloadFile != null) {

                    FileInputStream instream = null;
                    try {
                        instream = new FileInputStream(downloadFile);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }

                    String dest_path = dir + downloadFile;
                 //   String final_dest_path = dest_path.split("_")[0];
                    OutputStream out = null;
                    try {

                        out = new FileOutputStream(dest_path);

                    } catch (Exception e1) {

                        e1.printStackTrace();
                    }
                    byte[] buffer = new byte[4096];
                    int bytesRead = -1;
                    try {
                        while ((bytesRead = instream.read(buffer)) != -1) {
                            out.write(buffer, 0, bytesRead);
                            System.out.println("FILE contents"+out);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        instream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        out.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                     }
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Information-Download File");
                    alert.setHeaderText(null);
                    alert.setContentText("File Downloaded SuccessFully");
                    alert.showAndWait();
                  
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Error-Download File");
                    alert.setHeaderText(null);
                    alert.setContentText("Unable to download file, try later");
                    alert.showAndWait();
                }

            } else {
                System.out.println("Directory is not selected:");
            }
       
    }
  public void dragdrop() {
       attachmentAuthentication();
        m_id.setOnDragOver(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                Dragboard db = event.getDragboard();
                if (db.hasFiles()) {
                    System.out.println("tst HAS FILES" + db.getString());
                    event.acceptTransferModes(TransferMode.COPY);
                } else {
                    event.consume();
                }
            }
        });

        m_id.setOnDragDropped(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                Dragboard db = event.getDragboard();
                boolean success = false;
                if (db.hasFiles()) {
                    success = true;
                    String filePath = null;

                    for (File file : db.getFiles()) {

                        filePath = file.getAbsolutePath();
                        System.out.println("Darg Drop" + filePath);
                        long m_lengnth = file.length();
                        if (file.exists()) {
                            double bytes = file.length();
                            double kilobytes = (bytes / 1024);
                            double megabytes = (kilobytes / 1024);
                            double gigabyes = (megabytes / 1024);
                            double roundOffbytes = Math.floor(bytes * 100) / 100;
                            double roundOff = Math.floor(kilobytes * 100) / 100;
                            double roundOff1 = Math.floor(megabytes * 100) / 100;
                            double roundOffgb = Math.floor(gigabyes * 100) / 100;

                            Label m_fileName = new Label();

                            String filename = file.getName();

                            if (file.length() < 1024) {
                                m_fileName.setText(filename + "(" + roundOffbytes + " bytes" + ")");

                            } else if (file.length() >= 1024 && file.length() < (1024 * 1024)) {
                                m_fileName.setText(filename + "(" + roundOff + " KB" + ")");
                                //m_attachLabel.addRow(i, m_fileName);
                            } else if (file.length() >= (1024 * 1024) && file.length() < (1024 * 1024 * 1024)) {
                                m_fileName.setText(filename + "(" + roundOff1 + " MB" + ")");
                                // m_attachLabel.addRow(i, m_fileName);
                            } else if (file.length() >= (1024 * 1024 * 1024)) {
                                m_fileName.setText(filename + "(" + roundOffgb + " GB" + ")");
                                //m_attachLabel.addRow(i, m_fileName);
                            }

                            System.out.println("GET TEXT:" + m_fileName.getText());

                            int i = 0;

                            //boolean m_attach=attchmentfilCheck();
                            System.out.println("File length" + m_lengnth);
                            System.out.println("Max file length" + max_attch_size_allowed);
                            if (max_attch_size_allowed > m_lengnth) {
                                m_fileList.add(file);

                                // if (isAttachment == true) {
                                System.out.println("IS Attachment true");
                                Button closeButton = new Button("X");
                                closeButton.setStyle("-fx-font-size:5pt;-fx-background-color:white;-fx-text-fill:red;-fx-font-weight:bold;");
                                m_attachLabel.addRow(i, m_fileName);
                                System.out.println("Added the row");
                                m_fileName.setOnMouseEntered(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent e) {
                                        m_fileName.setStyle("-fx-font-weight:BOLD;-fx-text-fill:#090E00;-fx-background-color:#EEF6FF;-fx-font-size:13");

                                        closeButton.setVisible(true);
                                        m_fileName.setGraphic(closeButton);
                                        m_fileName.setContentDisplay(ContentDisplay.TOP.RIGHT);
                                        closeButton.setOnMouseClicked(e1 -> {
                                            System.out.println("Before remove " + m_fileList);
                                            //StringBuffer name= new StringBuffer(m_fileName.getText().toString());

                                            //String m_splt[]=m_fileName.getText().split("(");
                                            int rmVal = 0;
                                            int removeIndexFile = -1;
                                            for (File remove_file : m_fileList) {

                                                String name = m_fileName.getText();
                                                System.out.println("File name Clicked" + name);

                                                System.out.println("ArrayList:" + remove_file.getName());
                                                System.out.println("name:" + name.toString());

                                                int firstIndex = name.lastIndexOf("(");
                                                //int lastIndex = name.lastIndexOf(")");
                                                name = name.subSequence(0, firstIndex).toString();

                                                System.out.println("value:" + name);

                                                if (remove_file.getName().equalsIgnoreCase(name)) {

                                                    System.out.println("Removed..................");
                                                    removeIndexFile = rmVal;
                                                    //m_fileList.remove(remove_file);
                                                    //m_fileList.remove(rmVal);

                                                } else {
                                                    System.out.println("Not Removed..................");
                                                }
                                                rmVal++;
                                            }
                                            if (removeIndexFile != -1) {
                                                System.out.println("Test..." + removeIndexFile);
                                                m_fileList.remove(removeIndexFile);
                                                m_attachLabel.getChildren().remove(m_fileName);
                                            }

                                            System.out.println("After remove " + m_fileList);
                                        });

                                    }
                                });
                                m_fileName.setOnMouseExited(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent e) {
                                        m_fileName.setStyle("-fx-background-color:#F4F4F4;");
                                        closeButton.setVisible(false);

                                    }
                                });

                            } else {
                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                alert.initStyle(StageStyle.UTILITY);
                                alert.setTitle("Warning - Add Attachment");
                                alert.setHeaderText(null);
                                alert.setContentText("File size is exceed.You can't send");
                                alert.showAndWait();
                                 m_fileListFTP.add(file);
                                m_finalArrayFTP = new File[m_fileListFTP.size()];
                                for (int k = 0; k < m_fileListFTP.size(); k++) {
                                    m_finalArrayFTP[k] = m_fileListFTP.get(k);
                                }
                                System.out.println("List of FTP files" + m_finalArrayFTP);
                                List<String> flag = msghndlr.uploadFileToFTP(m_finalArrayFTP);

                                msgBody.setHtmlText(flag.toString());
                                System.out.println("FTP Upload FILE " + flag);
                            }

                        } else {
                            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                                if (m_warningFlag.equalsIgnoreCase("true")) {
                                  Approve_view_pageController.sm_audioSound.play();
                                }
                            }

                            Platform.runLater(() -> {
                                Notifications.create().text("Warning" + "File Not Exist").showWarning();
                            });
                            System.out.println("file not exist");
                            Alert alert = new Alert(Alert.AlertType.WARNING);
                            alert.initStyle(StageStyle.UTILITY);
                            alert.setTitle("Warning");
                            alert.setHeaderText(null);
                            alert.setContentText("File Not Exist");
                            alert.showAndWait();
                            isAttachment = false;
                        }
                    }

                }
                event.setDropCompleted(success);
                event.consume();
            }
        });
    }
    }
