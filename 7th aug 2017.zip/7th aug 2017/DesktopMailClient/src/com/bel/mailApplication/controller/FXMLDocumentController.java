package com.bel.mailApplication.controller;

import Test.AuthorisationObserver;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import com.bel.utility.DBConnection;
import com.bel.mailApplication.model.AddressBookpojo;
import com.bel.mailApplication.model.Usermstpojo;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import static com.bel.mailApplication.controller.LoginFXMLController.root1;
import com.bel.mailApplication.model.ApproveTabList;
import com.bel.mailApplication.model.DraftTabList;
import com.bel.mailApplication.model.SentMailList;
import com.bel.mailApplication.model.OfficeTabList;
import com.bel.mailApplication.model.OutTabList;
import com.bel.mailApplication.model.RiviewTabList;
import com.bel.mailApplication.model.InBoxTabList;
import com.bel.mailApplication.model.TrashTabList;
import com.jfoenix.controls.JFXListView;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTimePicker;
import com.jfoenix.controls.JFXTreeView;
import java.time.Clock;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javafx.scene.Node;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TablePosition;
import javafx.scene.control.TextArea;
import javafx.scene.input.ScrollEvent;
import javafx.util.Callback;
import mail.awan.beans.AddrBook;
import mail.awan.beans.AddressBookOwner;
import mail.awan.beans.Contact;
import mail.awan.beans.ContactInfoDTO;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.textfield.TextFields;
import com.bel.mailApplication.pdfGenerate.GeneratePDF;
import com.ldap.entity.Tcs_Users;

import static com.bel.mailApplication.controller.LoginFXMLController.SecurityClssificationConfigList;
import static com.bel.mailApplication.controller.LoginFXMLController.prcedenceList;
//import static com.bel.mailApplication.controller.FXMLDocumentController.msgType;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_netStatus;
import com.bel.mailApplication.model.PersonalCertificate;
import com.bel.mailApplication.progress.ProgressServices;
import com.bel.mailApplication.progress.ProgressServicesApproveMail;
import com.bel.mailApplication.progress.ProgressServicesDraftMail;
import com.bel.mailApplication.progress.ProgressServicesOfficeMail;
import com.bel.mailApplication.progress.ProgressServicesOutBoxMail;
import com.bel.mailApplication.progress.ProgressServicesReview;
import com.bel.mailApplication.progress.ProgressServicesSentMail;
import com.bel.mailApplication.progress.ProgressServicesTrashMail;
import com.entity.MailDTO;
import com.google.common.collect.Sets;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTabPane;
import java.awt.Desktop;
import java.io.File;
import java.time.LocalTime;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Task;
import javafx.geometry.Rectangle2D;
import javafx.print.Collation;
import javafx.scene.Parent;
import javafx.scene.control.Pagination;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableRow;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.StageStyle;
import jfxtras.scene.layout.HBox;
import mail.awan.beans.AlarmProfilesDTO;
import mail.awan.beans.CertificateInfo;
import mail.awan.beans.ContactsOfAddrBkDTO;
import mail.awan.beans.DeleteDto;
import mail.awan.beans.DeleteInput;
import mail.awan.beans.GetAllPrecedenceConfigDTO;
import mail.awan.beans.GetAllSecurityClassConfigDTO;
import mail.awan.beans.PrecedenceDTO;
import mail.awan.beans.PrintDTO;
import mail.awan.beans.ReceiveMailInputDTO;
import mail.awan.beans.SearchMailDTO;
import mail.awan.beans.SecurityClassConfigDTO;
import mail.awan.beans.ViewFolderMailsDTO;
import mail.awan.util.AuthorisationCheck;
import org.controlsfx.control.Notifications;

/**
 * ******************************************************************
 * @File Name : FXMLDocumentController
 * @Author : Ravikiran Bhat.
 * @Package : com.bel.mailApplication.controller
 * @Purpose : Display Main Page
 * @Created Date	:6-MAR-2017
 * @Modification History:NA
 * ******************************************************************
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private BorderPane boarder_pane = new BorderPane();
    private static final AudioClip ALERT_AUDIOCLIP1 = new AudioClip(FXMLDocumentController.class.getResource("/sounds/sound1.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP2 = new AudioClip(FXMLDocumentController.class.getResource("/sounds/sound2.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP4 = new AudioClip(FXMLDocumentController.class.getResource("/sounds/sound4.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP5 = new AudioClip(FXMLDocumentController.class.getResource("/sounds/sound5.wav").toString());
    private final Image imgorange = createImage(50, 13, Color.ORANGE);
    private final Image imglightblue = createImage(50, 13, Color.LIGHTBLUE);
    private final Image imgtomato = createImage(50, 13, Color.TOMATO);
    private final Image imglightgreen = createImage(50, 13, Color.LIGHTGREEN);
    private final Image imgyellow = createImage(50, 13, Color.YELLOW);
    private final Image imgpink = createImage(50, 13, Color.PINK);
    @FXML
    private Button addressbookRefresh;
    @FXML
    private BorderPane mainpane;
    @FXML
    private Label lblfmm;
    @FXML
    private TabPane tabpane;
    @FXML
    private TabPane insidetab;
    @FXML
    private JFXTabPane m_certificateTab;
    @FXML
    private HBox hboxtopmenu;
    @FXML
    private HBox hboxuserandlogout;
    @FXML
    private Pane paneRefCoDePrButton;
    @FXML
    private Pane paneShowTable;
    @FXML
    private GridPane gridpaneInbox;
    @FXML
    private GridPane gridpaneReview;
    @FXML
    private GridPane gridpaneApprove;
    @FXML
    private GridPane gridpaneApproveOffice;
    @FXML
    private GridPane gridpaneSentMail;
    @FXML
    private GridPane gridpaneOutBox;
    @FXML
    private GridPane gridpaneDraft;
    @FXML
    private GridPane gridpaneTrash;
    @FXML
    private GridPane m_prsnlCertfctGridpane;
    @FXML
    private GridPane m_otherCertfctGridpane;
    @FXML
    private HBox hboxmenuAddressBook;
    @FXML
    private HBox hboxAddressbook;
    @FXML
    private VBox vboxAddress;
    @FXML
    private VBox vboxContactlist;
    @FXML
    private VBox vboxContactDetails;
    @FXML
    private Pane paneaddressbook;
    private Pane paneSearch;
    @FXML
    private HBox searchHbox;
    @FXML
    private Pane pane1;
    @FXML
    private Label lblinboxview;
    @FXML
    private Label lblsentmailview;
    @FXML
    private Label lbloutboxview;
    @FXML
    private Label m_lblPersonalSerialNumber;
    @FXML
    private Label m_lablPersnlCrtIssuseTo;
    @FXML
    private Label m_lablPersnlCrtIssuseBy;
    @FXML
    private Label m_lablPersnlCrtExpiratioDate;
    @FXML
    private Label lblDraftview;
    @FXML
    private Label lblTrashview;
    @FXML
    private Label lblinboxreview;
    @FXML
    private Label lblinboxapprove;
    @FXML
    private Label lblinboxoffice;
    @FXML
    private Label lblSearch_results;
    @FXML
    private Tab tabinbox;
    @FXML
    private Tab tabReview;
    @FXML
    private Tab tabApprove;
    @FXML
    private Tab tabOffice;
    @FXML
    private Tab tabSent;
    @FXML
    private Tab tabOutbox;
    @FXML
    private Tab tabDraft;
    @FXML
    private Tab tabTrash;
    @FXML
    private ImageView imgPrint;
    @FXML
    private ImageView imgCompose;
    @FXML
    private ImageView imgrefresh;
    @FXML
    private Button btnmailsearch;
    @FXML
    private Label lblStatus;
    static int tred = 0;
    static int tred1 = 0;
    static String m_time = "";
    //Responsive
    @FXML
    private Label lbluser, search_lable, to_serch_lbl;
    @FXML
    private Pane top_pane, top_pane1, top_pane2;
    @FXML
    private AnchorPane inbox_anch_pane;
    @FXML
    private Label lbluserMail, lbl_serch, lab_search1, labl_title, m_inBoXUnreadMail, m_netWorkUpdate, m_netWorkUpdateTime;
    @FXML
    private Label m_sentBoxUnreadMail;
    @FXML
    private Label m_OutBoxUnreadMail;
    @FXML
    private Label m_draftBoxUnreadMail;
    @FXML
    private Label m_trashBoxUnreadMail;
    @FXML
    private Label lbluserCalender;
    @FXML
    private Label lbluserTasks;
    @FXML
    private Label lbluserPreferences = null;
    @FXML
    private ComboBox myCombobox1;
    @FXML
    private TextArea view_mail_check;
    @FXML
    private Button btn1;
    @FXML
    private Label btnAddress;
    @FXML
    private Button refresh_btn;
    @FXML
    private Button btncancel;
    @FXML
    private Button reset_serach;
    @FXML
    private DatePicker from_date;
    @FXML
    private Hyperlink contact_email;
    @FXML
    JFXTimePicker from_timer, to_timer;
    @FXML
    private DatePicker to_date;
    @FXML
    Map inboxmailsmap;
    private DBConnection dc;
    @FXML
    private DatePicker mainCalander;
    @FXML
    private TextField textsearch;
    //for compose button.....
    @FXML
    private TextField search_mail;
    @FXML
    private Button btnCompose, delete_mail, delete_reviewmail, deleteApproveMail, deleteOfficeMail, deleteSentMail, deleteOutBoxMail, deleteDraftMail, mail_inbox, mail_sentbox, mail_outbox, mail_draftbox, mail_trashbox;
    @FXML
    private ImageView delelete_btn_image, delelete_btn_image1, delelete_btn_imageapprove, delelete_btn_imageOffice, delelete_btn_imageSent, delelete_btn_imageout, delelete_btn_imageDraft;
    @FXML
    private Label lblConf, lblSecrt, lblTopscrt, lblRestrictd, lblUnclassfd, lblOpImdte, lblFlash, lblEmrgnvcy, lablPriority, lblDeffered, lblRoutine;
    @FXML
    static String mail_id = "";
    @FXML
    private TableView<Usermstpojo> contacttable = new TableView<>();
    @FXML
    private TableColumn<Usermstpojo, String> colcontactlist;
    @FXML
    private TableColumn<Usermstpojo, String> colemailaddress;
    @FXML
    private TableColumn<String, String> from_email;
    @FXML
    private TreeView<String> tableaddressbook;
    @FXML
    static String logout = null;
    @FXML
    private JFXTextArea Contact_details;
    //inbox table variables 
    @FXML
    public TableView<InBoxTabList> mail_header;
    @FXML
    private TableColumn<InBoxTabList, String> from_column_inbox;
    @FXML
    private TableColumn<InBoxTabList, String> Subj_column_inbox;
    @FXML
    private TableColumn<InBoxTabList, String> date_column_inbox;
    @FXML
    private TableColumn<InBoxTabList, String> sec_sym_column_inbox;
    @FXML
    private TableColumn<InBoxTabList, String> colinboxprecedencecolorvalue;
    @FXML
    private TableColumn<InBoxTabList, String> size_column_inbox;
    @FXML
    public static ObservableList<InBoxTabList> table_list = FXCollections.observableArrayList();
    // Riview table variables 
    @FXML
    private TableView<RiviewTabList> mail_header_review;
    @FXML
    private TableColumn<RiviewTabList, String> from_column_review;
    @FXML
    private TableColumn<RiviewTabList, String> Subj_column_review;
    @FXML
    private TableColumn<RiviewTabList, String> date_column_review;
    @FXML
    private TableColumn<RiviewTabList, String> sec_sym_column_review;
    @FXML
    private TableColumn<RiviewTabList, String> col_review_precedence;
    @FXML
    private TableColumn<RiviewTabList, String> size_column_review;
    @FXML
    public static ObservableList<RiviewTabList> riview_table_list = FXCollections.observableArrayList();
    //Approve table variables
    @FXML
    private TableView<ApproveTabList> mail_header_approve;
    @FXML
    private TableColumn<ApproveTabList, String> from_column_approve;
    @FXML
    private TableColumn<ApproveTabList, String> Subj_column_approve;
    @FXML
    private TableColumn<ApproveTabList, String> date_column_approve;
    @FXML
    private TableColumn<ApproveTabList, String> sec_sym_column_approve;
    @FXML
    private TableColumn<ApproveTabList, String> col_approve_precedence;
    @FXML
    private TableColumn<ApproveTabList, String> size_column_approve;
    @FXML
    public static ObservableList<ApproveTabList> approve_table_list = FXCollections.observableArrayList();
    //Office table variables
    @FXML
    private TableView<OfficeTabList> mail_header_office;
    @FXML
    private TableColumn<OfficeTabList, String> from_column_office;
    @FXML
    private TableColumn<OfficeTabList, String> Subj_column_office;
    @FXML
    private TableColumn<OfficeTabList, String> date_column_office;
    @FXML
    private TableColumn<OfficeTabList, String> sec_sym_column_office;
    @FXML
    private TableColumn<OfficeTabList, String> colofficeprecedencecolorvalue;
    @FXML
    private TableColumn<OfficeTabList, String> size_column_office;
    @FXML
    public static ObservableList<OfficeTabList> office_table_list = FXCollections.observableArrayList();
    //Trash,Sent,out box,Draft table
    @FXML
    private TableView<SentMailList> mail_table;
    @FXML
    private TableColumn<SentMailList, String> sec_sym_column_mail_table;
    @FXML
    private TableColumn<SentMailList, String> precedence_col_sent_mail;
    @FXML
    private TableColumn<SentMailList, String> from_column_mail_table;
    @FXML
    private TableColumn<SentMailList, String> Subj_column_mail_table;
    @FXML
    private TableColumn<SentMailList, String> date_column_mail_table;
    @FXML
    private TableColumn<SentMailList, String> size_column_mail_table;
    @FXML
    public static ObservableList<SentMailList> mail_table_list = FXCollections.observableArrayList();

    @FXML
    private TableView<OutTabList> mail_table_out_box;
    @FXML
    private TableColumn<OutTabList, String> precedence_col_out_box;
    @FXML
    private TableColumn<OutTabList, String> sec_sym_column_out_box;
    @FXML
    private TableColumn<OutTabList, String> from_column_out_box;
    @FXML
    private TableColumn<OutTabList, String> Subj_column_out_box;
    @FXML
    private TableColumn<OutTabList, String> date_column_out_box;
    @FXML
    private TableColumn<OutTabList, String> size_column_out_box;
    @FXML
    public static ObservableList<OutTabList> outbox_table_list = FXCollections.observableArrayList();
    @FXML
    private TableView<DraftTabList> mail_table_draft_table;
    @FXML
    private TableColumn<DraftTabList, String> precedence_col_traft_mail;
    @FXML
    private TableColumn<DraftTabList, String> sec_sym_column_draft_table;
    @FXML
    private TableColumn<DraftTabList, String> from_column_draft_table;
    @FXML
    private TableColumn<DraftTabList, String> Subj_column_draft_table;
    @FXML
    private TableColumn<DraftTabList, String> date_column_draft_table;
    @FXML
    private TableColumn<DraftTabList, String> size_column_draft_table;
    @FXML
    public static ObservableList<DraftTabList> draft_table_list = FXCollections.observableArrayList();
    @FXML
    private TableView<TrashTabList> mail_table_trash_box;
    @FXML
    private TableColumn<TrashTabList, String> precedence_col_trash_mail;
    @FXML
    private TableColumn<TrashTabList, String> sec_sym_column_trash_box;
    @FXML
    private TableColumn<TrashTabList, String> from_column_trash_box;
    @FXML
    private TableColumn<TrashTabList, String> Subj_column_trash_box;
    @FXML
    private TableColumn<TrashTabList, String> date_column_trash_box;
    @FXML
    private TableColumn<TrashTabList, String> size_column_trash_box;
    @FXML
    public static ObservableList<TrashTabList> trash_table_list = FXCollections.observableArrayList();
    @FXML
    private TableView<PersonalCertificate> m_personalCertificate;
    @FXML
    private TableColumn<PersonalCertificate, String> m_serialNumPersonalCertificate;
    @FXML
    private TableColumn<PersonalCertificate, String> m_issuedToPersonalCertificate;
    @FXML
    private TableColumn<PersonalCertificate, String> m_issuedByPersonalCertificate;
    @FXML
    private TableColumn<PersonalCertificate, String> m_expirationDatePersonalCertificate;
    @FXML
    public static ObservableList<PersonalCertificate> m_PersonalCertificateList = FXCollections.observableArrayList();
    @FXML
    private JFXButton btnserch_inbox, btnserch_sent, btnserch_out, btnserch_draft, btnserch_trash;
    @FXML
    private JFXListView contact_details;
    @FXML
    private ListView<String> check_list;
    @FXML
    private Hyperlink hyperLogout;
    @FXML
    private Button btnloadaddressbook;

    private ObservableList<AddressBookpojo> data;
    @FXML
    private MenuItem editcontext;
    @FXML
    private Button btncancel1;
    @FXML
    private MenuItem deletecontext, emailcontext;
    @FXML
    TableColumn check_box_tbl;
    @FXML
    private Button btnPrint;
    @FXML
    private TableColumn<String, String> from_mail;
    @FXML
    private ObservableList<Usermstpojo> data3;
    @FXML
    private ObservableList<Usermstpojo> data12;
    @FXML
    private ObservableList<Usermstpojo> data1;
    private ObservableList<InBoxTabList> masterData = FXCollections.observableArrayList();
    private ObservableList<InBoxTabList> filteretable_data = FXCollections.observableArrayList();
    private ObservableList<String> Selectlist = FXCollections.observableArrayList("Global Address Book");
    private Image availimg = new Image(getClass().getResourceAsStream("/img/available.png"));
    private Image offlineimg = new Image(getClass().getResourceAsStream("/img/disconn.png"));
    private Image imagediconnect = new Image(getClass().getResourceAsStream("/img/offline.png"));
    private Image imageAttachment = new Image(getClass().getResourceAsStream("/img/attach_new12.png"));
    @FXML
    private Image imgattach = new Image(getClass().getResourceAsStream("/img/attach_new12.png"));
    private Image icon = new Image(getClass().getResourceAsStream("/img/folder.png"));
    private Image icon1 = new Image(getClass().getResourceAsStream("/img/file.png"));
    @FXML
    private JFXTreeView<String> Local_adress_book;
    @FXML
    private FlowPane symbol_indicator;
    @FXML
    public String Allglobal_contact = "";
    @FXML
    public String locl_contact = "";
    @FXML
    public String Alllocal_contact = "";
    @FXML
    private ContextMenu contextID;
    @FXML
    public String authorisationStatus;
    public static String Office_name = null;
    public static String Postal_adress = null;
    public static String Role = null;
    public static String Telephone_number = null;
    public static String Exceptin_msg = null;
    public static String Mail_id = null;
    // public static String sec_symbl = null;
    public static TablePosition tablePosition;
    public static ObservableList selectedCells;
    public ObservableList<Usermstpojo> All_contact = FXCollections.observableArrayList();
    public ObservableList<Usermstpojo> All_Local_contact = FXCollections.observableArrayList();
    boolean Currentreadstatus;
    PrecedenceDTO objprecedence;
    @FXML
    public String Contacts[] = {"Cdr.AHQ", "COLGS.AHQ", "GSO-1.AHQ", "CO.AHQ", "Adjt.AHQ", "RDClerk.AHQ", "SysAdmin.AHQ", "Cdr.CmdHQ", "COLGS.CmdHQ", "GSO-1.CmdHQ", "CO.CmdHQ", "Adjt.CmdHQ", "RDClerk.CmdHQ", "SysAdmin.CmdHQ", "Cdr.1CorpHQ", "COLGS.1CorpHQ", "GSO-1.1CorpHQ", "CO.1CorpHQ", "Adjt.1CorpHQ", "RDClerk.1CorpHQ", "SysAdmin.1CorpHQ", "Cdr.2BrigHQ", "COLGS.2BrigHQ", "GSO-1.2BrigHQ", "CO.2BrigHQ", "Adjt.2BrigHQ", "RDClerk.2BrigHQ", "SysAdmin.2BrigHQ"};
    @FXML
    public TabPane inbox_tab;
    @FXML
    public ProgressIndicator progressIndicator = new ProgressIndicator();
    public String preceColor;
    public String m_Attachment = "";
    //public String m_attachmentTrue = "";
    MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);

    AlarmProfilesDTO alarmProfilesDTO = messageHandler.getAlarmProfiles(sm_name);

    public ObservableList<String> mail_rec_from = FXCollections.observableArrayList();
    // MessageHandler msghndlr = new MessageHandler(sm_name, sm_pass);
    List<MailDTO> list;
    public String receivedFrom = "";
    public String subject = "";
    public String receivedDate = "";
    // public String msgType = "";
    public String security_level = "";
    public String precVal = null;
    public String from = "";
    public String rec_subject = "";
    public String AltRecp = "";
    final ObservableList<String> listItems = FXCollections.observableArrayList();
    public String Read_Receipt;
    @FXML
    public static String fday = "";
    public static String eday = "";
    public static String fmonth = "";
    public static String emonth = "";
    @FXML
    private Label btnCOntactDetails;
    @FXML
    public static String contact = null;
    public static String itm = null;
    @FXML
    public static Stage comp_mail_stage = new Stage();
    @FXML
    public static Stage log_out = new Stage();
    @FXML
    public static Stage address_book = new Stage();
    @FXML
    public static Stage read_mail = new Stage();
    @FXML
    public static Stage notificatio_trash_mail = new Stage();
    @FXML
    public static Stage notificatio_sent_mail = new Stage();
    @FXML
    public static Stage notificatio_draft_mail = new Stage();
    @FXML
    public static Stage notificatio_mail = new Stage();
    @FXML
    public static Stage m_rejectThrashmail = new Stage();
    @FXML
    public static Stage m_reject_mail = new Stage();
    @FXML
    public static Stage read_reviewmail = new Stage();
    @FXML
    public static Stage read_approvemail = new Stage();
    @FXML
    public static Stage read_officeemail = new Stage();
    @FXML
    public static Stage sen_mail_stage = new Stage();
    @FXML
    public static Stage trash_mail_stage = new Stage();
    @FXML
    public static Stage draft_mail_stage = new Stage();
    @FXML
    public static Stage m_outboxStage = new Stage();
    @FXML
    public static Stage modify_add_bk = new Stage();
    @FXML
    public static Stage stageAuth = new Stage();
    @FXML
    public static Stage m_alaramPage = new Stage();
    @FXML
     public static String path = "dist"+System.getProperty("file.separator")+"PDF"+System.getProperty("file.separator")+"Mail_Print";
//    public static String path = "C:/PDF/Mail_Print";
    public static String tempStr1 = "";
    public static int m_unReadMailInboxcount = 0;
    public static int m_unReadReviewMailcount = 0;
    public static int m_unReadApproveMailcount = 0;
    public static int m_unReadOfficeMailcount = 0;
    String m_date = "";
    String unreadmail = "";
    public String m_successAlarmFlag = "false";
    public String m_errorAlarmFlag = "false";
    public String m_infoAlarmFlag = "false";
    public String m_warningFlag = "false";
    String Serialnumber;
    String m_issuedTo;
    String m_issuedBy;
    String m_expirationDate;
    @FXML
    private Pagination paginationSentmail;
    @FXML
    private Pagination paginationOutbox;
    @FXML
    private Pagination paginationDraftmail;
    @FXML
    private Pagination paginationTrashmail;
    @FXML
    private Pagination paginationInbox;
    @FXML
    private Pagination paginationReview;
    @FXML
    private Pagination paginationApprove;
    @FXML
    private Pagination paginationOffice;
    @FXML
//    private ComboBox comboBoxSentMailPagination;
    ObservableList<Integer> optionsPagination = FXCollections.observableArrayList(5, 10, 15);
    @FXML
    private ImageView imgSentRefresh;
    @FXML
    private ImageView imgRefreshInbox;
    @FXML
    private ImageView imgOutboxRefresh;
    @FXML
    private Button refresh_btnSent;
    @FXML
    private Button refresh_btnOutbox;
    @FXML
    private Button refresh_btnDraft;
    @FXML
    private Button refresh_btnTrash;
    @FXML
    private ImageView imgDraftRefresh;
    @FXML
    private ImageView imgTrashRefresh;

    @FXML
    private final Image createImage(int w, int h, Color color) {
        Rectangle rect = new Rectangle(w, h, color);
        return rect.snapshot(null, null);
    }

    /**
     * ******************************************************************
     * @Function Name :clickbtnCompose
     * @Description : Method to open compose page.
     * @Input Parameter : ActionEvent -provide by -JavaFX.
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat
     * @Created Date :6-MAR-2017
     * @Modification History:NA.
     * ******************************************************************
     */
    @FXML
    public void clickbtnCompose(ActionEvent event) throws IOException {
        Parent root1;
        if (event.getSource() == btnCompose) {
            root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/ComposePage.fxml"));
         
            comp_mail_stage.setScene(new Scene(root1));
            comp_mail_stage.setTitle("Compose Mail");
            comp_mail_stage.toFront();
            comp_mail_stage.resizableProperty().setValue(Boolean.FALSE);
            comp_mail_stage.getIcons().add(new Image("/img/Mail-icon.png"));
            comp_mail_stage.show();
        } else {
            comp_mail_stage.close();
        }
    }

    /**
     * ******************************************************************
     * @Function Name :logout_service
     * @Description : Method to get logout time.
     * @Input Parameter : NA.
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :6-MAR-2017
     * @Modification History:NA.
     * ******************************************************************
     */
    @FXML
    public String logout_service() {
        try {
            logout = messageHandler.logout();
            System.out.println(logout);
        } catch (NullPointerException e) {
            System.out.println("null pointer exception");
        }
        return logout;
    }

    /**
     * ******************************************************************
     * @Function Name :logout
     * @Description : Method to Log out.
     * @Input Parameter : ActionEvent -provided by -JavaFX.
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :6-MAR-2017
     * @Modification History:NA.
     * ******************************************************************
     */
    @FXML
    public void logout(ActionEvent event) throws IOException {
        try {

            if (messageHandler.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_infoAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getInfoAlarm();
            }

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation-Logout");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure want to Log Out!");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                String logout = "false";
                try {
                    logout = messageHandler.logout();
                   
                } catch (NullPointerException e) {
              e.printStackTrace();
                }
                if (logout.equalsIgnoreCase("true")) {
                    if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                        FXMLDocumentController.ALERT_AUDIOCLIP4.play();
                    }
                    Platform.runLater(() -> {
                        Notifications.create().text("Logout Conformation Message " + "\nLogout Successfull!").showConfirm();
                    });
                    ((Node) (event.getSource())).getScene().getWindow().hide();

                    Screen screen = Screen.getPrimary();
                    Rectangle2D bounds = screen.getVisualBounds();
                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/LoginFXML.fxml"));
                    log_out.setScene(new Scene(root1));
                    log_out.setX(bounds.getMinX());
                    log_out.setX(bounds.getMinY());
                    log_out.setWidth(bounds.getWidth());
                    log_out.setHeight(bounds.getHeight());
                    log_out.show();
                    log_out.getIcons().add(new Image("/img/Mail-icon.png"));
                    event.consume();
                } else {
                    System.out.println("Unable to logout");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
//        m_unReadMailcount=0;
//        m_unReadSentMailcount=0;
//        m_unReadDraftMailcount=0;
//        m_unReadTrashMailcount=0;

    }

    /**
     * ******************************************************************
     * @Function Name :onClickContactEmail
     * @Description : Method use to Redirect compose page when click contact
     * Mail-Id.
     * @Input Parameter : ActionEvent -provided by -JavaFX.
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :15-MAR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onClickContactEmail(ActionEvent event) throws IOException {
        if (contact_email.getText() == null) {
            System.out.println("Contact sm_name is not avilable");
        } else {
           
            root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/ComposePage.fxml"));
           comp_mail_stage.setScene(new Scene(root1));
            comp_mail_stage.setTitle("Compose Mail");
            comp_mail_stage.resizableProperty().setValue(Boolean.FALSE);
            comp_mail_stage.show();

        }
    }

    /**
     * ******************************************************************
     * @Function Name :onselectaction
     * @Description : Method use to call Global Address book contacts from LDAP.
     * @Input Parameter : ActionEvent -provided by -JavaFX.
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :15-MAR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onselectaction(ActionEvent event) throws SQLException {
        String comboval = "Global Address Book";
        String str = myCombobox1.getSelectionModel().getSelectedItem().toString();
    
        if (str.equalsIgnoreCase(comboval)) {
            MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
            List<String> list = messageHandler.getAllContactNames();
            for (String data : list) {
                System.out.println(data);
                Allglobal_contact = data;
                TextFields.bindAutoCompletion(textsearch, Contacts);
            }

        }
    }

    /**
     * ******************************************************************
     * @Function Name :on_delete_mail
     * @Description : Method use to Delete mail from table.
     * @Input Parameter : ActionEvent -provided by -JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :12-MAR-2017.
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void on_delete_review_mail(ActionEvent event) {

    
        List<RiviewTabList> deleteMail_REVIEW = null;
        Object rev = mail_header_review.getSelectionModel().getSelectedItem();
        if (rev == null) {
            if (messageHandler.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_infoAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                    FXMLDocumentController.ALERT_AUDIOCLIP5.play();
                }
            }

            Platform.runLater(() -> {
                Notifications.create().text("Delete Mail" + "\nPlease Select any Row").showError();
            });
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Information-Delete Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select any Row ! ");
            alert.showAndWait();
        } else {
            deleteMail_REVIEW = mail_header_review.getSelectionModel().getSelectedItems();
            System.out.println("Deleted rows" + deleteMail_REVIEW.size());
            ArrayList<Long> list = new ArrayList<Long>();
            for (int i = 0; i < deleteMail_REVIEW.size(); i++) {
                System.out.println(deleteMail_REVIEW.get(i).getMail_id());
                list.add((Long.parseLong(deleteMail_REVIEW.get(i).getMail_id())));
            }
            ObservableList<RiviewTabList> header_item, all_items;
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation-Delete Mail");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure to delete ?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
              
                DeleteInput dto = new DeleteInput();
                dto.setFolder("inbox");
                dto.setMsgUID(list);
                String status = messageHandler.deleteMail(dto);
                all_items = mail_header_review.getItems();
                header_item = mail_header_review.getSelectionModel().getSelectedItems();
                all_items.removeAll(header_item);
                if (messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm() != null) {
                    m_successAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm();
                    if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                        FXMLDocumentController.ALERT_AUDIOCLIP1.play();
                    }
                }

                Platform.runLater(() -> {
                    Notifications.create().text("Delete Mail" + "\nMail Deleted SuccessFully from Review").showInformation();
                });
            }
        }
    }

    @FXML
    public void on_delete_ApproveMail(ActionEvent event) {
   
        List<ApproveTabList> deleteMail_APPROVE = null;
        Object appro = mail_header_approve.getSelectionModel().getSelectedItem();
        if (appro == null) {
            if (messageHandler.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_infoAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                    FXMLDocumentController.ALERT_AUDIOCLIP5.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Delete Mail" + "\nPlease Select any Row").showError();
            });
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Information-Delete Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select any Row ! ");
            alert.showAndWait();
        } else {
            deleteMail_APPROVE = mail_header_approve.getSelectionModel().getSelectedItems();
         
            ArrayList<Long> list = new ArrayList<Long>();
            for (int i = 0; i < deleteMail_APPROVE.size(); i++) {
                System.out.println(deleteMail_APPROVE.get(i).getMail_id());
                list.add((Long.parseLong(deleteMail_APPROVE.get(i).getMail_id())));
            }
            ObservableList<ApproveTabList> header_item, all_items;
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation-Delete Mail");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure to delete ?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                System.out.println(" BEFORE DELETE :" + list);
                DeleteInput dto = new DeleteInput();
                dto.setFolder("inbox");
                dto.setMsgUID(list);
                String status = messageHandler.deleteMail(dto);
                all_items = mail_header_approve.getItems();
                header_item = mail_header_approve.getSelectionModel().getSelectedItems();
                all_items.removeAll(header_item);
                if (messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm() != null) {
                    m_successAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm();
                    if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                        FXMLDocumentController.ALERT_AUDIOCLIP1.play();
                    }
                }

                Platform.runLater(() -> {
                    Notifications.create().text("Delete Mail" + "\nMail Deleted SuccessFully from Approve").showInformation();
                });
            }
        }
    }

    @FXML
    public void on_delete_OfficeMail(ActionEvent event) {
      
        List<OfficeTabList> deleteMail_OFFICE = null;
        Object office = mail_header_office.getSelectionModel().getSelectedItem();
        if (office == null) {
            if (messageHandler.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_infoAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                    FXMLDocumentController.ALERT_AUDIOCLIP5.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Delete Mail" + "\nPlease Select any Row").showError();
            });
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Information-Delete Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select any Row ! ");
            alert.showAndWait();
        } else {
            deleteMail_OFFICE = mail_header_office.getSelectionModel().getSelectedItems();
            System.out.println("Deleted rows" + deleteMail_OFFICE.size());
            ArrayList<Long> list = new ArrayList<Long>();
            for (int i = 0; i < deleteMail_OFFICE.size(); i++) {
                System.out.println(deleteMail_OFFICE.get(i).getMail_id());
                list.add((Long.parseLong(deleteMail_OFFICE.get(i).getMail_id())));
            }
            ObservableList<OfficeTabList> header_item, all_items;
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation-Delete Mail");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure to delete ?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
                System.out.println(" BEFORE DELETE :" + list);
                DeleteInput dto = new DeleteInput();
                dto.setFolder("inbox");
                dto.setMsgUID(list);
                String status = messageHandler.deleteMail(dto);
                System.out.println(status);
                System.out.println("AFTER DELETE :" + list);
                all_items = mail_header_office.getItems();
                header_item = mail_header_office.getSelectionModel().getSelectedItems();
                all_items.removeAll(header_item);
                if (messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm() != null) {
                    m_successAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm();
                    if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                        FXMLDocumentController.ALERT_AUDIOCLIP1.play();
                    }
                }

                Platform.runLater(() -> {
                    Notifications.create().text("Delete Mail" + "\nMail Deleted SuccessFully from Office").showInformation();
                });
            }
        }
    }

    @FXML
    public void on_delete_SentMail(ActionEvent event) {
        System.out.println("sent delet btn clicked");
        Object sent = mail_table.getSelectionModel().getSelectedItem();
        List<SentMailList> deleteMail_SENT = null;
        if (sent == null) {
            if (messageHandler.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_infoAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                    FXMLDocumentController.ALERT_AUDIOCLIP5.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Delete Mail" + "\nPlease Select any Row").showError();
            });
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Information-Delete Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select any Row ! ");
            alert.showAndWait();
        } else {
            deleteMail_SENT = mail_table.getSelectionModel().getSelectedItems();
            System.out.println("Deleted rows" + deleteMail_SENT.size());
            ArrayList<Long> list = new ArrayList<Long>();
            for (int i = 0; i < deleteMail_SENT.size(); i++) {
                System.out.println(deleteMail_SENT.get(i).getMail_id());
                list.add((Long.parseLong(deleteMail_SENT.get(i).getMail_id())));
            }
            ObservableList<SentMailList> header_item, all_items;
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation-Delete Mail");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure to delete ?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
            
                DeleteInput dto = new DeleteInput();
                dto.setFolder("sent");
                dto.setMsgUID(list);
                String status = messageHandler.deleteMail(dto);
                all_items = mail_table.getItems();
                header_item = mail_table.getSelectionModel().getSelectedItems();
                all_items.removeAll(header_item);
                if (messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm() != null) {
                    m_successAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm();
                    if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                        FXMLDocumentController.ALERT_AUDIOCLIP1.play();
                    }
                }
                Platform.runLater(() -> {
                    Notifications.create().text("Delete Mail" + "\nMail Deleted SuccessFully from Sent ").showInformation();
                });
            }
        }
    }

    @FXML
    public void on_delete_OutBoxMail(ActionEvent event) {
  
        Object outbox = mail_table_out_box.getSelectionModel().getSelectedItem();
        List<OutTabList> deleteMail_OUTBOX = null;
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initStyle(StageStyle.UTILITY);
        alert.setTitle("Delete Message Dialogue");
        alert.setHeaderText(null);
        alert.setContentText("Please Select any Row ! ");
        alert.showAndWait();
//                   if (outbox != null) {
//            deleteMail_OUTBOX = mail_table_out_box.getSelectionModel().getSelectedItems();
//            System.out.println("Deleted rows" + deleteMail_OUTBOX.size());
//            ArrayList<Long> list = new ArrayList<Long>();
//            for (int i = 0; i < deleteMail_OUTBOX.size(); i++) {
//                System.out.println(deleteMail_OUTBOX.get(i).getMail_id());
//                list.add((Long.parseLong(deleteMail_OUTBOX.get(i).getMail_id())));
//            }
//            ObservableList<OutTabList> header_item, all_items;
//            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
//            alert.setTitle("Warning");
//            alert.setHeaderText(null);
//            alert.setContentText("Are you sure to delete ?");
//            Optional<ButtonType> result = alert.showAndWait();
//            if (result.get() == ButtonType.OK) {
//                System.out.println(" BEFORE DELETE :" + list);
//                DeleteInput dto = new DeleteInput();
//                dto.setFolder("outbox");
//                dto.setMsgUID(list);
//                String status = messageHandler.deleteMail(dto);
//                all_items = mail_table_out_box.getItems();
//                header_item = mail_table_out_box.getSelectionModel().getSelectedItems();
//                all_items.removeAll(header_item);
//                FXMLDocumentController.ALERT_AUDIOCLIP1.play();
//                Platform.runLater(() -> {
//                    Notifications.create().text("Delete Mail" + "\nMail Deleted SuccessFully from Out box").showInformation();
//                });
//
//            }
//        }
    }

    @FXML
    public void on_delete_DraftMail(ActionEvent event) {
 
        Object draft = mail_table_draft_table.getSelectionModel().getSelectedItem();
        List<DraftTabList> deleteMail_DRAFT = null;
        if (draft == null) {
            if (messageHandler.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_infoAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                    FXMLDocumentController.ALERT_AUDIOCLIP5.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Delete Mail" + "\nPlease Select any Row").showError();
            });
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Information-Delete Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select any Row ! ");
            alert.showAndWait();
        } else {
            deleteMail_DRAFT = mail_table_draft_table.getSelectionModel().getSelectedItems();
          
            ArrayList<Long> list = new ArrayList<Long>();
            for (int i = 0; i < deleteMail_DRAFT.size(); i++) {
                System.out.println(deleteMail_DRAFT.get(i).getMail_id());
                list.add((Long.parseLong(deleteMail_DRAFT.get(i).getMail_id())));
            }
            ObservableList<DraftTabList> header_item, all_items;
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation-Delete Mail");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure to delete ?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
              
                DeleteInput dto = new DeleteInput();
                dto.setFolder("drafts");
                dto.setMsgUID(list);
                String status = messageHandler.deleteMail(dto);
                System.out.println(status);
            
                all_items = mail_table_draft_table.getItems();
                header_item = mail_table_draft_table.getSelectionModel().getSelectedItems();
                all_items.removeAll(header_item);
                if (messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm() != null) {
                    m_successAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm();
                    if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                        FXMLDocumentController.ALERT_AUDIOCLIP1.play();
                    }
                }
                Platform.runLater(() -> {
                    Notifications.create().text("Delete Mail" + "\nMail Deleted SuccessFully from Draft").showInformation();
                });
            }
        }
    }

    @FXML
    public void on_delete_mail(ActionEvent event) throws SQLException {
   
        Object row_item = mail_header.getSelectionModel().getSelectedItem();
        List<InBoxTabList> deleteMail_INBOX = null;

        if (row_item == null) {
            if (messageHandler.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_infoAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                    FXMLDocumentController.ALERT_AUDIOCLIP5.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Delete Mail" + "\nPlease Select any Row").showError();
            });
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Information-Delete Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select any Row ! ");
            alert.showAndWait();

        } else {
            deleteMail_INBOX = mail_header.getSelectionModel().getSelectedItems();
      
            ArrayList<Long> list = new ArrayList<Long>();
            for (int i = 0; i < deleteMail_INBOX.size(); i++) {
                System.out.println(deleteMail_INBOX.get(i).getMail_id());
                list.add((Long.parseLong(deleteMail_INBOX.get(i).getMail_id())));
            }
            ObservableList<InBoxTabList> header_item, all_items;
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Confirmation-Delete Mail");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure to delete ?");
            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == ButtonType.OK) {
       
                DeleteInput dto = new DeleteInput();
                dto.setFolder("inbox");
                dto.setMsgUID(list);
                String status = messageHandler.deleteMail(dto);
                all_items = mail_header.getItems();
                header_item = mail_header.getSelectionModel().getSelectedItems();
                all_items.removeAll(header_item);
                if (messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm() != null) {
                    m_successAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm();
                    if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                        FXMLDocumentController.ALERT_AUDIOCLIP1.play();
                    }
                }
                Platform.runLater(() -> {
                    Notifications.create().text("Delete Mail" + "\nMail Deleted SuccessFully from Inbox").showInformation();
                });
            }
        }

    }

    /**
     * ******************************************************************
     * @Function Name :get_month
     * @Description : Method to change month format.
     * @Input Parameter : String Month.
     * @Output Parameter	: Return String value.
     * @Author : Ravikiran Bhat.
     * @Created Date :13-MAR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public String get_month(String fmonth) {
        if (fmonth.equalsIgnoreCase("JANUARY")) {

            return fmonth = "Jan";

        } else if (fmonth.equalsIgnoreCase("FEBRUARY")) {

            return fmonth = "Feb";

        } else if (fmonth.equalsIgnoreCase("MARCH")) {

            return fmonth = "Mar";

        } else if (fmonth.equalsIgnoreCase("APRIL")) {

            return fmonth = "Apr";

        } else if (fmonth.equalsIgnoreCase("MAY")) {

            return fmonth = "May";

        } else if (fmonth.equalsIgnoreCase("JUNE")) {

            return fmonth = "Jun";

        } else if (fmonth.equalsIgnoreCase("JULY")) {

            return fmonth = "Jul";

        } else if (fmonth.equalsIgnoreCase("AUGUST")) {

            return fmonth = "Aug";

        } else if (fmonth.equalsIgnoreCase("SEPTEMBER")) {

            return fmonth = "Sep";

        } else if (fmonth.equalsIgnoreCase("OCTOBER")) {

            return fmonth = "Oct";

        } else if (fmonth.equalsIgnoreCase("NOVEMBER")) {

            return fmonth = "Nov";

        }
        return fmonth = "Dec";
    }

    /**
     * ******************************************************************
     * @Function Name :get_day
     * @Description : Method to change Day format.
     * @Input Parameter : String Day.
     * @Output Parameter	: Return String value.
     * @Author : Ravikiran Bhat.
     * @Created Date :12-MAR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public String get_day(String fday) {
        if (fday.equalsIgnoreCase("SUNDAY")) {
            return fday = "Sun";
        } else if (fday.equalsIgnoreCase("MONDAY")) {
            return fday = "Mon";
        } else if (fday.equalsIgnoreCase("TUESDAY")) {
            return fday = "Tue";
        } else if (fday.equalsIgnoreCase("WEDNESDAY")) {
            return fday = "Wed";
        } else if (fday.equalsIgnoreCase("THURSDAY")) {
            return fday = "Thu";
        } else if (fday.equalsIgnoreCase("FRIDAY")) {
            return fday = "Fri";
        }
        return fday = "Sat";
    }

    /**
     * ******************************************************************
     * @Function Name :onSearch
     * @Description :Method to search mail in InBox table.
     * @Input Parameter : ActionEvent -Provided by JavaFX.
     * @Output Parameter	:NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :13-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onSearch(ActionEvent event) throws Exception {
        System.out.println("inbox serch clicked");

        m_progressService.restart();
        lblinboxview.setVisible(true);
        lblinboxreview.setVisible(false);
        lblinboxapprove.setVisible(false);
        lblinboxoffice.setVisible(false);
        lblsentmailview.setVisible(false);
        lbloutboxview.setVisible(false);
        lblDraftview.setVisible(false);
        lblTrashview.setVisible(false);
        search_lable.setVisible(true);
        table_list.clear();
        riview_table_list.clear();
        approve_table_list.clear();
        office_table_list.clear();
        fday = from_date.getValue().getDayOfWeek().toString();
        String from_day = get_day(fday);
        int date = from_date.getValue().getDayOfMonth();
        fmonth = from_date.getValue().getMonth().toString();
        String from_month = get_month(fmonth);
        int year = from_date.getValue().getYear();
        int h = from_timer.getValue().getHour();
        int m = from_timer.getValue().getMinute();
        int s = from_timer.getValue().getSecond();
        System.out.println(h + "" + m + "" + s);
        String FDate = from_day + "," + " " + date + " " + from_month + " " + year + " " + h + ":" + m + ":" + s + " " + "+0530" + " " + "(IST)";
        System.out.println("FDate :" + FDate);
        eday = to_date.getValue().getDayOfWeek().toString();
        String End_day = get_day(eday);
        int edate = to_date.getValue().getDayOfMonth();
        emonth = to_date.getValue().getMonth().toString();
        String To_month = get_month(emonth);
        int eyear = to_date.getValue().getYear();
        int eh = to_timer.getValue().getHour();
        int em = to_timer.getValue().getMinute();
        int es = to_timer.getValue().getSecond();
        System.out.println(h + "" + m + "" + s);
        String EDate = End_day + "," + " " + edate + " " + To_month + " " + eyear + " " + eh + ":" + em + ":" + es + " " + "+0530" + " " + "(IST)";
        System.out.println("EDate :" + EDate);
        String user = search_mail.getText();
        String officeName = messageHandler.preCheck(user).getOfficeName();
        System.out.println(user);
        Tcs_Users userObj = messageHandler.getTcsUser(user, officeName);
        String mailId = userObj.getMailId();
        System.out.println("mail Id: " + mailId);
        SearchMailDTO mail = new SearchMailDTO();
        mail.setFolder("inbox");
        mail.setFromCount(0);
        mail.setToCount(0);
        mail.setSearchTerm(mailId);
        mail.setFromDate(FDate);
        mail.setToDate(EDate);
        List<MailDTO> mailObj1 = messageHandler.searchMail(mail);
        Collections.reverse(mailObj1);
          for (MailDTO data : mailObj1) {
            String m_attachmentTrue = "";
            String msgType = "";
            String sec_symbl = "";
            if ((String) data.getHeaderMap().get("Date") != null) {
                receivedDate = (String) data.getHeaderMap().get("Date");
            }
            if ((String) data.getHeaderMap().get("From") != null) {
                receivedFrom = (String) data.getHeaderMap().get("From");
            }
            if ((String) data.getHeaderMap().get("Subject") != null) {
                subject = (String) data.getHeaderMap().get("Subject");
            }
            if ((String) data.getHeaderMap().get("msgType") != null) {
                msgType = (String) data.getHeaderMap().get("msgType");
            }
            if (data.getHeaderMap().get("uid") != null) {
                mail_id = data.getHeaderMap().get("uid") + "";
            }
            if ((String) data.getHeaderMap().get("Date") != null) {
                System.out.println("Receive date:" + (String) data.getHeaderMap().get("Date"));
            }
            if (data.getHeaderMap().get("Subject") != null) {
                System.out.println("Mail Subject:" + data.getHeaderMap().get("Subject"));
            }
            System.out.println("Message type" + msgType);
            System.out.println(mail_id);
            if (data.getHeaderMap().get("redStatus") != null) {
                Currentreadstatus = (boolean) data.getHeaderMap().get("redStatus");
            }
            if ((String) data.getHeaderMap().get("security_level") != null) {
                security_level = (String) data.getHeaderMap().get("security_level");
            }
            if (security_level != null || !security_level.equalsIgnoreCase("")) {
                System.out.println("SEC SYMBOL" + security_level);
                for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                    if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
                        sec_symbl = singleObj.getSecclasssymbol();
                    }
                }
            }
            if (data.getHeaderMap().get("Altrecp") != null) {
                AltRecp = (String) data.getHeaderMap().get("Altrecp");
                System.out.println("ALTERNATE" + AltRecp);
            }
//            if ((String) data.getHeaderMap().get("attachedFileName") != "" || (String) data.getHeaderMap().get("attachedFileName") != null) {
//                m_Attachment = (String) data.getHeaderMap().get("attachedFileName");
//                System.out.println("Attachment is" + m_Attachment);
//            }
            if (data.getHeaderMap().get("attachment") != null) {
                m_Attachment = (String) data.getHeaderMap().get("attachment");
                m_attachmentTrue = m_Attachment;
            }
            if (msgType == null || msgType.equalsIgnoreCase("PDSN") || msgType.equalsIgnoreCase("ForwardToSameOffice") || msgType.equalsIgnoreCase("ApproveReject") || msgType.equalsIgnoreCase("ReviewReject") || msgType.equalsIgnoreCase("ReadReceipt") || msgType.equalsIgnoreCase("PAltDSN") || msgType.equalsIgnoreCase("NDSN")) {

              
                if ((String) data.getHeaderMap().get("precedence") != null) {
                    precVal = (String) data.getHeaderMap().get("precedence");
                }
                if (precVal != null) {
                    for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                        if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                            preceColor = singleObj.getPreccolour();
                        }
                    }
                }
                table_list.add(new InBoxTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
                sec_sym_column_inbox.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
                from_column_inbox.setCellValueFactory(new PropertyValueFactory<>("from"));
                Subj_column_inbox.setCellValueFactory(new PropertyValueFactory<>("subject"));
                date_column_inbox.setCellValueFactory(new PropertyValueFactory<>("date"));
                size_column_inbox.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
                colinboxprecedencecolorvalue.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
                colinboxprecedencecolorvalue.setCellFactory(col -> new TableCell<InBoxTabList, String>() {
                    private final ImageView imageView = new ImageView();

                    @Override
                    protected void updateItem(String color, boolean empty) {
                        super.updateItem(color, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            if (color.equalsIgnoreCase("Tomato")) {
                                imageView.setImage(imgtomato);
                            } else if (color.equalsIgnoreCase("Orange")) {
                                imageView.setImage(imgorange);
                            } else if (color.equalsIgnoreCase("LightBlue")) {
                                imageView.setImage(imglightblue);
                            } else if (color.equalsIgnoreCase("LightGreen")) {
                                imageView.setImage(imglightgreen);
                            } else if (color.equalsIgnoreCase("Yellow")) {
                                imageView.setImage(imgyellow);
                            } else if (color.equalsIgnoreCase("Pink")) {
                                imageView.setImage(imgpink);
                            } else {
                                imageView.setImage(null);
                            }
                            setGraphic(imageView);
                        }
                    }
                });
                mail_header.setRowFactory(row -> new TableRow<InBoxTabList>() {
                    @Override
                    public void updateItem(InBoxTabList item, boolean status) {
                        super.updateItem(item, Currentreadstatus);
                        if (item == null) {
                            setStyle("");
                        } else if (item.getCurrentreadstatus() == false) {
                            setStyle("-fx-font-weight:bold;");
                        } else if (item.getCurrentreadstatus() == true) {
                            setStyle("-fx-font-weight:normal;");
                        }
                    }
                });
                size_column_inbox.setCellFactory(colattach -> new TableCell<InBoxTabList, String>() {
                    private final ImageView imageView = new ImageView();

                    @Override
                    protected void updateItem(String attach, boolean empty) {
                        super.updateItem(attach, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            if (attach.equals("true")) {
                                imageView.setImage(imgattach);
                            } else if (attach.equals("false")) {
                                imageView.setImage(null);
                            }
                            setGraphic(imageView);
                        }
                    }
                });
            } else if (msgType.equalsIgnoreCase("Draft")) // Mail header display in Riview Tab Table
            {
               
                if ((String) data.getHeaderMap().get("precedence") != null) {
                    precVal = (String) data.getHeaderMap().get("precedence");
                }
                if (precVal != null) {

                    if (precVal != null) {
                        for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                            if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                                preceColor = singleObj.getPreccolour();
                            }
                        }
                    }
                }

               
                riview_table_list.add(new RiviewTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
                sec_sym_column_review.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
                from_column_review.setCellValueFactory(new PropertyValueFactory<>("from"));
                Subj_column_review.setCellValueFactory(new PropertyValueFactory<>("subject"));
                date_column_review.setCellValueFactory(new PropertyValueFactory<>("date"));
                size_column_review.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
                col_review_precedence.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
                col_review_precedence.setCellFactory(col -> new TableCell<RiviewTabList, String>() {
                    private final ImageView imageView = new ImageView();

                    @Override
                    protected void updateItem(String color, boolean empty) {
                        super.updateItem(color, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            if (color.equalsIgnoreCase("Tomato")) {
                                imageView.setImage(imgtomato);
                            } else if (color.equalsIgnoreCase("Orange")) {
                                imageView.setImage(imgorange);
                            } else if (color.equalsIgnoreCase("LightBlue")) {
                                imageView.setImage(imglightblue);
                            } else if (color.equalsIgnoreCase("LightGreen")) {
                                imageView.setImage(imglightgreen);
                            } else if (color.equalsIgnoreCase("Yellow")) {
                                imageView.setImage(imgyellow);
                            } else if (color.equalsIgnoreCase("Pink")) {
                                imageView.setImage(imgpink);
                            } else {
                                imageView.setImage(null);
                            }
                            setGraphic(imageView);
                        }
                    }
                });
                mail_header_review.setRowFactory(row -> new TableRow<RiviewTabList>() {
                    @Override
                    public void updateItem(RiviewTabList item, boolean status) {
                        super.updateItem(item, Currentreadstatus);
                        if (item == null) {
                            setStyle("");
                        } else if (item.getCurrentreadstatus() == false) {
                            setStyle("-fx-font-weight:bold;");
                        } else if (item.getCurrentreadstatus() == true) {
                            setStyle("-fx-font-weight:normal;");
                        }
                    }
                });
                size_column_review.setCellFactory(colattach -> new TableCell<RiviewTabList, String>() {
                    private final ImageView imageView = new ImageView();

                    @Override
                    protected void updateItem(String attach, boolean empty) {
                        super.updateItem(attach, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            if (attach.equals("true")) {
                                imageView.setImage(imgattach);
                            } else if (attach.equals("false")) {
                                imageView.setImage(null);
                            }
                            setGraphic(imageView);
                        }
                    }
                });
            } else if (msgType.equalsIgnoreCase("ReviewAccept")) // Mail header display in Approve Tab Table
            {
                if ((String) data.getHeaderMap().get("precedence") != null) {
                    precVal = (String) data.getHeaderMap().get("precedence");
                }
                if (precVal != null) {

                    if (precVal != null) {
                        for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                            if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                                preceColor = singleObj.getPreccolour();
                            }
                        }
                    }
                }
            

                approve_table_list.add(new ApproveTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
                sec_sym_column_approve.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
                from_column_approve.setCellValueFactory(new PropertyValueFactory<>("from"));
                Subj_column_approve.setCellValueFactory(new PropertyValueFactory<>("subject"));
                date_column_approve.setCellValueFactory(new PropertyValueFactory<>("date"));
                col_approve_precedence.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
                size_column_approve.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
                col_approve_precedence.setCellFactory(col -> new TableCell<ApproveTabList, String>() {
                    private final ImageView imageView = new ImageView();

                    @Override
                    protected void updateItem(String color, boolean empty) {
                        super.updateItem(color, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            if (color.equalsIgnoreCase("Tomato")) {
                                imageView.setImage(imgtomato);
                            } else if (color.equalsIgnoreCase("Orange")) {
                                imageView.setImage(imgorange);
                            } else if (color.equalsIgnoreCase("LightBlue")) {
                                imageView.setImage(imglightblue);
                            } else if (color.equalsIgnoreCase("LightGreen")) {
                                imageView.setImage(imglightgreen);
                            } else if (color.equalsIgnoreCase("Yellow")) {
                                imageView.setImage(imgyellow);
                            } else if (color.equalsIgnoreCase("Pink")) {
                                imageView.setImage(imgpink);
                            } else {
                                imageView.setImage(null);
                            }
                            setGraphic(imageView);
                        }
                    }
                });
                mail_header_approve.setRowFactory(row -> new TableRow<ApproveTabList>() {
                    @Override
                    public void updateItem(ApproveTabList item, boolean status) {
                        super.updateItem(item, Currentreadstatus);
                        if (item == null) {
                            setStyle("");
                        } else if (item.getCurrentreadstatus() == false) {
                            setStyle("-fx-font-weight:bold;");
                        } else if (item.getCurrentreadstatus() == true) {
                            setStyle("-fx-font-weight:normal;");
                        }
                    }
                });
                size_column_approve.setCellFactory(colattach -> new TableCell<ApproveTabList, String>() {
                    private final ImageView imageView = new ImageView();

                    @Override
                    protected void updateItem(String attach, boolean empty) {
                        super.updateItem(attach, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            if (attach.equals("true")) {
                                imageView.setImage(imgattach);
                            } else if (attach.equals("false")) {
                                imageView.setImage(null);
                            }
                            setGraphic(imageView);
                        }
                    }
                });

            } else if (msgType.equalsIgnoreCase("ForwardToAnotherOffice") || msgType.equalsIgnoreCase("SENDTODESIGNATEDUSER") || AltRecp.equalsIgnoreCase("1")) // Mail header display in Office Tab Table
            {

                if ((String) data.getHeaderMap().get("precedence") != null) {
                    precVal = (String) data.getHeaderMap().get("precedence");
                }
                if (precVal != null) {

                    if (precVal != null) {
                        for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                            if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                                preceColor = singleObj.getPreccolour();
                            }
                        }
                    }
                }
               
                Boolean attachment = false;

                office_table_list.add(new OfficeTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
                sec_sym_column_office.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
                from_column_office.setCellValueFactory(new PropertyValueFactory<>("from"));
                Subj_column_office.setCellValueFactory(new PropertyValueFactory<>("subject"));
                date_column_office.setCellValueFactory(new PropertyValueFactory<>("date"));
                size_column_office.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
                colofficeprecedencecolorvalue.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
                colofficeprecedencecolorvalue.setCellFactory(col -> new TableCell<OfficeTabList, String>() {
                    private final ImageView imageView = new ImageView();

                    @Override
                    protected void updateItem(String color, boolean empty) {
                        super.updateItem(color, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            if (color.equalsIgnoreCase("Tomato")) {
                                imageView.setImage(imgtomato);
                            } else if (color.equalsIgnoreCase("Orange")) {
                                imageView.setImage(imgorange);
                            } else if (color.equalsIgnoreCase("LightBlue")) {
                                imageView.setImage(imglightblue);
                            } else if (color.equalsIgnoreCase("LightGreen")) {
                                imageView.setImage(imglightgreen);
                            } else if (color.equalsIgnoreCase("Yellow")) {
                                imageView.setImage(imgyellow);
                            } else if (color.equalsIgnoreCase("Pink")) {
                                imageView.setImage(imgpink);
                            } else {
                                imageView.setImage(null);
                            }
                            setGraphic(imageView);
                        }
                    }
                });
                mail_header_office.setRowFactory(row -> new TableRow<OfficeTabList>() {
                    @Override
                    public void updateItem(OfficeTabList item, boolean status) {
                        super.updateItem(item, Currentreadstatus);
                        if (item == null) {
                            setStyle("");
                        } else if (item.getCurrentreadstatus() == false) {
                            setStyle("-fx-font-weight:bold;");
                        } else if (item.getCurrentreadstatus() == true) {
                            setStyle("-fx-font-weight:normal;");
                        }
                    }
                });
                size_column_office.setCellFactory(colattach -> new TableCell<OfficeTabList, String>() {
                    private final ImageView imageView = new ImageView();

                    @Override
                    protected void updateItem(String attach, boolean empty) {
                        super.updateItem(attach, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            if (attach.equals("true")) {
                                imageView.setImage(imgattach);
                            } else if (attach.equals("false")) {
                                imageView.setImage(null);
                            }
                            setGraphic(imageView);
                        }
                    }
                });
            }
        }

        mail_header.setItems(FXCollections.observableArrayList(table_list));

        mail_header.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        mail_header_review.setItems(FXCollections.observableArrayList(riview_table_list));
        mail_header_review.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        mail_header_approve.setItems(FXCollections.observableArrayList(approve_table_list));
        mail_header_approve.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

        mail_header_office.setItems(FXCollections.observableArrayList(office_table_list));
        mail_header_office.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

    }

    /**
     * ******************************************************************
     * @Function Name :onSearchDraft
     * @Description :Method to search mail in Draft table.
     * @Input Parameter : ActionEvent -Provided by JavaFX.
     * @Output Parameter :NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :13-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onSearchDraft(ActionEvent event) throws Exception {
        System.out.println("Draft serch clicked");

        lblinboxview.setVisible(false);
        lblsentmailview.setVisible(false);
        lbloutboxview.setVisible(false);
        lblDraftview.setVisible(true);
        lblTrashview.setVisible(false);
        lblSearch_results.setVisible(true);
        lblSearch_results.setText("Result Showing for Searched Mails");
        draft_table_list.clear();
        fday = from_date.getValue().getDayOfWeek().toString();
        String from_day = get_day(fday);
        int date = from_date.getValue().getDayOfMonth();
        fmonth = from_date.getValue().getMonth().toString();
        String from_month = get_month(fmonth);
        int year = from_date.getValue().getYear();
        int h = from_timer.getValue().getHour();
        int m = from_timer.getValue().getMinute();
        int s = from_timer.getValue().getSecond();
        System.out.println(h + "" + m + "" + s);
        String FDate = from_day + "," + " " + date + " " + from_month + " " + year + " " + h + ":" + m + ":" + s + " " + "+0530" + " " + "(IST)";
        System.out.println("FDate :" + FDate);
        eday = to_date.getValue().getDayOfWeek().toString();
        String End_day = get_day(eday);
        int edate = to_date.getValue().getDayOfMonth();
        emonth = to_date.getValue().getMonth().toString();
        String To_month = get_month(emonth);
        int eyear = to_date.getValue().getYear();
        int eh = to_timer.getValue().getHour();
        int em = to_timer.getValue().getMinute();
        int es = to_timer.getValue().getSecond();
        System.out.println(h + "" + m + "" + s);
        String EDate = End_day + "," + " " + edate + " " + To_month + " " + eyear + " " + eh + ":" + em + ":" + es + " " + "+0530" + " " + "(IST)";
        System.out.println("EDate :" + EDate);
        String user = search_mail.getText();
        String officeName = messageHandler.preCheck(user).getOfficeName();
        System.out.println(user);
        Tcs_Users userObj = messageHandler.getTcsUser(user, officeName);
        String mailId = userObj.getMailId();
        System.out.println("mail Id: " + mailId);
        SearchMailDTO mail = new SearchMailDTO();
        mail.setFolder("drafts");
        mail.setFromCount(0);
        mail.setToCount(0);
        mail.setSearchTerm(mailId);
        mail.setFromDate(FDate);
        mail.setToDate(EDate);
        List<MailDTO> mailObj1 = messageHandler.searchMail(mail);
        Collections.reverse(mailObj1);
        for (MailDTO data : mailObj1) {
            String m_attachmentTrue = "";
            String msgType = "";
            String sec_symbl = "";
            if ((String) data.getHeaderMap().get("Date") != null) {
                receivedDate = (String) data.getHeaderMap().get("Date");
                System.out.println("Receive date:" + (String) data.getHeaderMap().get("Date"));
            }
            if ((String) data.getHeaderMap().get("From") != null) {
                receivedFrom = (String) data.getHeaderMap().get("From");
            }
            if ((String) data.getHeaderMap().get("Subject") != null) {
                subject = (String) data.getHeaderMap().get("Subject");
            }
            if ((String) data.getHeaderMap().get("msgType") != null) {
                msgType = (String) data.getHeaderMap().get("msgType");
            }
            if (data.getHeaderMap().get("uid") != null) {
                mail_id = data.getHeaderMap().get("uid") + "";
            }
            System.out.println("Mail Id:" + mail_id);

            if ((String) data.getHeaderMap().get("Date") != null) {
                System.out.println("Receive date:" + (String) data.getHeaderMap().get("Date"));
            }
            if (data.getHeaderMap().get("Subject") != null) {
                System.out.println("Mail Subject:" + data.getHeaderMap().get("Subject"));
            }
            System.out.println("Message type" + msgType);
            System.out.println(mail_id);
            if ((String) data.getHeaderMap().get("security_level") != null) {
                security_level = (String) data.getHeaderMap().get("security_level");
            }
            if (security_level != null || !security_level.equalsIgnoreCase("")) {
                System.out.println("SEC SYMBOL" + security_level);
                for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                    if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
                        sec_symbl = singleObj.getSecclasssymbol();
                    }
                }
            }
            preceColor = "";
            if ((String) data.getHeaderMap().get("precedence") != null) {
                precVal = (String) data.getHeaderMap().get("precedence");
            }
            if (precVal != null) {

                if (precVal != null) {
                    for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                        if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                            preceColor = singleObj.getPreccolour();
                        }
                    }
                }

            }
            if (data.getHeaderMap().get("attachment") != null) {
                m_Attachment = (String) data.getHeaderMap().get("attachment");
                m_attachmentTrue = m_Attachment;
            }
            draft_table_list.add(new DraftTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, m_attachmentTrue));
            sec_sym_column_draft_table.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
            from_column_draft_table.setCellValueFactory(new PropertyValueFactory<>("from"));
            Subj_column_draft_table.setCellValueFactory(new PropertyValueFactory<>("subject"));
            date_column_draft_table.setCellValueFactory(new PropertyValueFactory<>("date"));
            precedence_col_traft_mail.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
            size_column_draft_table.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
            precedence_col_traft_mail.setCellFactory(col -> new TableCell<DraftTabList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String color, boolean empty) {
                    super.updateItem(color, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (color.equalsIgnoreCase("Tomato")) {
                            imageView.setImage(imgtomato);
                        } else if (color.equalsIgnoreCase("Orange")) {
                            imageView.setImage(imgorange);
                        } else if (color.equalsIgnoreCase("LightBlue")) {
                            imageView.setImage(imglightblue);
                        } else if (color.equalsIgnoreCase("LightGreen")) {
                            imageView.setImage(imglightgreen);
                        } else if (color.equalsIgnoreCase("Yellow")) {
                            imageView.setImage(imgyellow);
                        } else if (color.equalsIgnoreCase("Pink")) {
                            imageView.setImage(imgpink);
                        } else {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
            size_column_draft_table.setCellFactory(colattach -> new TableCell<DraftTabList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String attach, boolean empty) {
                    super.updateItem(attach, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (attach.equals("true")) {
                            imageView.setImage(imgattach);
                        } else if (attach.equals("false")) {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
        }
        mail_table_draft_table.setItems(FXCollections.observableArrayList(draft_table_list));
        mail_table_draft_table.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    /**
     * ******************************************************************
     * @Function Name :onSearchOut
     * @Description :Method to search mail in Out Box table.
     * @Input Parameter : ActionEvent -Provided by JavaFX.
     * @Output Parameter	:NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :14-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onSearchOut(ActionEvent event) throws Exception {

        lblinboxview.setVisible(false);
        lblsentmailview.setVisible(false);
        lbloutboxview.setVisible(true);
        lblDraftview.setVisible(false);
        lblTrashview.setVisible(false);
        lblSearch_results.setVisible(true);
        lblSearch_results.setText("Result Showing for Searched Mails");
        outbox_table_list.clear();
        fday = from_date.getValue().getDayOfWeek().toString();
        String from_day = get_day(fday);
        int date = from_date.getValue().getDayOfMonth();
        fmonth = from_date.getValue().getMonth().toString();
        String from_month = get_month(fmonth);
        int year = from_date.getValue().getYear();
        int h = from_timer.getValue().getHour();
        int m = from_timer.getValue().getMinute();
        int s = from_timer.getValue().getSecond();
        System.out.println(h + "" + m + "" + s);
        String FDate = from_day + "," + " " + date + " " + from_month + " " + year + " " + h + ":" + m + ":" + s + " " + "+0530" + " " + "(IST)";
        System.out.println("FDate :" + FDate);
        eday = to_date.getValue().getDayOfWeek().toString();
        String End_day = get_day(eday);
        int edate = to_date.getValue().getDayOfMonth();
        emonth = to_date.getValue().getMonth().toString();
        String To_month = get_month(emonth);
        int eyear = to_date.getValue().getYear();
        int eh = to_timer.getValue().getHour();
        int em = to_timer.getValue().getMinute();
        int es = to_timer.getValue().getSecond();
        System.out.println(h + "" + m + "" + s);
        String EDate = End_day + "," + " " + edate + " " + To_month + " " + eyear + " " + eh + ":" + em + ":" + es + " " + "+0530" + " " + "(IST)";
        System.out.println("EDate :" + EDate);
        String user = search_mail.getText();
        String officeName = messageHandler.preCheck(user).getOfficeName();
        System.out.println(user);
        Tcs_Users userObj = messageHandler.getTcsUser(user, officeName);
        String mailId = userObj.getMailId();
        System.out.println("mail Id: " + mailId);
        SearchMailDTO mail = new SearchMailDTO();
        mail.setFolder("outbox");
        mail.setFromCount(0);
        mail.setToCount(0);
        mail.setSearchTerm(mailId);
        mail.setFromDate(FDate);
        mail.setToDate(EDate);
        List<MailDTO> mailObj1 = messageHandler.searchMail(mail);
        Collections.reverse(mailObj1);
        for (MailDTO data : mailObj1) {
            String m_attachmentTrue = "";
            String msgType = "";
            String sec_symbl = "";
            if ((String) data.getHeaderMap().get("Date") != null) {
                receivedDate = (String) data.getHeaderMap().get("Date");
                System.out.println("Receive date:" + (String) data.getHeaderMap().get("Date"));
            }
            if ((String) data.getHeaderMap().get("From") != null) {
                receivedFrom = (String) data.getHeaderMap().get("From");
            }
            if ((String) data.getHeaderMap().get("Subject") != null) {
                subject = (String) data.getHeaderMap().get("Subject");
            }
            if ((String) data.getHeaderMap().get("msgType") != null) {
                msgType = (String) data.getHeaderMap().get("msgType");
            }
            if (data.getHeaderMap().get("uid") != null) {
                mail_id = data.getHeaderMap().get("uid") + "";
            }
            System.out.println("Mail Id:" + mail_id);
            if (data.getHeaderMap().get("redStatus") != null) {
                Currentreadstatus = (boolean) data.getHeaderMap().get("redStatus");
            }
            if ((String) data.getHeaderMap().get("Date") != null) {
                System.out.println("Receive date:" + (String) data.getHeaderMap().get("Date"));
            }
            if (data.getHeaderMap().get("Subject") != null) {
                System.out.println("Mail Subject:" + data.getHeaderMap().get("Subject"));
            }
            if ((String) data.getHeaderMap().get("security_level") != null) {
                security_level = (String) data.getHeaderMap().get("security_level");
            }
            if (security_level != null || !security_level.equalsIgnoreCase("")) {
                System.out.println("SEC SYMBOL" + security_level);
                for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                    if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
                        sec_symbl = singleObj.getSecclasssymbol();
                    }
                }
            }
            preceColor = "";
            if ((String) data.getHeaderMap().get("precedence") != null) {
                precVal = (String) data.getHeaderMap().get("precedence");
            }
            if (precVal != null) {

                if (precVal != null) {
                    for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                        if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                            preceColor = singleObj.getPreccolour();
                        }
                    }
                }
            }
            if (data.getHeaderMap().get("attachment") != null) {
                m_Attachment = (String) data.getHeaderMap().get("attachment");
                m_attachmentTrue = m_Attachment;
            }
            outbox_table_list.add(new OutTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
            sec_sym_column_out_box.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
            from_column_out_box.setCellValueFactory(new PropertyValueFactory<>("from"));
            Subj_column_out_box.setCellValueFactory(new PropertyValueFactory<>("subject"));
            date_column_out_box.setCellValueFactory(new PropertyValueFactory<>("date"));
            precedence_col_out_box.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
            size_column_out_box.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
            precedence_col_out_box.setCellFactory(col -> new TableCell<OutTabList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String color, boolean empty) {
                    super.updateItem(color, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (color.equalsIgnoreCase("Tomato")) {
                            imageView.setImage(imgtomato);
                        } else if (color.equalsIgnoreCase("Orange")) {
                            imageView.setImage(imgorange);
                        } else if (color.equalsIgnoreCase("LightBlue")) {
                            imageView.setImage(imglightblue);
                        } else if (color.equalsIgnoreCase("LightGreen")) {
                            imageView.setImage(imglightgreen);
                        } else if (color.equalsIgnoreCase("Yellow")) {
                            imageView.setImage(imgyellow);
                        } else if (color.equalsIgnoreCase("Pink")) {
                            imageView.setImage(imgpink);
                        } else {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
            mail_table_out_box.setRowFactory(row -> new TableRow<OutTabList>() {
                @Override
                public void updateItem(OutTabList item, boolean status) {
                    super.updateItem(item, Currentreadstatus);
                    if (item == null) {
                        setStyle("");
                    } else if (item.getCurrentreadstatus() == false) {
                        setStyle("-fx-font-weight:bold;");
                    } else if (item.getCurrentreadstatus() == true) {
                        setStyle("-fx-font-weight:normal;");
                    }
                }
            });
            size_column_out_box.setCellFactory(colattach -> new TableCell<OutTabList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String attach, boolean empty) {
                    super.updateItem(attach, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (attach.equals("true")) {
                            imageView.setImage(imgattach);
                        } else if (attach.equals("false")) {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
        }
        mail_table_out_box.setItems(FXCollections.observableArrayList(outbox_table_list));

        mail_table_out_box.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        System.out.println("End FOR loop");
    }

    /**
     * ******************************************************************
     * @Function Name :onSearchSent.
     * @Description :Method to search mail in Sent Box table.
     * @Input Parameter : ActionEvent -Provided by JavaFX.
     * @Output Parameter	:NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :13-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onSearchSent(ActionEvent event) throws Exception {
//        progressIndiCatorSentMail();

//        m_progressServicesSentMail.restart();
        lblinboxview.setVisible(false);
        lblsentmailview.setVisible(true);
        lbloutboxview.setVisible(false);
        lblDraftview.setVisible(false);
        lblTrashview.setVisible(false);
        lblSearch_results.setVisible(true);
        lblSearch_results.setText("Result Showing for Searched Mails");
        mail_table_list.clear();
        fday = from_date.getValue().getDayOfWeek().toString();
        String from_day = get_day(fday);
        int date = from_date.getValue().getDayOfMonth();
        fmonth = from_date.getValue().getMonth().toString();
        String from_month = get_month(fmonth);
        int year = from_date.getValue().getYear();
        int h = from_timer.getValue().getHour();
        int m = from_timer.getValue().getMinute();
        int s = from_timer.getValue().getSecond();
        System.out.println(h + "" + m + "" + s);
        String FDate = from_day + "," + " " + date + " " + from_month + " " + year + " " + h + ":" + m + ":" + s + " " + "+0530" + " " + "(IST)";
        System.out.println("FDate :" + FDate);
        eday = to_date.getValue().getDayOfWeek().toString();
        String End_day = get_day(eday);
        int edate = to_date.getValue().getDayOfMonth();
        emonth = to_date.getValue().getMonth().toString();
        String To_month = get_month(emonth);
        int eyear = to_date.getValue().getYear();
        int eh = to_timer.getValue().getHour();
        int em = to_timer.getValue().getMinute();
        int es = to_timer.getValue().getSecond();
        System.out.println(h + "" + m + "" + s);
        String EDate = End_day + "," + " " + edate + " " + To_month + " " + eyear + " " + eh + ":" + em + ":" + es + " " + "+0530" + " " + "(IST)";
        System.out.println("EDate :" + EDate);
        String user = search_mail.getText();
        String officeName = messageHandler.preCheck(user).getOfficeName();
        System.out.println(user);
        Tcs_Users userObj = messageHandler.getTcsUser(user, officeName);
        String mailId = userObj.getMailId();
        System.out.println("mail Id: " + mailId);
        SearchMailDTO mail = new SearchMailDTO();
        mail.setFolder("sent");
        mail.setFromCount(0);
        mail.setToCount(0);
        mail.setSearchTerm(mailId);
        mail.setFromDate(FDate);
        mail.setToDate(EDate);
        List<MailDTO> mailObj1 = messageHandler.searchMail(mail);
         Collections.reverse(mailObj1);
        for (MailDTO data : mailObj1) {
            String m_attachmentTrue = "";
            String msgType = "";
            String sec_symbl = "";
            if ((String) data.getHeaderMap().get("Date") != null) {
                receivedDate = (String) data.getHeaderMap().get("Date");
            }
            //String mailId = data.getId();
            if ((String) data.getHeaderMap().get("originalReceiver") != null) {
                receivedFrom = (String) data.getHeaderMap().get("originalReceiver");
            }
            if ((String) data.getHeaderMap().get("Subject") != null) {
                subject = (String) data.getHeaderMap().get("Subject");
            }
            if ((String) data.getHeaderMap().get("msgType") != null) {
                msgType = (String) data.getHeaderMap().get("msgType");
            }
            if (data.getHeaderMap().get("uid") != null) {
                mail_id = data.getHeaderMap().get("uid") + "";
            }
            if (data.getHeaderMap().get("redStatus") != null) {
                Currentreadstatus = (boolean) data.getHeaderMap().get("redStatus");
            }
            System.out.println("Mail Id:" + mail_id);
            if ((String) data.getHeaderMap().get("Date") != null) {
                System.out.println("Receive date:" + (String) data.getHeaderMap().get("Date"));
            }
            if (data.getHeaderMap().get("Subject") != null) {
                System.out.println("Mail Subject:" + data.getHeaderMap().get("Subject"));
            }
            if ((String) data.getHeaderMap().get("security_level") != null) {
                security_level = (String) data.getHeaderMap().get("security_level");
            }

            if (security_level != null || !security_level.equalsIgnoreCase("")) {
                System.out.println("SEC SYMBOL" + security_level);
                for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                    if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
                        sec_symbl = singleObj.getSecclasssymbol();
                    }
                }
            }
            preceColor = "";
            if ((String) data.getHeaderMap().get("precedence") != null) {
                precVal = (String) data.getHeaderMap().get("precedence");
            }
            if (precVal != null) {
                if (precVal != null) {
                    for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                        if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                            preceColor = singleObj.getPreccolour();
                        }
                    }
                }
            }
            if (data.getHeaderMap().get("attachment") != null) {
                m_Attachment = (String) data.getHeaderMap().get("attachment");
                m_attachmentTrue = m_Attachment;
            }

            mail_table_list.add(new SentMailList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
            sec_sym_column_mail_table.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
            from_column_mail_table.setCellValueFactory(new PropertyValueFactory<>("from"));
            Subj_column_mail_table.setCellValueFactory(new PropertyValueFactory<>("subject"));
            date_column_mail_table.setCellValueFactory(new PropertyValueFactory<>("date"));
            precedence_col_sent_mail.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
            size_column_mail_table.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
            precedence_col_sent_mail.setCellFactory(col -> new TableCell<SentMailList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String color, boolean empty) {
                    super.updateItem(color, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (color.equalsIgnoreCase("Tomato")) {
                            imageView.setImage(imgtomato);
                        } else if (color.equalsIgnoreCase("Orange")) {
                            imageView.setImage(imgorange);
                        } else if (color.equalsIgnoreCase("LightBlue")) {
                            imageView.setImage(imglightblue);
                        } else if (color.equalsIgnoreCase("LightGreen")) {
                            imageView.setImage(imglightgreen);
                        } else if (color.equalsIgnoreCase("Yellow")) {
                            imageView.setImage(imgyellow);
                        } else if (color.equalsIgnoreCase("Pink")) {
                            imageView.setImage(imgpink);
                        } else {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
            mail_table.setRowFactory(row -> new TableRow<SentMailList>() {
                @Override
                public void updateItem(SentMailList item, boolean status) {
                    super.updateItem(item, Currentreadstatus);
                    if (item == null) {
                        setStyle("");
                    } else if (item.getCurrentreadstatus() == false) {
                        setStyle("-fx-font-weight:bold;");
                    } else if (item.getCurrentreadstatus() == true) {
                        setStyle("-fx-font-weight:normal;");
                    }
                }
            });
            size_column_mail_table.setCellFactory(colattach -> new TableCell<SentMailList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String attach, boolean empty) {
                    super.updateItem(attach, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (attach.equals("true")) {
                            imageView.setImage(imgattach);
                        } else if (attach.equals("false")) {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
        }
        mail_table.setItems(FXCollections.observableArrayList(mail_table_list));
        mail_table.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    /**
     * ******************************************************************
     * @Function Name :onSearchTrash.
     * @Description :Method to search mail in Trash Box table.
     * @Input Parameter : ActionEvent -Provided by JavaFX.
     * @Output Parameter	:NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :13-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onSearchTrash(ActionEvent event) throws Exception {
     

        lblinboxview.setVisible(false);
        lblsentmailview.setVisible(false);
        lbloutboxview.setVisible(false);
        lblDraftview.setVisible(false);
        lblTrashview.setVisible(true);
        lblSearch_results.setVisible(true);
        lblSearch_results.setText("Result Showing for Searched Mails");
        trash_table_list.clear();
        fday = from_date.getValue().getDayOfWeek().toString();
        String from_day = get_day(fday);
        int date = from_date.getValue().getDayOfMonth();
        fmonth = from_date.getValue().getMonth().toString();
        String from_month = get_month(fmonth);
        int year = from_date.getValue().getYear();
        int h = from_timer.getValue().getHour();
        int m = from_timer.getValue().getMinute();
        int s = from_timer.getValue().getSecond();
        System.out.println(h + "" + m + "" + s);
        String FDate = from_day + "," + " " + date + " " + from_month + " " + year + " " + h + ":" + m + ":" + s + " " + "+0530" + " " + "(IST)";
        System.out.println("FDate :" + FDate);
        eday = to_date.getValue().getDayOfWeek().toString();
        String End_day = get_day(eday);
        int edate = to_date.getValue().getDayOfMonth();
        emonth = to_date.getValue().getMonth().toString();
        String To_month = get_month(emonth);
        int eyear = to_date.getValue().getYear();
        int eh = to_timer.getValue().getHour();
        int em = to_timer.getValue().getMinute();
        int es = to_timer.getValue().getSecond();
        System.out.println(h + "" + m + "" + s);
        String EDate = End_day + "," + " " + edate + " " + To_month + " " + eyear + " " + eh + ":" + em + ":" + es + " " + "+0530" + " " + "(IST)";
        System.out.println("EDate :" + EDate);
        String user = search_mail.getText();
        String officeName = messageHandler.preCheck(user).getOfficeName();
        System.out.println(user);
        Tcs_Users userObj = messageHandler.getTcsUser(user, officeName);
        String mailId = userObj.getMailId();
        System.out.println("mail Id: " + mailId);
        SearchMailDTO mail = new SearchMailDTO();
        mail.setFolder("trash");
        mail.setFromCount(0);
        mail.setToCount(0);
        mail.setSearchTerm(mailId);
        mail.setFromDate(FDate);
        mail.setToDate(EDate);
        List<MailDTO> mailObj1 = messageHandler.searchMail(mail);
        Collections.reverse(mailObj1);
        for (MailDTO data : mailObj1) {
            String m_attachmentTrue = "";
            String msgType = "";
            String sec_symbl = "";
            if ((String) data.getHeaderMap().get("Date") != null) {
                receivedDate = (String) data.getHeaderMap().get("Date");
            }
            if ((String) data.getHeaderMap().get("From") != null) {
                receivedFrom = (String) data.getHeaderMap().get("From");
            }
            if ((String) data.getHeaderMap().get("Subject") != null) {
                subject = (String) data.getHeaderMap().get("Subject");
            }
            if ((String) data.getHeaderMap().get("msgType") != null) {
                msgType = (String) data.getHeaderMap().get("msgType");
            }
            if (data.getHeaderMap().get("uid") != null) {
                mail_id = data.getHeaderMap().get("uid") + "";
            }
            System.out.println("Mail Id:" + mail_id);
            if (data.getHeaderMap().get("redStatus") != null) {
                Currentreadstatus = (boolean) data.getHeaderMap().get("redStatus");
            }
            if ((String) data.getHeaderMap().get("Date") != null) {
                System.out.println("Receive date:" + (String) data.getHeaderMap().get("Date"));
            }
            if (data.getHeaderMap().get("Subject") != null) {
                System.out.println("Mail Subject:" + data.getHeaderMap().get("Subject"));
            }
            if ((String) data.getHeaderMap().get("security_level") != null) {
                security_level = (String) data.getHeaderMap().get("security_level");
            }

            if (security_level != null || security_level == "") {
                for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                    if (security_level.equalsIgnoreCase(singleObj.getSecclassvalue())) {
                        sec_symbl = singleObj.getSecclasssymbol();
                    }
                }
            }

            preceColor = "";
            if ((String) data.getHeaderMap().get("precedence") != null) {
                precVal = (String) data.getHeaderMap().get("precedence");
            }
            if (precVal != null) {
                if (precVal != null) {
                    for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                        if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                            preceColor = singleObj.getPreccolour();
                        }
                    }
                }
            }
            if (data.getHeaderMap().get("attachment") != null) {
                m_Attachment = (String) data.getHeaderMap().get("attachment");
                m_attachmentTrue = m_Attachment;
            }
//         if ((String) data.getHeaderMap().get("attachedFileName") != "" || (String) data.getHeaderMap().get("attachedFileName") != null) {
//                m_Attachment = (String) data.getHeaderMap().get("attachedFileName");
//                System.out.println("Attachment is" + m_Attachment);
//            }
//            Boolean attachment = false;
//            if (m_Attachment == null || m_Attachment.equals("")) {
//                attachment = false;
//                m_attachmentTrue = attachment.toString();
//                System.out.println("Attachment is false" + m_attachmentTrue);
//            } else {
//                attachment = true;
//                m_attachmentTrue = attachment.toString();
//                System.out.println("attachment is true " + m_attachmentTrue);
//            }
            trash_table_list.add(new TrashTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
            sec_sym_column_trash_box.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
            from_column_trash_box.setCellValueFactory(new PropertyValueFactory<>("from"));
            Subj_column_trash_box.setCellValueFactory(new PropertyValueFactory<>("subject"));
            date_column_trash_box.setCellValueFactory(new PropertyValueFactory<>("date"));
            precedence_col_trash_mail.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
            size_column_trash_box.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
            precedence_col_trash_mail.setCellFactory(col -> new TableCell<TrashTabList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String color, boolean empty) {
                    super.updateItem(color, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (color.equalsIgnoreCase("Tomato")) {
                            imageView.setImage(imgtomato);
                        } else if (color.equalsIgnoreCase("Orange")) {
                            imageView.setImage(imgorange);
                        } else if (color.equalsIgnoreCase("LightBlue")) {
                            imageView.setImage(imglightblue);
                        } else if (color.equalsIgnoreCase("LightGreen")) {
                            imageView.setImage(imglightgreen);
                        } else if (color.equalsIgnoreCase("Yellow")) {
                            imageView.setImage(imgyellow);
                        } else if (color.equalsIgnoreCase("Pink")) {
                            imageView.setImage(imgpink);
                        } else {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
            mail_table_trash_box.setRowFactory(row -> new TableRow<TrashTabList>() {
                @Override
                public void updateItem(TrashTabList item, boolean status) {
                    super.updateItem(item, Currentreadstatus);
                    if (item == null) {
                        setStyle("");
                    } else if (item.getCurrentreadstatus() == false) {
                        setStyle("-fx-font-weight:bold;");
                    } else if (item.getCurrentreadstatus() == true) {
                        setStyle("-fx-font-weight:normal;");
                    }
                }
            });
            size_column_trash_box.setCellFactory(colattach -> new TableCell<TrashTabList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String attach, boolean empty) {
                    super.updateItem(attach, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (attach.equals("true")) {
                            imageView.setImage(imgattach);
                        } else if (attach.equals("false")) {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
        }
        mail_table_trash_box.setItems(FXCollections.observableArrayList(trash_table_list));
        mail_table_trash_box.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    /**
     * ******************************************************************
     * @Function Name :onClickResetSerach.
     * @Description :Method to Reset fields.
     * @Input Parameter : ActionEvent -Provided by JavaFX.
     * @Output Parameter	:NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :12-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onClickResetSerach(ActionEvent event) throws SQLException {
        search_lable.setVisible(false);
        System.out.println("reset...");
        try {
            from_date.setValue(null);
            to_date.setValue(null);
            from_timer.getEditor().clear();
            from_timer.setValue(null);
            to_timer.setValue(null);
            search_mail.setText(null);
        } catch (NullPointerException e) {
            System.out.println("Button not Reset");
        }
    }

    /**
     * ******************************************************************
     * @Function Name :addMouseScrolling.
     * @Description :Method to handle table Scroll events.
     * @Input Parameter : ScrollEvent -Provided by JavaFX.
     * @Output Parameter :NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :9-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void addMouseScrolling(TableView mail_header) {
        mail_header.setOnScroll((ScrollEvent event) -> {
         
        });
    }

    /**
     * ******************************************************************
     * @Function Name :onSearchAdressBook.
     * @Description :Method to search address book contact Details.
     * @Input Parameter : ActionEvent -Provided by JavaFX.
     * @Output Parameter	:NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :29-MAR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onSearchAdressBook(ActionEvent event) throws Exception {
        try {
            contact_email.setText(null);
            Contact_details.setText(null);
            MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
            Contact contact = new Contact();
            contact.setOffice(messageHandler.ldapUserOffice(textsearch.getText()));
            contact.setOwner(textsearch.getText());
            ContactInfoDTO dto = messageHandler.getContactINfo(contact);
            Office_name = dto.getOfficeName();
            Postal_adress = dto.getPostalAddress();
            Role = dto.getRole();
            Telephone_number = dto.getTelephoneNumber();
            Exceptin_msg = dto.getExceptionMsg();
            Mail_id = dto.getMailId();
            String Office[] = Office_name.split(":");
            String SplitId[] = Mail_id.split(":");
         
            //Displaying Contact information in Text Area
            Contact_details.setText(" Office Name: " + Office[1] + "\n\n" + " Rank: " + "\n\n" + " Appointment: " + "\n\n" + " Unit/Formation: " + "\n\n" + " Telephone number: " + Telephone_number + "\n\n" + " Mobile number: " + "\n\n" + " E-mail id: " + "\n\n" + " Role: " + "\n\n");
            contact_email.setText(SplitId[1]);
        } catch (NullPointerException e) {
            System.out.println("Not able read contact details");
        }
    }

    /**
     * ******************************************************************
     * @Function Name :refresh.
     * @Description :Method to use refresh all mail headers.
     * @Input Parameter : NA.
     * @Output Parameter	:NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :20-MAR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    public void refresh() {
      

        unReadMailCountFolder();
        m_unReadMailInboxcount = 0;
        if (m_unReadMailInboxcount == 0) {
            tabinbox.setText("Inbox");
        } else {
            tabinbox.setText("Inbox(" + m_unReadMailInboxcount + ")");
        }
        System.out.println(m_unReadMailInboxcount);

        m_unReadReviewMailcount = 0;
        if (m_unReadReviewMailcount == 0) {
            tabReview.setText("Review");
        } else {
            tabReview.setText("Review(" + m_unReadReviewMailcount + ")");
        }
        System.out.println(m_unReadReviewMailcount);
        m_unReadApproveMailcount = 0;
        if (m_unReadApproveMailcount == 0) {
            tabApprove.setText("Approve");
        } else {
            tabApprove.setText("Approve(" + m_unReadApproveMailcount + ")");
        }

        System.out.println(m_unReadApproveMailcount);
        m_unReadOfficeMailcount = 0;
        if (m_unReadOfficeMailcount == 0) {
            tabOffice.setText("Office");
        } else {
            tabOffice.setText("Office(" + m_unReadOfficeMailcount + ")");
        }

        System.out.println(m_unReadOfficeMailcount);
        table_list.clear();
        riview_table_list.clear();
        approve_table_list.clear();
        office_table_list.clear();
        lblSearch_results.setVisible(false);
        search_lable.setVisible(false);
//        delete_mail.setVisible(true);
//        delete_reviewmail.setVisible(false);
//        deleteApproveMail.setVisible(false);
//        deleteOfficeMail.setVisible(false);
//        deleteSentMail.setVisible(false);
//        deleteOutBoxMail.setVisible(false);
//        deleteDraftMail.setVisible(false);

        prcedenceList = messageHandler.getAllPrecedenceConfig();
        SecurityClssificationConfigList = messageHandler.getAllSecurityClassConfig();
        PrecedenceDTO objprecedence;
        try {
            ViewFolderMailsDTO obj = new ViewFolderMailsDTO();
            obj.setFolder("inbox");
            obj.setFromCount(0);
            obj.setToCount(0);
            list = messageHandler.receiveInboxMails(obj);
            
            System.out.println("MAil Count:" + list.size());
             Collections.reverse(list);
            for (MailDTO data : list) {

                String msgType = "";
                String sec_symbl = "";
                String m_attachmentTrue = "";
                if (data.getHeaderMap().get("From") != null) {
                    receivedFrom = (String) data.getHeaderMap().get("From");
                }
                if (data.getHeaderMap().get("Subject") != null) {
                    subject = (String) data.getHeaderMap().get("Subject");
                }
                if ((String) data.getHeaderMap().get("Date") != null) {
                    receivedDate = (String) data.getHeaderMap().get("Date");
                    System.out.println("receivedDate"+receivedDate);
                }
                if ((String) data.getHeaderMap().get("msgType") != null) {
                    msgType = (String) data.getHeaderMap().get("msgType");
                }
                //              else {
//                    msgType = null;
//                }
                Double temp_mail_id_double = null;
                long temp_mail_id_long = 0;

                if (data.getHeaderMap().get("uid") != null) {
                    temp_mail_id_double = (Double) data.getHeaderMap().get("uid");
                }
                if (temp_mail_id_double != null) {
                    temp_mail_id_long = temp_mail_id_double.intValue();
                }
                mail_id = temp_mail_id_long + "";
                if (data.getHeaderMap().get("redStatus") != null) {
                    System.out.println("getRead()" + data.getHeaderMap().get("redStatus"));
                }

//                if (data.getHeaderMap().get("redStatus") != null) {
//                    Currentreadstatus = (boolean) data.getHeaderMap().get("redStatus");
//                    if(Currentreadstatus==false){
//                  //  m_unReadMailcount++;
//                    }
//                      System.out.println("unreadmail"+m_unReadMailcount);
//                      unreadmail=Integer.toString(m_unReadMailcount);
//                     m_inBoXUnreadMail.setText("("+unreadmail+")");         
//                    
//                       if(Currentreadstatus==true){
//                   m_sentBoxUnreadMail.setText(null);
//                    }
////                    if(unreadmail=="0"){
////                   m_inBoXUnreadMail.setText(null);
//  //              }
//                    
//              
//                    System.out.println("READ STATUS "+Currentreadstatus);
                //   }
                System.out.println("Mail Id:" + mail_id);
                System.out.println("Mail Subject:" + subject);
                System.out.println("Message type" + msgType);
                System.out.println(mail_id);
//                if ((String) data.getHeaderMap().get("security_level") != null) {
//                    security_level = (String) data.getHeaderMap().get("security_level");
//                }
//                SecurityClassConfigDTO obj1 = null;
//
//                if (security_level != null || !security_level.equalsIgnoreCase("")) {
//                    System.out.println("SEC SYMBOL" + security_level);
//                    for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
//                        if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
//                            sec_symbl = singleObj.getSecclasssymbol();
//                        }
//                    }
//                }
                if (data.getHeaderMap().get("Altrecp") != null) {
                    AltRecp = (String) data.getHeaderMap().get("Altrecp");
                    System.out.println("ALTERNATE" + AltRecp);
                    if(AltRecp.equals("1"))   
                    {
                        msgType="AlternateRecipt";
                    }
                    System.out.println("ALTERNATE_MAIL_ID" + mail_id);

                }
//                if ((String) data.getHeaderMap().get("attachment") != "" || (String) data.getHeaderMap().get("attachment") != null) {
//                    m_Attachment = (String) data.getHeaderMap().get("attachment");
//
//                }
                if (data.getHeaderMap().get("attachment") != null) {
                    m_Attachment = (String) data.getHeaderMap().get("attachment");
                    m_attachmentTrue = m_Attachment;
                }

//                if ((subject.equals("Successful Mail Delivery Report") && msgType == null) || msgType.equalsIgnoreCase("PDSN") || msgType.equalsIgnoreCase("ForwardToSameOffice") || msgType.equalsIgnoreCase("ReadReceipt") || msgType.equalsIgnoreCase("PAltDSN") || msgType.equalsIgnoreCase("NDSN") || msgType.equalsIgnoreCase("REJECTMAIL")) {
                //if (msgType=="" || msgType == null || msgType.equalsIgnoreCase("ForwardToSameOffice") || msgType.equalsIgnoreCase("ReadReceipt") || msgType.equalsIgnoreCase("REJECTMAIL")||msgType.equalsIgnoreCase("PDSN")) {
                if ("".equals(msgType) || msgType == null || msgType.equalsIgnoreCase("PDSN") || msgType.equalsIgnoreCase("ForwardToSameOffice") || msgType.equalsIgnoreCase("ReadReceipt") || msgType.equalsIgnoreCase("PAltDSN") || msgType.equalsIgnoreCase("NDSN") || msgType.equalsIgnoreCase("REJECTMAIL") || subject.equals("Successful Mail Delivery Report")) {
                    /*   if (AltRecp != null) {
                    
                        if (AltRecp.equalsIgnoreCase("1") || AltRecp == "1") {

                            preceColor = "";
                            precVal = null;
//                    System.out.println("I'm in ForwardToAnotherOffice condition..........");
                            if ((String) data.getHeaderMap().get("precedence") != null) {
                                precVal = (String) data.getHeaderMap().get("precedence");
                            }
                            if (precVal != null) {

                                objprecedence = messageHandler.getPrecedenceConfig(precVal);
                                preceColor = objprecedence.getPreccolour();
//                        System.out.println("bel color is:" + preceColor);

                            }
                            office_table_list.add(new OfficeTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus));
                            sec_sym_column_office.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
                            from_column_office.setCellValueFactory(new PropertyValueFactory<>("from"));

                            Subj_column_office.setCellValueFactory(new PropertyValueFactory<>("subject"));

                            date_column_office.setCellValueFactory(new PropertyValueFactory<>("date"));

                            colofficeprecedencecolorvalue.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
                            colofficeprecedencecolorvalue.setCellFactory(col -> new TableCell<office_tab_list, String>() {
                                private final ImageView imageView = new ImageView();

                                @Override
                                protected void updateItem(String color, boolean empty) {
                                    super.updateItem(color, empty);
                                    if (empty) {
                                        setGraphic(null);
                                    } else {
                                        if (color.equalsIgnoreCase("Tomato")) {
                                            imageView.setImage(imgtomato);
                                        } else if (color.equalsIgnoreCase("Orange")) {
                                            imageView.setImage(imgorange);
                                        } else if (color.equalsIgnoreCase("LightBlue")) {
                                            imageView.setImage(imglightblue);
                                        } else if (color.equalsIgnoreCase("LightGreen")) {
                                            imageView.setImage(imglightgreen);
                                        } else if (color.equalsIgnoreCase("Yellow")) {
                                            imageView.setImage(imgyellow);
                                        } else if (color.equalsIgnoreCase("Pink")) {
                                            imageView.setImage(imgpink);
                                        } else {
                                            imageView.setImage(null);
                                        }
                                        setGraphic(imageView);
                                    }
                                }
                            });
                            mail_header_office.setRowFactory(row -> new TableRow<office_tab_list>() {
                                @Override
                                public void updateItem(OfficeTabList item, boolean status) {
                                    super.updateItem(item, Currentreadstatus);
                                    if (item == null) {
                                        setStyle("");
                                    } else if (item.getCurrentreadstatus() == false) {
                                        setStyle("-fx-font-weight:bold;");
                                    } else if (item.getCurrentreadstatus() == true) {
                                        setStyle("-fx-font-weight:normal;");
                                    }
                                }
                            });
                        }
                  } else 
                    {} */

                    preceColor = "";
                    precVal = null;
                    if ((String) data.getHeaderMap().get("precedence") != null) {
                        precVal = (String) data.getHeaderMap().get("precedence");
                    }
                    if (precVal != null) {

                        if (precVal != null) {
                            for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                                if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                                    preceColor = singleObj.getPreccolour();
                                }
                            }
                        }

                    }
                    if (data.getHeaderMap().get("redStatus") != null) {
                        Currentreadstatus = (boolean) data.getHeaderMap().get("redStatus");
                    }
                    if ((String) data.getHeaderMap().get("security_level") != null) {
                        security_level = (String) data.getHeaderMap().get("security_level");
                    }
                    SecurityClassConfigDTO obj1 = null;

                    if (security_level != null || !security_level.equalsIgnoreCase("")) {
                        System.out.println("SEC SYMBOL" + security_level);
                        for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                            if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
                                sec_symbl = singleObj.getSecclasssymbol();
                            }
                        }
                    }

                    table_list.add(new InBoxTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));

                    from_column_inbox.setCellValueFactory(new PropertyValueFactory<>("from"));
                    date_column_inbox.setCellValueFactory(new PropertyValueFactory<>("date"));
                    Subj_column_inbox.setCellValueFactory(new PropertyValueFactory<>("subject"));
                    sec_sym_column_inbox.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
                    colinboxprecedencecolorvalue.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
                    size_column_inbox.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
                    colinboxprecedencecolorvalue.setCellFactory(col -> new TableCell<InBoxTabList, String>() {
                        private final ImageView imageView = new ImageView();

                        @Override
                        protected void updateItem(String color, boolean empty) {
                            super.updateItem(color, empty);
                            if (empty) {
                                setGraphic(null);
                            } else {
                                if (color.equalsIgnoreCase("Tomato")) {
                                    imageView.setImage(imgtomato);
                                } else if (color.equalsIgnoreCase("Orange")) {
                                    imageView.setImage(imgorange);
                                } else if (color.equalsIgnoreCase("LightBlue")) {
                                    imageView.setImage(imglightblue);
                                } else if (color.equalsIgnoreCase("LightGreen")) {
                                    imageView.setImage(imglightgreen);
                                } else if (color.equalsIgnoreCase("Yellow")) {
                                    imageView.setImage(imgyellow);
                                } else if (color.equalsIgnoreCase("Pink")) {
                                    imageView.setImage(imgpink);
                                } else {
                                    imageView.setImage(null);
                                }
                                setGraphic(imageView);
                            }
                        }
                    });
                    mail_header.setRowFactory(row -> new TableRow<InBoxTabList>() {
                        @Override
                        public void updateItem(InBoxTabList item, boolean status) {
                            super.updateItem(item, Currentreadstatus);
                            if (item == null) {
                                setStyle("");
                            } else if (item.getCurrentreadstatus() == false) {
                                setStyle("-fx-font-weight:bold;");
                            } else if (item.getCurrentreadstatus() == true) {
                                setStyle("-fx-font-weight:normal;");
                            }
                        }
                    });
                    if (Currentreadstatus == false) {
                        m_unReadMailInboxcount++;
                        // unreadmail=Integer.toString(m_unReadMailInboxcount);
                        System.out.println("INBOX TAB" + m_unReadMailInboxcount);
                        tabinbox.setText("Inbox (" + m_unReadMailInboxcount + ")");
                    }

                    size_column_inbox.setCellFactory(colattach -> new TableCell<InBoxTabList, String>() {
                        private final ImageView imageView = new ImageView();

                        @Override
                        protected void updateItem(String attach, boolean empty) {
                            super.updateItem(attach, empty);
                            if (empty) {
                                setGraphic(null);
                            } else {
                                if (attach.equals("true")) {
                                    imageView.setImage(imgattach);
                                } else if (attach.equals("false")) {
                                    imageView.setImage(null);
                                }
                                setGraphic(imageView);
                            }
                        }
                    });

                } else if (msgType.equalsIgnoreCase("Draft")) // Mail header display in Riview Tab Table
                {
                    preceColor = "";
                    precVal = null;
                    if ((String) data.getHeaderMap().get("precedence") != null) {
                        precVal = (String) data.getHeaderMap().get("precedence");
                    }
                    if (precVal != null) {

                        if (precVal != null) {
                            for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                                if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                                    preceColor = singleObj.getPreccolour();
                                }
                            }
                        }
                    }
                    if (data.getHeaderMap().get("redStatus") != null) {
                        Currentreadstatus = (boolean) data.getHeaderMap().get("redStatus");
                    }
                    if ((String) data.getHeaderMap().get("security_level") != null) {
                        security_level = (String) data.getHeaderMap().get("security_level");
                    }
                    SecurityClassConfigDTO obj1 = null;

                    if (security_level != null || !security_level.equalsIgnoreCase("")) {
                        System.out.println("SEC SYMBOL" + security_level);
                        for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                            if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
                                sec_symbl = singleObj.getSecclasssymbol();
                            }
                        }
                    }

                    riview_table_list.add(new RiviewTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
                    sec_sym_column_review.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
                    from_column_review.setCellValueFactory(new PropertyValueFactory<>("from"));
                    Subj_column_review.setCellValueFactory(new PropertyValueFactory<>("subject"));
                    date_column_review.setCellValueFactory(new PropertyValueFactory<>("date"));
                    size_column_review.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
                    col_review_precedence.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
                    col_review_precedence.setCellFactory(col -> new TableCell<RiviewTabList, String>() {
                        private final ImageView imageView = new ImageView();

                        @Override
                        protected void updateItem(String color, boolean empty) {
                            super.updateItem(color, empty);
                            if (empty) {
                                setGraphic(null);
                            } else {
                                if (color.equalsIgnoreCase("Tomato")) {
                                    imageView.setImage(imgtomato);
                                } else if (color.equalsIgnoreCase("Orange")) {
                                    imageView.setImage(imgorange);
                                } else if (color.equalsIgnoreCase("LightBlue")) {
                                    imageView.setImage(imglightblue);
                                } else if (color.equalsIgnoreCase("LightGreen")) {
                                    imageView.setImage(imglightgreen);
                                } else if (color.equalsIgnoreCase("Yellow")) {
                                    imageView.setImage(imgyellow);
                                } else if (color.equalsIgnoreCase("Pink")) {
                                    imageView.setImage(imgpink);
                                } else {
                                    imageView.setImage(null);
                                }
                                setGraphic(imageView);
                            }
                        }
                    });

                    mail_header_review.setRowFactory(row -> new TableRow<RiviewTabList>() {
                        @Override
                        public void updateItem(RiviewTabList item, boolean status) {
                            super.updateItem(item, Currentreadstatus);
                            if (item == null) {
                                setStyle("");
                            } else if (item.getCurrentreadstatus() == false) {
                                setStyle("-fx-font-weight:bold;");
                            } else if (item.getCurrentreadstatus() == true) {
                                setStyle("-fx-font-weight:normal;");
                            }
                        }
                    });
                    if (Currentreadstatus == false) {
                        m_unReadReviewMailcount++;
                        // unreadmail=Integer.toString(m_unReadMailInboxcount);
                        System.out.println("Review TAB" + m_unReadReviewMailcount);
                        tabReview.setText("Review (" + m_unReadReviewMailcount + ")");
                    }
                    size_column_review.setCellFactory(colattach -> new TableCell<RiviewTabList, String>() {
                        private final ImageView imageView = new ImageView();

                        @Override
                        protected void updateItem(String attach, boolean empty) {
                            super.updateItem(attach, empty);
                            if (empty) {
                                setGraphic(null);
                            } else {
                                if (attach.equals("true")) {
                                    imageView.setImage(imgattach);
                                } else if (attach.equals("false")) {
                                    imageView.setImage(null);
                                }
                                setGraphic(imageView);
                            }
                        }
                    });
                } else if (msgType.equalsIgnoreCase("ReviewAccept")) // Mail header display in Approve Tab Table
                {
                    preceColor = "";
                    precVal = null;
                    if ((String) data.getHeaderMap().get("precedence") != null) {
                        precVal = (String) data.getHeaderMap().get("precedence");
                    }
                    if (precVal != null) {

                        if (precVal != null) {
                            for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                                if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                                    preceColor = singleObj.getPreccolour();
                                }
                            }
                        }

                    }
                    if (data.getHeaderMap().get("redStatus") != null) {
                        Currentreadstatus = (boolean) data.getHeaderMap().get("redStatus");
                    }
                    if ((String) data.getHeaderMap().get("security_level") != null) {
                        security_level = (String) data.getHeaderMap().get("security_level");
                    }
                    SecurityClassConfigDTO obj1 = null;

                    if (security_level != null || !security_level.equalsIgnoreCase("")) {
                        System.out.println("SEC SYMBOL" + security_level);
                        for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                            if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
                                sec_symbl = singleObj.getSecclasssymbol();
                            }
                        }
                    }

                    approve_table_list.add(new ApproveTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
                    sec_sym_column_approve.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
                    from_column_approve.setCellValueFactory(new PropertyValueFactory<>("from"));
                    Subj_column_approve.setCellValueFactory(new PropertyValueFactory<>("subject"));
                    date_column_approve.setCellValueFactory(new PropertyValueFactory<>("date"));
                    col_approve_precedence.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
                    size_column_approve.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
                    col_approve_precedence.setCellFactory(col -> new TableCell<ApproveTabList, String>() {
                        private final ImageView imageView = new ImageView();

                        @Override
                        protected void updateItem(String color, boolean empty) {
                            super.updateItem(color, empty);
                            if (empty) {
                                setGraphic(null);
                            } else {
                                if (color.equalsIgnoreCase("Tomato")) {
                                    imageView.setImage(imgtomato);
                                } else if (color.equalsIgnoreCase("Orange")) {
                                    imageView.setImage(imgorange);
                                } else if (color.equalsIgnoreCase("LightBlue")) {
                                    imageView.setImage(imglightblue);
                                } else if (color.equalsIgnoreCase("LightGreen")) {
                                    imageView.setImage(imglightgreen);
                                } else if (color.equalsIgnoreCase("Yellow")) {
                                    imageView.setImage(imgyellow);
                                } else if (color.equalsIgnoreCase("Pink")) {
                                    imageView.setImage(imgpink);
                                } else {
                                    imageView.setImage(null);
                                }
                                setGraphic(imageView);
                            }
                        }
                    });
                    mail_header_approve.setRowFactory(row -> new TableRow<ApproveTabList>() {
                        @Override
                        public void updateItem(ApproveTabList item, boolean status) {
                            super.updateItem(item, Currentreadstatus);
                            if (item == null) {
                                setStyle("");
                            } else if (item.getCurrentreadstatus() == false) {
                                setStyle("-fx-font-weight:bold;");
                            } else if (item.getCurrentreadstatus() == true) {
                                setStyle("-fx-font-weight:normal;");
                            }
                        }
                    });
                    if (Currentreadstatus == false) {
                        m_unReadApproveMailcount++;
                        // unreadmail=Integer.toString(m_unReadMailInboxcount);
                        System.out.println("Approve TAB" + m_unReadApproveMailcount);
                        tabApprove.setText("Approve (" + m_unReadApproveMailcount + ")");
                    }
                    size_column_approve.setCellFactory(colattach -> new TableCell<ApproveTabList, String>() {
                        private final ImageView imageView = new ImageView();

                        @Override
                        protected void updateItem(String attach, boolean empty) {
                            super.updateItem(attach, empty);
                            if (empty) {
                                setGraphic(null);
                            } else {
                                if (attach.equals("true")) {
                                    imageView.setImage(imgattach);
                                } else if (attach.equals("false")) {
                                    imageView.setImage(null);
                                }
                                setGraphic(imageView);
                            }
                        }
                    });
                } else if (AltRecp.equalsIgnoreCase("1") || AltRecp.equals("1") || msgType.equalsIgnoreCase("ForwardToAnotherOffice") || msgType.equalsIgnoreCase("SENDTODESIGNATEDUSER")) // Mail header display in Office Tab Table
                {

                    preceColor = "";
                    precVal = null;
                    if ((String) data.getHeaderMap().get("precedence") != null) {
                        precVal = (String) data.getHeaderMap().get("precedence");
                    }
                    if (precVal != null) {
                        if (precVal != null) {
                            for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                                if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                                    preceColor = singleObj.getPreccolour();
                                }
                            }
                        }

                    }
                    if (data.getHeaderMap().get("redStatus") != null) {
                        Currentreadstatus = (boolean) data.getHeaderMap().get("redStatus");
                    }
                    if ((String) data.getHeaderMap().get("security_level") != null) {
                        security_level = (String) data.getHeaderMap().get("security_level");
                    }
                    SecurityClassConfigDTO obj1 = null;

                    if (security_level != null || !security_level.equalsIgnoreCase("")) {
                        System.out.println("SEC SYMBOL" + security_level);
                        for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                            if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
                                sec_symbl = singleObj.getSecclasssymbol();
                            }
                        }
                    }

                    office_table_list.add(new OfficeTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
                    sec_sym_column_office.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
                    from_column_office.setCellValueFactory(new PropertyValueFactory<>("from"));

                    Subj_column_office.setCellValueFactory(new PropertyValueFactory<>("subject"));

                    date_column_office.setCellValueFactory(new PropertyValueFactory<>("date"));
                    size_column_office.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
                    colofficeprecedencecolorvalue.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
                    colofficeprecedencecolorvalue.setCellFactory(col -> new TableCell<OfficeTabList, String>() {
                        private final ImageView imageView = new ImageView();

                        @Override
                        protected void updateItem(String color, boolean empty) {
                            super.updateItem(color, empty);
                            if (empty) {
                                setGraphic(null);
                            } else {
                                if (color.equalsIgnoreCase("Tomato")) {
                                    imageView.setImage(imgtomato);
                                } else if (color.equalsIgnoreCase("Orange")) {
                                    imageView.setImage(imgorange);
                                } else if (color.equalsIgnoreCase("LightBlue")) {
                                    imageView.setImage(imglightblue);
                                } else if (color.equalsIgnoreCase("LightGreen")) {
                                    imageView.setImage(imglightgreen);
                                } else if (color.equalsIgnoreCase("Yellow")) {
                                    imageView.setImage(imgyellow);
                                } else if (color.equalsIgnoreCase("Pink")) {
                                    imageView.setImage(imgpink);
                                } else {
                                    imageView.setImage(null);
                                }
                                setGraphic(imageView);
                            }
                        }
                    });
                    mail_header_office.setRowFactory(row -> new TableRow<OfficeTabList>() {
                        @Override
                        public void updateItem(OfficeTabList item, boolean status) {
                            super.updateItem(item, Currentreadstatus);
                            if (item == null) {
                                setStyle("");
                            } else if (item.getCurrentreadstatus() == false) {
                                setStyle("-fx-font-weight:bold;");
                            } else if (item.getCurrentreadstatus() == true) {
                                setStyle("-fx-font-weight:normal;");
                            }
                        }
                    });
                    if (Currentreadstatus == false) {
                        m_unReadOfficeMailcount++;
                        // unreadmail=Integer.toString(m_unReadMailInboxcount);
                        System.out.println("Offoce TAB" + m_unReadOfficeMailcount);
                        tabOffice.setText("Office (" + m_unReadOfficeMailcount + ")");
                    }
                    size_column_office.setCellFactory(colattach -> new TableCell<OfficeTabList, String>() {
                        private final ImageView imageView = new ImageView();

                        @Override
                        protected void updateItem(String attach, boolean empty) {
                            super.updateItem(attach, empty);
                            if (empty) {
                                setGraphic(null);
                            } else {
                                if (attach.equals("true")) {
                                    imageView.setImage(imgattach);
                                } else if (attach.equals("false")) {
                                    imageView.setImage(null);
                                }
                                setGraphic(imageView);
                            }
                        }
                    });
                }

            }
//            System.out.println("End FOR loop");
            paginationInbox.setPageCount(numberOfPages(table_list.size()));
            paginationInbox.setPageFactory(this::createContactsPageInbox);
            paginationReview.setPageCount(numberOfPages(riview_table_list.size()));
            paginationReview.setPageFactory(this::createContactsPageReview);
            paginationApprove.setPageCount(numberOfPages(approve_table_list.size()));
            paginationApprove.setPageFactory(this::createContactsPageApprove);
            paginationOffice.setPageCount(numberOfPages(office_table_list.size()));
            paginationOffice.setPageFactory(this::createContactsPageOffice);

//            mail_header.setItems(FXCollections.observableArrayList(table_list));
            mail_header.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

//            mail_header_review.setItems(FXCollections.observableArrayList(riview_table_list));
            mail_header_review.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

//           mail_header_approve.setItems(FXCollections.observableArrayList(approve_table_list));
            mail_header_approve.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

//            mail_header_office.setItems(FXCollections.observableArrayList(office_table_list));
            mail_header_office.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        } catch (NullPointerException e) {

            e.printStackTrace();
            System.out.println("No data found some connection problem");
            System.out.println("Not getting data from Online");
        }

//                
//        ViewFolderMailsDTO obj1 = new ViewFolderMailsDTO();
//        obj1.setFolder("sent");
//        obj1.setFromCount(0);
//        obj1.setToCount(0);
//      
//        List<MailDTO> mailObjSent = messageHandler.receiveSentMails(obj1);
//        for (MailDTO data : mailObjSent) {
//            
//            
//                if (data.getHeaderMap().get("redStatus") != null) {
//                    Currentreadstatus = (boolean) data.getHeaderMap().get("redStatus");
//                    if(Currentreadstatus==false){
//                    m_unReadSentMailcount++;
//                    }
//                    System.out.println("unreadmail"+m_unReadSentMailcount);
//                    String unreadmail=Integer.toString(m_unReadSentMailcount);
//                    m_sentBoxUnreadMail.setText("("+unreadmail+")");
//                     if(Currentreadstatus==true){
//                   m_sentBoxUnreadMail.setText(null);
//                    }
//                }
//        
//        }
//        ViewFolderMailsDTO obj2 = new ViewFolderMailsDTO();
//        obj2.setFolder("drafts");
//        obj2.setFromCount(0);
//        obj2.setToCount(0);
//      
//        List<MailDTO> mailObjDraft = messageHandler.receiveSentMails(obj2);
//        for (MailDTO data : mailObjDraft) {
//            
//            
//                if (data.getHeaderMap().get("redStatus") != null) {
//                    Currentreadstatus = (boolean) data.getHeaderMap().get("redStatus");
//                    if(Currentreadstatus==false){
//                    m_unReadDraftMailcount++;
//                    }
//                    System.out.println("unreadmail"+m_unReadDraftMailcount);
//                    String unreadmail=Integer.toString(m_unReadDraftMailcount);
//                    m_draftBoxUnreadMail.setText("("+unreadmail+")");
//                     if(Currentreadstatus==true){
//                   m_draftBoxUnreadMail.setText(null);
//                    }
//                }
//        
//        }
//        
//           ViewFolderMailsDTO obj3 = new ViewFolderMailsDTO();
//        obj3.setFolder("trash");
//        obj3.setFromCount(0);
//        obj3.setToCount(0);
//      
//        List<MailDTO> mailObjTrash = messageHandler.receiveSentMails(obj3);
//        for (MailDTO data : mailObjTrash) {
//            
//            
//                if (data.getHeaderMap().get("redStatus") != null) {
//                    Currentreadstatus = (boolean) data.getHeaderMap().get("redStatus");
//                    if(Currentreadstatus==false){
//                    m_unReadTrashMailcount++;
//                    }
//                    System.out.println("unreadmail"+m_unReadTrashMailcount);
//                    String unreadmail=Integer.toString(m_unReadTrashMailcount);
//                    m_trashBoxUnreadMail.setText("("+unreadmail+")");
//                     if(Currentreadstatus==true){
//                   m_trashBoxUnreadMail.setText(null);
//                    }
//                }
//        
//        }
    }

    /**
     * ******************************************************************
     * @Function Name :onClickRefresh
     * @Description : Method to use refresh all mail headers
     * @Input Parameter : ActionEvent -Provided by JavaFX
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :20-MAR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onClickRefresh(ActionEvent event) throws SQLException {

        refresh();
//        m_progressService.restart();
    }

    /**
     * ******************************************************************
     * @Function Name :handleButtonAction
     * @Description : Method to create new Address book.
     * @Input Parameter : ActionEvent -Provided by JavaFX
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :8-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void handleButtonAction(ActionEvent event) throws IOException {
        if (event.getSource() == btn1) {
            root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/AddAddressBook.fxml"));
            address_book.setScene(new Scene(root1));
            address_book.setTitle("Add new addressbook");
            address_book.resizableProperty().setValue(Boolean.FALSE);
            address_book.show();
        } else {
            address_book = (Stage) btncancel.getScene().getWindow();
            address_book.close();
        }

    }

    /**
     * ******************************************************************
     * @Function Name :oneditaction
     * @Description : Method to Modify existing Address book.
     * @Input Parameter : ActionEvent -Provided by JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :25-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void oneditaction(ActionEvent event) throws IOException {
        if (event.getSource() == editcontext) {
            root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/EditAddressbook_controller.fxml"));
            modify_add_bk.setScene(new Scene(root1));
            modify_add_bk.setTitle("Modify AddressBook");
            modify_add_bk.show();
            modify_add_bk.resizableProperty().setValue(Boolean.FALSE);
        }

    }

    /**
     * ******************************************************************
     * @Function Name :deleteSelectedNode
     * @Description : Method to delete existing Address book.
     * @Input Parameter : ActionEvent -Provided by JavaFX
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :27-MAR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void deleteSelectedNode(ActionEvent e) throws SQLException {
//Delete Address BOOK
        ObservableList<AddressBookpojo> alladdress;
        alladdress = FXCollections.observableArrayList();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation-Delete Node");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure want to delete !");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            try {
                TreeItem c = (TreeItem) tableaddressbook.getSelectionModel().getSelectedItem();
                boolean remove = c.getParent().getChildren().remove(c);
                System.out.println("Remove" + remove);
                System.out.println(itm);
                DeleteDto dto2 = new DeleteDto();
                dto2.setCn(itm);    //address book sm_name...

                dto2.setNode(messageHandler.ldapUserOffice(sm_name));   // office sm_name..
                String output1 = null;
                try {
                    output1 = (String) messageHandler.deleteAddressBook(dto2);
                    if (messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm() != null) {
                        m_successAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm();
                        if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                            FXMLDocumentController.ALERT_AUDIOCLIP1.play();
                        }
                    }

                } catch (Exception e1) {
                    System.out.println("already exists..!!");
                }

            } catch (Exception ex) {
                System.out.println("error " + ex);
            }
            contacttable.getItems().clear();
        }
    }

    /**
     * ******************************************************************
     * @Function Name :onclick_inbox_btn
     * @Description : Method to display In box Mail headers.
     * @Input Parameter : ActionEvent -Provided by JavaFX
     * @Output Parameter	: NA
     * @Author : Ravikiran Bhat.
     * @Created Date :18-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onclick_inbox_btn(ActionEvent event) throws Exception {
//        m_progressService.restart();
        lblinboxview.setVisible(true);
        lblsentmailview.setVisible(false);
        lbloutboxview.setVisible(false);
        lblDraftview.setVisible(false);
        lblTrashview.setVisible(false);
        lblinboxreview.setVisible(false);
        lblinboxapprove.setVisible(false);
        lblinboxoffice.setVisible(false);

        btnPrint.setVisible(true);
        imgPrint.setVisible(true);

        inbox_tab.getTabs().remove(tabDraft);
        inbox_tab.getTabs().remove(tabOutbox);
        inbox_tab.getTabs().remove(tabTrash);
        inbox_tab.getTabs().remove(tabSent);
        inbox_tab.getTabs().add(tabinbox);
        inbox_tab.getTabs().add(tabReview);
        inbox_tab.getTabs().add(tabApprove);
        inbox_tab.getTabs().add(tabOffice);
        refresh_btn.setVisible(true);
        imgRefreshInbox.setVisible(true);
        imgSentRefresh.setVisible(false);
        refresh_btnSent.setVisible(false);
        imgOutboxRefresh.setVisible(false);
        refresh_btnOutbox.setVisible(false);
        refresh_btnDraft.setVisible(false);
        imgDraftRefresh.setVisible(false);
        refresh_btnTrash.setVisible(false);
        imgTrashRefresh.setVisible(false);

        search_lable.setVisible(false);
        btnserch_inbox.setVisible(true);
        btnserch_sent.setVisible(false);
        btnserch_out.setVisible(false);
        btnserch_draft.setVisible(false);
        btnserch_trash.setVisible(false);
        lblSearch_results.setVisible(false);

        delete_mail.setVisible(true);
        delete_reviewmail.setVisible(false);
        deleteApproveMail.setVisible(false);
        deleteOfficeMail.setVisible(false);
        deleteSentMail.setVisible(false);
        deleteOutBoxMail.setVisible(false);
        deleteDraftMail.setVisible(false);

        delelete_btn_image.setVisible(true);
        delelete_btn_image1.setVisible(false);
        delelete_btn_imageapprove.setVisible(false);
        delelete_btn_imageOffice.setVisible(false);
        delelete_btn_imageSent.setVisible(false);
        delelete_btn_imageout.setVisible(false);
        delelete_btn_imageDraft.setVisible(false);

        tabinbox.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");

        tabReview.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
        tabApprove.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
        tabOffice.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
    }
    /**
     * ******************************************************************
     * @Function Name :progressIndiCatorSentMail
     * @Description : progressindicator for sent box
     * @Input Parameter : ActionEvent -Provided by JavaFX
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul
     * @Created Date :17-JUNE-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public ProgressIndicator m_progressIndicatorSentMail = new ProgressIndicator();
    final ProgressServicesSentMail m_progressServicesSentMail = new ProgressServicesSentMail();
    Region m_regionSentMail = new Region();

    public void progressIndiCatorSentMail() {
        m_progressIndicatorSentMail.progressProperty().bind(m_progressServicesSentMail.progressProperty());
        m_regionSentMail.visibleProperty().bind(m_progressServicesSentMail.runningProperty());
        m_progressIndicatorSentMail.visibleProperty().bind(m_progressServicesSentMail.runningProperty());
        mail_table.itemsProperty().bind(m_progressServicesSentMail.valueProperty());
        m_progressServicesSentMail.start();

    }

    /**
     * ******************************************************************
     * @Function Name :onclick_sent_btn
     * @Description : Method to display Sent box Mail headers.
     * @Input Parameter : ActionEvent -Provided by JavaFX
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :18-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onclick_sent_btn(ActionEvent event) throws Exception {
        if (sm_netStatus.equalsIgnoreCase("Online")) {
            btnPrint.setVisible(false);
            imgPrint.setVisible(false);
        }
// m_progressServicesSentMail.restart();
        lblinboxreview.setVisible(false);
        lblinboxapprove.setVisible(false);
        lblinboxoffice.setVisible(false);
        lblinboxview.setVisible(false);
        lblsentmailview.setVisible(true);
        lbloutboxview.setVisible(false);
        lblDraftview.setVisible(false);
        lblTrashview.setVisible(false);
        btnPrint.setVisible(false);
        imgPrint.setVisible(false);
        System.out.println("Sent button Clicked");
        btnserch_inbox.setVisible(false);
        btnserch_sent.setVisible(true);
        btnserch_out.setVisible(false);
        btnserch_draft.setVisible(false);
        btnserch_trash.setVisible(false);

        inbox_tab.getTabs().remove(tabDraft);
        inbox_tab.getTabs().remove(tabOutbox);
        inbox_tab.getTabs().remove(tabTrash);
        inbox_tab.getTabs().add(tabSent);
        inbox_tab.getTabs().remove(tabApprove);
        inbox_tab.getTabs().remove(tabOffice);
        inbox_tab.getTabs().remove(tabReview);
        inbox_tab.getTabs().remove(tabinbox);

        refresh_btn.setVisible(false);
        imgRefreshInbox.setVisible(false);
        imgSentRefresh.setVisible(true);
        refresh_btnSent.setVisible(true);
        imgOutboxRefresh.setVisible(false);
        refresh_btnOutbox.setVisible(false);
        refresh_btnDraft.setVisible(false);
        imgDraftRefresh.setVisible(false);
        refresh_btnTrash.setVisible(false);
        imgTrashRefresh.setVisible(false);
        //delelete_btn_image.setVisible(true);
        search_lable.setVisible(false);
        lblSearch_results.setVisible(false);

        delete_mail.setVisible(false);
        delete_reviewmail.setVisible(false);
        deleteApproveMail.setVisible(false);
        deleteOfficeMail.setVisible(false);
        deleteSentMail.setVisible(true);
        deleteOutBoxMail.setVisible(false);
        deleteDraftMail.setVisible(false);

        delelete_btn_image.setVisible(false);
        delelete_btn_image1.setVisible(false);
        delelete_btn_imageapprove.setVisible(false);
        delelete_btn_imageOffice.setVisible(false);
        delelete_btn_imageSent.setVisible(true);
        delelete_btn_imageout.setVisible(false);
        delelete_btn_imageDraft.setVisible(false);

        //receiveSentMails
        mail_table_list.clear();
        ViewFolderMailsDTO obj1 = new ViewFolderMailsDTO();
        obj1.setFolder("sent");
        obj1.setFromCount(0);
        obj1.setToCount(0);
        PrecedenceDTO objprecedence;
        List<MailDTO> mailObj12 = messageHandler.receiveSentMails(obj1);
            Collections.reverse(mailObj12);
        for (MailDTO data : mailObj12) {
            String m_attachmentTrue = "";
            String msgType = "";
            String sec_symbl = "";
            System.out.println(data.getFrom());
            System.out.println(data.getSubject());

            if (data.getHeaderMap().get("originalReceiver") != null) {
                receivedFrom = (String) data.getHeaderMap().get("originalReceiver");
            }
            if (data.getHeaderMap().get("Subject") != null) {
                subject = (String) data.getHeaderMap().get("Subject");
            }
            if ((String) data.getHeaderMap().get("Date") != null) {
                receivedDate = (String) data.getHeaderMap().get("Date");
            }
            if ((String) data.getHeaderMap().get("msgType") != null) {
                msgType = (String) data.getHeaderMap().get("msgType");
            }
            Double temp_mail_id_double = null;
            long temp_mail_id_long = 0;

            if (data.getHeaderMap().get("uid") != null) {
                temp_mail_id_double = (Double) data.getHeaderMap().get("uid");
            }
            if (temp_mail_id_double != null) {
                temp_mail_id_long = temp_mail_id_double.intValue();
            }
            mail_id = temp_mail_id_long + "";

            if ((String) data.getHeaderMap().get("security_level") != null) {
                security_level = (String) data.getHeaderMap().get("security_level");
            }

            if (security_level != null || !security_level.equalsIgnoreCase("")) {
                System.out.println("SEC SYMBOL" + security_level);
                for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                    if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
                        sec_symbl = singleObj.getSecclasssymbol();
                    }
                }
            }
            preceColor = "";
            if ((String) data.getHeaderMap().get("precedence") != null) {
                precVal = (String) data.getHeaderMap().get("precedence");
            }
            if (precVal != null) {

                if (precVal != null) {
                    for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                        if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                            preceColor = singleObj.getPreccolour();
                        }
                    }
                }

            }
            if (data.getHeaderMap().get("attachment") != null) {
                m_Attachment = (String) data.getHeaderMap().get("attachment");
                m_attachmentTrue = m_Attachment;
            }
//            Boolean attachment = false;
//            if (m_Attachment == null || m_Attachment.equals("")) {
//                attachment = false;
//                m_attachmentTrue = attachment.toString();
//
//            } else {
//                attachment = true;
//                m_attachmentTrue = attachment.toString();
////                System.out.println("attachment is true " + m_attachmentTrue);
//            }
            mail_table_list.add(new SentMailList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
            sec_sym_column_mail_table.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
            from_column_mail_table.setCellValueFactory(new PropertyValueFactory<>("from"));
            Subj_column_mail_table.setCellValueFactory(new PropertyValueFactory<>("subject"));
            date_column_mail_table.setCellValueFactory(new PropertyValueFactory<>("date"));
            precedence_col_sent_mail.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
            size_column_mail_table.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
            precedence_col_sent_mail.setCellFactory(col -> new TableCell<SentMailList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String color, boolean empty) {
                    super.updateItem(color, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (color.equalsIgnoreCase("Tomato")) {
                            imageView.setImage(imgtomato);
                        } else if (color.equalsIgnoreCase("Orange")) {
                            imageView.setImage(imgorange);
                        } else if (color.equalsIgnoreCase("LightBlue")) {
                            imageView.setImage(imglightblue);
                        } else if (color.equalsIgnoreCase("LightGreen")) {
                            imageView.setImage(imglightgreen);
                        } else if (color.equalsIgnoreCase("Yellow")) {
                            imageView.setImage(imgyellow);
                        } else if (color.equalsIgnoreCase("Pink")) {
                            imageView.setImage(imgpink);
                        } else {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
            mail_table.setRowFactory(row -> new TableRow<SentMailList>() {
                @Override
                public void updateItem(SentMailList item, boolean status) {
                    super.updateItem(item, Currentreadstatus);
                    if (item == null) {
                        setStyle("");
                    } else if (item.getCurrentreadstatus() == false) {
                        setStyle("-fx-font-weight:bold;");
                    } else if (item.getCurrentreadstatus() == true) {
                        setStyle("-fx-font-weight:normal;");
                    }
                }
            });
            size_column_mail_table.setCellFactory(colattach -> new TableCell<SentMailList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String attach, boolean empty) {
                    super.updateItem(attach, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (attach.equals("true")) {
                            imageView.setImage(imgattach);
                        } else if (attach.equals("false")) {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });

        }

        // mail_table.setItems(FXCollections.observableArrayList(mail_table_list));
        paginationSentmail.setPageCount(numberOfPages(mail_table_list.size()));
        paginationSentmail.setPageFactory(this::createContactsPage);
      mail_table.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

    }
    /**
     * ******************************************************************
     * @Function Name :progressIndiCatorOutboxMail
     * @Description : progressindicator for out box
     * @Input Parameter : ActionEvent -Provided by JavaFX
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul
     * @Created Date :17-JUNE-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public ProgressIndicator m_progressIndicatorOutbox = new ProgressIndicator();
    final ProgressServicesOutBoxMail m_progressServicesOutboxMail = new ProgressServicesOutBoxMail();
    Region m_regionOutboxMail = new Region();

    public void progressIndiCatorOutboxMail() {
        m_progressIndicatorOutbox.progressProperty().bind(m_progressServicesOutboxMail.progressProperty());
        m_regionOutboxMail.visibleProperty().bind(m_progressServicesOutboxMail.runningProperty());
        m_progressIndicatorOutbox.visibleProperty().bind(m_progressServicesOutboxMail.runningProperty());
        mail_table_out_box.itemsProperty().bind(m_progressServicesOutboxMail.valueProperty());
        m_progressServicesOutboxMail.start();

    }

    /**
     * ******************************************************************
     * @Function Name :onclick_outbox_btn
     * @Description : Method to display Out box Mail headers.
     * @Input Parameter : ActionEvent -Provided by JavaFX
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :19-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onclick_outbox_btn(ActionEvent event) throws Exception {
        if (sm_netStatus.equalsIgnoreCase("Online")) {
            btnPrint.setVisible(false);
            imgPrint.setVisible(false);
        }
        outbox_table_list.clear();
//        m_progressServicesOutboxMail.restart();
        lblinboxreview.setVisible(false);
        lblinboxapprove.setVisible(false);
        lblinboxoffice.setVisible(false);
        lblinboxview.setVisible(false);
        lblsentmailview.setVisible(false);
        lbloutboxview.setVisible(true);
        lblDraftview.setVisible(false);
        lblTrashview.setVisible(false);
        btnPrint.setVisible(false);
        imgPrint.setVisible(false);

        btnserch_inbox.setVisible(false);
        btnserch_sent.setVisible(false);
        btnserch_out.setVisible(true);
        btnserch_draft.setVisible(false);
        btnserch_trash.setVisible(false);
        
        refresh_btn.setVisible(false);
        imgRefreshInbox.setVisible(false);
        imgSentRefresh.setVisible(false);
        refresh_btnSent.setVisible(false);
        imgOutboxRefresh.setVisible(true);
        refresh_btnOutbox.setVisible(true);
        refresh_btnDraft.setVisible(false);
        imgDraftRefresh.setVisible(false);
        refresh_btnTrash.setVisible(false);
        imgTrashRefresh.setVisible(false);
        
        inbox_tab.getTabs().remove(tabDraft);
        inbox_tab.getTabs().add(tabOutbox);
        inbox_tab.getTabs().remove(tabTrash);
        inbox_tab.getTabs().remove(tabSent);
        inbox_tab.getTabs().remove(tabApprove);
        inbox_tab.getTabs().remove(tabOffice);
        inbox_tab.getTabs().remove(tabReview);
        inbox_tab.getTabs().remove(tabinbox);
        delelete_btn_image.setVisible(true);
        search_lable.setVisible(false);
        lblSearch_results.setVisible(false);

        delete_mail.setVisible(false);
        delete_reviewmail.setVisible(false);
        deleteApproveMail.setVisible(false);
        deleteOfficeMail.setVisible(false);
        deleteSentMail.setVisible(false);
        deleteOutBoxMail.setVisible(true);
        deleteDraftMail.setVisible(false);
        delelete_btn_image.setVisible(false);
        delelete_btn_image1.setVisible(false);
        delelete_btn_imageapprove.setVisible(false);
        delelete_btn_imageOffice.setVisible(false);
        delelete_btn_imageSent.setVisible(true);
        delelete_btn_imageout.setVisible(true);
        delelete_btn_imageDraft.setVisible(false);

        //getTrashMail
        ViewFolderMailsDTO obj1 = new ViewFolderMailsDTO();
        obj1.setFolder("outbox");
        obj1.setFromCount(0);
        obj1.setToCount(0);
        PrecedenceDTO objprecedence;
        List<MailDTO> mailObj12 = messageHandler.receiveOutBoxMails(obj1);
         Collections.reverse(mailObj12);
        for (MailDTO data : mailObj12) {
            String m_attachmentTrue = "";
            String msgType = "";
            String sec_symbl = "";
            System.out.println(data.getFrom());
            System.out.println(data.getSubject());

            if (data.getFrom() != null) {
                receivedFrom = data.getFrom();
            }
            if (data.getSubject() != null) {
                subject = data.getSubject();
            }
            if ((String) data.getHeaderMap().get("Date") != null) {
                receivedDate = (String) data.getHeaderMap().get("Date");
            }
            //String mailId = data.getId();
            if ((String) data.getHeaderMap().get("msgType") != null) {
                msgType = (String) data.getHeaderMap().get("msgType");
            }
            Double temp_mail_id_double = null;
            long temp_mail_id_long = 0;

            if (data.getHeaderMap().get("uid") != null) {
                temp_mail_id_double = (Double) data.getHeaderMap().get("uid");
            }
            if (temp_mail_id_double != null) {
                temp_mail_id_long = temp_mail_id_double.intValue();
            }
            mail_id = temp_mail_id_long + "";

            if ((String) data.getHeaderMap().get("security_level") != null) {
                security_level = (String) data.getHeaderMap().get("security_level");
            }

            if (security_level != null || !security_level.equalsIgnoreCase("")) {
                System.out.println("SEC SYMBOL" + security_level);
                for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                    if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
                        sec_symbl = singleObj.getSecclasssymbol();
                    }
                }
            }
            preceColor = "";
            if ((String) data.getHeaderMap().get("precedence") != null) {
                precVal = (String) data.getHeaderMap().get("precedence");
            }
            if (precVal != null) {

                if (precVal != null) {
                    for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                        if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                            preceColor = singleObj.getPreccolour();
                        }
                    }
                }

            }
            if (data.getHeaderMap().get("attachment") != null) {
                m_Attachment = (String) data.getHeaderMap().get("attachment");
                m_attachmentTrue = m_Attachment;
            }
//            if ((String) data.getHeaderMap().get("attachment") != "" || (String) data.getHeaderMap().get("attachment") != null) {
//                m_Attachment = (String) data.getHeaderMap().get("attachment");
//            }
//            Boolean attachment = false;
//            if (m_Attachment == null || m_Attachment.equals("")) {
//                attachment = false;
//                m_attachmentTrue = attachment.toString();
//            } else {
//                attachment = true;
//                m_attachmentTrue = attachment.toString();
//            }
            outbox_table_list.add(new OutTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
            sec_sym_column_out_box.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
            from_column_out_box.setCellValueFactory(new PropertyValueFactory<>("from"));
            Subj_column_out_box.setCellValueFactory(new PropertyValueFactory<>("subject"));
            date_column_out_box.setCellValueFactory(new PropertyValueFactory<>("date"));
            precedence_col_out_box.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
            size_column_out_box.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
            precedence_col_out_box.setCellFactory(col -> new TableCell<OutTabList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String color, boolean empty) {
                    super.updateItem(color, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (color.equalsIgnoreCase("Tomato")) {
                            imageView.setImage(imgtomato);
                        } else if (color.equalsIgnoreCase("Orange")) {
                            imageView.setImage(imgorange);
                        } else if (color.equalsIgnoreCase("LightBlue")) {
                            imageView.setImage(imglightblue);
                        } else if (color.equalsIgnoreCase("LightGreen")) {
                            imageView.setImage(imglightgreen);
                        } else if (color.equalsIgnoreCase("Yellow")) {
                            imageView.setImage(imgyellow);
                        } else if (color.equalsIgnoreCase("Pink")) {
                            imageView.setImage(imgpink);
                        } else {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
            mail_table_out_box.setRowFactory(row -> new TableRow<OutTabList>() {
                @Override
                public void updateItem(OutTabList item, boolean status) {
                    super.updateItem(item, Currentreadstatus);
                    if (item == null) {
                        setStyle("");
                    } else if (item.getCurrentreadstatus() == false) {
                        setStyle("-fx-font-weight:bold;");
                    } else if (item.getCurrentreadstatus() == true) {
                        setStyle("-fx-font-weight:normal;");
                    }
                }
            });
            size_column_out_box.setCellFactory(colattach -> new TableCell<OutTabList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String attach, boolean empty) {
                    super.updateItem(attach, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (attach.equals("true")) {
                            imageView.setImage(imgattach);
                        } else if (attach.equals("false")) {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
            for (Object Obj : mail_table.getItems()) {

                sec_sym_column_out_box.getCellData(0);
                from_column_out_box.getCellData(1);
                Subj_column_out_box.getCellData(2);
                date_column_out_box.getCellData(3);

            }
        }
        paginationOutbox.setPageCount(numberOfPages(outbox_table_list.size()));
        paginationOutbox.setPageFactory(this::createContactsPageOutBox);
//        mail_table_out_box.setItems(FXCollections.observableArrayList(outbox_table_list));

      mail_table_out_box.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }
    /**
     * ******************************************************************
     * @Function Name :progressIndiCatorSentMail
     * @Description : progressindicator for sent box
     * @Input Parameter : ActionEvent -Provided by JavaFX
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul
     * @Created Date :17-JUNE-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public ProgressIndicator m_progressIndicatorDraft = new ProgressIndicator();
    final ProgressServicesDraftMail m_progressServicesDraftMail = new ProgressServicesDraftMail();
    Region m_regionDraftMail = new Region();

    public void progressIndiCatorDraftMail() {
        m_progressIndicatorDraft.progressProperty().bind(m_progressServicesDraftMail.progressProperty());
        m_regionDraftMail.visibleProperty().bind(m_progressServicesDraftMail.runningProperty());
        m_progressIndicatorDraft.visibleProperty().bind(m_progressServicesDraftMail.runningProperty());
        mail_table_draft_table.itemsProperty().bind(m_progressServicesDraftMail.valueProperty());
        m_progressServicesDraftMail.start();

    }

    /**
     * ******************************************************************
     * @Function Name :onclick_draft_btn
     * @Description : Method to display Draft box Mail headers.
     * @Input Parameter : ActionEvent -Provided by JavaFX
     * @Output Parameter	: NA
     * @Author : Ravikiran Bhat.
     * @Created Date :18-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onclick_draft_btn(ActionEvent event) throws Exception {
        if (sm_netStatus.equalsIgnoreCase("Online")) {
            btnPrint.setVisible(false);
            imgPrint.setVisible(false);
        }
//        m_progressServicesDraftMail.restart();
        lblinboxreview.setVisible(false);
        lblinboxapprove.setVisible(false);
        lblinboxoffice.setVisible(false);
        lblinboxview.setVisible(false);
        lblsentmailview.setVisible(false);
        lbloutboxview.setVisible(false);
        lblDraftview.setVisible(true);
        lblTrashview.setVisible(false);
        btnPrint.setVisible(false);
        imgPrint.setVisible(false);
        System.out.println("Draft button Clicked");
        btnserch_inbox.setVisible(false);
        btnserch_sent.setVisible(false);
        btnserch_out.setVisible(false);
        btnserch_draft.setVisible(true);
        btnserch_trash.setVisible(false);
        
        refresh_btn.setVisible(false);
        imgRefreshInbox.setVisible(false);
        imgSentRefresh.setVisible(false);
        refresh_btnSent.setVisible(false);
        imgOutboxRefresh.setVisible(false);
        refresh_btnOutbox.setVisible(false);
        refresh_btnDraft.setVisible(true);
        imgDraftRefresh.setVisible(true);
        refresh_btnTrash.setVisible(false);
        imgTrashRefresh.setVisible(false);

        inbox_tab.getTabs().add(tabDraft);
        inbox_tab.getTabs().remove(tabOutbox);
        inbox_tab.getTabs().remove(tabTrash);
        inbox_tab.getTabs().remove(tabSent);
        inbox_tab.getTabs().remove(tabApprove);
        inbox_tab.getTabs().remove(tabOffice);
        inbox_tab.getTabs().remove(tabReview);
        inbox_tab.getTabs().remove(tabinbox);
        //delete_mail.setVisible(true);
        delelete_btn_image.setVisible(true);
        search_lable.setVisible(false);
        lblSearch_results.setVisible(false);
        draft_table_list.clear();

        delete_mail.setVisible(false);
        delete_reviewmail.setVisible(false);
        deleteApproveMail.setVisible(false);
        deleteOfficeMail.setVisible(false);
        deleteSentMail.setVisible(false);
        deleteOutBoxMail.setVisible(false);
        deleteDraftMail.setVisible(true);
        delelete_btn_image.setVisible(false);
        delelete_btn_image1.setVisible(false);
        delelete_btn_imageapprove.setVisible(false);
        delelete_btn_imageOffice.setVisible(false);
        delelete_btn_imageSent.setVisible(true);
        delelete_btn_imageout.setVisible(false);
        delelete_btn_imageDraft.setVisible(true);

//Reciving mail From Draft
        ViewFolderMailsDTO obj1 = new ViewFolderMailsDTO();
        obj1.setFolder("drafts");
        obj1.setFromCount(0);
        obj1.setToCount(0);
        PrecedenceDTO objprecedence;
        List<MailDTO> mailObj12 = messageHandler.receiveDraftsMails(obj1);
         Collections.reverse(mailObj12);
        for (MailDTO data : mailObj12) {
            String m_attachmentTrue = "";
            String msgType = "";
            String sec_symbl = "";
            System.out.println(data.getFrom());
            System.out.println(data.getSubject());

//            if (data.getFrom() != null || data.getFrom() != "") {
//                receivedFrom = (String) data.getFrom();
//            }
            if(data.getHeaderMap().get("originalReceiver") != null)
            {
                receivedFrom=(String)data.getHeaderMap().get("originalReceiver");
            }
            if ((String) data.getHeaderMap().get("Date") != null) {
                subject = (String) data.getHeaderMap().get("Subject");
            }
            if ((String) data.getHeaderMap().get("Date") != null) {
                receivedDate = (String) data.getHeaderMap().get("Date");
            } else {
                receivedDate = " ";
            }
            //String mailId = data.getId();
            if ((String) data.getHeaderMap().get("msgType") != null) {
                msgType = (String) data.getHeaderMap().get("msgType");
            }
            Double temp_mail_id_double = null;
            long temp_mail_id_long = 0;

            if (data.getHeaderMap().get("uid") != null) {
                temp_mail_id_double = (Double) data.getHeaderMap().get("uid");
            }
            if (temp_mail_id_double != null) {
                temp_mail_id_long = temp_mail_id_double.intValue();
            }
            mail_id = temp_mail_id_long + "";
            if ((String) data.getHeaderMap().get("security_level") != null) {
                security_level = (String) data.getHeaderMap().get("security_level");
            }

            if (security_level != null || !security_level.equalsIgnoreCase("")) {
                System.out.println("SEC SYMBOL" + security_level);
                for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                    if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
                        sec_symbl = singleObj.getSecclasssymbol();
                    }
                }
            }
            preceColor = "";

            if ((String) data.getHeaderMap().get("precedence") != null) {
                precVal = (String) data.getHeaderMap().get("precedence");
            }
            if (precVal != null) {

                if (precVal != null) {
                    for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                        if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                            preceColor = singleObj.getPreccolour();
                        }
                    }
                }

            }
            if (data.getHeaderMap().get("attachment") != null) {
                m_Attachment = (String) data.getHeaderMap().get("attachment");
                m_attachmentTrue = m_Attachment;
            }
            draft_table_list.add(new DraftTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, m_attachmentTrue));
            sec_sym_column_draft_table.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
            from_column_draft_table.setCellValueFactory(new PropertyValueFactory<>("from"));
            Subj_column_draft_table.setCellValueFactory(new PropertyValueFactory<>("subject"));
            date_column_draft_table.setCellValueFactory(new PropertyValueFactory<>("date"));
            precedence_col_traft_mail.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
            size_column_draft_table.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
            precedence_col_traft_mail.setCellFactory(col -> new TableCell<DraftTabList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String color, boolean empty) {
                    super.updateItem(color, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (color.equalsIgnoreCase("Tomato")) {
                            imageView.setImage(imgtomato);
                        } else if (color.equalsIgnoreCase("Orange")) {
                            imageView.setImage(imgorange);
                        } else if (color.equalsIgnoreCase("LightBlue")) {
                            imageView.setImage(imglightblue);
                        } else if (color.equalsIgnoreCase("LightGreen")) {
                            imageView.setImage(imglightgreen);
                        } else if (color.equalsIgnoreCase("Yellow")) {
                            imageView.setImage(imgyellow);
                        } else if (color.equalsIgnoreCase("Pink")) {
                            imageView.setImage(imgpink);
                        } else {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
            size_column_draft_table.setCellFactory(colattach -> new TableCell<DraftTabList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String attach, boolean empty) {
                    super.updateItem(attach, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (attach.equals("true")) {
                            imageView.setImage(imgattach);
                        } else if (attach.equals("false")) {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });

        }
        paginationDraftmail.setPageCount(numberOfPages(draft_table_list.size()));
        paginationDraftmail.setPageFactory(this::createContactsPageDraft);
//        mail_table_draft_table.setItems(FXCollections.observableArrayList(draft_table_list));
        // mail_table_draft_table.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }
    /**
     * ******************************************************************
     * @Function Name :progressIndiCatorTrashMail
     * @Description : progressindicator for Trash box
     * @Input Parameter : ActionEvent -Provided by JavaFX
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul
     * @Created Date :17-JUNE-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public ProgressIndicator m_progressIndicatorTrash = new ProgressIndicator();
    final ProgressServicesTrashMail m_progressServicestrashMail = new ProgressServicesTrashMail();
    Region m_regionTrashMail = new Region();

    public void progressIndiCatorTrashMail() {
        m_progressIndicatorTrash.progressProperty().bind(m_progressServicestrashMail.progressProperty());
        m_regionTrashMail.visibleProperty().bind(m_progressServicestrashMail.runningProperty());
        m_progressIndicatorTrash.visibleProperty().bind(m_progressServicestrashMail.runningProperty());
        mail_table_trash_box.itemsProperty().bind(m_progressServicestrashMail.valueProperty());
        m_progressServicestrashMail.start();

    }

    /**
     * ******************************************************************
     * @Function Name :onclick_trash_btn
     * @Description : Method to display Trash box Mail headers.
     * @Input Parameter : ActionEvent -Provided by JavaFX
     * @Output Parameter : NA
     * @Author : Ravikiran Bhat.
     * @Created Date :18-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onclick_trash_btn(ActionEvent event) throws Exception {

        if (sm_netStatus.equalsIgnoreCase("Online")) {
            btnPrint.setVisible(false);
            imgPrint.setVisible(false);
        }
//        m_progressServicestrashMail.restart();
        lblinboxreview.setVisible(false);
        lblinboxapprove.setVisible(false);
        lblinboxoffice.setVisible(false);
        lblinboxview.setVisible(false);
        lblsentmailview.setVisible(false);
        lbloutboxview.setVisible(false);
        lblDraftview.setVisible(false);
        lblTrashview.setVisible(true);
        btnPrint.setVisible(false);
        imgPrint.setVisible(false);
        System.out.println("Trsh button Clicked");
        btnserch_inbox.setVisible(false);
        btnserch_sent.setVisible(false);
        btnserch_out.setVisible(false);
        btnserch_draft.setVisible(false);
        btnserch_trash.setVisible(true);
        
        refresh_btn.setVisible(false);
        imgRefreshInbox.setVisible(false);
        imgSentRefresh.setVisible(false);
        refresh_btnSent.setVisible(false);
        imgOutboxRefresh.setVisible(false);
        refresh_btnOutbox.setVisible(false);
        refresh_btnDraft.setVisible(false);
        imgDraftRefresh.setVisible(false);
        refresh_btnTrash.setVisible(true);
        imgTrashRefresh.setVisible(true);

        inbox_tab.getTabs().remove(tabDraft);
        inbox_tab.getTabs().remove(tabOutbox);
        inbox_tab.getTabs().add(tabTrash);
        inbox_tab.getTabs().remove(tabSent);
        inbox_tab.getTabs().remove(tabApprove);
        inbox_tab.getTabs().remove(tabOffice);
        inbox_tab.getTabs().remove(tabReview);
        inbox_tab.getTabs().remove(tabinbox);
        search_lable.setVisible(false);

        lblSearch_results.setVisible(false);
        trash_table_list.clear();
        delete_mail.setVisible(false);
        delete_reviewmail.setVisible(false);
        deleteApproveMail.setVisible(false);
        deleteOfficeMail.setVisible(false);
        deleteSentMail.setVisible(false);
        deleteOutBoxMail.setVisible(false);
        deleteDraftMail.setVisible(false);

        delelete_btn_image.setVisible(false);
        delelete_btn_image1.setVisible(false);
        delelete_btn_imageapprove.setVisible(false);
        delelete_btn_imageOffice.setVisible(false);
        delelete_btn_imageSent.setVisible(false);
        delelete_btn_imageout.setVisible(false);
        delelete_btn_imageDraft.setVisible(false);
//Reciving mail From Draft
        ViewFolderMailsDTO obj1 = new ViewFolderMailsDTO();
        obj1.setFolder("trash");
        obj1.setFromCount(0);
        obj1.setToCount(0);
        PrecedenceDTO objprecedence;
        List<MailDTO> mailObj12 = messageHandler.receiveTrashMails(obj1);
         Collections.reverse(mailObj12);
        for (MailDTO data : mailObj12) {
            String m_attachmentTrue = "";
            String msgType = "";
            String sec_symbl = "";
            System.out.println(data.getFrom());
            System.out.println(data.getSubject());

            if (data.getHeaderMap().get("From") != null) {
                receivedFrom = (String) data.getHeaderMap().get("From");
            }
            if (data.getHeaderMap().get("Subject") != null) {
                subject = (String) data.getHeaderMap().get("Subject");
            }
            if ((String) data.getHeaderMap().get("Date") != null) {
                receivedDate = (String) data.getHeaderMap().get("Date");
            }
            if ((String) data.getHeaderMap().get("msgType") != null) {
                msgType = (String) data.getHeaderMap().get("msgType");
            }
            Double temp_mail_id_double = null;
            long temp_mail_id_long = 0;

            if (data.getHeaderMap().get("uid") != null) {
                temp_mail_id_double = (Double) data.getHeaderMap().get("uid");
            }
            if (temp_mail_id_double != null) {
                temp_mail_id_long = temp_mail_id_double.intValue();
            }
            mail_id = temp_mail_id_long + "";
            if ((String) data.getHeaderMap().get("security_level") != null) {
                security_level = (String) data.getHeaderMap().get("security_level");
            }
            if (security_level != null || !security_level.equalsIgnoreCase("")) {
                System.out.println("SEC SYMBOL" + security_level);
                for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
                    if (singleObj.getSecclassvalue().equalsIgnoreCase(security_level)) {
                        sec_symbl = singleObj.getSecclasssymbol();
                    }
                }
            }
            preceColor = "";

            if ((String) data.getHeaderMap().get("precedence") != null) {
                precVal = (String) data.getHeaderMap().get("precedence");
            }
            if (precVal != null) {

                if (precVal != null) {
                    for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
                        if (precVal.equalsIgnoreCase(singleObj.getPrecvalue())) {
                            preceColor = singleObj.getPreccolour();
                        }
                    }
                }

            }
//            if ((String) data.getHeaderMap().get("attachment") != "" || (String) data.getHeaderMap().get("attachment") != null) {
//                m_Attachment = (String) data.getHeaderMap().get("attachment");
//
//            }
//            Boolean attachment = false;
//            if (m_Attachment == null || m_Attachment.equals("")) {
//                attachment = false;
//                m_attachmentTrue = attachment.toString();
//
//            } else {
//                attachment = true;
//                m_attachmentTrue = attachment.toString();
//
//            }
            if (data.getHeaderMap().get("attachment") != null) {
                m_Attachment = (String) data.getHeaderMap().get("attachment");
                m_attachmentTrue = m_Attachment;
            }
            trash_table_list.add(new TrashTabList(receivedFrom, subject, receivedDate, mail_id, sec_symbl, preceColor, Currentreadstatus, m_attachmentTrue));
            sec_sym_column_trash_box.setCellValueFactory(new PropertyValueFactory<>("sec_symbl"));
            from_column_trash_box.setCellValueFactory(new PropertyValueFactory<>("from"));
            Subj_column_trash_box.setCellValueFactory(new PropertyValueFactory<>("subject"));
            date_column_trash_box.setCellValueFactory(new PropertyValueFactory<>("date"));
            precedence_col_trash_mail.setCellValueFactory(new PropertyValueFactory<>("preceColor"));
            size_column_trash_box.setCellValueFactory(new PropertyValueFactory<>("m_attachmentTrue"));
            precedence_col_trash_mail.setCellFactory(col -> new TableCell<TrashTabList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String color, boolean empty) {
                    super.updateItem(color, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (color.equalsIgnoreCase("Tomato")) {
                            imageView.setImage(imgtomato);
                        } else if (color.equalsIgnoreCase("Orange")) {
                            imageView.setImage(imgorange);
                        } else if (color.equalsIgnoreCase("LightBlue")) {
                            imageView.setImage(imglightblue);
                        } else if (color.equalsIgnoreCase("LightGreen")) {
                            imageView.setImage(imglightgreen);
                        } else if (color.equalsIgnoreCase("Yellow")) {
                            imageView.setImage(imgyellow);
                        } else if (color.equalsIgnoreCase("Pink")) {
                            imageView.setImage(imgpink);
                        } else {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
            mail_table_trash_box.setRowFactory(row -> new TableRow<TrashTabList>() {
                @Override
                public void updateItem(TrashTabList item, boolean status) {
                    super.updateItem(item, Currentreadstatus);
                    if (item == null) {
                        setStyle("");
                    } else if (item.getCurrentreadstatus() == false) {
                        setStyle("-fx-font-weight:bold;");
                    } else if (item.getCurrentreadstatus() == true) {
                        setStyle("-fx-font-weight:normal;");
                    }
                }
            });
            size_column_trash_box.setCellFactory(colattach -> new TableCell<TrashTabList, String>() {
                private final ImageView imageView = new ImageView();

                @Override
                protected void updateItem(String attach, boolean empty) {
                    super.updateItem(attach, empty);
                    if (empty) {
                        setGraphic(null);
                    } else {
                        if (attach.equals("true")) {
                            imageView.setImage(imgattach);
                        } else if (attach.equals("false")) {
                            imageView.setImage(null);
                        }
                        setGraphic(imageView);
                    }
                }
            });
        }
        paginationTrashmail.setPageCount(numberOfPages(trash_table_list.size()));
        paginationTrashmail.setPageFactory(this::createContactsPageTrash);
//        mail_table_trash_box.setItems(FXCollections.observableArrayList(trash_table_list));
        //  mail_table_trash_box.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    /**
     * ******************************************************************
     * @Function Name :progressindi
     * @Description : Method to display progress bar in Inbox Mail Table.
     * @Input Parameter : NA.
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul.
     * @Created Date :17-JUNE-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    final ProgressServices m_progressService = new ProgressServices();
    Region m_region = new Region();

    public void progressindi() {
        progressIndicator.progressProperty().bind(m_progressService.progressProperty());
        m_region.visibleProperty().bind(m_progressService.runningProperty());
        progressIndicator.visibleProperty().bind(m_progressService.runningProperty());
        mail_header.itemsProperty().bind(m_progressService.valueProperty());
        m_progressService.start();

    }

    /**
     * ******************************************************************
     * @Function Name :progressIndiCatorReview
     * @Description : Method to display progress bar in review Table.
     * @Input Parameter : NA.
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul.
     * @Created Date :17-JUNE-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public ProgressIndicator m_progressIndiReview = new ProgressIndicator();
    final ProgressServicesReview m_progressServicesReview = new ProgressServicesReview();
    Region m_regionReview = new Region();

    public void progressIndiCatorReview() {
        m_progressIndiReview.progressProperty().bind(m_progressServicesReview.progressProperty());
        m_regionReview.visibleProperty().bind(m_progressServicesReview.runningProperty());
        m_progressIndiReview.visibleProperty().bind(m_progressServicesReview.runningProperty());
        mail_header_review.itemsProperty().bind(m_progressServicesReview.valueProperty());
        m_progressServicesReview.start();

    }

    /**
     * ******************************************************************
     * @Function Name :progressIndiCatorApprove
     * @Description : Method to display progress bar in Approve Table.
     * @Input Parameter : NA.
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul.
     * @Created Date :17-JUNE-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public ProgressIndicator m_progressIndiApprove = new ProgressIndicator();
    final ProgressServicesApproveMail m_progressServicesApproveMail = new ProgressServicesApproveMail();
    Region m_regionApprove = new Region();

    public void progressIndiCatorApprove() {
        m_progressIndiApprove.progressProperty().bind(m_progressServicesApproveMail.progressProperty());
        m_regionApprove.visibleProperty().bind(m_progressServicesApproveMail.runningProperty());
        m_progressIndiApprove.visibleProperty().bind(m_progressServicesApproveMail.runningProperty());
        mail_header_approve.itemsProperty().bind(m_progressServicesApproveMail.valueProperty());
        m_progressServicesApproveMail.start();

    }
    /**
     * ******************************************************************
     * @Function Name :progressIndiCatorOffice
     * @Description : Method to display progress bar in Office Table.
     * @Input Parameter : NA.
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul.
     * @Created Date :17-JUNE-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public ProgressIndicator m_progressIndiOffice = new ProgressIndicator();
    final ProgressServicesOfficeMail m_progressServicesofficeMail = new ProgressServicesOfficeMail();
    Region m_regionOffice = new Region();

    public void progressIndiCatorOffice() {
        m_progressIndiOffice.progressProperty().bind(m_progressServicesofficeMail.progressProperty());
        m_regionOffice.visibleProperty().bind(m_progressServicesofficeMail.runningProperty());
        m_progressIndiOffice.visibleProperty().bind(m_progressServicesofficeMail.runningProperty());
        mail_header_office.itemsProperty().bind(m_progressServicesofficeMail.valueProperty());
        m_progressServicesofficeMail.start();

    }

    /**
     * ******************************************************************
     * @Function Name :address_book_initialize
     * @Description : Method to display Address book details.
     * @Input Parameter : NA.
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :25-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    public void address_book_initialize() {
        TreeItem<String> root = new TreeItem<>("Address Book", new ImageView(icon));
        contacttable.getItems().clear();
        root.setExpanded(true);
        TreeItem<String> item = new TreeItem<>("Global Address", new ImageView(icon1));
        root.getChildren().addAll(item);
        tableaddressbook.setRoot(root);
        try {
            editcontext.setVisible(false);
            deletecontext.setVisible(false);
            emailcontext.setVisible(false);
            contacttable.getItems().clear();
            MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
            AddrBook addrbkownr = new AddrBook();

            String officeName = messageHandler.ldapUserOffice(sm_name);
            addrbkownr.setNode(officeName);
            addrbkownr.setOwner(sm_name);

            List<AddressBookOwner> list = messageHandler.addressBookOfOwner(addrbkownr);
            List<String> addressBookNames = new ArrayList<String>();

            if (list != null) {
                Iterator itr = list.iterator();
                while (itr.hasNext()) {
                    AddressBookOwner obj = (AddressBookOwner) itr.next();

                    String sm_name = obj.getCn();
                    addressBookNames.add(sm_name);
                }

                for (String data1 : addressBookNames) {
                    System.out.println("Address Book Name is: " + data1);

                    // data.add(new AddressBookpojo(data1));
                    TreeItem<String> item1 = new TreeItem<>(data1, new ImageView(icon1));

                    item1.setValue(data1);

                    root.getChildren().addAll(item1);

                    System.out.println(item1.getValue());

                }

                tableaddressbook.setRoot(root);
            }
        } catch (Exception ex) {
            System.out.println("error is" + ex);
        }
    }
//    
//    public String getTime()
//    {
//         Date d=new Date();
//            m_time=d.toString(); 
//            return m_time;
//    }

    public void unReadMailCountFolder() {
        String m_unreadMailInBox = messageHandler.getUnreadMailCount("inbox");
        System.out.println("INBOX UNREAD:::" + m_unreadMailInBox);
        if (m_unreadMailInBox.equalsIgnoreCase("0")) {
            mail_inbox.setText("Inbox");
        } else {
            mail_inbox.setText("Inbox (" + m_unreadMailInBox + ")");
        }

        String m_unreadMailSentBox = messageHandler.getUnreadMailCount("sent");
        System.out.println("SENT UNREAD:::" + m_unreadMailSentBox);
        if (m_unreadMailSentBox.equalsIgnoreCase("0")) {
            mail_sentbox.setText("Sent");
        } else {
            mail_sentbox.setText("Sent (" + m_unreadMailSentBox + ")");
        }
        String m_unreadMailOutBox = messageHandler.getUnreadMailCount("outbox");
        System.out.println("OUT UNREAD:::" + m_unreadMailOutBox);
        if (m_unreadMailOutBox.equalsIgnoreCase("0")) {
            mail_outbox.setText("Outbox");
        } else {
            mail_outbox.setText("Outbox (" + m_unreadMailOutBox + ")");
        }
        String m_unreadMailDraftBox = messageHandler.getUnreadMailCount("drafts");
        System.out.println("DRAFT UNREAD:::" + m_unreadMailDraftBox);
        if (m_unreadMailDraftBox.equalsIgnoreCase("0")) {
            mail_draftbox.setText("Draft");
        } else {
            mail_draftbox.setText("Draft (" + m_unreadMailDraftBox + ")");
        }
        String m_unreadMailTrashBox = messageHandler.getUnreadMailCount("trash");
        System.out.println("TRASH UNREAD:::" + m_unreadMailTrashBox);

        if (m_unreadMailTrashBox.equalsIgnoreCase("0")) {
            mail_trashbox.setText("Trash");
        } else {
            mail_trashbox.setText("Trash (" + m_unreadMailTrashBox + ")");
        }
    }
@FXML
private BorderPane borderPaneInside;
@FXML
private BorderPane borderpaneAddressBook;
@FXML
private Label lab_searchAddressBook;
    /**
     * ******************************************************************
     * @Function Name :initialization
     * @Description : Method to initialize function when loading of this file.
     * @Input Parameter : NA.
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :30-MAR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void initialization() {
        //  mail_table.sort();
//        comboBoxSentMailPagination.setItems(optionsPagination);
        unReadMailCountFolder();
        lblfmm.prefWidthProperty().bind(mainpane.widthProperty());

        ////cell size
        mail_table.setFixedCellSize(40);
        mail_table_out_box.setFixedCellSize(40);
        mail_table_draft_table.setFixedCellSize(40);
        mail_table_trash_box.setFixedCellSize(40);
        mail_header.setFixedCellSize(40);
        mail_header_review.setFixedCellSize(40);
        mail_header_approve.setFixedCellSize(40);
        mail_header_office.setFixedCellSize(40);

//        inbox_tab.setPrefHeight(700);
//        mail_header.setPrefSize(gridpaneInbox.getWidth() - 10, gridpaneInbox.getHeight() - 10);
        pane1.prefWidthProperty().bind(mainpane.widthProperty());
        lab_search1.prefWidthProperty().bind(borderPaneInside.widthProperty());
        lab_searchAddressBook.prefWidthProperty().bind(borderpaneAddressBook.widthProperty());
        hboxmenuAddressBook.prefWidthProperty().bind(borderpaneAddressBook.widthProperty());
        searchHbox.prefWidthProperty().bind(borderPaneInside.widthProperty());
        hboxtopmenu.prefWidthProperty().bind(mainpane.widthProperty());
        hboxuserandlogout.prefWidthProperty().bind(mainpane.widthProperty());
        paneRefCoDePrButton.prefWidthProperty().bind(borderPaneInside.widthProperty());
        paneShowTable.prefWidthProperty().bind(tabpane.widthProperty());
      
        hboxAddressbook.prefWidthProperty().bind(tabpane.widthProperty());
        hboxAddressbook.prefHeightProperty().bind(tabpane.heightProperty());
        vboxAddress.prefHeightProperty().bind(tabpane.heightProperty());
        vboxContactlist.prefHeightProperty().bind(tabpane.heightProperty());
        vboxContactDetails.prefHeightProperty().bind(tabpane.heightProperty());

//        VBox.setVgrow(tableaddressbook, Priority.ALWAYS);
        HBox.setHgrow(vboxAddress, Priority.ALWAYS);
        btnAddress.prefWidthProperty().bind(vboxAddress.widthProperty());
        addressbookRefresh.prefWidthProperty().bind(vboxAddress.widthProperty());

//        VBox.setVgrow(contacttable, Priority.ALWAYS);
        HBox.setHgrow(vboxContactlist, Priority.ALWAYS);

//        VBox.setVgrow(Contact_details, Priority.ALWAYS);
        HBox.setHgrow(vboxContactDetails, Priority.ALWAYS);
        btnCOntactDetails.prefWidthProperty().bind(vboxContactDetails.widthProperty());
//        vboxAddress.prefHeightProperty().bind(hboxAddressbook.heightProperty());
//        vboxContactlist.prefHeightProperty().bind(hboxAddressbook.heightProperty());
//        vboxContactDetails.prefHeightProperty().bind(hboxAddressbook.heightProperty());

        delete_mail.setVisible(true);
        delete_reviewmail.setVisible(false);
        deleteApproveMail.setVisible(false);
        deleteOfficeMail.setVisible(false);
        deleteSentMail.setVisible(false);
        deleteOutBoxMail.setVisible(false);
        deleteDraftMail.setVisible(false);

        delelete_btn_image.setVisible(true);
        delelete_btn_image1.setVisible(false);
        delelete_btn_imageapprove.setVisible(false);
        delelete_btn_imageOffice.setVisible(false);
        delelete_btn_imageSent.setVisible(false);
        delelete_btn_imageout.setVisible(false);
        delelete_btn_imageDraft.setVisible(false);
        inbox_tab.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Tab>() {
            @Override
            public void changed(ObservableValue<? extends Tab> observable, Tab oldTab, Tab newTab) {

                if (newTab == tabinbox) {
                    m_progressService.restart();

                    // tabinbox.setStyle("-fx-font-size: 15px;");
                    lblinboxreview.setVisible(false);
                    lblinboxapprove.setVisible(false);
                    lblinboxoffice.setVisible(false);
                    lblinboxview.setVisible(true);
                    lblsentmailview.setVisible(false);
                    lbloutboxview.setVisible(false);
                    lblDraftview.setVisible(false);
                    lblTrashview.setVisible(false);

                    delete_mail.setVisible(true);
                    delete_reviewmail.setVisible(false);
                    deleteApproveMail.setVisible(false);
                    deleteOfficeMail.setVisible(false);
                    deleteSentMail.setVisible(false);
                    deleteOutBoxMail.setVisible(false);
                    deleteDraftMail.setVisible(false);

                    delelete_btn_image.setVisible(true);
                    delelete_btn_image1.setVisible(false);
                    delelete_btn_imageapprove.setVisible(false);
                    delelete_btn_imageOffice.setVisible(false);
                    delelete_btn_imageSent.setVisible(false);
                    delelete_btn_imageout.setVisible(false);
                    delelete_btn_imageDraft.setVisible(false);

                    tabinbox.setStyle("-fx-background-color:#A0E7E4;-fx-font-weight: bold;-fx-font-size:14px;");
                    //tabinbox.setStyle(";");
                    tabReview.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
                    tabApprove.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
                    tabOffice.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");

                } else if (newTab == tabReview) {
                    m_progressServicesReview.restart();
                    lblinboxreview.setVisible(true);
                    lblinboxapprove.setVisible(false);
                    lblinboxoffice.setVisible(false);
                    lblinboxview.setVisible(false);
                    lblsentmailview.setVisible(false);
                    lbloutboxview.setVisible(false);
                    lblDraftview.setVisible(false);
                    lblTrashview.setVisible(false);

                    delete_mail.setVisible(false);
                    delete_reviewmail.setVisible(true);
                    deleteApproveMail.setVisible(false);
                    deleteOfficeMail.setVisible(false);
                    deleteSentMail.setVisible(false);
                    deleteOutBoxMail.setVisible(false);
                    deleteDraftMail.setVisible(false);

                    delelete_btn_image.setVisible(false);
                    delelete_btn_image1.setVisible(true);
                    delelete_btn_imageapprove.setVisible(false);
                    delelete_btn_imageOffice.setVisible(false);
                    delelete_btn_imageSent.setVisible(false);
                    delelete_btn_imageout.setVisible(false);
                    delelete_btn_imageDraft.setVisible(false);

                    // tabinbox.setText("Example");
                    tabinbox.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
                    tabReview.setStyle("-fx-background-color:#A0E7E4;-fx-font-weight: bold;-fx-font-size:14px;");
                    tabApprove.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
                    tabOffice.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
                } else if (newTab == tabApprove) {
                    m_progressServicesApproveMail.restart();
                    lblinboxreview.setVisible(false);
                    lblinboxapprove.setVisible(true);
                    lblinboxoffice.setVisible(false);
                    lblinboxview.setVisible(false);
                    lblsentmailview.setVisible(false);
                    lbloutboxview.setVisible(false);
                    lblDraftview.setVisible(false);
                    lblTrashview.setVisible(false);

                    delete_mail.setVisible(false);
                    delete_reviewmail.setVisible(false);
                    deleteApproveMail.setVisible(true);
                    deleteOfficeMail.setVisible(false);
                    deleteSentMail.setVisible(false);
                    deleteOutBoxMail.setVisible(false);
                    deleteDraftMail.setVisible(false);

                    delelete_btn_image.setVisible(false);
                    delelete_btn_image1.setVisible(false);
                    delelete_btn_imageapprove.setVisible(true);
                    delelete_btn_imageOffice.setVisible(false);
                    delelete_btn_imageSent.setVisible(false);
                    delelete_btn_imageout.setVisible(false);
                    delelete_btn_imageDraft.setVisible(false);

                    tabinbox.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
                    tabReview.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
                    tabApprove.setStyle("-fx-background-color:#A0E7E4;-fx-font-weight: bold;-fx-font-size:14px;");
                    tabOffice.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
                } else if (newTab == tabOffice) {
                    m_progressServicesofficeMail.restart();
                    lblinboxreview.setVisible(false);
                    lblinboxapprove.setVisible(false);
                    lblinboxoffice.setVisible(true);
                    lblinboxview.setVisible(false);
                    lblsentmailview.setVisible(false);
                    lbloutboxview.setVisible(false);
                    lblDraftview.setVisible(false);
                    lblTrashview.setVisible(false);

                    delete_mail.setVisible(false);
                    delete_reviewmail.setVisible(false);
                    deleteApproveMail.setVisible(false);
                    deleteOfficeMail.setVisible(true);
                    deleteSentMail.setVisible(false);
                    deleteOutBoxMail.setVisible(false);
                    deleteDraftMail.setVisible(false);

                    delelete_btn_image.setVisible(false);
                    delelete_btn_image1.setVisible(false);
                    delelete_btn_imageapprove.setVisible(false);
                    delelete_btn_imageOffice.setVisible(true);
                    delelete_btn_imageSent.setVisible(false);
                    delelete_btn_imageout.setVisible(false);
                    delelete_btn_imageDraft.setVisible(false);
                    tabinbox.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
                    tabReview.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
                    tabApprove.setStyle("-fx-background-color:#71CDFB;-fx-font-weight: bold;-fx-font-size:14px;");
                    tabOffice.setStyle("-fx-background-color:#A0E7E4;-fx-font-weight: bold;-fx-font-size:14px;");
                } else {
                }
            }
        });

        btnserch_sent.setVisible(false);
        btnserch_out.setVisible(false);
        btnserch_draft.setVisible(false);
        btnserch_trash.setVisible(false);
        if (lblStatus == null) {
            System.out.println("lblStatus is null");
        } else {
            System.out.println("lblStatus is not null:" + sm_netStatus);
        }

        //    System.out.println("Last up date Time"+date);
        Task task = new Task<Void>() {

            @Override
            public Void call() throws Exception {
//                int i = 0;
                while (true) {
                    final String finalI = sm_netStatus;
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            lblStatus.setText("" + finalI);
                            if (finalI == "Online") {
                                btnPrint.setVisible(true);
                                imgPrint.setVisible(true);
                                lblStatus.setGraphic(new ImageView(availimg));
                                m_netWorkUpdate.setText("All Folders are Upto Date");
                                m_netWorkUpdateTime.setText(null);
                                Date d = new Date();
                                m_time = d.toString();
                                if(itm!=null){
                                itm = tableaddressbook.getSelectionModel().getSelectedItem().getValue();
                                String itm1 = "Global Address";
                                if (itm1.equalsIgnoreCase(itm)) {
//                                    editcontext.setVisible(false);
//                                    deletecontext.setVisible(false);
//                                    emailcontext.setVisible(false);
          editcontext.setDisable(true);
                                    deletecontext.setDisable(true);
                                      deletecontext.setDisable(true);
                                   // contextID.hide();

                                } else if (itm.equalsIgnoreCase("Address Book")) {
                                    contacttable.getItems().clear();
                                
//                                    editcontext.setVisible(false);
//                                    deletecontext.setVisible(false);
//                                    emailcontext.setVisible(false);
                                     editcontext.setDisable(true);
                                     deletecontext.setDisable(true);
                                      emailcontext.setDisable(true);
                                     // contextID.hide();
                                } //Display Contact list based on Address book office sm_name
                                else {
//                                    editcontext.setVisible(true);
//                                    deletecontext.setVisible(true);
//                                    emailcontext.setVisible(true);
                                    editcontext.setDisable(false);
                                    deletecontext.setDisable(false);
                                     emailcontext.setDisable(false);
                                     
                                }
                                btn1.setVisible(true);
                                lblStatus.setGraphic(new ImageView(availimg));
                                m_netWorkUpdate.setText("All Folders are Upto Date");
                                m_netWorkUpdateTime.setText(null);
                              
}
//                            m_date=messageHandler.getLastUpdatedTime();
                            } else if (finalI == "Offline") {

                                lblStatus.setGraphic(new ImageView(offlineimg));
                                m_netWorkUpdate.setText("These Folders are last Update at:");
                                m_date = messageHandler.getLastUpdatedTime();

                                m_netWorkUpdateTime.setText(m_date);

                                // System.out.println("Last up date Time"+m_date);
                                btnPrint.setVisible(false);
                                imgPrint.setVisible(false);
                                
                                //                                 editcontext.setVisible(false);
//                                 deletecontext.setVisible(false);
//                                  emailcontext.setVisible(false);
                                  editcontext.setDisable(true);
                                    deletecontext.setDisable(true);
                                      emailcontext.setDisable(true);
                                    btn1.setVisible(false);
                            }
                        }

                    });
                    tred++;
                    Thread.sleep(1000);
                }
            }
        };
        Thread th = new Thread(task);
        th.setDaemon(true);
        th.start();

        Task task1 = new Task<Void>() {
            @Override

            public Void call() throws Exception {
                while (true) {
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            AuthorisationCheck authorisationCheck = AuthorisationCheck
                                    .getAuthorisationCheckInstance();
                            AuthorisationObserver authorisationObserver = AuthorisationObserver.getAuthorisationObserverInstance(authorisationCheck);
                            authorisationStatus = authorisationObserver.getAuthorisationChangeIndicator();
                            if (authorisationStatus != null) {
                                if (authorisationStatus.equalsIgnoreCase("UnAuthorised")) {
                                    try {
                                        System.out.println("aaauthorisation status: " + authorisationStatus);
                                        System.out.println("UNAUTHORISED");
                                        AuthorisationCheck.getAuthorisationCheckInstance().setAuthorisationChangeIndicator("Authorised");
                                        root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/Authorization.fxml"));
                                        stageAuth.setScene(new Scene(root1));
                                        stageAuth.setTitle("Authorization");
                                        stageAuth.toFront();
                                        stageAuth.resizableProperty().setValue(Boolean.FALSE);
                                        stageAuth.show();
                                        stageAuth.getIcons().add(new Image("/img/Mail-icon.png"));
                                        System.out.println("UN-AUTHORISED");
                                    } catch (IOException ex) {
                                        System.out.println("exception is" + ex);
                                        ex.printStackTrace();
                                    }
                                }
                            }
                        }
                    });
                    Thread.sleep(1000);
                }
            }
        };
        Thread th1 = new Thread(task1);
        th1.setDaemon(true);
        th1.start();

//        progressindi();
//        progressIndiCatorReview();
//        progressIndiCatorApprove();
//        progressIndiCatorOffice();
//        progressIndiCatorSentMail();
//        progressIndiCatorDraftMail();
//        progressIndiCatorTrashMail();
//        progressIndiCatorOutboxMail();
        lblinboxreview.setVisible(false);
        lblinboxapprove.setVisible(false);
        lblinboxoffice.setVisible(false);
        lblinboxview.setVisible(true);
        lblsentmailview.setVisible(false);
        lbloutboxview.setVisible(false);
        lblDraftview.setVisible(false);
        lblTrashview.setVisible(false);
        initUI();
        addMouseScrolling(mail_header);

        search_lable.setVisible(false);
        TextFields.bindAutoCompletion(search_mail, Contacts);
        TextFields.bindAutoCompletion(textsearch, Contacts);
        refresh();
        myCombobox1.setValue("Select");
        myCombobox1.setItems(Selectlist);
        lbluser.setText(sm_name);
        address_book_initialize();
        String Confidential_symbol = "";
        String Restricted_symbol = "";
        String Secret_symbol = "";
        String TopSecret_symbol = "";
        String Unclassified_symbol = "";
        for (GetAllSecurityClassConfigDTO singleObj : SecurityClssificationConfigList) {
            if (singleObj.getSecclassvalue().equalsIgnoreCase("Confidential")) {
                Confidential_symbol = singleObj.getSecclasssymbol();
                lblConf.setText(Confidential_symbol);
            }
            if (singleObj.getSecclassvalue().equalsIgnoreCase("Restricted")) {
                Restricted_symbol = singleObj.getSecclasssymbol();
                lblRestrictd.setText(Restricted_symbol);
            }

            if (singleObj.getSecclassvalue().equalsIgnoreCase("Secret")) {
                Secret_symbol = singleObj.getSecclasssymbol();
                lblSecrt.setText(Secret_symbol);
            }

            if (singleObj.getSecclassvalue().equalsIgnoreCase("TopSecret")) {
                TopSecret_symbol = singleObj.getSecclasssymbol();
                lblTopscrt.setText(TopSecret_symbol);
            }

            if (singleObj.getSecclassvalue().equalsIgnoreCase("Unclassified")) {
                Unclassified_symbol = singleObj.getSecclasssymbol();
                lblUnclassfd.setText(Unclassified_symbol);
            }
        }

        String defere_col = "";
        for (GetAllPrecedenceConfigDTO singleObj : prcedenceList) {
            if (singleObj != null) {
                String str = singleObj.getPrecvalue();
                if (str.equalsIgnoreCase("Deferred")) {
                    defere_col = singleObj.getPreccolour();
                }
            }

            System.out.println("1col" + defere_col);
            if (defere_col.equalsIgnoreCase("Orange")) {
                lblDeffered.setStyle("-fx-background-color:Orange;");
            }

            String Emergency_col = "";

            if (singleObj != null) {
                String str = singleObj.getPrecvalue();
                if (str.equalsIgnoreCase("Emergency")) {
                    Emergency_col = singleObj.getPreccolour();
                }
            }

            System.out.println("2col" + Emergency_col);
            if (Emergency_col.equalsIgnoreCase("LightBlue")) {
                lblEmrgnvcy.setStyle("-fx-background-color:lightblue;");

            }

            String Flash_col = "";

            if (singleObj != null) {
                String str = singleObj.getPrecvalue();
                if (str.equalsIgnoreCase("Flash")) {
                    Flash_col = singleObj.getPreccolour();
                }
            }

            if (Flash_col.equalsIgnoreCase("Tomato")) {
                lblFlash.setStyle("-fx-background-color:Tomato;");

            }

            String OpImmediate_col = "";

            if (singleObj != null) {
                String str = singleObj.getPrecvalue();
                if (str.equalsIgnoreCase("OpImmediate")) {
                    OpImmediate_col = singleObj.getPreccolour();
                }
            }

            if (OpImmediate_col.equalsIgnoreCase("LightGreen")) {
                lblOpImdte.setStyle("-fx-background-color:lightgreen;");

            }

            String Priority_col = "";

            if (singleObj != null) {
                String str = singleObj.getPrecvalue();
                if (str.equalsIgnoreCase("Priority")) {
                    Priority_col = singleObj.getPreccolour();
                }
            }

            System.out.println("5col" + Priority_col);

            if (Priority_col.equalsIgnoreCase("Yellow")) {
                lablPriority.setStyle("-fx-background-color:Yellow;");

            }

            String Routine_col = "";

            if (singleObj != null) {
                if (singleObj.getPrecvalue().equalsIgnoreCase("Routine")) {
                    Routine_col = singleObj.getPreccolour();
                }
            }

            System.out.println("6col" + Routine_col);
            if (Routine_col.equalsIgnoreCase("Pink")) {
                lblRoutine.setStyle("-fx-background-color:Pink;");

            }
        }
        System.out.println("CERTIFICATE CODE");

        CertificateInfo certificateInfo = messageHandler.getCertificate(sm_name);

        Map<Object, Object> map1 = certificateInfo.getBasicInfo();
        if (map1 != null) {
            if (map1.get("serialNumber") != null) {
                Serialnumber = (String) map1.get("serialNumber");
                System.out.println("Serialnumber Number" + Serialnumber);
            }
            if (map1.get("subject") != null) {
                String m_variableIssuedTo = (String) map1.get("subject");
                String name = m_variableIssuedTo.substring(4, m_variableIssuedTo.length() - 1);
                String split[] = name.split("/");
                m_issuedTo = split[0];
                System.out.println("m_issuedTo::" + m_issuedTo);
            }
            if (map1.get("issuer") != null) {
                String m_variableIssuedBy = (String) map1.get("issuer");
                String m1_variableIssuedBy = m_variableIssuedBy.substring(4, m_variableIssuedBy.length() - 1);
                String split1[] = m1_variableIssuedBy.split("/");
                m_issuedBy = split1[0];
                System.out.println("m_issuedBy::" + m_issuedBy);
            }

            if (map1.get("validTo") != null) {
                m_expirationDate = (String) map1.get("validTo");
                System.out.println("Expiration Date" + m_expirationDate);
            }
            m_PersonalCertificateList.add(new PersonalCertificate(Serialnumber, m_issuedTo, m_issuedBy, m_expirationDate));
            m_serialNumPersonalCertificate.setCellValueFactory(new PropertyValueFactory<>("serialNumber"));
            m_issuedToPersonalCertificate.setCellValueFactory(new PropertyValueFactory<>("issuedTo"));
            m_issuedByPersonalCertificate.setCellValueFactory(new PropertyValueFactory<>("issuedBy"));
            m_expirationDatePersonalCertificate.setCellValueFactory(new PropertyValueFactory<>("expirationDate"));

            m_personalCertificate.setItems(FXCollections.observableArrayList(m_PersonalCertificateList));
            m_personalCertificate.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
            m_lblPersonalSerialNumber.setText(Serialnumber);
            m_lablPersnlCrtIssuseTo.setText(m_issuedTo);
            m_lablPersnlCrtIssuseBy.setText(m_issuedBy);
            m_lablPersnlCrtExpiratioDate.setText(m_expirationDate);
//        for (Map.Entry<Object, Object> key1 : map1.entrySet()) {
//            System.out.println("Key1: " + key1.getKey() + "        Value1: " + key1.getValue());
//        }

//		System.out.println();	
//		Map<Object,Object> map2 = certificateInfo.getCriticalExtensions();
//		for(Entry<Object, Object> key2:map2.entrySet()){
//			System.out.println("Key2: "+key2.getKey()+"        Value2: "+key2.getValue());
//		}
////		
////		System.out.println();	
//		Map<Object,Object> map3 = certificateInfo.getExtensions();
//		for(Entry<Object, Object> key3:map3.entrySet()){
//			System.out.println("Key3: "+key3.getKey()+"        Value3: "+key3.getValue());
//		}
//        System.out.println("");
//        Map<Object, Object> map4 = certificateInfo.getPropertiens();
//        for (Map.Entry<Object, Object> key4 : map4.entrySet()) {
//            System.out.println("Key4: " + key4.getKey() + "        Value4: " + key4.getValue());
//        }
//
//        Object certPath = certificateInfo.getCertPath();
//        System.out.println(certPath.toString());
        }
    }

    /**
     * ******************************************************************
     * @Function Name :initialize
     * @Description : Method to call initialization function.
     * @Input Parameter : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :30-MAR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        inbox_tab.getTabs().remove(tabDraft);
        inbox_tab.getTabs().remove(tabOutbox);
        inbox_tab.getTabs().remove(tabTrash);
        inbox_tab.getTabs().remove(tabSent);

        refresh_btn.setVisible(true);
        imgRefreshInbox.setVisible(true);
        imgSentRefresh.setVisible(false);
        refresh_btnSent.setVisible(false);
        imgOutboxRefresh.setVisible(false);
        refresh_btnOutbox.setVisible(false);
        refresh_btnDraft.setVisible(false);
        imgDraftRefresh.setVisible(false);
        refresh_btnTrash.setVisible(false);
        imgTrashRefresh.setVisible(false);
        initialization();
    }

    /**
     * ******************************************************************
     * @Function Name :mouseclick
     * @Description : Method to getting Global Address book contact from LDAP.
     * @Input Parameter : MouseEvent-Provided by JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :30-MAR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void mouseclick(MouseEvent mouseEvent) throws SQLException {

        try {

            itm = tableaddressbook.getSelectionModel().getSelectedItem().getValue();
            String itm1 = "Global Address";
            if (itm1.equalsIgnoreCase(itm)) {
                editcontext.setVisible(false);
                deletecontext.setVisible(false);
                emailcontext.setVisible(false);

                try {
                    MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
                    List<String> list = messageHandler.getAllContactNames();
                    contacttable.getItems().clear();
                    for (String data : list) {

                        System.out.println(data);

                        Allglobal_contact = data;

                        All_contact.add(new Usermstpojo(data));
                        colcontactlist.setCellValueFactory(new PropertyValueFactory<>("username"));
                        contacttable.setItems(All_contact);
                        contacttable.setVisible(true);

                        contacttable.getItems();

                        // All_contact.add(Allglobal_contact);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            } else if (itm.equalsIgnoreCase("Address Book")) {
                contacttable.getItems().clear();
                System.out.println("Address Book");
                editcontext.setVisible(false);
                deletecontext.setVisible(false);
                emailcontext.setVisible(false);
            } //Display Contact list based on Address book office sm_name
            else {
                editcontext.setVisible(true);
                deletecontext.setVisible(true);
                emailcontext.setVisible(true);

                itm = tableaddressbook.getSelectionModel().getSelectedItem().getValue();
                MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
                ContactsOfAddrBkDTO dto = new ContactsOfAddrBkDTO();
                dto.setCn(itm);   //address book sm_name
                String officeName = messageHandler.ldapUserOffice(sm_name);
                dto.setNode(officeName);   //office sm_name
                dto.setOwner(sm_name);     //login person sm_name.

                List<String> str = messageHandler.ContactsOfAddrBk(dto);
                contacttable.getItems().clear();
                for (String data : str) {
                    System.out.println(data);

                    locl_contact = data;

                    All_Local_contact.add(new Usermstpojo(data));
                    colcontactlist.setCellValueFactory(new PropertyValueFactory<>("username"));
                    contacttable.setItems(All_Local_contact);
                    contacttable.setVisible(true);

                    contacttable.getItems();

                }

            }

        } catch (NullPointerException e) {
            System.out.println("No data found");
        }

    }

    /**
     * ******************************************************************
     * @Function Name :contactitemclick
     * @Description : Method to Display contact information about Particular
     * contact from LDAP .
     * @Input Parameter : MouseEvent-Provided by JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :27-MAR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void contactitemclick(MouseEvent mouseEvent) throws Exception {
        try {

            contact_email.setText(null);
            Contact_details.setText(null);
            MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
            String row_item = contacttable.getSelectionModel().getSelectedItem().getUsername();

            System.out.println(row_item);
            //Getting  contact Info 
            Contact contact = new Contact();

            contact.setOffice(messageHandler.ldapUserOffice(row_item));
            contact.setOwner(row_item);

            ContactInfoDTO dto = messageHandler.getContactINfo(contact);
            Office_name = dto.getOfficeName();
            Postal_adress = dto.getPostalAddress();
            Role = dto.getRole();
            Telephone_number = dto.getTelephoneNumber();
            Exceptin_msg = dto.getExceptionMsg();
            Mail_id = dto.getMailId();
            String SplitId[] = Mail_id.split(":");
            String Office[] = Office_name.split(":");
            System.out.println("Mail Id: " + dto.getMailId());
            System.out.println("Office Name: " + dto.getOfficeName());
            System.out.println("Postal Address: " + dto.getPostalAddress());
            System.out.println("Role: " + dto.getRole());
            System.out.println("Telephone Number: " + dto.getTelephoneNumber());
            System.out.println("Exception Msg: " + dto.getExceptionMsg());

            //Displaying Contact information in Text Area
            // Contact_details.setText(Office_name + "\n" + "Postal_adress" + Postal_adress + "\n" + "Role" + Role + "\n" + "Telephone_number" + Telephone_number + "\n");
           Contact_details.setText(" Office Name: " + Office[1] + "\n\n" + " Rank: " + "\n\n" + " Appointment: " + "\n\n" + " Unit/Formation: " + "\n\n" + " Telephone number: " + Telephone_number + "\n\n" + " Mobile number: " + "\n\n" + " E-mail id: " + "\n\n" + " Role: " + "\n\n");
            contact_email.setText(SplitId[1]);
        } catch (NullPointerException e) {
            System.out.println("Not able read contact details");
        }

    }

    /**
     * ******************************************************************
     * @Function Name :onClickRefreshAddressBook
     * @Description : Method to Refresh addr.
     * @Input Parameter : MouseEvent-Provided by JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat..
     * @Created Date :18-MAR-2017
     * @Modification History : NA.
     * ******************************************************************
     */
    @FXML
    public void onClickRefreshAddressBook(ActionEvent event) throws Exception {
        address_book_initialize();
    }

    /**
     * ******************************************************************
     * @Function Name :onClickRow
     * @Description : Method to Display In Box mail view page.
     * @Input Parameter : MouseEvent-Provided by JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :26-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onClickRow(MouseEvent Event) throws Exception {
        int count = Event.getClickCount();
        MailDTO outputDTO;
        if (count == 2) {

            mail_id = mail_header.getSelectionModel().getSelectedItem().getMail_id();
            System.out.println("MAIL ID AFTER CLICK" + mail_id);

            double c = Double.parseDouble(mail_id);

            System.out.println("MAIL ID AFTER CLICK 111" + mail_id);
            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID((int) c);
            inputDTO.setFolder("inbox");

            outputDTO = messageHandler.readSpecificeMail(inputDTO);
            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
//             Read_Receipt = (String) headers.get("read_receipt");
            String Subject = (String) headers.get("Subject");
            String Msgtype = (String) headers.get("msgType");
            System.out.println("Subject is::::" + Subject);
            System.out.println("msgtyoe is::::" + Msgtype);

//                if(Read_Receipt.equalsIgnoreCase("true"))
            if (Subject.equalsIgnoreCase("Successful Mail Delivery Report") || Msgtype.equalsIgnoreCase("READRECEIPT") || Subject.equalsIgnoreCase("Undelivered Mail Returned to Sender")) {
                System.out.println("before loading...");
                try {
                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/System_Notification.fxml"));
                    System.out.println("After loading...");
                    notificatio_mail.setScene(new Scene(root1));
                    notificatio_mail.setTitle("View Messaging");

                    notificatio_mail.resizableProperty().setValue(Boolean.FALSE);
                    notificatio_mail.show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (Msgtype.equalsIgnoreCase("REJECTMAIL")) {
                try {
                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/RejectMailInboxView.fxml"));
                    System.out.println("After loading...");
                    m_reject_mail.setScene(new Scene(root1));
                    m_reject_mail.setTitle("Reject Mail");
                    m_reject_mail.resizableProperty().setValue(Boolean.FALSE);
                    m_reject_mail.show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {

                try {
                    {
                        root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/View_inboxmail_page.fxml"));
                        System.out.println("After loading...");
                        read_mail.setScene(new Scene(root1));
                        read_mail.setTitle("View Messaging");
                        read_mail.resizableProperty().setValue(Boolean.FALSE);
                        read_mail.show();
                    }

                } catch (Exception E) {
                    System.out.println("Serching");
                }
            }

        }
    }

    /**
     * ******************************************************************
     * @Function Name :onClickReview
     * @Description : Method to Display Review Mail view page.
     * @Input Parameter : MouseEvent-Provided by JavaFX.
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :26-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onClickReview(MouseEvent Event) throws Exception {

        System.out.println("On_clicK_review entered");

        int count = Event.getClickCount();
        if (count == 2) {

            mail_id = mail_header_review.getSelectionModel().getSelectedItem().getMail_id();

            System.out.println(mail_id);
            try {

                System.out.println("View mail Before loading...");
                root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/Review_rview_mail.fxml"));
                System.out.println("After loading...");
                read_reviewmail.setScene(new Scene(root1));
                read_reviewmail.setTitle("View Messaging");

                read_reviewmail.resizableProperty().setValue(Boolean.FALSE);
                read_reviewmail.show();

            } catch (Exception E) {
                System.out.println("Serching" + E);
            }

        }
    }

    /**
     * ******************************************************************
     * @Function Name :onClickApprove
     * @Description : Method to Display Approve Mail view page.
     * @Input Parameter : MouseEvent-Provided by JavaFX.
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :27-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onClickApprove(MouseEvent Event) throws Exception {
        System.out.println("On_clicK_Approve entered");

        int count = Event.getClickCount();

        if (count == 2) {

            mail_id = mail_header_approve.getSelectionModel().getSelectedItem().getMail_id();
            System.out.println("APProveMID:" + mail_id);
            try {

                System.out.println("View mail Before loading...");
                root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/Approve_view_page.fxml"));
                System.out.println("After loading...");
                read_approvemail.setScene(new Scene(root1));
                read_approvemail.setTitle("View Messaging");
                // stage3.initModality(Modality.APPLICATION_MODAL);             
                //stage3.initOwner(btnCompose.getScene().getWindow());
                //mainStage.toFront();
                // stage3.getIcons().add(new Image("/img/Mail-icon.png"));
                //stage3.showAndWait();
                read_approvemail.resizableProperty().setValue(Boolean.FALSE);
                read_approvemail.show();
            } catch (Exception E) {
                System.out.println("Serching" + E);
            }

        }
    }

    /**
     * ******************************************************************
     * @Function Name :onClickOffice
     * @Description : Method to Display Office Mail view page.
     * @Input Parameter : MouseEvent-Provided by JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :27-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onClickOffice(MouseEvent Event) throws Exception {

        System.out.println("On_clicK_office entered");

        int count = Event.getClickCount();

        if (count == 2) {

            mail_id = mail_header_office.getSelectionModel().getSelectedItem().getMail_id();
            try {

// 
                System.out.println("View mail Before loading...");
                root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/Office_view_page.fxml"));
                System.out.println("After loading...");
                read_officeemail.setScene(new Scene(root1));
                read_officeemail.setTitle("View Messaging");
                // stage3.initModality(Modality.APPLICATION_MODAL);             
                //stage3.initOwner(btnCompose.getScene().getWindow());
                //mainStage.toFront();
                // stage3.getIcons().add(new Image("/img/Mail-icon.png"));
                //stage3.showAndWait();
                read_officeemail.resizableProperty().setValue(Boolean.FALSE);
                read_officeemail.show();

            } catch (Exception C) {
                System.out.println("Serching");
            }

        }

    }

    /**
     * ******************************************************************
     * @Function Name :onClickSent
     * @Description : Method to Display Sent Mail view page.
     * @Input Parameter : MouseEvent-Provided by JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :27-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void onClickSent(MouseEvent Event) throws Exception {

        System.out.println("On_clicK_SENT entered");
        int count = Event.getClickCount();
        MailDTO outputDTO;
        if (count == 2) {
            mail_id = mail_table.getSelectionModel().getSelectedItem().getMail_id();
            System.out.println("MAILID" + mail_id);
            double c = Double.parseDouble(mail_id);
            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID((int) c);
            inputDTO.setFolder("sent");
            outputDTO = messageHandler.readSpecificeMail(inputDTO);
            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
//             Read_Receipt = (String) headers.get("read_receipt");
            String Subject = (String) headers.get("Subject");
            String Msgtype = (String) headers.get("msgType");
            System.out.println("Subject is::::" + Subject);
            System.out.println("msgtyoe is::::" + Msgtype);
//                if(Read_Receipt.equalsIgnoreCase("true"))
            if (Subject.equalsIgnoreCase("Successful Mail Delivery Report") || Msgtype.equalsIgnoreCase("READRECEIPT") || Subject.equalsIgnoreCase("Undelivered Mail Returned to Sender")) {
                System.out.println("before loading...");
                try {
                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/Sent_notification.fxml"));
                    System.out.println("After loading...");
                    notificatio_sent_mail.setScene(new Scene(root1));
                    notificatio_sent_mail.setTitle("View Messaging");
                    // stage3.initModality(Modality.APPLICATION_MODAL);             
                    //stage3.initOwner(btnCompose.getScene().getWindow());
                    //mainStage.toFront();
                    // stage3.getIcons().add(new Image("/img/Mail-icon.png"));
                    //stage3.showAndWait();
                    notificatio_sent_mail.resizableProperty().setValue(Boolean.FALSE);
                    notificatio_sent_mail.show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } //                        else if(Msgtype.equalsIgnoreCase("REJECTMAIL"))
            //                
            //            {
            //                 try {
            //                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/RejectMailInboxView.fxml"));
            //                    System.out.println("After loading...");
            //                    m_reject_mail.setScene(new Scene(root1));
            //                    m_reject_mail.setTitle("Reject Mail");
            //                    m_reject_mail.resizableProperty().setValue(Boolean.FALSE);
            //                    m_reject_mail.show();
            //                } catch (Exception e) {
            //                    e.printStackTrace();
            //                }
            //            }
            else {

                try {
                    System.out.println("View mail Before loading...");
                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/Sent_mail_view.fxml"));
                    System.out.println("After loading...");
                    sen_mail_stage.setScene(new Scene(root1));
                    sen_mail_stage.setTitle("View Messaging");
                    // stage3.initModality(Modality.APPLICATION_MODAL);             
                    //stage3.initOwner(btnCompose.getScene().getWindow());
                    //mainStage.toFront();
                    // stage3.getIcons().add(new Image("/img/Mail-icon.png"));
                    //stage3.showAndWait();
                    sen_mail_stage.resizableProperty().setValue(Boolean.FALSE);
                    sen_mail_stage.show();

                } catch (Exception E) {
                    System.out.println("Serching");
                }

            }

        }
    }

    /**
     * ******************************************************************
     * @Function Name :on_click_trash
     * @Description : Method to Display Trash Mail view page.
     * @Input Parameter : MouseEvent-Provided by JavaFX.
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :27-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void on_click_trash(MouseEvent Event) throws Exception {
        int count = Event.getClickCount();
        MailDTO outputDTO;
        if (count == 2) {

            mail_id = mail_table_trash_box.getSelectionModel().getSelectedItem().getMail_id();
            System.out.println("MAILID" + mail_id);
            int c = Integer.parseInt(mail_id);
            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID(c);
            inputDTO.setFolder("trash");
            outputDTO = messageHandler.readSpecificeMail(inputDTO);
            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
//             Read_Receipt = (String) headers.get("read_receipt");
            String Subject = (String) headers.get("Subject");
            String Msgtype = (String) headers.get("msgType");
            System.out.println("Subject is::::" + Subject);
            System.out.println("msgtyoe is::::" + Msgtype);
//                if(Read_Receipt.equalsIgnoreCase("true"))
            if (Subject.equalsIgnoreCase("Successful Mail Delivery Report") || Msgtype.equalsIgnoreCase("READRECEIPT") || Subject.equalsIgnoreCase("Undelivered Mail Returned to Sender")) {
                System.out.println("before loading...");
                try {

                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/Trash_Notification.fxml"));
                    System.out.println("After loading...");
                    notificatio_trash_mail.setScene(new Scene(root1));
                    notificatio_trash_mail.setTitle("View Messaging");
                    //  notificatio_mail.initModality(Modality.APPLICATION_MODAL);             
                    //stage3.initOwner(btnCompose.getScene().getWindow());
                    // notificatio_mail.toFront();
                    // stage3.getIcons().add(new Image("/img/Mail-icon.png"));
                    //stage3.showAndWait();
                    notificatio_trash_mail.resizableProperty().setValue(Boolean.FALSE);
                    notificatio_trash_mail.show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (Msgtype.equalsIgnoreCase("REJECTMAIL")) {
                try {
                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/RejectMailTrash.fxml"));
                    System.out.println("After loading...");
                    m_rejectThrashmail.setScene(new Scene(root1));
                    m_rejectThrashmail.setTitle("Reject Mail");
                    m_rejectThrashmail.resizableProperty().setValue(Boolean.FALSE);
                    m_rejectThrashmail.show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                try {

// 
                    System.out.println("View mail Before loading...");
                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/Trash_mail_view.fxml"));
                    System.out.println("After loading...");
                    trash_mail_stage.setScene(new Scene(root1));
                    trash_mail_stage.setTitle("View Messaging");
                    // stage3.initModality(Modality.APPLICATION_MODAL);             
                    //stage3.initOwner(btnCompose.getScene().getWindow());
                    //mainStage.toFront();
                    // stage3.getIcons().add(new Image("/img/Mail-icon.png"));
                    //stage3.showAndWait();
                    trash_mail_stage.resizableProperty().setValue(Boolean.FALSE);
                    trash_mail_stage.show();

                } catch (Exception E) {
                    System.out.println("Serching");
                }

            }
        }

    }

    /**
     * ******************************************************************
     * @Function Name :on_click_draft
     * @Description : Method to Display Draft Mail view page.
     * @Input Parameter : MouseEvent-Provided by JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :28-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void on_click_draft(MouseEvent Event) throws Exception {

        System.out.println("On_clicK_draft entered");

        int count = Event.getClickCount();
        MailDTO outputDTO = new MailDTO();
        if (count == 2) {

            mail_id = mail_table_draft_table.getSelectionModel().getSelectedItem().getMail_id();
            System.out.println("MAILID" + mail_id);
            int c = Integer.parseInt(mail_id);
            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID(c);
            inputDTO.setFolder("drafts");
            outputDTO = messageHandler.readSpecificeMail(inputDTO);
            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
//             Read_Receipt = (String) headers.get("read_receipt");
//            String Subject = (String) headers.get("Subject");
            String Subject = outputDTO.getSubject();
            String Msgtype = (String) headers.get("msgType");
            System.out.println("Subject is::::" + Subject);
            System.out.println("msgtyoe is::::" + Msgtype);
//                if(Read_Receipt.equalsIgnoreCase("true"))
//            if (Subject.equalsIgnoreCase("Successful Mail Delivery Report") || Msgtype.equalsIgnoreCase("READRECEIPT") || Subject.equalsIgnoreCase("Undelivered Mail Returned to Sender")) {
//                System.out.println("before loading...");
//                try {
//                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/Draft_notification.fxml"));
//                    System.out.println("After loading...");
//                    notificatio_draft_mail.setScene(new Scene(root1));
//                    notificatio_draft_mail.setTitle("View Messaging");
//                    // stage3.initModality(Modality.APPLICATION_MODAL);             
//                    //stage3.initOwner(btnCompose.getScene().getWindow());
//                    //mainStage.toFront();
//                    // stage3.getIcons().add(new Image("/img/Mail-icon.png"));
//                    //stage3.showAndWait();
//                    notificatio_draft_mail.resizableProperty().setValue(Boolean.FALSE);
//                    notificatio_draft_mail.show();
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            } //                        else if(Msgtype.equalsIgnoreCase("REJECTMAIL"))
            //                
            //            {
            //                 try {
            //                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/RejectMailInboxView.fxml"));
            //                    System.out.println("After loading...");
            //                    m_reject_mail.setScene(new Scene(root1));
            //                    m_reject_mail.setTitle("Reject Mail");
            //                    m_reject_mail.resizableProperty().setValue(Boolean.FALSE);
            //                    m_reject_mail.show();
            //                } catch (Exception e) {
            //                    e.printStackTrace();
            //                }
            //            }
            //else {
            try {

// 
                System.out.println("View mail Before loading...");
                root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/Draft_view_mail.fxml"));
                System.out.println("After loading...");
                draft_mail_stage.setScene(new Scene(root1));
                draft_mail_stage.setTitle("View Messaging");
                // stage3.initModality(Modality.APPLICATION_MODAL);             
                //stage3.initOwner(btnCompose.getScene().getWindow());
                //mainStage.toFront();
                // stage3.getIcons().add(new Image("/img/Mail-icon.png"));
                //stage3.showAndWait();
                draft_mail_stage.resizableProperty().setValue(Boolean.FALSE);
                draft_mail_stage.show();

            } catch (Exception E) {
                System.out.println("Serching");
            }

            //}
        }

    }
     @FXML
    public void on_click_outbox (MouseEvent Event) throws Exception {
         int count = Event.getClickCount();
        MailDTO outputDTO = new MailDTO();
        if (count == 2) {
            mail_id = mail_table_out_box.getSelectionModel().getSelectedItem().getMail_id();
            System.out.println("MAILID" + mail_id);
            int c = Integer.parseInt(mail_id);
            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID(c);
            inputDTO.setFolder("outbox");
            outputDTO = messageHandler.readSpecificeMail(inputDTO);
            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();

            String Subject = outputDTO.getSubject();
            String Msgtype = (String) headers.get("msgType");
            System.out.println("Subject is::::" + Subject);
            System.out.println("msgtyoe is::::" + Msgtype);
    
            try {
                root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/OutBoxViewMailPage.fxml"));
                m_outboxStage.setScene(new Scene(root1));
                m_outboxStage.setTitle("View Messaging");
                // stage3.initModality(Modality.APPLICATION_MODAL);             
                //stage3.initOwner(btnCompose.getScene().getWindow());
                //mainStage.toFront();
                // stage3.getIcons().add(new Image("/img/Mail-icon.png"));
                //stage3.showAndWait();
                m_outboxStage.resizableProperty().setValue(Boolean.FALSE);
                m_outboxStage.show();

            } catch (Exception E) {
               E.printStackTrace();
            }
        }
    }
//    public void on_click_draft(MouseEvent Event) throws Exception {
//
//        System.out.println("On_clicK_SENT entered");
//
//        int count = Event.getClickCount();
//        MailDTO outputDTO;
//        if (count == 2) {
//
//            mail_id = mail_table_draft_table.getSelectionModel().getSelectedItem().getMail_id();
//            System.out.println("MAILID" + mail_id);
//            int c = Integer.parseInt(mail_id);
//            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
//            inputDTO.setMsgUID(c);
//            inputDTO.setFolder("drafts");
//            outputDTO = msghndlr.readSpecificeMail(inputDTO);
//            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
////             Read_Receipt = (String) headers.get("read_receipt");
//            String Subject = (String) headers.get("Subject");
//            String Msgtype = (String) headers.get("msgType");
//            System.out.println("Subject is::::" + Subject);
//            System.out.println("msgtyoe is::::" + Msgtype);
////                if(Read_Receipt.equalsIgnoreCase("true"))
//            if (Subject.equalsIgnoreCase("Successful Mail Delivery Report") || Msgtype.equalsIgnoreCase("READRECEIPT") || Subject.equalsIgnoreCase("Undelivered Mail Returned to Sender")) {
//                System.out.println("before loading...");
//                try {
//                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/Draft_notification.fxml"));
//                    System.out.println("After loading...");
//                    notificatio_draft_mail.setScene(new Scene(root1));
//                    notificatio_draft_mail.setTitle("View Messaging");
//                    // stage3.initModality(Modality.APPLICATION_MODAL);             
//                    //stage3.initOwner(btnCompose.getScene().getWindow());
//                    //mainStage.toFront();
//                    // stage3.getIcons().add(new Image("/img/Mail-icon.png"));
//                    //stage3.showAndWait();
//                    notificatio_draft_mail.resizableProperty().setValue(Boolean.FALSE);
//                    notificatio_draft_mail.show();
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            } else {
//                try {
//
//// 
//                    System.out.println("View mail Before loading...");
//                    root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/Draft_view_mail.fxml"));
//                    System.out.println("After loading...");
//                    draft_mail_stage.setScene(new Scene(root1));
//                    draft_mail_stage.setTitle("View Messaging");
//                    // stage3.initModality(Modality.APPLICATION_MODAL);             
//                    //stage3.initOwner(btnCompose.getScene().getWindow());
//                    //mainStage.toFront();
//                    // stage3.getIcons().add(new Image("/img/Mail-icon.png"));
//                    //stage3.showAndWait();
//                    draft_mail_stage.resizableProperty().setValue(Boolean.FALSE);
//                    draft_mail_stage.show();
//
//                } catch (Exception E) {
//                    System.out.println("Serching");
//                }
//
//            }
//        }
//
//    }

    /**
     * ******************************************************************
     * @Function Name :initUI
     * @Description : Method for Date picker validation.
     * @Input Parameter : NA.
     * @Output Parameter : NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :29-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    private void initUI() {

        from_date.setValue(LocalDate.now(Clock.systemUTC()).now());
        to_date.setValue(LocalDate.now(Clock.systemUTC()).now());
        from_timer.setValue(LocalTime.now());
        to_timer.setValue(LocalTime.now());
        final Callback<DatePicker, DateCell> dayCellFactory
                = new Callback<DatePicker, DateCell>() {
            @Override
            public DateCell call(final DatePicker datePicker) {
                return new DateCell() {
                    @Override
                    public void updateItem(LocalDate item, boolean empty) {
                        super.updateItem(item, empty);

                        if (item.isBefore(
                                from_date.getValue().plusDays(0))) {
                            setDisable(true);
                            setStyle("-fx-background-color: #82C3E1;");
                        } else if (item.isAfter(LocalDate.now())) {
                            setDisable(true);
                            setStyle("-fx-background-color: #82C3E1;");
                        }
                    }
                };
            }
        };
        final Callback<DatePicker, DateCell> dayCellFactory1;
        dayCellFactory1 = new Callback<DatePicker, DateCell>() {
            @Override
            public DateCell call(final DatePicker datePicker) {
                return new DateCell() {
                    @Override
                    public void updateItem(LocalDate item, boolean empty) {
                        super.updateItem(item, empty);

                        if (item.isAfter(LocalDate.now())) {

                            setDisable(true);
                            setStyle("-fx-background-color: #82C3E1;");
                        }
//                        else
//                        {
//                            item.isAfter(checkOutDatePicker.getValue().minusDays(1));
//                               setDisable(true);
//                            setStyle("-fx-background-color: #ffc0cb;");
//                                    }
                    }
                };
            }
        };
        from_date.setDayCellFactory(dayCellFactory1);
        to_date.setDayCellFactory(dayCellFactory);
        to_date.setValue(from_date.getValue().plusDays(0));

    }

    /**
     * ******************************************************************
     * @Function Name :stripHTMLTags1
     * @Description : Method to remove HTML tags.
     * @Input Parameter : String htmlText.
     * @Output Parameter	: String text.
     * @Author : Ram Krishna Paul.
     * @Created Date :28-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    private String stripHTMLTags1(String htmlText) {

        Pattern pattern = Pattern.compile("<[^>]*>");
        Matcher matcher = pattern.matcher(htmlText);
        final StringBuffer sb = new StringBuffer(htmlText.length());
        while (matcher.find()) {
            matcher.appendReplacement(sb, " ");
        }
        matcher.appendTail(sb);
        System.out.println(sb.toString().trim());
        return sb.toString().trim();
    }

    /**
     * ******************************************************************
     * @Function Name :clickbtnPrint
     * @Description : Method to print Mail.
     * @Input Parameter : ActionEvent -Provided by JavaFX.
     * @Output Parameter : NA.
     * @Author : Ram Krishna Paul.
     * @Created Date :28-APR-2017
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void clickbtnPrint(ActionEvent event) throws IOException {
        String from = "";
        String To = "";
        String Intendedto = "";
        String CC = "";
        String IntendedCC = "";
        String BCC = "";
        String IntendedBCC = "";
        String Subject = "";
        String SIC = "";
        String Attachment = "";
        String precedence = "";
        String SceurityClassification = "";
        String SceurityCategory = "";
        String SceurityPolicy = "";
        String SceurityMark = "";
        String MailBody = "";
        String Time = "";
        PrintDTO prntDto = new PrintDTO();
        // select value from table
        Object row_item = mail_header.getSelectionModel().getSelectedItem();
        Object rev = mail_header_review.getSelectionModel().getSelectedItem();
        Object appro = mail_header_approve.getSelectionModel().getSelectedItem();
        Object office = mail_header_office.getSelectionModel().getSelectedItem();
        Object sent = mail_table.getSelectionModel().getSelectedItem();
        Object outbox = mail_table_out_box.getSelectionModel().getSelectedItem();
        Object draft = mail_table_draft_table.getSelectionModel().getSelectedItem();

        List<InBoxTabList> printMail_INBOX = null;
        List<RiviewTabList> printMail_REVIEW = null;
        List<ApproveTabList> printMail_APPROVE = null;
        List<OfficeTabList> printMail_OFFICE = null;
        List<SentMailList> printMail_SENT = null;
        List<OutTabList> printMail_OUTBOX = null;
        List<DraftTabList> printMail_DRAFT = null;

        if (draft == null && row_item == null && rev == null && appro == null && office == null && sent == null && outbox == null) {
            if (messageHandler.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_warningFlag = messageHandler.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_warningFlag.equalsIgnoreCase("true")) {
                    FXMLDocumentController.ALERT_AUDIOCLIP2.play();
                }
            }

            Platform.runLater(() -> {
                Notifications.create().text("Warning - Print Mail" + "\nPlease Select a MAIL for Printing ! ").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Print Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select a MAIL for Printing ! ");
            alert.showAndWait();
            return;
        }
        if (row_item != null) {
            System.out.println("ROW ITEM is not null" + row_item.toString());
        } else {
            System.out.println("ROW ITEM is null");
        }
        if (rev != null) {
            System.out.println("revis not null" + rev.toString());
        } else {
            System.out.println("rev is null");
        }
        if (appro != null) {
            System.out.println("ROW ITEM is not null" + row_item.toString());
        } else {
            System.out.println("ROW ITEM is null");
        }
        if (office != null) {
            System.out.println("ROW ITEM is not null" + row_item.toString());
        } else {
            System.out.println("ROW ITEM is null");
        }

        if (sent != null) {
            System.out.println("SENT is not null" + sent.toString());
        } else {
            System.out.println("SENT is null");
        }
        if (row_item != null) {
            ObservableList<InBoxTabList> header_item, all_items;
            mail_id = mail_header.getSelectionModel().getSelectedItem().getMail_id();
            //  Mail data = new Mail();
            MailDTO outputDTO;

            int c = Integer.parseInt(mail_id);

            try {

                ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
                inputDTO.setMsgUID(c);
                inputDTO.setFolder("inbox");
                outputDTO = messageHandler.readSpecificeMail(inputDTO);
                HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
//                data = msghndlr.receiveOneMail(mail1);

                System.out.println(outputDTO.getFrom());
                System.out.println(outputDTO.getSubject());
                System.out.println(headers.get("Date"));
                System.out.println("------------------------");
                from = outputDTO.getFrom();
                To = (String) headers.get("To");
                Intendedto = outputDTO.getToRecipient();
                CC = (String) headers.get("ccOffice");
                IntendedCC = outputDTO.getCcRecipient();
                BCC = (String) headers.get("bccOffice");
                IntendedBCC = outputDTO.getBccRecipient();
                Subject = outputDTO.getSubject();
                SIC = (String) headers.get("sic");
                Attachment = (String) headers.get("fileName");
                precedence = (String) headers.get("precedence");
                SceurityClassification = (String) headers.get("security_level");
                SceurityCategory = (String) headers.get("security_category");
                SceurityPolicy = (String) headers.get("security_policy");
                SceurityMark = (String) headers.get("security_privacy_mark");
                String htmlText1 = outputDTO.getContent();
                tempStr1 = stripHTMLTags1(htmlText1);
                MailBody = tempStr1;
                Time = (String) headers.get("Date");
            } catch (Exception e) {
                System.out.println(e.getStackTrace());

            }

        } else if (rev != null) {
            ObservableList<InBoxTabList> header_item, all_items;
            mail_id = mail_header_review.getSelectionModel().getSelectedItem().getMail_id();
            //  Mail data = new Mail();
            MailDTO outputDTO;

            int c = Integer.parseInt(mail_id);

            try {

                ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
                inputDTO.setMsgUID(c);
                inputDTO.setFolder("inbox");
                outputDTO = messageHandler.readSpecificeMail(inputDTO);
                HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
//                data = msghndlr.receiveOneMail(mail1);

                System.out.println(outputDTO.getFrom());
                System.out.println(outputDTO.getSubject());
                System.out.println(headers.get("Date"));
                System.out.println("------------------------");
                from = outputDTO.getFrom();
                To = (String) headers.get("To");
                Intendedto = outputDTO.getToRecipient();
                CC = (String) headers.get("ccOffice");
                IntendedCC = outputDTO.getCcRecipient();
                BCC = (String) headers.get("bccOffice");
                IntendedBCC = outputDTO.getBccRecipient();
                Subject = outputDTO.getSubject();
                SIC = (String) headers.get("sic");
                Attachment = (String) headers.get("fileName");
                precedence = (String) headers.get("precedence");
                SceurityClassification = (String) headers.get("security_level");
                SceurityCategory = (String) headers.get("security_category");
                SceurityPolicy = (String) headers.get("security_policy");
                SceurityMark = (String) headers.get("security_privacy_mark");
                String htmlText1 = outputDTO.getContent();
                tempStr1 = stripHTMLTags1(htmlText1);
                MailBody = tempStr1;
                Time = (String) headers.get("Date");
            } catch (Exception e) {
                System.out.println(e.getStackTrace());

            }

        } else if (rev != null) {
            ObservableList<InBoxTabList> header_item, all_items;
            mail_id = mail_header_approve.getSelectionModel().getSelectedItem().getMail_id();
            //  Mail data = new Mail();
            MailDTO outputDTO;

            int c = Integer.parseInt(mail_id);

            try {

                ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
                inputDTO.setMsgUID(c);
                inputDTO.setFolder("inbox");
                outputDTO = messageHandler.readSpecificeMail(inputDTO);
                HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
                from = outputDTO.getFrom();
                To = (String) headers.get("To");
                Intendedto = outputDTO.getToRecipient();
                CC = (String) headers.get("ccOffice");
                IntendedCC = outputDTO.getCcRecipient();
                BCC = (String) headers.get("bccOffice");
                IntendedBCC = outputDTO.getBccRecipient();
                Subject = outputDTO.getSubject();
                SIC = (String) headers.get("sic");
                Attachment = (String) headers.get("fileName");
                precedence = (String) headers.get("precedence");
                SceurityClassification = (String) headers.get("security_level");
                SceurityCategory = (String) headers.get("security_category");
                SceurityPolicy = (String) headers.get("security_policy");
                SceurityMark = (String) headers.get("security_privacy_mark");
                String htmlText1 = outputDTO.getContent();
                tempStr1 = stripHTMLTags1(htmlText1);
                MailBody = tempStr1;
                Time = (String) headers.get("Date");
            } catch (Exception e) {
                System.out.println(e.getStackTrace());

            }

        } else if (rev != null) {
            ObservableList<InBoxTabList> header_item, all_items;
            mail_id = mail_header_office.getSelectionModel().getSelectedItem().getMail_id();
            MailDTO outputDTO;
            int c = Integer.parseInt(mail_id);

            try {
                ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
                inputDTO.setMsgUID(c);
                inputDTO.setFolder("inbox");
                outputDTO = messageHandler.readSpecificeMail(inputDTO);
                HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
                from = outputDTO.getFrom();
                To = (String) headers.get("To");
                Intendedto = outputDTO.getToRecipient();
                CC = (String) headers.get("ccOffice");
                IntendedCC = outputDTO.getCcRecipient();
                BCC = (String) headers.get("bccOffice");
                IntendedBCC = outputDTO.getBccRecipient();
                Subject = outputDTO.getSubject();
                SIC = (String) headers.get("sic");
                Attachment = (String) headers.get("fileName");
                precedence = (String) headers.get("precedence");
                SceurityClassification = (String) headers.get("security_level");
                SceurityCategory = (String) headers.get("security_category");
                SceurityPolicy = (String) headers.get("security_policy");
                SceurityMark = (String) headers.get("security_privacy_mark");
                String htmlText1 = outputDTO.getContent();
                tempStr1 = stripHTMLTags1(htmlText1);
                MailBody = tempStr1;
                Time = (String) headers.get("Date");
            } catch (Exception e) {
                System.out.println(e.getStackTrace());

            }

        } else if (rev != null) {
            ObservableList<InBoxTabList> header_item, all_items;
            mail_id = mail_table.getSelectionModel().getSelectedItem().getMail_id();
            MailDTO outputDTO;

            int c = Integer.parseInt(mail_id);

            try {
                ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
                inputDTO.setMsgUID(c);
                inputDTO.setFolder("inbox");
                outputDTO = messageHandler.readSpecificeMail(inputDTO);
                HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
                from = outputDTO.getFrom();
                To = (String) headers.get("To");
                Intendedto = outputDTO.getToRecipient();
                CC = (String) headers.get("ccOffice");
                IntendedCC = outputDTO.getCcRecipient();
                BCC = (String) headers.get("bccOffice");
                IntendedBCC = outputDTO.getBccRecipient();
                Subject = outputDTO.getSubject();
                SIC = (String) headers.get("sic");
                Attachment = (String) headers.get("fileName");
                precedence = (String) headers.get("precedence");
                SceurityClassification = (String) headers.get("security_level");
                SceurityCategory = (String) headers.get("security_category");
                SceurityPolicy = (String) headers.get("security_policy");
                SceurityMark = (String) headers.get("security_privacy_mark");
                String htmlText1 = outputDTO.getContent();
                tempStr1 = stripHTMLTags1(htmlText1);
                MailBody = tempStr1;
                Time = (String) headers.get("Date");
            } catch (Exception e) {
                System.out.println(e.getStackTrace());

            }

        } else if (rev != null) {
            ObservableList<InBoxTabList> header_item, all_items;
            mail_id = mail_table_out_box.getSelectionModel().getSelectedItem().getMail_id();
            //  Mail data = new Mail();
            MailDTO outputDTO;

            int c = Integer.parseInt(mail_id);

            try {

                ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
                inputDTO.setMsgUID(c);
                inputDTO.setFolder("inbox");
                outputDTO = messageHandler.readSpecificeMail(inputDTO);
                HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
                from = outputDTO.getFrom();
                To = (String) headers.get("To");
                Intendedto = outputDTO.getToRecipient();
                CC = (String) headers.get("ccOffice");
                IntendedCC = outputDTO.getCcRecipient();
                BCC = (String) headers.get("bccOffice");
                IntendedBCC = outputDTO.getBccRecipient();
                Subject = outputDTO.getSubject();
                SIC = (String) headers.get("sic");
                Attachment = (String) headers.get("fileName");
                precedence = (String) headers.get("precedence");
                SceurityClassification = (String) headers.get("security_level");
                SceurityCategory = (String) headers.get("security_category");
                SceurityPolicy = (String) headers.get("security_policy");
                SceurityMark = (String) headers.get("security_privacy_mark");
                String htmlText1 = outputDTO.getContent();
                tempStr1 = stripHTMLTags1(htmlText1);
                MailBody = tempStr1;
                Time = (String) headers.get("Date");
            } catch (Exception e) {
                System.out.println(e.getStackTrace());

            }

        } else if (rev != null) {
            ObservableList<InBoxTabList> header_item, all_items;
            mail_id = mail_table_draft_table.getSelectionModel().getSelectedItem().getMail_id();
            //  Mail data = new Mail();
            MailDTO outputDTO;

            int c = Integer.parseInt(mail_id);

            try {

                ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
                inputDTO.setMsgUID(c);
                inputDTO.setFolder("inbox");
                outputDTO = messageHandler.readSpecificeMail(inputDTO);
                HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
                from = outputDTO.getFrom();
                To = (String) headers.get("To");
                Intendedto = outputDTO.getToRecipient();
                CC = (String) headers.get("ccOffice");
                IntendedCC = outputDTO.getCcRecipient();
                BCC = (String) headers.get("bccOffice");
                IntendedBCC = outputDTO.getBccRecipient();
                Subject = outputDTO.getSubject();
                SIC = (String) headers.get("sic");
                Attachment = (String) headers.get("fileName");
                precedence = (String) headers.get("precedence");
                SceurityClassification = (String) headers.get("security_level");
                SceurityCategory = (String) headers.get("security_category");
                SceurityPolicy = (String) headers.get("security_policy");
                SceurityMark = (String) headers.get("security_privacy_mark");
                String htmlText1 = outputDTO.getContent();
                tempStr1 = stripHTMLTags1(htmlText1);
                MailBody = tempStr1;
                Time = (String) headers.get("Date");
            } catch (Exception e) {
                System.out.println(e.getStackTrace());

            }

        }
        GeneratePDF generatePDF = new GeneratePDF();
        String path1 = path + System.currentTimeMillis() + ".pdf";
        int msgUid = Integer.parseInt(mail_id);
        System.out.println("UID: " + msgUid);
        prntDto.setFolder("INBOX");
        prntDto.setMsgUID(msgUid);
        String waterCount = messageHandler.updatePrintStatus(prntDto);

        GeneratePDF.createPDF(waterCount, from, To, Intendedto, CC, IntendedCC, BCC, IntendedBCC, Subject, SIC, Attachment, precedence, SceurityClassification, MailBody, Time, SceurityCategory, SceurityPolicy, SceurityMark, path1);
        if (messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm() != null) {
            m_successAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm();
            if (m_successAlarmFlag.equalsIgnoreCase("true")) {
              
            }
        }
//          FXMLDocumentController.ALERT_AUDIOCLIP1.play();
//        Platform.runLater(() -> {
//            Notifications.create().text("Information - Print Mail" + "\nMail Print Generated successfully,Opening the printed mail ").showInformation();
//        });
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.initStyle(StageStyle.UTILITY);
        alert.setTitle("Information-Print mail");
        alert.setHeaderText(null);
        alert.setContentText("Mail Print Generated successfully,Opening the printed mail");
        alert.show();
        File pdfFile = new File(path1);
        if (pdfFile.exists()) {
            if (Desktop.isDesktopSupported()) {
                try {
                    Desktop.getDesktop().open(pdfFile);
                } catch (IOException e) {

                    e.printStackTrace();
                }
            } else {
                if (messageHandler.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                    m_infoAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getInfoAlarm();
                    if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                        FXMLDocumentController.ALERT_AUDIOCLIP5.play();
                    }
                }
                Platform.runLater(() -> {
                    Notifications.create().text("Error" + "\nFile not supported please install pdf viewer!!").showError();
                });
                alert = new Alert(Alert.AlertType.ERROR);
                alert.initStyle(StageStyle.UTILITY);
                alert.setTitle("Error-Print Mail");
                alert.setHeaderText(null);
                alert.setContentText("File not supported please install pdf viewer!!");
                alert.showAndWait();
            }
        } else {
            if (messageHandler.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_infoAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                    FXMLDocumentController.ALERT_AUDIOCLIP5.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Error" + "\nFile is not exists!!").showError();
            });
            alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Error-Print Mail");
            alert.setHeaderText(null);
            alert.setContentText("File is not exists!!");
            alert.showAndWait();
        }
//        refresh();
    }
    @FXML
    private Button m_btnalrams;

    public void clickbtnAlrams(ActionEvent event) throws Exception {
        Stage stageAlarm = new Stage();
        Parent root1;

        if (event.getSource() == m_btnalrams) {
            root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/AlaramSetting.fxml"));
            stageAlarm.setScene(new Scene(root1));
            stageAlarm.setTitle("Alarm Setting");
            stageAlarm.initModality(Modality.APPLICATION_MODAL);
            stageAlarm.initOwner(m_btnalrams.getScene().getWindow());
            stageAlarm.toFront();
            stageAlarm.resizableProperty().setValue(Boolean.FALSE);
            stageAlarm.showAndWait();

        }
    }
    @FXML
    private Button m_preMessage;

    public void clickbtnpreMsg(ActionEvent event) throws Exception {
        Stage m_preformattedmsg = new Stage();
        Parent root1;

        if (event.getSource() == m_preMessage) {
            root1 = FXMLLoader.load(getClass().getResource("/com/bel/mailApplication/scene/PreformattedMessage.fxml"));
            m_preformattedmsg.setScene(new Scene(root1));
            m_preformattedmsg.setTitle("PreFormatted Message");
            m_preformattedmsg.initModality(Modality.APPLICATION_MODAL);
            m_preformattedmsg.initOwner(m_preMessage.getScene().getWindow());
            m_preformattedmsg.toFront();
            m_preformattedmsg.resizableProperty().setValue(Boolean.FALSE);
            m_preformattedmsg.showAndWait();

        }
    }

//     pagination
    public int rowsPerPage() {
        return 15;
    }

    public int numberOfPages(int datasize) {
        int numOfPages = 1;
        if (datasize == 0) {
            numOfPages = 1;
        } else if (datasize % rowsPerPage() == 0) {
            numOfPages = datasize / rowsPerPage();
        } else if (datasize > rowsPerPage()) {
            numOfPages = datasize / rowsPerPage() + 1;
        }
//        System.out.println("numOfPages is:" + numOfPages + " and data size is: " + datasize);
        return numOfPages;
    }
// for sent mail
    
    
//    public void paginationandProgressSent() {
//        paginationSentmail.setPageFactory(new Callback<Integer, Node>() {
//            public Node call(final Integer pageIndex) {
//                m_progressIndicatorSentMail.setVisible(true);
//                mail_table_list.clear();
//                // long running background task
//                new Thread() {
//                    public void run() {
//                        try {
//                            int fromIndex = pageIndex * rowsPerPage();
//                            int toIndex = Math.min(fromIndex + rowsPerPage(), numberOfPages(3));
//                            List<SentMailList> loadedList = loadData(fromIndex, toIndex);
//                            Platform.runLater(() -> dataList.setAll(loadedList));
//                        } finally {
//                            Platform.runLater(() -> m_progressIndicatorSentMail.setVisible(false));
//                        }
//                    }
//                }.start();
//
//                return tablePane;
//            }
//        });
//    }
    
    private Node createContactsPage(int pageIndex) {
        int fromIndex = pageIndex * rowsPerPage();
        int toIndex = Math.min(fromIndex + rowsPerPage(), mail_table_list.size());
        mail_table.setItems(FXCollections.observableArrayList(mail_table_list.subList(fromIndex, toIndex)));
        mail_table.setId("mail_table");
        GridPane gp = new GridPane();
        gp.add(mail_table, 0, 0);
        return gp;

    }

// for Draft mail
    private Node createContactsPageDraft(int pageIndex) {
        int fromIndex = pageIndex * rowsPerPage();
        int toIndex = Math.min(fromIndex + rowsPerPage(), draft_table_list.size());
        mail_table_draft_table.setItems(FXCollections.observableArrayList(draft_table_list.subList(fromIndex, toIndex)));
        mail_table_draft_table.setId("mail_table_draft_table");
        GridPane gp = new GridPane();
        gp.add(mail_table_draft_table, 0, 0);
        return gp;

    }
    //for trash mail

    private Node createContactsPageTrash(int pageIndex) {
        int fromIndex = pageIndex * rowsPerPage();
        int toIndex = Math.min(fromIndex + rowsPerPage(), trash_table_list.size());
        mail_table_trash_box.setItems(FXCollections.observableArrayList(trash_table_list.subList(fromIndex, toIndex)));
        mail_table_trash_box.setId("mail_table_trash_box");
        GridPane gp = new GridPane();
        gp.add(mail_table_trash_box, 0, 0);
        return gp;

    }
    //for outbox

    private Node createContactsPageOutBox(int pageIndex) {
      //  progressIndicator.setVisible(true);
        int fromIndex = pageIndex * rowsPerPage();
        int toIndex = Math.min(fromIndex + rowsPerPage(), outbox_table_list.size());
        mail_table_out_box.setItems(FXCollections.observableArrayList(outbox_table_list.subList(fromIndex, toIndex)));
        mail_table_out_box.setId("mail_table_out_box");
        GridPane gp = new GridPane();
        gp.add(mail_table_out_box, 0, 0);
        return gp;

    }
    //for inbox

    private Node createContactsPageInbox(int pageIndex) {
        int fromIndex = pageIndex * rowsPerPage();
        int toIndex = Math.min(fromIndex + rowsPerPage(), table_list.size());
        mail_header.setItems(FXCollections.observableArrayList(table_list.subList(fromIndex, toIndex)));
        mail_header.setId("mail_header");
        GridPane gp = new GridPane();
        gp.add(mail_header, 0, 0);

        return gp;

    }
    //for review

    private Node createContactsPageReview(int pageIndex) {
        int fromIndex = pageIndex * rowsPerPage();
        int toIndex = Math.min(fromIndex + rowsPerPage(), riview_table_list.size());
        mail_header_review.setItems(FXCollections.observableArrayList(riview_table_list.subList(fromIndex, toIndex)));
        mail_header_review.setId("mail_header_review");
        GridPane gp = new GridPane();
        gp.add(mail_header_review, 0, 0);
        return gp;

    }

    //for approve
    private Node createContactsPageApprove(int pageIndex) {
        int fromIndex = pageIndex * rowsPerPage();
        int toIndex = Math.min(fromIndex + rowsPerPage(), approve_table_list.size());
        mail_header_approve.setItems(FXCollections.observableArrayList(approve_table_list.subList(fromIndex, toIndex)));
        mail_header_approve.setId("mail_header_approve");
        GridPane gp = new GridPane();
        gp.add(mail_header_approve, 0, 0);
        return gp;

    }

    //for office 
    private Node createContactsPageOffice(int pageIndex) {
        int fromIndex = pageIndex * rowsPerPage();
        int toIndex = Math.min(fromIndex + rowsPerPage(), office_table_list.size());
        mail_header_office.setItems(FXCollections.observableArrayList(office_table_list.subList(fromIndex, toIndex)));
        mail_header_office.setId("mail_header_office");
        GridPane gp = new GridPane();
        gp.add(mail_header_office, 0, 0);
        return gp;

    }

}
