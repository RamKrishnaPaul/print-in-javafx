package com.bel.mailApplication;

import static com.bel.mailApplication.controller.LoginFXMLController.mainStage;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 * ******************************************************************
 * @File Name           : MailApplication.
 * @Author              : Ram Krishna Paul.
 * @Package             : com.bel.mailApplication
 * @Purpose             : Display Login Page.
 * @Created Date	:14-FEB-2017
 * @Modification History:NA.
 * ******************************************************************
 */
public class MailApplication extends Application {
 /**
     * ******************************************************************
     * @Function Name           :start
     * @Description             : Method to start application.
     * @Input Parameter         : Stage -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ram Krishna Paul.
     * @Created Date            :14-FEB-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void start(Stage stage) throws Exception {

        Screen screen = Screen.getPrimary();
        Rectangle2D bounds = screen.getVisualBounds();
        Parent root = FXMLLoader.load(getClass().getResource("scene/LoginFXML.fxml"));
        Scene scene = new Scene(root);
        scene.getStylesheets().add(this.getClass().getResource("/css/style.css").toExternalForm());
        stage.setTitle("Mail Application");
        stage.setX(bounds.getMinX());
        stage.setX(bounds.getMinY());
        stage.setWidth(bounds.getWidth());
        stage.setHeight(bounds.getHeight());
        stage.setScene(scene);
        stage.show();

        stage.getIcons().add(new Image("/img/Mail-icon.png"));
        stage.setResizable(true);

    }

    public static void main(String[] args) {

        launch(args);

    }

}
