/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.controller;

import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * @File Name : SecurityController
 * @author : Vimal Marupatla
 * @Description: For Security of mail
 * @Package : com.bel.mailApplication.controller
 * @Created : July 2017
 * @Modification History: NA
 */
public class SecurityController implements Initializable {

    @FXML
    public TextField txtPin;
    @FXML
    private JFXButton btnSecuritySubmit;
    @FXML
    private JFXButton btnSecurityCancel;
    public boolean sendSecurityFlag = false;

    /**
     * ******************************************************************
     * @Function Name : initialize
     * @Description :
     * @Input Parameter :
     * @Output Parameter : NA
     * @Author : Vimal Marupatla.
     * @Created Date : July 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    /**
     * ******************************************************************
     * @Function Name : on_click_btnSecuritySubmit
     * @Description :
     * @Input Parameter :
     * @Output Parameter : NA
     * @Author : Vimal Marupatla.
     * @Created Date : July 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    private void on_click_btnSecuritySubmit(ActionEvent event) {
        String m_textpin = txtPin.getText();
        if (true) {
            sendSecurityFlag = true;
        } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Send Mail - Security");
                    alert.setHeaderText(null);
                    alert.setContentText("Invalid Pin");
                    alert.showAndWait();
                }

        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
    }
    /**
     * ******************************************************************
     * @Function Name : on_click_btnSecurityCancel
     * @Description :
     * @Input Parameter :
     * @Output Parameter : NA
     * @Author : Vimal Marupatla.
     * @Created Date : July 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    private void on_click_btnSecurityCancel(ActionEvent event) {
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
    }
}
