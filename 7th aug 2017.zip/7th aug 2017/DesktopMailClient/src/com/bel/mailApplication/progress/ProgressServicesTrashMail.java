package com.bel.mailApplication.progress;

import com.bel.mailApplication.model.TrashTabList;
import javafx.collections.ObservableList;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
/**
 * @File Name : ProgressServicesTrashMail
 * @author : Ram Krishna Paul
 * @Description: For creating task of Trash mail
 * @Package : com.bel.mailApplication.progress
 * @Created : 17th june 2017
 * @Modification History: NA
 */
public class ProgressServicesTrashMail extends Service<ObservableList<TrashTabList>> {

    @Override
    protected Task createTask() {
        return new GetProgrssTaskTrashMail();
    }
}
