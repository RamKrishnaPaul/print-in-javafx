package com.bel.mailApplication.progress;

import static com.bel.mailApplication.controller.FXMLDocumentController.outbox_table_list;
import com.bel.mailApplication.model.OutTabList;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;

/**
 * @File Name : GetProgrssTaskOutBoxMail
 * @author : Ram Krishna Paul
 * @Description: For Getting progresTask in outbox mail
 * @Package : com.bel.mailApplication.progress
 * @Created : 17th june 2017
 * @Modification History: NA
 */
public class GetProgrssTaskOutBoxMail extends Task<ObservableList<OutTabList>> {

    @Override
    protected ObservableList<OutTabList> call() throws Exception {
//        for (int i = 0; i < 100; i++) {
        updateProgress(0, 0);
        Thread.sleep(14);
//        }
        return outbox_table_list;

    }
}
