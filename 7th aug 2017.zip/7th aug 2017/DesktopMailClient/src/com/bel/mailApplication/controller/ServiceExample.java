package com.bel.mailApplication.controller;

import java.util.LinkedList;
import java.util.List;
import javafx.concurrent.Service;
import javafx.concurrent.Task;


/**
 * ******************************************************************
 * @File Name           : ServiceExample.
 * @Author              : Ram Krishna Paul.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display progress indicator in In Box.
 * @Created Date	:19-MAY-2017
 * @Modification History:NA. 
*******************************************************************
 */
public class ServiceExample extends Service<String> {
@Override
protected Task<String> createTask() {
    final List<String> loadedItems = new LinkedList<>();
    return new Task<String>() {
        @Override
        protected String call() throws Exception {
            //DO YOU HARD STUFF HERE
            String res = "HELLO";
            Thread.sleep(3000);
             while (loadedItems.size() <10) {
                    loadedItems.add("Item " + loadedItems.size());
                }
             return res;
        }
    };
}
}
