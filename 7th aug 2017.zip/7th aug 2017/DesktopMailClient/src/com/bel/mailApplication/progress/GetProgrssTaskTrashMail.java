package com.bel.mailApplication.progress;

import static com.bel.mailApplication.controller.FXMLDocumentController.trash_table_list;
import com.bel.mailApplication.model.TrashTabList;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
/**
 * @File Name : GetProgrssTaskTrashMail
 * @author : Ram Krishna Paul
 * @Description: For Getting progresTask in trash mail
 * @Package : com.bel.mailApplication.progress
 * @Created : 17th june 2017
 * @Modification History: NA
 */
public class GetProgrssTaskTrashMail extends Task<ObservableList<TrashTabList>> {

    @Override
    protected ObservableList<TrashTabList> call() throws Exception {
//        for (int i = 0; i < 100; i++) {
            updateProgress(0, 0);
            Thread.sleep(14);
//        }
        return trash_table_list;

    }
}
