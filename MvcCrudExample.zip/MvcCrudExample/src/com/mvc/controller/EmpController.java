package com.mvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.mvc.beans.Emp;
import com.mvc.dao.EmpDao;

@Controller
public class EmpController {

	@Autowired  
    EmpDao dao;
	
@RequestMapping("/")
public String hello(){
	
	return "index";
}

@RequestMapping("/empform")
public ModelAndView showform(){
	System.out.println("inside showform");
	 return new ModelAndView("empform","command",new Emp());
	
}


@RequestMapping(value="/save",method = RequestMethod.POST)  
public ModelAndView save(@ModelAttribute("emp") Emp emp){  
	System.out.println(emp.getDesignation());
	System.out.println(emp.getSalary());
    dao.save(emp);  
    return new ModelAndView("redirect:/viewemp");//will redirect to viewemp request mapping  
}

@RequestMapping(value="/viewemp")
public ModelAndView view(){
	List<Emp> list = dao.getEmployees();
	return new ModelAndView("viewemp","list",list);
}

@RequestMapping(value="/editemp/{id}")
public ModelAndView update(@PathVariable int id){
	Emp emp =dao.getEmpById(id);
	return new ModelAndView("empeditform","command",emp);
}

@RequestMapping(value="/deleteemp/{id}")
public ModelAndView delete(@PathVariable int id){
	dao.delete(id);  
    return new ModelAndView("redirect:/viewemp"); 
}

@RequestMapping(value="/editsave",method = RequestMethod.POST)  
public ModelAndView editsave(@ModelAttribute("emp") Emp emp){  
    dao.update(emp);  
    return new ModelAndView("redirect:/viewemp");  
}  

}
