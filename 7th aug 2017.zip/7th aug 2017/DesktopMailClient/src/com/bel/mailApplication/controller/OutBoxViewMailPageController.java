/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.controller;

import static com.bel.mailApplication.controller.FXMLDocumentController.mail_id;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import com.entity.MailDTO;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.web.HTMLEditor;
import mail.awan.beans.GroupMailInfo;
import mail.awan.beans.ReceiveMailInputDTO;
import mail.awan.messageHandler.MessageHandler;

/**
 * FXML Controller class
 *
 * @author Root
 */
public class OutBoxViewMailPageController implements Initializable {

    @FXML
    private Label headinglabl;
    @FXML
    private Label send_label;
    @FXML
    private JFXButton btnBCC;
    @FXML
    private Label lblBCC;
    @FXML
    private Label from_name;
    @FXML
    private JFXButton Compose_to_btn;
    @FXML
    private Label to_mail;
    @FXML
    private JFXButton IntendeTo;
    @FXML
    private Label lblIntendeTo;
    @FXML
    private Tooltip m_tooltipIntendedTo;
    @FXML
    private JFXButton btncc;
    @FXML
    private Label lblcc;
    @FXML
    private JFXButton btnintendedcc;
    @FXML
    private Label lblintendedcc;
    @FXML
    private Tooltip m_tooltipIntendedCC;
    @FXML
    private JFXButton btnintendedBCC;
    @FXML
    private Label lblintendedBCC;
    @FXML
    private Tooltip m_tooltipIntendedBCC;
    @FXML
    private TextField sub_textfield;
    @FXML
    private HTMLEditor html_editor;
    @FXML
    private ScrollPane m_id;
    @FXML
    private ComboBox<?> Combobox_policy;
    @FXML
    private ComboBox<?> Combobox_classification;
    @FXML
    private TextField txtPrivacy;
    @FXML
    private ComboBox<?> Combobox_category;
    @FXML
    private JFXCheckBox chk_bx_read_reqst;
    @FXML
    private JFXCheckBox chk_bx_single_reqst;
    @FXML
    private JFXCheckBox chk_bx_encryption;
    @FXML
    private JFXButton btn_modify;
    @FXML
    private Button cancel_mail;
    @FXML
    private TextArea txtMsgInstruction;
    @FXML
    private ComboBox<?> combBoxMsgType;
    @FXML
    private ComboBox<?> Combobox_precednce;
    @FXML
    private ComboBox<?> txtSIC;
    @FXML
    private Label change_lable;

    String precedence;
    String security_level;
    String From;
    String OriginalSender;
    String Read_Receipt;
    String attach_file;
    MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
     String groupMailIdTo="" ;
    String GroupMailIdCc="" ;
    String GroupMailIdBcc="" ;
    @FXML
    private GridPane m_attachLabel;
         int i = 0;
        int j=0;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       txtMsgInstruction.setEditable(false);
       
        sub_textfield.setEditable(false);
        btnBCC.setDisable(true);

        Compose_to_btn.setDisable(true);

        IntendeTo.setDisable(true);

        btncc.setDisable(true);

        txtPrivacy.setEditable(false);
        btnintendedcc.setDisable(true);

        btnintendedBCC.setDisable(true);

        chk_bx_read_reqst.setDisable(true);
        chk_bx_single_reqst.setDisable(true);
        txtSIC.setEditable(false);
        chk_bx_encryption.setDisable(true);
        txtPrivacy.setEditable(false);

        
        html_editor.setDisable(true);
        
        MailDTO outputDTO;
        try {
            double c = Double.parseDouble(mail_id);

            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID((int)c);
            inputDTO.setFolder("inbox");

            outputDTO = msghndlr.readSpecificeMail(inputDTO);
             if(outputDTO.getHeaderMap().get("uid")!=null)
            System.out.println("UID: " + outputDTO.getHeaderMap().get("uid"));
     
            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();

            String fromOffice = (String) headers.get("fromOffice");
            
            
            System.out.println(fromOffice);
            String bccOfficeDU = (String) headers.get("bccOfficeDU");
            System.out.println(bccOfficeDU);
            String replyRequested = (String) headers.get("replyRequested");
            String split[];
            if (headers.get("attachedFileName") != null) {
                attach_file = (String) headers.get("attachedFileName");
                        String Split[]=attach_file.split(",");
             while(i<Split.length){
            for(j=0;j<Split.length;j++){
            Label labl=new Label();
           
             labl.setText(Split[j]+" ");   
          //   labl.setContextMenu(menu);
              m_attachLabel.add(labl,i,0);
        
          i++;
           labl.setOnMouseEntered(new EventHandler<MouseEvent>() {
          @Override
          public void handle(MouseEvent e) {
            labl.setStyle("-fx-font-weight:BOLD;-fx-text-fill:White;-fx-background-color:blue;-fx-font-size:13");

          }
        });   
        
        labl.setOnMouseExited(new EventHandler<MouseEvent>() {
          @Override
          public void handle(MouseEvent e) {
              labl.setStyle("-fx-background-color:#F4F4F4;");

          }
        });
//        labl.setOnMousePressed((e) -> {
//
//                            System.out.println("Attach FIle Name download:" + labl.getText());
//                            file_download(labl.getText().trim());
//
//                        });
           }
     }
            }
            
            System.out.println(replyRequested);
            String sic = (String) headers.get("sic");
            precedence = (String) headers.get("precedence");
            OriginalSender = (String) headers.get("OriginalSender");

            String OriginalBcc = (String) headers.get("originalBcc");
            String receiverOfficeDesignatedUser = (String) headers.get("receiverOfficeDesignatedUser");
            String encryption = (String) headers.get("encryption");

            String signed_receipt_receiptfrom = (String) headers.get("signed_receipt_receiptfrom");
            String ccOfficeDU = (String) headers.get("ccOfficeDU");
            String security_category = (String) headers.get("security_category");

            String Approver = (String) headers.get("Approver");
            String To = (String) headers.get("toOffice");
            String DSN = (String) headers.get("DSN");

            String ContentType = (String) headers.get("Content-Type");
            String DSNTo = (String) headers.get("DSNTo");
            String ReturnPath = (String) headers.get("Return-Path");

            String XOriginalTo = (String) headers.get("X-Original-To");
            String OriginalReceiver = (String) headers.get("originalReceiver");
            String security_policy = (String) headers.get("security_policy");

            String Received = (String) headers.get("Received");
            From = (String) headers.get("From");
            String MsgType = (String) headers.get("msgType");
            String messageType = (String) headers.get("messageType");
            String msgInstruction = (String) headers.get("messageInstructions");
            String Reviewer = (String) headers.get("Reviewer");
            String Date = (String) headers.get("Date");

            String Subject = (String) headers.get("Subject");
            String MIME_Version = (String) headers.get("MIME-Version");
            security_level = (String) headers.get("security_level");

            String signed_receipt = (String) headers.get("signed_receipt");
            String mailMsgType = (String) headers.get("mailMsgType");
            Read_Receipt = (String) headers.get("read_receipt");

            String security_privacy_mark = (String) headers.get("security_privacy_mark");
            System.out.println("Privacy mark" + security_privacy_mark);
            String OriginalCc = (String) headers.get("originalCc");
            String DeliveredTo = (String) headers.get("Delivered-To");
            String signed_receipt_receiptto = (String) headers.get("signed_receipt_receiptto");
            groupMailIdTo = (String) headers.get("groupMailIdTo");
            GroupMailIdCc = (String) headers.get("groupMailIdCc");
            GroupMailIdBcc = (String) headers.get("groupMailIdBcc");
            String ccOffice = (String) headers.get("ccOffice");
            String bccOffice = (String) headers.get("bccOffice");
 
            ObservableList<String> Policy_value = FXCollections.observableArrayList(security_policy);
            ObservableList<String> Category_value = FXCollections.observableArrayList(security_level);
            ObservableList<String> combobox_category = FXCollections.observableArrayList(security_category);
            ObservableList<String> combobox_precednc = FXCollections.observableArrayList(precedence);
            from_name.setText(outputDTO.getFrom());
            to_mail.setText(To);
            lblcc.setText(ccOffice);
            lblBCC.setText(bccOffice);
     
            System.out.println("REVIEWER OROGINAL Reciver" + OriginalReceiver);
            lblIntendeTo.setText(OriginalReceiver + " " + groupMailIdTo);
            lblintendedcc.setText(OriginalCc + " " + GroupMailIdCc);
            lblintendedBCC.setText(OriginalBcc + " " + GroupMailIdBcc);
            if (groupMailIdTo.length() != 0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(groupMailIdTo);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedTo.setText(str.toString());
            }
            if (GroupMailIdCc.length() != 0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(GroupMailIdCc);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedCC.setText(str.toString());
            }
            if (GroupMailIdBcc.length() != 0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(GroupMailIdBcc);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedBCC.setText(str.toString());
            }
                       
            txtSIC.setPromptText(sic);

            sub_textfield.setText(outputDTO.getSubject());
            html_editor.setHtmlText(outputDTO.getContent());

            html_editor.setAccessibleText(outputDTO.getContent());
            Combobox_classification.setPromptText(security_level);
            txtPrivacy.setText(security_privacy_mark);
    
            Combobox_precednce.setPromptText(precedence);
            Combobox_category.setPromptText(security_category);
            Combobox_policy.setPromptText(security_policy);
            txtMsgInstruction.setText(msgInstruction);
            combBoxMsgType.setPromptText(messageType);
            System.out.println("Reviewer read reciept test:" + Read_Receipt);
            if (Read_Receipt.equalsIgnoreCase("true")) {
                System.out.println("Reviewer read reciept true");
                chk_bx_read_reqst.setSelected(true);
            }
            if (security_level.equalsIgnoreCase("TopSecret")) {
                change_lable.setText("TOP-SECRET");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: red;");
            } else if (security_level.equalsIgnoreCase("Secret")) {
                change_lable.setText("SECRET");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: orange;");
            } else if (security_level.equalsIgnoreCase("Confidential")) {
                System.out.println("Entered the confidential..........");
                change_lable.setText("CONFIDENTIAL");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: blue;");
            } else if (security_level.equalsIgnoreCase("Restricted")) {
                change_lable.setText("RESTRICTED");
                change_lable.setTextFill(Color.web("Black"));
                change_lable.setStyle("-fx-background-color: yellow;");
            } else if (security_level.equalsIgnoreCase("Unclassified")) {
                change_lable.setText("UNCLASSIFIED");
                change_lable.setTextFill(Color.web("black"));
                change_lable.setStyle("-fx-background-color: white;");
            }

        } catch (Exception e) {
            System.out.println("View mmail working");
        }
    }    

    @FXML
    private void onClickbtnBCC(ActionEvent event) {
    }

    @FXML
    private void compose_to(ActionEvent event) {
    }

    @FXML
    private void openIntendeTo(ActionEvent event) {
    }

    @FXML
    private void clickBtnCC(ActionEvent event) {
    }

    @FXML
    private void onClickIntendedCC(ActionEvent event) {
    }

    @FXML
    private void clickbtnintendedBCC(ActionEvent event) {
    }

    @FXML
    private void on_selection_classification(ActionEvent event) {
    }

    @FXML
    private void on_click_modify(ActionEvent event) {
    }

    @FXML
    private void on_click_cancel(ActionEvent event) {
        FXMLDocumentController.m_outboxStage.close();
    }

    @FXML
    private void onPrecedenceSelectaction(ActionEvent event) {
    }
    
}
