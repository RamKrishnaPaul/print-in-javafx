/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.services;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;

/**
 *
 * @author Admin
 */
public class TcsOfficeAttributesMapper {
    
public TcsOffice mapFromAttributes(Attributes attributes) throws NamingException {
		TcsOffice officeObject=new TcsOffice();

                
		String ou="";
		String DesignatedUser="";
		String AlternateDesignatedUser="";

		try{
			ou = (String)attributes.get("ou").get();
		}
		catch(Exception ex){
			ou = "";
		}

		try{
			DesignatedUser = (String)attributes.get("DesignatedUser").get();
		}
		catch(Exception ex){
			DesignatedUser = "";
		}
		try{
			AlternateDesignatedUser = (String)attributes.get("AlternateDesignatedUser").get();
		}
		catch(Exception ex){
			AlternateDesignatedUser = "";
		}

		officeObject.setOu(ou);
		officeObject.setDesignatedUser(DesignatedUser);
		officeObject.setAlternateDesignatedUser(AlternateDesignatedUser);

		return officeObject;
	}

}
