/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.controller;

import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import static com.bel.mailApplication.controller.Draft_view_mailController.classificationvaleforIntendedTo;
import static com.bel.mailApplication.controller.Draft_view_mailController.precedencevaleforIntendedTo;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;
import mail.awan.beans.CheckClearenceDTO;
import mail.awan.beans.MailSenderInfo;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.CheckListView;

/**
 * FXML Controller class
 *
 * @author Root
 */
public class IntendedToDraftController implements Initializable {

     @FXML
    private Button AddIntendedTo;
    @FXML
    private Button btnAddgroup;
    @FXML
    private ObservableList<String> data;
    @FXML
    private ObservableList<String> userNames;
    @FXML
    public CheckListView<String> listGroupMails;
    public List<String> m_selectedGroupMail = new ArrayList<String>();
    @FXML
    public ObservableList<String> datagroup;
    @FXML
    public CheckListView EmailIntendedTo;
    public List<String> selectedIntendedToOffice = new ArrayList<String>();
    public static List<String> dataGroupmails;
    public String GroupEmails;
    public static String ListOfGrupMails = "";
    GroupMailsController groupMailsController;
    MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);

    /**
     * ******************************************************************
     * @Function Name :initialize
     * @Description : Method to call initialization function.
     * @Input Parameter : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul.
     * @Created Date :11-MAY-2017.
     * @Modification History :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnAddgroup.setVisible(false);
//        EmailIntendedTo.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        data = FXCollections.observableArrayList();

        String officename = messageHandler.ldapUserOffice(sm_name);
        List<String> li = new ArrayList<String>();
        li = Draft_view_mailController.dataList();
        String[] obj = li.toArray(new String[0]);
        CheckClearenceDTO dto = new CheckClearenceDTO();
        dto.setOffice(obj);
        dto.setMaxSecurityClassificationView(classificationvaleforIntendedTo);
        dto.setAttachmentSize(0);
        dto.setMaxMessagePrecedence(precedencevaleforIntendedTo);
        List<String> list = messageHandler.checkClearence(dto);
        if(li.size()==0){}
        for (String OfficeUserNames : list) {

            data.addAll(OfficeUserNames);
            EmailIntendedTo.setItems(data);
            EmailIntendedTo.getCheckModel().getCheckedItems().addListener(new ListChangeListener<String>() {
                @Override
                public void onChanged(ListChangeListener.Change<? extends String> c) {
                    selectedIntendedToOffice = EmailIntendedTo.getCheckModel().getCheckedItems();
//                    System.out.println("selectedIntendedToOffice" + selectedIntendedToOffice);
                }
            });

        }
        groupmail();
    }
/**
     * ******************************************************************
     * @Function Name :groupmail
     * @Description : Method to iterate groupmail.
     * @Input Parameter :null
     * @Output Parameter	: group list.
     * @Author : Ram Krishna Paul.
     * @Created Date :14-JULY-2017.
     * @Modification History :NA.
     * ******************************************************************
     */
    public void groupmail() {
        MailSenderInfo obj = messageHandler.preCheck(sm_name);
        datagroup = FXCollections.observableArrayList();
        List<String> list = messageHandler.getAllMailGroupNames();

        for (String listofGroup : list) {
            System.out.println(datagroup);
            datagroup.addAll(listofGroup);
            listGroupMails.setItems(datagroup);
            listGroupMails.getCheckModel().getCheckedItems().addListener(new ListChangeListener<String>() {
                @Override
                public void onChanged(ListChangeListener.Change<? extends String> c) {
                    m_selectedGroupMail = listGroupMails.getCheckModel().getCheckedItems();
//                    System.out.println("selectedIntendedToOffice" + m_selectedGroupMail);
                }
            });
        }
    }

    /**
     * ******************************************************************
     * @Function Name :Add_AddIntendedTo
     * @Description : Method to add IntendedTo to list.
     * @Input Parameter : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul.
     * @Created Date :11-MAY-2017.
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void add_AddIntendedTo(ActionEvent event) throws IOException {
        String Emailselected;
        // alloffice = add_list.getItems();
        List<String> data = EmailIntendedTo.getSelectionModel().getSelectedItems();
        for (String email1 : data) {

        }
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();

    }

    /**
     * ******************************************************************
     * @Function Name :openbtnAddGroup
     * @Description : Method to Open Group Mail list.
     * @Input Parameter : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul.
     * @Created Date :11-MAY-2017.
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    public void openbtnAddGroup(ActionEvent event) throws IOException {
        Stage stageGroup = new Stage();
        Parent root1;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/GroupMails.fxml"));
        root1 = (Parent) fXMLLoader.load();
        groupMailsController = fXMLLoader.getController();
        stageGroup.setScene(new Scene(root1));
        stageGroup.setTitle("Groups");
        stageGroup.initModality(Modality.APPLICATION_MODAL);
        stageGroup.initOwner(btnAddgroup.getScene().getWindow());
        stageGroup.toFront();
        stageGroup.show();
        stageGroup.getIcons().add(new Image("/img/Mail-icon.png"));

//        dataGroupmails = groupMailsController.listGroupMails.getSelectionModel().getSelectedItems();
        dataGroupmails = groupMailsController.m_selectedGroupMail;
        GroupEmails = new String();

        for (String email : dataGroupmails) {
            GroupEmails += email + ";";
        }
        System.out.println("email1 is" + GroupEmails);
        try {
            ListOfGrupMails = GroupEmails.substring(0, GroupEmails.length() - 1);
        } catch (StringIndexOutOfBoundsException e) {

        }
        System.out.println("mail id list is" + ListOfGrupMails);
    }

    public GroupMailsController getGroupMailsController() {
        return this.groupMailsController;
    }

}
