/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.controller;

import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import mail.awan.beans.PreFormattedAttributes;
import mail.awan.messageHandler.MessageHandler;

/**
 * FXML Controller class
 *
 * @author Root
 */
public class PreformattedMessageController implements Initializable {

    @FXML
    private JFXComboBox<String> m_comboboxMessage;
    @FXML
    private JFXButton m_composepreMessage;
     public ObservableList<String> m_templates = FXCollections.observableArrayList("Message1", "Message2", "Message3");
      MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
        private ObservableList<String> m_preTemplates = FXCollections.observableArrayList();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      List<PreFormattedAttributes> m_list=  msghndlr.getAllPreFormatedTemplates();
      List<Object> matchedTemplates = msghndlr.getMatchedPreFormatedTemplates();
        System.out.println("Matched Templates"+matchedTemplates);
      for(PreFormattedAttributes obj:m_list)
      {
          obj.getMsgPrecedence();
          obj.getMsgSecLabel();
          obj.getMsgSubject();
          System.out.println("Template ID:"+obj.getMsgTemplateId());
          m_preTemplates.add(obj.getMsgTemplateId());
      }
      m_comboboxMessage.setItems(m_preTemplates);
    }    

    @FXML
    private void onActionmsgCompose(ActionEvent event) {
        String msg=m_comboboxMessage.getSelectionModel().getSelectedItem().toString();
        System.out.println(msg);
        
    }
    
}
