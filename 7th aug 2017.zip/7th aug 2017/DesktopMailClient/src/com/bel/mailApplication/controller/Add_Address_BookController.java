
package com.bel.mailApplication.controller;

import static com.bel.mailApplication.controller.FXMLDocumentController.address_book;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.media.AudioClip;
import mail.awan.beans.AlarmProfilesDTO;
import mail.awan.beans.LdapDTO;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.Notifications;
/**
 * ******************************************************************
 * @File Name           : Add_Address_BookController.
 * @Author              : Ravikiran Bhat.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display window  for  add new address book.
 * @Created Date        : 5-APR-2017
 * @Modification History: NA.
*******************************************************************
 */
public class Add_Address_BookController implements Initializable {
    private static final AudioClip sm_alertAudio = new AudioClip(Add_Address_BookController.class.getResource("/sounds/sound1.wav").toString());
    private static final AudioClip sm_alertAudioO = new AudioClip(Add_Address_BookController.class.getResource("/sounds/sound5.wav").toString());
    @FXML
    private Button m_btnrmove;
    @FXML
    private Button m_btnAdd;
    @FXML
    private Label m_lblexistinguser;
    @FXML
    private ListView<String> m_existing_user;
    @FXML
    private ListView<String> m_nonexisting_user;

    @FXML
    private ObservableList<String> m_allContact = FXCollections.observableArrayList();

    @FXML
    private Button m_saveAddBook;
    @FXML
    private String m_allGlobalContact = "";
    @FXML
    private TextField m_new_add_bk_txtfld;
    @FXML  
    private Image m_icon = new Image(getClass().getResourceAsStream("/img/folder.png"));
    private Image m_icon1 = new Image(getClass().getResourceAsStream("/img/file.png"));
    public String m_successAlarmFlag;
    public String m_errorAlarmFlag;
    public String m_infoAlarmFlag;
    public String m_warningFlag;

    MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
    AlarmProfilesDTO alarmProfilesDTO = messageHandler.getAlarmProfiles(sm_name);
 /**
     * ******************************************************************
     * @Function Name           :initialization
     * @Description             : Method to initialize when loading page.
     * @Input Parameter         : NA.
     * @Output Parameter	: NA.
     * @Author                  : Ravikiran Bhat.
     * @Created Date            :5-APR-2017
     * @Modification History    :NA.
     * ******************************************************************
     */
      public void initialization()
      {
      try {

            List<String> list = messageHandler.getAllContactNames();
           
            for (String data : list) {

                System.out.println(data);

                m_allGlobalContact = data;
                m_existing_user.setItems(m_allContact);

                m_allContact.add(m_allGlobalContact);

            }
        } catch (NullPointerException ex) {
            System.out.println("No Global data found in create new address book");
        }
           m_nonexisting_user.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
      }
                 /**
     * ******************************************************************
     * @Function Name           :initialize
     * @Description             : Method to call initialization function.
     * @Input Parameter         : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
      * @Author                 : Ravikiran Bhat.
     * @Created Date            :5-MAY-2017
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      initialization();
        
    }
                  /**
     * ******************************************************************
     * @Function Name            :removeexistingdata
     * @Description              : Method to remove contact from list.
     * @Input Parameter          : ActionEvent-provided by -JavaFX.
     * @Output Parameter	 : NA.
      * @Author                  : Ravikiran Bhat.
     * @Created Date             :5-APR-2017
     * @Modification History     :NA.
     * ******************************************************************
     */

    @FXML
    private void removeexistingdata(ActionEvent event) {
        ObservableList<String> contactselected, allcontacts;
        ObservableList<String> existingcontacts;

        allcontacts = m_nonexisting_user.getItems();
        existingcontacts = m_existing_user.getItems();
        contactselected = m_nonexisting_user.getSelectionModel().getSelectedItems();

        contactselected.forEach(existingcontacts::add);

        contactselected.forEach(allcontacts::remove);
    }
             /**
     * ******************************************************************
     * @Function Name            :addingexistingdata
     * @Description              : Method to add contact to list.
     * @Input Parameter          : ActionEvent-provided by -JavaFX.
     * @Output Parameter	 : NA.
      * @Author                  : Ravikiran Bhat.
     * @Created Date             :5-APR-2017
     * @Modification History     :NA.
     * ******************************************************************
     */
    @FXML
    private void addingexistingdata(ActionEvent event) {

        ObservableList<String> contactselected, allcontacts;
        ObservableList<String> nonexistingcontacts;

        allcontacts = m_existing_user.getItems();

        nonexistingcontacts = m_nonexisting_user.getItems();

        contactselected = m_existing_user.getSelectionModel().getSelectedItems();

        contactselected.forEach(nonexistingcontacts::add);
        contactselected.forEach(allcontacts::remove);
    }
        /**
     * ******************************************************************
     * @Function Name            :onclickSaveAddBook
     * @Description              : Method to save address book.
     * @Input Parameter          : ActionEvent-provided by -JavaFX.
     * @Output Parameter	 : NA.
      * @Author                  : Ravikiran Bhat.
     * @Created Date             :5-APR-2017
     * @Modification History     :NA.
     * ******************************************************************
     */
    @FXML
    private void  onclickSaveAddBook(ActionEvent event) {

        System.out.println("Entered onclickSaveAddBook");
        if (m_new_add_bk_txtfld.getText() == null) {
            if(messageHandler.getAlarmProfiles(sm_name).getInfoAlarm()!=null)
            {
            m_warningFlag = messageHandler.getAlarmProfiles(sm_name).getInfoAlarm();
                 if (m_warningFlag.equalsIgnoreCase("true")) {
                            Add_Address_BookController.sm_alertAudioO.play();
                 }
            }
          
                         Platform.runLater(() -> {
                    Notifications.create().text("Create Address book Information" + "\nPlease Add New address book Name!!!").showError();
                });
            Alert alert1 = new Alert(Alert.AlertType.WARNING);
            alert1.setTitle("Warning-Create Address book Information ");
            alert1.setHeaderText("Please Add New address book Name ");
            alert1.getAlertType();
            alert1.show();

        } else {
            String New_Address_book_name = m_new_add_bk_txtfld.getText();
           m_nonexisting_user.getSelectionModel().selectAll();
             List<String> contacts = m_nonexisting_user.getSelectionModel().getSelectedItems();
           
        
            System.out.println(New_Address_book_name);
                
                try {

                    String officeName = messageHandler.ldapUserOffice(sm_name);
                    LdapDTO dto1 = new LdapDTO();
                    dto1.setCn(New_Address_book_name);     //address book sm_name(anything) 
                                                  // contacts list to be added in that address bookd
                    dto1.setMembers(contacts);
                    dto1.setNode(officeName);                 // office of that login user
                    dto1.setOwner(sm_name);           // login person sm_name..

                    boolean status = messageHandler.addAddressBook(dto1);
                    System.out.println(status);
                  if(messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm()!=null)
            {
                    m_successAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getSuccessAlarm();
                 if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                        Add_Address_BookController.sm_alertAudio.play();
                    }
            }
                           Platform.runLater(() -> {
                    Notifications.create().text("Create Address book Information" + "\nAddress book added Successfully ").showInformation();
                });
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information-Create Address book Information ");
                    alert.setHeaderText("Address book added Successfully ");
                    alert.getAlertType();
                    alert.show();
   
                } catch (NullPointerException e) {
                    System.out.println("Unable To add Address book");
                }
           // }
            }
            //  Nonexisting_user.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
            address_book.close();
         
    }
          /**
     * ******************************************************************
     * @Function Name               :onClickCancelButton.
     * @Description                 : Method to close address book window.
     * @Input Parameter             : ActionEvent-provided by -JavaFX.
     * @Output Parameter            : NA.
      * @Author                     : Ravikiran Bhat.
     * @Created Date                :5-APR-2017
     * @Modification History        :NA.
     * ******************************************************************
     */
    @FXML
    private void onClickCancelButton(ActionEvent event) {
       
        address_book.close();
    }

}
