/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.model;

/**
 *
 * @author Root
 */
public class DraftTabList {

    String from;
    String subject;
    String date;
    String mail_id;
    String sec_symbl;
    String preceColor;
    String m_attachmentTrue;
//public DraftTabList(String from,String subject,String date,String mail_id,String sec_symbl)
//{
//    this.from=from;
//    this.subject=subject;
//    this.date=date;
//    this.mail_id=mail_id;
//    this.sec_symbl = sec_symbl;
//
//}
    public DraftTabList(String from, String subject, String date, String mail_id, String sec_symbl, String preceColor, String m_attachmentTrue) {
        this.from = from;
        this.subject = subject;
        this.date = date;
        this.mail_id = mail_id;
        this.sec_symbl = sec_symbl;
        this.preceColor = preceColor;
        this.m_attachmentTrue=m_attachmentTrue;
    }

    public String getM_attachmentTrue() {
        return m_attachmentTrue;
    }

    public void setM_attachmentTrue(String m_attachmentTrue) {
        this.m_attachmentTrue = m_attachmentTrue;
    }

    public String getPreceColor() {
        return preceColor;
    }

    public void setPreceColor(String preceColor) {
        this.preceColor = preceColor;
    }

    public String getSec_symbl() {
        return sec_symbl;
    }

    public void setSec_symbl(String sec_symbl) {
        this.sec_symbl = sec_symbl;
    }

    public String getMail_id() {
        return mail_id;
    }

    public void setMail_id(String mail_id) {
        this.mail_id = mail_id;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public DraftTabList(String from) {
        this.from = from;

    }

}
