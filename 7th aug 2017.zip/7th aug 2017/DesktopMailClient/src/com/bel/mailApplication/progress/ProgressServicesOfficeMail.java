package com.bel.mailApplication.progress;

import com.bel.mailApplication.model.OfficeTabList;
import javafx.collections.ObservableList;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
/**
 * @File Name : ProgressServicesOfficeMail
 * @author : Ram Krishna Paul
 * @Description: For creating task of office mail
 * @Package : com.bel.mailApplication.progress
 * @Created : 17th june 2017
 * @Modification History: NA
 */
public class ProgressServicesOfficeMail extends Service<ObservableList<OfficeTabList>> {

    @Override
    protected Task createTask() {
        return new GetProgrssTaskOfficeMail();
    }
}
