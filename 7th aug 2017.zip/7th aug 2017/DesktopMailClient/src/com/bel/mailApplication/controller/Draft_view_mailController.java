package com.bel.mailApplication.controller;

import com.entity.MailDTO;

import static com.bel.mailApplication.controller.FXMLDocumentController.draft_mail_stage;
import static com.bel.mailApplication.controller.FXMLDocumentController.mail_id;
import static com.bel.mailApplication.controller.LoginFXMLController.securityStatusFlag;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.web.HTMLEditor;
import javafx.stage.Modality;
import javafx.stage.Stage;
import mail.awan.beans.AlarmProfilesDTO;
import mail.awan.beans.GroupMailInfo;
import mail.awan.beans.ReceiveMailInputDTO;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.Notifications;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContentDisplay;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.StageStyle;
import mail.awan.beans.AttachmentClearenceDTO;
import mail.awan.beans.MailSenderInfo;
import mail.awan.beans.ResultDTO;

/**
 * @File Name : Draft_view_mailController
 * @author : Ram Krishna Paul
 * @Description: for compose and drafting of mail
 * @Package : com.bel.mailApplication.controller
 * @Created : 5th May 2017
 * @Modification History: NA
 */
public class Draft_view_mailController implements Initializable {

    @FXML
    private Label send_label;
    @FXML
    private JFXButton btnBCC;
    @FXML
    private Label lblBCC;
    @FXML
    private Label from_name;
    @FXML
    private JFXButton Compose_to_btn;
    @FXML
    private Label to_mail;
    @FXML
    private JFXButton IntendeTo;
    @FXML
    private Label lblIntendeTo;
    @FXML
    private JFXButton btncc;
    @FXML
    private Label lblcc;
    @FXML
    private JFXButton btnintendedcc;
    @FXML
    private Label lblintendedcc;
    @FXML
    private JFXButton btnintendedBCC;
    @FXML
    private Label lblintendedBCC;
    @FXML
    private TextField sub_textfield;
    @FXML
    private ComboBox txtSIC;
    @FXML
    private ComboBox<String> combBoxMsgType;
    @FXML
    private TextArea txtMsgInstruction;
    @FXML
    private HTMLEditor html_editor;
    @FXML
    private Label lblattachfile;
    @FXML
    private ComboBox<String> Combobox_precednce;
    @FXML
    private ComboBox<String> Combobox_policy;
    @FXML
    private ComboBox<String> Combobox_classification;
    @FXML
    private TextField txtPrivacy;
    @FXML
    private ComboBox<String> Combobox_category;
    @FXML
    private Button attch_file;
    @FXML
    private JFXCheckBox chk_bx_read_reqst;
    @FXML
    private JFXCheckBox chk_bx_single_reqst;
    @FXML
    private JFXCheckBox chk_bx_encryption;
    @FXML
    private JFXButton btn_cancel;
    @FXML
    private Tooltip m_tooltipIntendedTo;
    @FXML
    private Tooltip m_tooltipIntendedCC;
    @FXML
    private Tooltip m_tooltipIntendedBCC;
    @FXML
    private Tooltip m_tooltipIntendedcc;
    String groupMailIdTo = "";
    String GroupMailIdCc = "";
    String GroupMailIdBcc = "";
    public String classification;
    @FXML
    private Label change_lable;
    public String attach_file;
    public String security_policy = "";
    public String security_level = "";
    public String security_category = "";
    public String security_privacy_mark = "";
    public String precedence = "";
    public String To = "";
    public String ccOffice = "";
    public String bccOffice = "";
    public String OriginalReceiver = "";
    public String OriginalCc = "";
    public String OriginalBcc = "";
    public String Subject = "";
    public String body = "";
    public String msgInstruction = "";
    public String messageType = "";
    public String Read_Receipt = "";
    public String sic = "";
    public String toOffice;
    public String encval = "";
    public String precedenceOfTcsUser;
    MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
    public List<String> m_groupdata = new ArrayList<String>();
    public StringBuilder toUser = new StringBuilder();
    public StringBuilder m_finalGroupMembers;
    String m_groupEmails = "";
    String groupEmails = "";
    public static File file = null;
    IntendedToDraftController intendedToDraftController;
    public String email1 = "";
    public static List<String> dataIntentedeTo = new ArrayList<>();
    public static List<String> datacc = new ArrayList<>();
    public static String precedencevalue = "";
    public static String classificationvlue = "";
    public static List<String> dataIntendedCC = new ArrayList<>();
    public static List<String> databcc = new ArrayList<>();
    public static List<String> dataTO = new ArrayList<>();
    public static String precedencevaleforIntendedTo = "";
    public static String classificationvaleforIntendedTo = "";
    public List<String> m_precedenceList = new ArrayList<String>();
    public List<String> m_classificationValue = new ArrayList<String>();
    public StringBuilder listdatacc = new StringBuilder();
    public String FinalEmailCC = "";
    public StringBuilder listdatBcc = new StringBuilder();
    public List<String> m_groupintendedccdata = new ArrayList<String>();
    String m_groupCCEmails = "";
    String groupccEmails = "";
    public String securityMark = "";
    public String subject;
    @FXML
    public GridPane m_attachLabel;
    @FXML
    public static List<String> dataIntendedBCC = new ArrayList<>();
    public ObservableList<String> precedence_value = FXCollections.observableArrayList("Flash", "Emergency", "OpImmediate", "Priority", "Routine", "Deferred");
    public ObservableList<String> Classification_value = FXCollections.observableArrayList("TopSecret", "Secret", "Confidential", "Restricted", "Unclassified");
//    public ObservableList<String> precedence_value;
//    public ObservableList<String> Classification_value;
    public ObservableList<String> MsgType = FXCollections.observableArrayList("Exercise", "Operation", "Project", "Drill");
    public ObservableList<String> Policy_value = FXCollections.observableArrayList("NATO", "National");
    public ObservableList<String> Category_value = FXCollections.observableArrayList("Restrictive", "Permissive", "Informative");
    AlarmProfilesDTO alarmProfilesDTO = msghndlr.getAlarmProfiles(sm_name);
    public String m_successAlarmFlag;
    public String m_errorAlarmFlag;
    public String m_infoAlarmFlag;
    public String m_warningFlag;
    public String intendedEmailList = "";
    public String intendedccEmailList = "";
    public String intendedbccEmailList = "";
    public List<String> m_groupintendedbccdata = new ArrayList<String>();
    public String FinalEmailIntendedBcc;
    String m_groupBCCEmails = "";
    String groupbccEmails = "";
    ArrayList<File> m_fileList = new ArrayList<File>();
    File finalFilesArray[];
    public int max_attch_size_allowed;
    private Boolean isAttachment = false;
    public String senderOfficeName = "";
    public String getMailID = "";
    public List<String> AttchmntSuccessList;
    public List<String> AttchmntFailurList;
    private boolean Attachflag = false;
    public ArrayList<String> mailIds = new ArrayList<String>();
    public String msgTypee = "";

    public String policyValue = "";
    public String categoryValue = "";
    public String SICVal = "";
    public String txtmessageInstruction = "";
    @FXML
    private Tooltip m_tooltipIntendedbcc;
    private static final AudioClip ALERT_AUDIOCLIP1 = new AudioClip(ComposePageContrller.class.getResource("/sounds/sound1.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP2 = new AudioClip(ComposePageContrller.class.getResource("/sounds/sound2.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP4 = new AudioClip(ComposePageContrller.class.getResource("/sounds/sound4.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP5 = new AudioClip(ComposePageContrller.class.getResource("/sounds/sound5.wav").toString());
    int i, j;
    ArrayList<String> m_array = new ArrayList<String>();

    /**
     * ******************************************************************
     * @Function Name : initialize
     * @Description : initialize method of the class file.
     * @Input Parameter : URL url, ResourceBundle rb provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date :5th June 2017
     * @Modification History: NA
     * ******************************************************************
     */

    protected static List<String> dataListIntendedTO() {
        return dataIntentedeTo;
    }

    protected static List<String> dataccList() {
        return datacc;
    }

    protected static List<String> dataList() {
        return dataTO;
    }

    protected static List<String> databccList() {
        return databcc;

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        viewDraftMails();
        attachmentAuthentication();
        maxprecedence();
        //
    }

    public void sendmailPrecheck() {
        senderOfficeName = obj.getOfficeName();
        getMailID = obj.getMailId();
        System.out.println("groupmails are" + obj.getGroupMailNames().toString());
        System.out.println("size is" + obj.getAttachmentMaxSize());
    }

    public void maxprecedence() {
        String office = msghndlr.ldapUserOffice(sm_name);
        System.out.println("officename" + msghndlr.ldapUserOffice(sm_name));
        precedenceOfTcsUser = msghndlr.getPrecedenceOfTcsUser(office, sm_name);
        int index = 0;

        Iterator itr = precedence_value.iterator();
        int lngth = precedence_value.size();
        while (itr.hasNext()) {
            String name = (String) itr.next();
            Combobox_precednce.setItems(precedence_value);
            if (precedenceOfTcsUser.equals(name)) {
                index = precedence_value.indexOf(precedenceOfTcsUser);
            }
            Combobox_precednce.setItems(getSubList(index, lngth));

        }

    }

    public ObservableList<String> getSubList(int start, int end) {

        final ObservableList<String> toBeDisplayedList = FXCollections.<String>observableArrayList();
        toBeDisplayedList.addAll(precedence_value.subList(start, end));
        return toBeDisplayedList;
    }

    public ObservableList<String> getSubList1(int start, int end) {

        final ObservableList<String> toBeDisplayedList = FXCollections.<String>observableArrayList();
        toBeDisplayedList.addAll(Classification_value.subList(start, end));
        return toBeDisplayedList;
    }

    public void classificationselect() {
        String office = msghndlr.ldapUserOffice(sm_name);
        classification = msghndlr.getMaxSecurityClassificationSendOfTcsUser(office, sm_name);
        int index = 0;

        Iterator itr = Classification_value.iterator();
        int lngth = Classification_value.size();
        while (itr.hasNext()) {
            String classificationval = (String) itr.next();
            Combobox_classification.setItems(Classification_value);
            if (classification.equals(classificationval)) {
                index = Classification_value.indexOf(classification);
            }
            Combobox_classification.setItems(getSubList1(index, lngth));
        }
    }

    @FXML
    private void compose_to(ActionEvent event) throws IOException {
        if (lblIntendeTo != null) {
            lblIntendeTo.setText(null);
            dataTO.clear();
            m_groupdata.clear();
            dataIntentedeTo.clear();
        }
        List<String> toVal = new ArrayList<>();
        Stage stageTo = new Stage();
        Parent rootTo;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/To_mail.fxml"));
        rootTo = (Parent) fXMLLoader.load();
        To_mail_Controller to_mail_Controller = fXMLLoader.getController();
        stageTo.setScene(new Scene(rootTo));
        stageTo.setTitle("Send Mail To");
        stageTo.initModality(Modality.APPLICATION_MODAL);
        stageTo.initOwner(Compose_to_btn.getScene().getWindow());
        stageTo.toFront();
        stageTo.showAndWait();
        stageTo.setResizable(false);
//        data = to_mail_Controller.add_list.getSelectionModel().getSelectedItems();

        // dataTO = to_mail_Controller.selectedToOffice;
        toVal = to_mail_Controller.selectedToOffice;
        dataTO.clear();

        if (toVal.size() != 0) {
            for (String str_To : toVal) {
                dataTO.add(str_To);
            }

            toUser = new StringBuilder();
            for (String userTo : dataTO) {
                toUser.append(userTo + ",");
            }

            to_mail.setText(toUser.toString());
//            removeTo.setVisible(true);
//            imgviewto.setVisible(true);

            ObservableList<String> sicList = FXCollections.observableArrayList();
            List<Map<Object, Object>> list = msghndlr.getnewSicList(dataTO);
            for (Map m_sicvalue : list) {
                Set set = m_sicvalue.entrySet();
                Iterator itr = set.iterator();
                while (itr.hasNext()) {
                    Map.Entry m = (Map.Entry) itr.next();

                    sicList.add((String) m.getKey());
                }
            }
            txtSIC.setItems(sicList);
        }

    }

    @FXML
    private void onClickbtnBCC(ActionEvent event) throws IOException {
        if (lblintendedBCC != null) {
            lblintendedBCC.setText(null);
            databcc.clear();
            dataIntendedBCC.clear();
        }
        List<String> bccVal = new ArrayList<>();
        Stage stageBCC = new Stage();
        Parent rootBCC;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/BCC.fxml"));
        rootBCC = (Parent) fXMLLoader.load();
        BCCController bCCController = fXMLLoader.getController();
        stageBCC.setScene(new Scene(rootBCC));
        stageBCC.setTitle("BCC");
        stageBCC.initModality(Modality.APPLICATION_MODAL);
        stageBCC.initOwner(btnBCC.getScene().getWindow());
        stageBCC.toFront();
        stageBCC.showAndWait();
        stageBCC.setResizable(false);
//            databcc = bCCController.ListBCC.getSelectionModel().getSelectedItems();
        bccVal = bCCController.selectedBccOffice;
        databcc.clear();
        for (String str_bcc : bccVal) {
            databcc.add(str_bcc);
        }
        listdatBcc = new StringBuilder();

        for (String userBcc : databcc) {
            listdatBcc.append(userBcc + ",");
        }
        lblBCC.setText(listdatBcc.toString());
//        imgviewBCC.setVisible(true);
//        removeBCC.setVisible(true);

    }

    public String newclassification = "";
    public String newprecedence = "";

    @FXML
    private void openIntendeTo(ActionEvent event) throws IOException, InterruptedException {
//        if (Combobox_precednce.getSelectionModel().getSelectedItem() == null || Combobox_classification.getSelectionModel().getSelectedItem() == null) {
        // if ( Combobox_precednce.getSelectionModel().getSelectedItem().length()!=0 || Combobox_classification.getSelectionModel().getSelectedItem().length()!=0){
              //System.out.println("test intended to ");
        
                   System.out.println("test intended to ");
       // if (Combobox_precednce.getSelectionModel().getSelectedItem().toString() != null || Combobox_classification.getSelectionModel().getSelectedItem().toString() != null) {
//            newclassification = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
//            newprecedence = Combobox_classification.getSelectionModel().getSelectedItem().toString();
//            classificationvaleforIntendedTo = newclassification;
//            precedencevaleforIntendedTo = newprecedence;
//        System.out.println("Selected value:"+Combobox_precednce.getSelectionModel().getSelectedItem().toString()); 
//    MailDTO outputDTO;
//            int c = Integer.parseInt(mail_id);
//
//            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
//            inputDTO.setMsgUID(c);
//            inputDTO.setFolder("drafts");
//
//            outputDTO = msghndlr.readSpecificeMail(inputDTO);
//              if (outputDTO.getHeaderMap().get("security_level") != null) {
//                classificationvaleforIntendedTo = (String) outputDTO.getHeaderMap().get("security_level");
//            }
//              if (outputDTO.getHeaderMap().get("precedence") != null) {
//                precedencevaleforIntendedTo = (String) outputDTO.getHeaderMap().get("precedence");
//            }
//            if(classificationvaleforIntendedTo!=null||precedencevaleforIntendedTo!=null)  
//            {
//                outputDTO = msghndlr.readSpecificeMail(inputDTO);
//              if (outputDTO.getHeaderMap().get("security_level") != null) {
//                classificationvaleforIntendedTo = (String) outputDTO.getHeaderMap().get("security_level");
//            }
//              if (outputDTO.getHeaderMap().get("precedence") != null) {
//                precedencevaleforIntendedTo = (String) outputDTO.getHeaderMap().get("precedence");
//            }
//            }
//              if(sec_level==""||pre_level=="")
//              {
//                  classificationvaleforIntendedTo = (String) outputDTO.getHeaderMap().get("security_level");
//                   precedencevaleforIntendedTo = (String) outputDTO.getHeaderMap().get("precedence");
//                  
//              }
//}
//String sec_level="";
//String pre_level="";
//             MailDTO outputDTO;
//            int c = Integer.parseInt(mail_id);
//
//            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
//            inputDTO.setMsgUID(c);
//            inputDTO.setFolder("drafts");
//
//            outputDTO = msghndlr.readSpecificeMail(inputDTO);
//              if (outputDTO.getHeaderMap().get("security_level") != null) {
//                sec_level = (String) outputDTO.getHeaderMap().get("security_level");
//            }
//              if (outputDTO.getHeaderMap().get("precedence") != null) {
//                pre_level = (String) outputDTO.getHeaderMap().get("precedence");
//            }
//              if(sec_level==""||pre_level=="")
//              {
//                  classificationvaleforIntendedTo = (String) outputDTO.getHeaderMap().get("security_level");
//                   precedencevaleforIntendedTo = (String) outputDTO.getHeaderMap().get("precedence");
//                  
           //   }
        
             if (Combobox_precednce.getValue() == null) {
            
            if (msghndlr.getAlarmProfiles(sm_name).getWarningAlarm() != null) {
                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getWarningAlarm();
                if (m_warningFlag.equalsIgnoreCase("true")) {
                    Draft_view_mailController.ALERT_AUDIOCLIP2.play();
                }
            }

            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Drafted Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Choose the Precedence");
            alert.showAndWait();

        } 
      if (Combobox_classification.getValue() == null) {
            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_warningFlag.equalsIgnoreCase("true")) {
                    Draft_view_mailController.ALERT_AUDIOCLIP2.play();
                }
            }

            Platform.runLater(() -> {
                Notifications.create().text("Drafted Mail-" + "\nPlease Enter Security Label Value for the mail ").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Drafted Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Enter Security Label Value for the mail ");
            alert.showAndWait();

        }
//        else if (Combobox_precednce.getSelectionModel().getSelectedItem().toString() != null || Combobox_classification.getSelectionModel().getSelectedItem().toString() != null) {
////            newclassification = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
////            newprecedence = Combobox_classification.getSelectionModel().getSelectedItem().toString();
////            classificationvaleforIntendedTo = newclassification;
////            precedencevaleforIntendedTo = newprecedence;
//             MailDTO outputDTO;
//            int c = Integer.parseInt(mail_id);
//
//            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
//            inputDTO.setMsgUID(c);
//            inputDTO.setFolder("drafts");
//
//            outputDTO = msghndlr.readSpecificeMail(inputDTO);
//              if (outputDTO.getHeaderMap().get("security_level") != null) {
//                classificationvaleforIntendedTo = (String) outputDTO.getHeaderMap().get("security_level");
//            }
//              if (outputDTO.getHeaderMap().get("precedence") != null) {
//                precedencevaleforIntendedTo = (String) outputDTO.getHeaderMap().get("precedence");
//            }
//              
//        }
       else {
//            classificationvaleforIntendedTo = security_level;
//            precedencevaleforIntendedTo = precedence;
//        } 

        Stage stageIntendedTo = new Stage();
        Parent rootIntendedTo;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/IntendedToDraft.fxml"));
        rootIntendedTo = (Parent) fXMLLoader.load();
        intendedToDraftController = fXMLLoader.getController();

        stageIntendedTo.setScene(new Scene(rootIntendedTo));
        stageIntendedTo.setTitle("Intended To");
        stageIntendedTo.initModality(Modality.APPLICATION_MODAL);
        stageIntendedTo.initOwner(IntendeTo.getScene().getWindow());
        stageIntendedTo.toFront();
        stageIntendedTo.showAndWait();
        stageIntendedTo.setResizable(false);
        stageIntendedTo.getIcons().add(new Image("/img/Mail-icon.png"));

        dataIntentedeTo = intendedToDraftController.EmailIntendedTo.getSelectionModel().getSelectedItems();
        dataIntentedeTo = intendedToDraftController.selectedIntendedToOffice;
        StringBuilder mailIdsList = new StringBuilder();

        for (String email : dataIntentedeTo) {
            mailIdsList.append(email + ",");
            email1 += email + ",";
        }
        StringBuilder finalEmail = mailIdsList;
        intendedEmailList = finalEmail.substring(0, finalEmail.length() - 1);
        lblIntendeTo.setText(intendedEmailList.toString());
        textintendedto();
        }
    }

    public void textintendedto() {

        if (lblIntendeTo.getText() == null || lblIntendeTo.getText().isEmpty()) {
            txtSIC.setDisable(false);
        } else {
            txtSIC.setDisable(true);
            txtSIC.setItems(null);
        }
    }

    @FXML
    private void clickBtnCC(ActionEvent event) throws IOException {
        if (lblintendedcc != null) {
            lblintendedcc.setText(null);
            datacc.clear();
            dataIntendedCC.clear();
            m_groupintendedccdata.clear();
        } //        if (lblIntendeTo.getText() == null || lblIntendeTo.getText().isEmpty()) {
        //            ComposePageContrller.ALERT_AUDIOCLIP2.play();
        //            Platform.runLater(() -> {
        //                Notifications.create().text("Compose Mail-" + "\nPlease Intended To").showWarning();
        //            });
        //            Alert alert = new Alert(Alert.AlertType.WARNING);
        //            alert.initStyle(StageStyle.UTILITY);
        //            alert.setTitle("Compose Mail");
        //            alert.setHeaderText(null);
        //            alert.setContentText("Please Select Intended To ");
        //            alert.showAndWait();
        //
        //        } 

        List<String> ccVal = new ArrayList<>();
        Stage stageCC = new Stage();
        Parent root1;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/CCFXML.fxml"));
        root1 = (Parent) fXMLLoader.load();
        CCFXMLController cCFXMLController = fXMLLoader.getController();
        stageCC.setScene(new Scene(root1));
        stageCC.setTitle("CC");
        stageCC.initModality(Modality.APPLICATION_MODAL);
        stageCC.initOwner(btncc.getScene().getWindow());
        stageCC.toFront();
        stageCC.showAndWait();
        stageCC.setResizable(false);
        stageCC.getIcons().add(new Image("/img/Mail-icon.png"));
        ccVal = cCFXMLController.selectedccOffice;
        datacc.clear();
        for (String str_CC : ccVal) {
            datacc.add(str_CC);
        }
        listdatacc = new StringBuilder();
        for (String recDataFromCC : datacc) {
            listdatacc.append(recDataFromCC + ",");
        }
        System.out.println("listdatacc" + listdatacc.toString());
        lblcc.setText(listdatacc.toString());
//        removeCC.setVisible(true);
//        imgviewCC.setVisible(true);
    }

    @FXML
    private void onClickIntendedCC(ActionEvent event) throws IOException {

        if (Combobox_precednce.getValue() == null) {
            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_warningFlag.equalsIgnoreCase("true")) {
                    Draft_view_mailController.ALERT_AUDIOCLIP2.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Select Precedence and Security Label!").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Compose Mail-");
            alert.setHeaderText(null);
            alert.setContentText("Please Select Precedence and Security Label!");
            alert.showAndWait();

        } else if (Combobox_classification.getValue() == null) {
            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_warningFlag.equalsIgnoreCase("true")) {
                    Draft_view_mailController.ALERT_AUDIOCLIP2.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Select Classification Label!").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Compose Mail-");
            alert.setHeaderText(null);
            alert.setContentText("Please Select Classification Label!");
            alert.showAndWait();

        } else {
            classificationvaleforIntendedTo = Combobox_classification.getSelectionModel().getSelectedItem().toString();
            precedencevaleforIntendedTo = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
            List<String> intendedccVal = new ArrayList<>();
            List<String> m_intendedgroupccVal = new ArrayList<>();
            Stage stageIntendedCC = new Stage();
            Parent rootintendedCC;
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/IntendedCCDraft.fxml"));
            rootintendedCC = (Parent) fXMLLoader.load();
            IntendedCCDraftController intendedCCController = fXMLLoader.getController();
            stageIntendedCC.setScene(new Scene(rootintendedCC));
            stageIntendedCC.setTitle("Intended CC");
            stageIntendedCC.initModality(Modality.APPLICATION_MODAL);
            stageIntendedCC.initOwner(btnintendedcc.getScene().getWindow());
            stageIntendedCC.toFront();
            stageIntendedCC.showAndWait();
            stageIntendedCC.setResizable(false);
//            dataIntendedCC = intendedCCController.ListIntendedCC.getSelectionModel().getSelectedItems();
            intendedccVal = intendedCCController.selectedIntendedccOffice;
            m_intendedgroupccVal = intendedCCController.m_selectedccGroupMail;
            System.out.println("m_intendedgroupccVal is" + m_intendedgroupccVal.toString());
            String m_intendedccval = "";
            StringBuilder m_strintendedcc = null;
            Set<String> m_ccofficename = null;
            /////////////////////////////////Group mail///////////////////////////////////////////////////////// 
            if (m_intendedgroupccVal.size() != 0) {
                m_groupintendedccdata.clear();
                for (String m_userGroup : m_intendedgroupccVal) {
                    m_groupintendedccdata.add(m_userGroup);
                }
                StringBuilder m_listdataGroup = new StringBuilder();;

                for (String m_emailGroup : m_groupintendedccdata) {
                    m_listdataGroup.append(m_emailGroup + ",");
                    groupccEmails += m_emailGroup + ",";
                }
                StringBuilder finalGroupEmail = m_listdataGroup;
                if (finalGroupEmail != null || !finalGroupEmail.equals("")) {
                    m_groupCCEmails = finalGroupEmail.substring(0, finalGroupEmail.length() - 1);
                    groupccEmails = m_groupCCEmails;
                } else {
                    groupccEmails = m_groupCCEmails;
                }

                List<String> m_ccGroup = new ArrayList<String>();
                for (String mailGroupName : m_groupintendedccdata) {
                    GroupMailInfo groupMailInfo = msghndlr.getMailGroup(mailGroupName);
                    List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                    m_ccofficename = (Set<String>) groupMailInfo.getOfficeNames();

                    String strr = "";
                    m_strintendedcc = new StringBuilder(strr);
                    for (String memberMailId : memberMailIdsList) {
                        m_strintendedcc.append(memberMailId + ",");
                    }
                    for (String m_groupOffice : m_ccofficename) {
                        m_ccGroup.add(m_groupOffice);
                    }
                    String m_fgroupemailoffice = "";
                    StringBuilder group = new StringBuilder();
                    for (String m_finalGroup : m_ccGroup) {
                        group.append(m_finalGroup + ",");
                        m_fgroupemailoffice += m_finalGroup + ",";
                    }
                }
                Set<String> m_fTo = new HashSet<String>(m_ccGroup);
                m_fTo.addAll(datacc);

                List<String> finalSortedList = new ArrayList<>(m_fTo);
                System.out.println("finalSortedList" + finalSortedList);
                StringBuilder m_finalOfficeCC = new StringBuilder();
                String m_finalcc = "";
                for (String str1 : finalSortedList) {
                    m_finalOfficeCC.append(str1 + ",");
                    m_finalcc += str1 + ",";
                }
                if (finalSortedList.size() > 0) {
                    datacc = finalSortedList;
                }
//                System.out.println("m_finalTo" + m_finalTo);
                lblcc.setText(m_finalcc);
                m_ccGroup.clear();
//                removeCC.setVisible(true);
//                imgviewCC.setVisible(true);
            }
            /////////////////////////////////////////////Group mail//////////////////////////////////////////////               

            if (intendedccVal.size() != 0) {
                dataIntendedCC.clear();
                for (String str_Intendedcc : intendedccVal) {
                    dataIntendedCC.add(str_Intendedcc);
                }
                StringBuilder emailIntendedCC = new StringBuilder();
                for (String emailintendedCC : dataIntendedCC) {
                    emailIntendedCC.append(emailintendedCC + ",");
                    FinalEmailCC += emailintendedCC + ",";
                }
                StringBuilder finalEmail = new StringBuilder(emailIntendedCC);
                String intendedcc = "";
                if (finalEmail != null || !finalEmail.equals("")) {
                    intendedcc = finalEmail.substring(0, finalEmail.length() - 1);
                    m_intendedccval = intendedcc;
                } else {
                    m_intendedccval = intendedcc;
                }
            }
            intendedccEmailList = m_intendedccval;
            lblintendedcc.setText(groupccEmails + " " + intendedccEmailList);

//            removeIntendedCC.setVisible(true);
//            imgviewIntendedCC.setVisible(true);
            m_tooltipIntendedcc.setText(intendedccEmailList);
            if (m_strintendedcc != null) {
                m_tooltipIntendedcc.setText(m_strintendedcc.toString().substring(0, m_strintendedcc.toString().length() - 1));
            }
        }

    }

    @FXML
    private void clickbtnintendedBCC(ActionEvent event) throws IOException {
        if (Combobox_precednce.getValue() == null) {
            m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
            if (m_warningFlag.equalsIgnoreCase("true")) {
                Draft_view_mailController.ALERT_AUDIOCLIP2.play();
            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Select Precedence and Security Label!").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning-Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select Precedence and Security Label!");
            alert.showAndWait();

        } else if (Combobox_classification.getValue() == null) {
            m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
            if (m_warningFlag.equalsIgnoreCase("true")) {
                Draft_view_mailController.ALERT_AUDIOCLIP2.play();
            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Select Classification Label!").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning-Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select Classification Label!");
            alert.showAndWait();

        } else {
            classificationvaleforIntendedTo = Combobox_classification.getSelectionModel().getSelectedItem().toString();
            precedencevaleforIntendedTo = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
            List<String> intendedbccVal = new ArrayList<>();
            List<String> m_intendedgroupbccVal = new ArrayList<>();
            Stage stageIntedBCC = new Stage();
            Parent rootIntendedBCC;
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/IntendedBCCDraft.fxml"));
            rootIntendedBCC = (Parent) fXMLLoader.load();
            IntendedBCCDraftController intendedBCCController = fXMLLoader.getController();
            stageIntedBCC.setScene(new Scene(rootIntendedBCC));
            stageIntedBCC.setTitle("Intended BCC");
            stageIntedBCC.initModality(Modality.APPLICATION_MODAL);
            stageIntedBCC.initOwner(btnintendedBCC.getScene().getWindow());
            stageIntedBCC.toFront();
            stageIntedBCC.showAndWait();
            stageIntedBCC.setResizable(false);
//            dataIntendedBCC = intendedBCCController.ListIntendedBCC.getSelectionModel().getSelectedItems();
            intendedbccVal = intendedBCCController.selectedIntendedBccOffice;
            m_intendedgroupbccVal = intendedBCCController.m_selectedbccGroupMail;
            String m_intendedbccval = "";
            StringBuilder m_strintendedbcc = null;
            Set<String> m_bccofficename = null;
            /////////////////////////////////Group mail///////////////////////////////////////////////////////// 
            if (m_intendedgroupbccVal.size() != 0) {
                m_groupintendedbccdata.clear();
                for (String m_userGroup : m_intendedgroupbccVal) {
                    m_groupintendedbccdata.add(m_userGroup);
                }
                StringBuilder m_listdatabccGroup = new StringBuilder();

                for (String m_emailGroup : m_groupintendedbccdata) {
                    m_listdatabccGroup.append(m_emailGroup + ",");
                    groupbccEmails += m_emailGroup + ",";
                }
                StringBuilder finalGroupEmail = m_listdatabccGroup;
                if (finalGroupEmail != null || !finalGroupEmail.equals("")) {
                    m_groupBCCEmails = finalGroupEmail.substring(0, finalGroupEmail.length() - 1);
                    groupbccEmails = m_groupBCCEmails;
                } else {
                    groupbccEmails = m_groupBCCEmails;
                }

                List<String> m_bccGroup = new ArrayList<String>();
                for (String mailGroupName : m_groupintendedbccdata) {
                    GroupMailInfo groupMailInfo = msghndlr.getMailGroup(mailGroupName);
                    List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                    m_bccofficename = (Set<String>) groupMailInfo.getOfficeNames();

                    String strr = "";
                    m_strintendedbcc = new StringBuilder(strr);
                    for (String memberMailId : memberMailIdsList) {
                        m_strintendedbcc.append(memberMailId + ",");
                    }
                    for (String m_groupOffice : m_bccofficename) {
                        m_bccGroup.add(m_groupOffice);
                    }
                    String m_fgroupemailbccoffice = "";
                    StringBuilder group = new StringBuilder();
                    for (String m_finalGroup : m_bccGroup) {
                        group.append(m_finalGroup + ",");
                        m_fgroupemailbccoffice += m_finalGroup + ",";
                    }
                }
                Set<String> m_fbcc = new HashSet<String>(m_bccGroup);
                m_fbcc.addAll(databcc);

                List<String> finalSortedListbcc = new ArrayList<>(m_fbcc);
                System.out.println("finalSortedList" + finalSortedListbcc);
                StringBuilder m_finalOfficeBCC = new StringBuilder();
                String m_finalbcc = "";
                for (String str1 : finalSortedListbcc) {
                    m_finalOfficeBCC.append(str1 + ",");
                    m_finalbcc += str1 + ",";
                }
                if (finalSortedListbcc.size() > 0) {
                    databcc = finalSortedListbcc;
                }
//                System.out.println("m_finalTo" + m_finalTo);
                lblBCC.setText(m_finalbcc);
//                imgviewBCC.setVisible(true);
//                removeBCC.setVisible(true);
                m_bccGroup.clear();
            }
            /////////////////////////////////////////////Group mail//////////////////////////////////////////////               

            if (intendedbccVal.size() != 0) {
                dataIntendedBCC.clear();
                for (String str_Intendedbcc : intendedbccVal) {
                    dataIntendedBCC.add(str_Intendedbcc);
                }
                StringBuilder emailIntendedBCC = new StringBuilder();
                for (String IntendedBCC : dataIntendedBCC) {
                    emailIntendedBCC.append(IntendedBCC + ",");
                    FinalEmailIntendedBcc += IntendedBCC + ",";
                }
                StringBuilder finalEmail = new StringBuilder(emailIntendedBCC);
                String intendedbcc = "";
                if (finalEmail != null || !finalEmail.equals("")) {
                    intendedbcc = finalEmail.substring(0, finalEmail.length() - 1);
                    m_intendedbccval = intendedbcc;
                } else {
                    m_intendedbccval = intendedbcc;
                }
            }
            intendedbccEmailList = m_intendedbccval;
            lblintendedBCC.setText(groupbccEmails + " " + intendedbccEmailList);

//            imgviewIntendedBCC.setVisible(true);
//            removeIntendeBCC.setVisible(true);
            m_tooltipIntendedbcc.setText(intendedbccEmailList);
            if (m_strintendedbcc != null) {
                m_tooltipIntendedbcc.setText(m_strintendedbcc.toString().substring(0, m_strintendedbcc.toString().length() - 1));
            }
        }
    }

    @FXML
    private void onPrecedenceSelectaction(ActionEvent event) {
    }

    @FXML
    private void on_selection_classification(ActionEvent event) {
    }

    @FXML
    private Boolean on_click_send(ActionEvent event) throws Exception {
        String retVal = "false";
// if (Combobox_precednce.getValue() == null) {
//            if (msghndlr.getAlarmProfiles(sm_name).getWarningAlarm() != null) {
//                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getWarningAlarm();
//                if (m_warningFlag.equalsIgnoreCase("true")) {
//                    Draft_view_mailController.ALERT_AUDIOCLIP2.play();
//                }
//            }
//
//            Alert alert = new Alert(Alert.AlertType.WARNING);
//            alert.initStyle(StageStyle.UTILITY);
//            alert.setTitle("Warning - Compose Mail");
//            alert.setHeaderText(null);
//            alert.setContentText("Please Choose the Precedence");
//            alert.showAndWait();
//            return false;
//
//        }
//        if (Combobox_classification.getValue() == null) {
//            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
//                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
//                if (m_warningFlag.equalsIgnoreCase("true")) {
//                    Draft_view_mailController.ALERT_AUDIOCLIP2.play();
//                }
//            }
//
//            Platform.runLater(() -> {
//                Notifications.create().text("Compose Mail-" + "\nPlease Enter Security Label Value for the mail ").showWarning();
//            });
//            Alert alert = new Alert(Alert.AlertType.WARNING);
//            alert.initStyle(StageStyle.UTILITY);
//            alert.setTitle("Warning - Compose Mail");
//            alert.setHeaderText(null);
//            alert.setContentText("Please Enter Security Label Value for the mail ");
//            alert.showAndWait();
//            return false;
//        }
        if (sub_textfield.getText() == null || sub_textfield.getText().isEmpty()) {
            m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
            if (m_warningFlag.equalsIgnoreCase("true")) {
                if (msghndlr.getAlarmProfiles(sm_name).getWarningAlarm() != null) {
                    m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getWarningAlarm();
                    if (m_warningFlag.equalsIgnoreCase("true")) {
                        Draft_view_mailController.ALERT_AUDIOCLIP2.play();
                    }
                }

            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Enter Subject for the mail ").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Enter Subject for the mail ");
            alert.showAndWait();
            return false;

        }

//        if (Combobox_policy.getValue() == null) {
//            m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
//            if (m_warningFlag.equalsIgnoreCase("true")) {
//                if (msghndlr.getAlarmProfiles(sm_name).getWarningAlarm() != null) {
//                    m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getWarningAlarm();
//                    if (m_warningFlag.equalsIgnoreCase("true")) {
//                        Draft_view_mailController.ALERT_AUDIOCLIP2.play();
//                    }
//                }
//
//            }
//            Platform.runLater(() -> {
//                Notifications.create().text("Compose Mail-" + "\nPlease choose the Policy").showWarning();
//            });
//            Alert alert = new Alert(Alert.AlertType.WARNING);
//            alert.initStyle(StageStyle.UTILITY);
//            alert.setTitle("Warning - Compose Mail");
//            alert.setHeaderText(null);
//            alert.setContentText("Please choose the Policy");
//            alert.showAndWait();
//
//        }
//        if (Combobox_category.getValue() == null) {
//            m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
//            if (m_warningFlag.equalsIgnoreCase("true")) {
//                if (msghndlr.getAlarmProfiles(sm_name).getWarningAlarm() != null) {
//                    m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getWarningAlarm();
//                    if (m_warningFlag.equalsIgnoreCase("true")) {
//                        Draft_view_mailController.ALERT_AUDIOCLIP2.play();
//                    }
//                }
//            }
//            Platform.runLater(() -> {
//                Notifications.create().text("Compose Mail-" + "\nPlease choose the Category").showWarning();
//            });
//            Alert alert = new Alert(Alert.AlertType.WARNING);
//            alert.initStyle(StageStyle.UTILITY);
//            alert.setTitle("Warning - Compose Mail");
//            alert.setHeaderText(null);
//            alert.setContentText("Please choose the Category");
//            alert.showAndWait();
//
//        }
        subject = sub_textfield.getText();
        body = html_editor.getHtmlText();
        precedencevalue = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
        classificationvlue = Combobox_classification.getSelectionModel().getSelectedItem().toString();
        policyValue = Combobox_policy.getSelectionModel().getSelectedItem().toString();
        categoryValue = Combobox_category.getSelectionModel().getSelectedItem().toString();
        if (txtSIC.getSelectionModel().getSelectedItem() != null) {
            SICVal = txtSIC.getSelectionModel().getSelectedItem().toString();
        } else {
            SICVal = null;
        }
        if (combBoxMsgType.getSelectionModel().getSelectedItem() != null) {
            msgTypee = combBoxMsgType.getSelectionModel().getSelectedItem();
        } else {
            msgTypee = null;
        }
        if (txtMsgInstruction.getText() != null) {
            txtmessageInstruction = txtMsgInstruction.getText();
        } else {
            txtmessageInstruction = null;
        }

        HashMap<Object, Object> headers = new HashMap<Object, Object>();

        String FinalIntendedTO = "";
        if (dataIntentedeTo != null) {
            for (int i = 0; i < dataIntentedeTo.size(); i++) {
                String temp = dataIntentedeTo.get(i).toString();
                if (i >= 0 && i < dataIntentedeTo.size() - 1) {
                    FinalIntendedTO = FinalIntendedTO + temp + ",";
                } else {
                    FinalIntendedTO = FinalIntendedTO + temp;
                }
            }

        }

        ///for final to value to send mail
        String FinalTO = "";
        String tempTo = "";
        int sizeto = dataTO.size();
        for (int i = 0; i < sizeto; i++) {

            tempTo = dataTO.get(i).toString();

            if (i >= 0 && i < dataTO.size() - 1) {
                FinalTO = FinalTO + tempTo + ",";
            } else {
                FinalTO = FinalTO + tempTo;
            }
        }
        /// for final cc value to send mail

        String FinalCC = "";
        String tempCC = "";
        int sizecc = datacc.size();
        for (int j = 0; j < sizecc; j++) {

            tempCC = datacc.get(j).toString();

            if (j >= 0 && j < datacc.size() - 1) {
                FinalCC = FinalCC + tempCC + ",";
            } else {
                FinalCC = FinalCC + tempCC;
            }
        }
        // for final bcc value to send mail
        String FinalBCC = "";
        String tempBCC = "";
        int sizebcc = databcc.size();
        for (int k = 0; k < sizebcc; k++) {

            tempBCC = databcc.get(k).toString();

            if (k >= 0 && k < databcc.size() - 1) {
                FinalBCC = FinalBCC + tempBCC + ",";
            } else {
                FinalBCC = FinalBCC + tempBCC;
            }
        }

        boolean readFlag = checkboxrecept();

        String readVal = "";
        if (readFlag) {
            readVal = "true";
        } else {
            readVal = "false";
        }

        boolean encryptFlag = encryptionCheck();

        if (encryptFlag) {
            encval = "true";
        } else {
            encval = "false";
        }

        String tempStr = "";
        String htmlText = html_editor.getHtmlText();

        tempStr = stripHTMLTags(htmlText);
        if (tempStr == null || tempStr.isEmpty()) {
            m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
            if (m_warningFlag.equalsIgnoreCase("true")) {
                if (msghndlr.getAlarmProfiles(sm_name).getWarningAlarm() != null) {
                    m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getWarningAlarm();
                    if (m_warningFlag.equalsIgnoreCase("true")) {
                        Draft_view_mailController.ALERT_AUDIOCLIP2.play();
                    }
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Enter Message Body for the mail").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Enter Message Body for the mail ");
            alert.showAndWait();
            return false;
        }
        if (txtPrivacy.getText() == null || txtPrivacy.getText().isEmpty() || txtPrivacy.getText() == "") {
            securityMark = "";

        } else {

            securityMark = txtPrivacy.getText();
        }

        MailDTO input = new MailDTO();
        input.setSubject(subject);
        input.setContent(body);
        input.setFrom(sm_name + "@tcs.mil.in");
        headers.put("toOffice", FinalTO);
        headers.put("ccOffice", FinalCC);
        headers.put("bccOffice", FinalBCC);
        headers.put("originalReceiver", FinalIntendedTO);
        headers.put("originalCc", intendedccEmailList);
        headers.put("originalBcc", intendedbccEmailList);
        headers.put("read_receipt", readVal);
        headers.put("sic", SICVal);
        headers.put("signed_receipt", "");
        headers.put("signed_receipt_receiptfrom", "");
        headers.put("signed_receipt_receiptto", "");
        headers.put("encryption", encval);
        headers.put("precedence", precedencevalue);
        headers.put("security_policy", policyValue);
        headers.put("security_level", classificationvlue);
        headers.put("security_privacy_mark", securityMark);
        headers.put("security_category", categoryValue);
        headers.put("messageType", msgTypee);
        headers.put("msgType", "DRAFT");
        headers.put("messageInstructions", txtmessageInstruction);
        headers.put("groupMailIdTo", m_groupEmails);
        headers.put("groupMailIdCc", m_groupCCEmails);
        headers.put("groupMailIdBcc", m_groupBCCEmails);

        input.setToRecipient("");
        input.setCcRecipient("");
        input.setBccRecipient("");
        input.setAttachment("");
        input.setMsgType("");
        input.setHeaderMap(headers);
        if (m_groupEmails != "" && FinalCC != "" && intendedccEmailList == "" && FinalBCC != "" && intendedbccEmailList == "") {

            //m_groupEmails != null && intendedccEmailList == null && intendedbccEmailList == null) {
            Draft_view_mailController.ALERT_AUDIOCLIP2.play();
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nplease select intended CC & BCC recepient").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("please select intended CC & BCC recepient");
            alert.showAndWait();
            return false;
        } else if (m_groupEmails != "" && FinalCC != "" && intendedccEmailList == "") {
            Draft_view_mailController.ALERT_AUDIOCLIP2.play();
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nplease select intended CC recepient").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("please select intended CC recepient");
            alert.showAndWait();
            return false;
        } else if (m_groupEmails != "" && FinalBCC != "" && intendedbccEmailList == "") {
            Draft_view_mailController.ALERT_AUDIOCLIP2.play();
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nplease select intended BCC recepient").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("please select intended BCC recepient");
            alert.showAndWait();
            return false;
        }

        if (FinalIntendedTO == "" && FinalCC != "" && m_groupCCEmails != "" && FinalBCC != "" && m_groupBCCEmails != "") {
            Draft_view_mailController.ALERT_AUDIOCLIP2.play();
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\ngroup address can not be added, as based " + "\n on to address the mail will be either profiled or SIC").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("group address can not be added, as based " + "\n on to address the mail will be either profiled or SIC");
            alert.showAndWait();
            return false;
        } else if (FinalIntendedTO == "" && FinalCC != "" && m_groupCCEmails != "") {
            Draft_view_mailController.ALERT_AUDIOCLIP2.play();
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\ngroup address can not be added, as based " + "\n on to address the mail will be either profiled or SIC").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("group address can not be added, as based " + "\n on to address the mail will be either profiled or SIC");
            alert.showAndWait();
            return false;
        } else if (FinalIntendedTO == "" && FinalBCC != "" && m_groupBCCEmails != "") {
            Draft_view_mailController.ALERT_AUDIOCLIP2.play();
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\ngroup address can not be added, as based " + "\n on to address the mail will be either profiled or SIC").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("group address can not be added, as based " + "\n on to address the mail will be either profiled or SIC");
            alert.showAndWait();
            return false;
        }
//        boolean inteto = true;
//        if (dataIntentedeTo == null || dataIntentedeTo.isEmpty()) {
//            ComposePageContrller.ALERT_AUDIOCLIP2.play();
//            Platform.runLater(() -> {
//                Notifications.create().text("Compose Mail-" + "\nAre you sure want to send mail without Intended To Users !").showWarning();
//            });
//            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
//            alert.setTitle("Confirmation - Compose Mail");
//            alert.setHeaderText(null);
//            alert.setContentText("Are you sure want to send mail without Intended To Users !");
//            Optional<ButtonType> result = alert.showAndWait();
//            if (result.get() == ButtonType.OK) {
//                inteto = true;
//            } else if (result.get() == ButtonType.CANCEL) {
//                inteto = false;
//                return false;
//            }
//        }
        if (isAttachment) {

            // if (lblattachfile.getText().length() > 0) {
            mailIds.clear();
            StringTokenizer stMailId = new StringTokenizer(intendedEmailList, ",");
            while (stMailId.hasMoreTokens()) {
                mailIds.add(stMailId.nextToken());
            }
            System.out.println("Mail Ids List: " + mailIds.toString());
            AttachmentClearenceDTO dto = new AttachmentClearenceDTO();
            if (file.length() != 0) {
                dto.setAttachmentSize((long) file.length());
            } else {
                dto.setAttachmentSize((long) 0);
            }
            dto.setUserMailIds(mailIds.toArray(new String[0]));
            Attachflag = true;

            ResultDTO dtoAttachClearance = (ResultDTO) msghndlr.checkAttachmentClearence(dto);
            AttchmntFailurList = dtoAttachClearance.getFailure();
            String filureListofAttach = "";
            for (int i = 0; i < AttchmntFailurList.size(); i++) {
                String temp = AttchmntFailurList.get(i).toString();
                if (i >= 0 && i < AttchmntFailurList.size() - 1) {
                    filureListofAttach = filureListofAttach + temp + ",";
                } else {
                    filureListofAttach = filureListofAttach + temp;
                }

            }

            if (AttchmntFailurList.size() > 0) {

                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.initStyle(StageStyle.UTILITY);
                alert.setTitle("Compose Mail - Attachment Clearence");
                alert.setHeaderText(null);
                alert.setContentText("The Following Users are not authorized to Receive Attachment in a mail -" + filureListofAttach);
                alert.showAndWait();
                return false;
            }
            // }
        }

        try {
            System.out.println("BEFORE SENDING FILES" + m_fileList);
            retVal = "false";
            finalFilesArray = new File[m_fileList.size()];
            for (int i = 0; i < m_fileList.size(); i++) {
                finalFilesArray[i] = m_fileList.get(i);
            }
            Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
            alert1.setTitle("Confirmation-Send Mail");
            alert1.setHeaderText(null);
            alert1.setContentText("Are you sure to Send Mail");
            Optional<ButtonType> result = alert1.showAndWait();
            if (finalFilesArray.length != 0) {

                headers.put("attachment", true);
            } else {
                headers.put("attachment", false);
            }
            if (result.get() == ButtonType.OK) {
                if (securityStatusFlag) {
                    Stage stageSecurity = new Stage();
                    Parent rootSecurity;
                    FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/Security.fxml"));
                    rootSecurity = (Parent) fXMLLoader.load();
                    SecurityController securityController = fXMLLoader.getController();
                    stageSecurity.setScene(new Scene(rootSecurity));
                    stageSecurity.setTitle("Security");
                    stageSecurity.initModality(Modality.APPLICATION_MODAL);
//                stageTo.initOwner(OK.getScene().getWindow());
                    stageSecurity.toFront();
                    stageSecurity.getIcons().add(new Image("/img/Mail-icon.png"));
                    stageSecurity.showAndWait();
                    stageSecurity.setResizable(false);
                    stageSecurity.setResizable(false);

                    if (securityController.sendSecurityFlag) {
                        retVal = msghndlr.sendMailWthAtchmnt(input, finalFilesArray,securityStatusFlag);
                    }
                } else {
                    retVal = msghndlr.sendMailWthAtchmnt(input, finalFilesArray,securityStatusFlag);
                }
            }
        } catch (Exception e) {
            retVal = "false";
            System.err.println("exception is" + e);
        }

        if (retVal.equalsIgnoreCase("true")) {

            if (msghndlr.getAlarmProfiles(sm_name).getSuccessAlarm() != null) {
                m_successAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getSuccessAlarm();
                if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                    Draft_view_mailController.ALERT_AUDIOCLIP1.play();
                }
            }
//           
            Platform.runLater(() -> {
                Notifications.create().text("Send Mail-" + "\nMail Sent SuccessFully..").showInformation();
            });
//            dataTO.clear();
//            dataIntentedeTo.clear();
//            datacc.clear();
//            dataIntendedCC.clear();
//            databcc.clear();
//            dataIntendedBCC.clear();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Information-Send Mail");
            alert.setHeaderText(null);
            alert.setContentText("Mail Sent SuccessFully..");
            alert.showAndWait();

            final Node Source = (Node) event.getSource();
            final Stage stage = (Stage) Source.getScene().getWindow();
            stage.close();

        } else if (retVal.equalsIgnoreCase("false")) {
            if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                    Draft_view_mailController.ALERT_AUDIOCLIP5.play();
                }
            }

            Platform.runLater(() -> {
                Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
            });
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Error-Send Mail");
            alert.setHeaderText(null);
            alert.setContentText("Failed to Send Mail..");
            alert.showAndWait();

        } else if (retVal.equalsIgnoreCase("StoredInOutBox")) {
            if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                    Draft_view_mailController.ALERT_AUDIOCLIP5.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Send Mail-" + "\nStored In OutBox").showError();
            });
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Error-Send Mail");
            alert.setHeaderText(null);
            alert.setContentText("Stored In OutBox");
            alert.showAndWait();

        } else if (retVal.equalsIgnoreCase("No Sic List Found")) {
            if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                    Draft_view_mailController.ALERT_AUDIOCLIP5.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
            });
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Error-Send Mail");
            alert.setHeaderText(null);
            alert.setContentText("No Sic List Found");
            alert.showAndWait();

        } else if (retVal.equalsIgnoreCase("No Profile found")) {
            if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                    Draft_view_mailController.ALERT_AUDIOCLIP5.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
            });
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Error-Send Mail");
            alert.setHeaderText(null);
            alert.setContentText("No Profile found");
            alert.showAndWait();

        }
        return null;
    }
    int[] files;

    private String stripHTMLTags(String htmlText) {

        Pattern pattern = Pattern.compile("<[^>]*>");
        Matcher matcher = pattern.matcher(htmlText);
        final StringBuffer sb = new StringBuffer(htmlText.length());
        while (matcher.find()) {
            matcher.appendReplacement(sb, " ");
        }
        matcher.appendTail(sb);
        return sb.toString().trim();
    }

    public boolean checkboxrecept() {

        boolean isSelect = chk_bx_read_reqst.isSelected();
        if (isSelect) {
            chk_bx_read_reqst.setSelected(true);
        } else {
            chk_bx_read_reqst.setSelected(false);
        }
        return isSelect;

    }

    public boolean encryptionCheck() {
        boolean isSelect = chk_bx_encryption.isSelected();
        if (isSelect) {
            chk_bx_encryption.setSelected(true);
        } else {
            chk_bx_encryption.setSelected(false);
        }
        return isSelect;

    }

    /**
     * ******************************************************************
     * @Function Name : ViewDraftMails
     * @Description : for loading draft mail and viewing draft mail.
     * @Input Parameter :NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 5th June 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public void viewDraftMails() {
        try {
            MailDTO outputDTO;
            int c = Integer.parseInt(mail_id);

            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID(c);
            inputDTO.setFolder("drafts");

            outputDTO = msghndlr.readSpecificeMail(inputDTO);
            if (outputDTO.getHeaderMap().get("uid") != null) {
                System.out.println("UID: " + outputDTO.getHeaderMap().get("uid"));
            }

            outputDTO.getToRecipient();
            if (Subject != null || Subject != "") {
                Subject = outputDTO.getSubject();
            }
            if (body != null || body != "") {
                body = outputDTO.getContent();
            }
            outputDTO.getFrom();
            outputDTO.getAttachment();
            outputDTO.getBccRecipient();
            outputDTO.getCcRecipient();
            outputDTO.getMsgType();
            if (outputDTO.getHeaderMap().get("toOffice") != null) {
                toOffice = (String) outputDTO.getHeaderMap().get("toOffice");
            }

            if (outputDTO.getHeaderMap().get("ccOffice") != null) {
                ccOffice = (String) outputDTO.getHeaderMap().get("ccOffice");
            }
            if (outputDTO.getHeaderMap().get("bccOffice") != null) {
                bccOffice = (String) outputDTO.getHeaderMap().get("bccOffice");
            }
            if (outputDTO.getHeaderMap().get("originalReceiver") != null) {
                OriginalReceiver = (String) outputDTO.getHeaderMap().get("originalReceiver");
            }
            if (outputDTO.getHeaderMap().get("originalCc") != null) {
                OriginalCc = (String) outputDTO.getHeaderMap().get("originalCc");
            }
            if (outputDTO.getHeaderMap().get("originalBcc") != null) {
                OriginalBcc = (String) outputDTO.getHeaderMap().get("originalBcc");
            }
            if (outputDTO.getHeaderMap().get("Read_Receipt") != null) {
                Read_Receipt = (String) outputDTO.getHeaderMap().get("Read_Receipt");
            }
            if (outputDTO.getHeaderMap().get("sic") != null) {
                sic = (String) outputDTO.getHeaderMap().get("sic");
            }
            if (outputDTO.getHeaderMap().get("signed_receipt") != null) {
                outputDTO.getHeaderMap().get("signed_receipt");
            }
            if (outputDTO.getHeaderMap().get("signed_receipt_receiptto") != null) {
                outputDTO.getHeaderMap().get("signed_receipt_receiptto");
            }
            if (outputDTO.getHeaderMap().get("signed_receipt_receiptfrom") != null) {
                outputDTO.getHeaderMap().get("signed_receipt_receiptfrom");
            }
            if (outputDTO.getHeaderMap().get("encryption") != null) {
                encval = (String) outputDTO.getHeaderMap().get("encryption");
            }
            if (outputDTO.getHeaderMap().get("precedence") != null) {
                precedence = (String) outputDTO.getHeaderMap().get("precedence");
            }
            if (outputDTO.getHeaderMap().get("security_policy") != null) {
                security_policy = (String) outputDTO.getHeaderMap().get("security_policy");
            }
            if (outputDTO.getHeaderMap().get("security_category") != null) {
                security_category = (String) outputDTO.getHeaderMap().get("security_category");
            }
            if (outputDTO.getHeaderMap().get("security_privacy_mark") != null) {
                security_privacy_mark = (String) outputDTO.getHeaderMap().get("security_privacy_mark");
            }
            if (outputDTO.getHeaderMap().get("security_level") != null) {
                security_level = (String) outputDTO.getHeaderMap().get("security_level");
            }
            if (outputDTO.getHeaderMap().get("messageInstructions") != null) {
                msgInstruction = (String) outputDTO.getHeaderMap().get("messageInstructions");
            }
            if (outputDTO.getHeaderMap().get("messageType") != null) {
                messageType = (String) outputDTO.getHeaderMap().get("messageType");
            }
            if (outputDTO.getHeaderMap().get("msgType") != null) {
                outputDTO.getHeaderMap().get("msgType");
            }
            if (outputDTO.getHeaderMap().get("groupMailIdTo") != null) {
                outputDTO.getHeaderMap().get("groupMailIdTo");
            }
            if (outputDTO.getHeaderMap().get("groupMailIdCc") != null) {
                outputDTO.getHeaderMap().get("groupMailIdCc");
            }
            if (outputDTO.getHeaderMap().get("groupMailIdBcc") != null) {
                outputDTO.getHeaderMap().get("groupMailIdBcc");
            }

            if (outputDTO.getHeaderMap().get("attachedFileName") != null) {
                attach_file = (String) outputDTO.getHeaderMap().get("attachedFileName");
                System.out.println("ATTACHMENT FILE" + attach_file);
                String Split[] = attach_file.split(",");

                for (int i = 0; i < Split.length; i++) {
                    m_array.add(Split[i]);
                }
                System.out.println("Array values" + m_array);
                while (i < Split.length) {
                    for (j = 0; j < Split.length; j++) {
                        Label labl = new Label();
                        Button closeButton = new Button("X");
                        labl.setText(Split[j] + " ");

                        closeButton.setStyle("-fx-font-size:5pt;-fx-background-color:white;-fx-text-fill:red;-fx-font-weight:bold;");

                        m_attachLabel.add(labl, i, 0);

                        i++;

                        labl.setOnMouseEntered(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent e) {
                                labl.setStyle("-fx-font-weight:BOLD;-fx-text-fill:#090E00;-fx-background-color:#EEF6FF;-fx-font-size:13");
                                // if (send_mail.isVisible() == true) {
                                closeButton.setVisible(true);
                                labl.setGraphic(closeButton);
                                labl.setContentDisplay(ContentDisplay.TOP.RIGHT);
                                closeButton.setOnMouseClicked(e1 -> {
                                    m_attachLabel.getChildren().remove(labl);
                                    m_array.remove(labl.getText().trim());
                                    System.out.println("Array values After" + m_array);
                                });
                                // }

                            }
                        });

                        labl.setOnMouseExited(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent e) {
                                labl.setStyle("-fx-background-color:#F4F4F4;");

//                                if (send_mail.isVisible() == true) {
//                                    closeButton.setVisible(true);
//                                } else {
//                                    closeButton.setVisible(false);
//                                }
                            }
                        });
                        labl.setOnMousePressed((e) -> {

                            System.out.println("Attach FIle Name download:" + labl.getText());
                            String m_downloadFileName = labl.getText().trim();
                            //file_download(m_downloadFileName);

                        });

                    }
                }
            }

            // ObservableList<String> Policy_value = FXCollections.observableArrayList(security_policy);
            //  ObservableList<String> Category_value = FXCollections.observableArrayList(security_level);
//            ObservableList<String> combobox_category = FXCollections.observableArrayList(security_category);
//            ObservableList<String> combobox_precednc = FXCollections.observableArrayList(precedence);
            from_name.setText(outputDTO.getFrom());
            to_mail.setText(toOffice.toString());
            lblcc.setText(ccOffice);
            lblBCC.setText(bccOffice);
            lblIntendeTo.setText(OriginalReceiver + " " + groupMailIdTo);
            lblintendedcc.setText(OriginalCc + " " + GroupMailIdCc);
            lblintendedBCC.setText(OriginalBcc + " " + GroupMailIdBcc);
            if (groupMailIdTo.length() != 0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(groupMailIdTo);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedTo.setText(str.toString());
            }
            if (GroupMailIdCc.length() != 0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(GroupMailIdCc);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedCC.setText(str.toString());
            }
            if (GroupMailIdBcc.length() != 0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(GroupMailIdBcc);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedBCC.setText(str.toString());
            }
            lblBCC.setText(bccOffice);

            sub_textfield.setText(Subject);
            html_editor.setHtmlText(body);
            html_editor.setAccessibleText(body);
            Combobox_classification.setPromptText(security_level);

            txtPrivacy.setText(security_privacy_mark);
            Combobox_precednce.setPromptText(precedence);
            Combobox_category.setPromptText(security_category);
            Combobox_policy.setPromptText(security_policy);
            txtMsgInstruction.setText(msgInstruction);
            combBoxMsgType.setPromptText(messageType);
            if (Read_Receipt.equalsIgnoreCase("true")) {
                chk_bx_read_reqst.setSelected(true);
            }
            if (encval.equalsIgnoreCase("true")) {
                chk_bx_encryption.setSelected(true);
            }
            if (security_level.equalsIgnoreCase("TopSecret")) {
                change_lable.setText("TOP-SECRET");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: red;");
            } else if (security_level.equalsIgnoreCase("Secret")) {
                change_lable.setText("SECRET");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: orange;");
            } else if (security_level.equalsIgnoreCase("Confidential")) {
                System.out.println("Entered the confidential..........");
                change_lable.setText("CONFIDENTIAL");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: blue;");
            } else if (security_level.equalsIgnoreCase("Restricted")) {
                change_lable.setText("RESTRICTED");
                change_lable.setTextFill(Color.web("Black"));
                change_lable.setStyle("-fx-background-color: yellow;");
            } else if (security_level.equalsIgnoreCase("Unclassified")) {
                change_lable.setText("UNCLASSIFIED");
                change_lable.setTextFill(Color.web("black"));
                change_lable.setStyle("-fx-background-color: white;");
            }
            combBoxMsgType.setItems(MsgType);
            Combobox_policy.setItems(Policy_value);
            //classificationselect();
            Combobox_classification.setItems(Classification_value);
            Combobox_category.setItems(Category_value);
            Combobox_precednce.setItems(precedence_value);
//          classificationselect();    sub_textfield.setEditable(false);
//            html_editor.setDisable(false);
//            btnBCC.setDisable(true);
//            Compose_to_btn.setDisable(true);
//            IntendeTo.setDisable(true);
//            btncc.setDisable(true);
//            txtPrivacy.setEditable(false);
//            btnintendedcc.setDisable(true);
//            btnintendedBCC.setDisable(true);
//            lblattachfile.setDisable(true);
//            lblattachfile.setDisable(true);
//            chk_bx_single_reqst.setDisable(true);
//            txtSIC.setEditable(false);
//            chk_bx_encryption.setDisable(true);
//            txtPrivacy.setEditable(false);
//            html_editor.setDisable(true);

        } catch (Exception e) {

            System.out.println("View mail exception" + e);
        }
    }
//     public ObservableList<String> getSubList1(int start, int end) {
//
//        final ObservableList<String> toBeDisplayedList = FXCollections.<String>observableArrayList();
//        toBeDisplayedList.addAll(Classification_value.subList(start, end));
//        return toBeDisplayedList;
//    }

    /**
     * ******************************************************************
     * @Function Name : on_click_cancel
     * @Description : for closing draft mail view window
     * @Input Parameter :NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 5th June 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    private void on_click_cancel(ActionEvent event) {
        draft_mail_stage.close();
    }

    @FXML
    public void attach_action_btn(ActionEvent event) throws Exception {
        try {
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Open File");

            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("All files (*.*)", "*.*");
            // FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Files (*.txt,*.zip,*.rar,*.jpg,*.html,*.docx,*.pdf,*.pptx,*.png,*.gif,*.xlsx)", ".txt", "*.rar", "*.zip", "*.jpg", "*.html", "*.docx", "*.pdf", "*.pptx", "*.png", "*.gif", "*.xlsx");
            //FileChooser.ExtensionFilter extFilter1 = new FileChooser.ExtensionFilter("files (*.txt)", "*.txt");
            chooser.getExtensionFilters().add(extFilter);
            // chooser.getExtensionFilters().remove(extFilter1);

            //  chooser.setSelectedExtensionFilter(extFilter1);
            file = chooser.showOpenDialog(null);
            if (file.getName().endsWith("exe") || file.getName().endsWith("jar") || file.getName().endsWith("bat")) {
                System.out.println("Not able to attach");
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.initStyle(StageStyle.UTILITY);
                alert.setTitle("Warning-Attach File");
                alert.setHeaderText(null);
                alert.setContentText("Executable Files are  Not Allowed to Attach");
                alert.showAndWait();
            } else {
                System.out.println("file selected" + file);
                if (file.exists()) {
                    double bytes = file.length();
                    double kilobytes = (bytes / 1024);
                    double megabytes = (kilobytes / 1024);
                    double gigabyes = (megabytes / 1024);
                    double roundOffbytes = Math.floor(bytes * 100) / 100;
                    double roundOff = Math.floor(kilobytes * 100) / 100;
                    double roundOff1 = Math.floor(megabytes * 100) / 100;
                    double roundOffgb = Math.floor(gigabyes * 100) / 100;

                    Label m_fileName = new Label();

                    String filename = file.getName();

                    if (file.length() < 1024) {
                        m_fileName.setText(filename + "(" + roundOffbytes + " bytes" + ")");

                    } else if (file.length() >= 1024 && file.length() < (1024 * 1024)) {
                        m_fileName.setText(filename + "(" + roundOff + " KB" + ")");
                        //m_attachLabel.addRow(i, m_fileName);
                    } else if (file.length() >= (1024 * 1024) && file.length() < (1024 * 1024 * 1024)) {
                        m_fileName.setText(filename + "(" + roundOff1 + " MB" + ")");
                        // m_attachLabel.addRow(i, m_fileName);
                    } else if (file.length() >= (1024 * 1024 * 1024)) {
                        m_fileName.setText(filename + "(" + roundOffgb + " GB" + ")");
                        //m_attachLabel.addRow(i, m_fileName);
                    }
                    int i = 0;
                    isAttachment = checkFileSize();
                    if (isAttachment == true) {
                        Button closeButton = new Button("X");
                        closeButton.setStyle("-fx-font-size:5pt;-fx-background-color:white;-fx-text-fill:red;-fx-font-weight:bold;");
                        m_attachLabel.addRow(i, m_fileName);
                        m_fileName.setOnMouseEntered(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent e) {
                                m_fileName.setStyle("-fx-font-weight:BOLD;-fx-text-fill:#090E00;-fx-background-color:#EEF6FF;-fx-font-size:13");

                                closeButton.setVisible(true);
                                m_fileName.setGraphic(closeButton);
                                m_fileName.setContentDisplay(ContentDisplay.TOP.RIGHT);
                                closeButton.setOnMouseClicked(e1 -> {
                                    System.out.println("Before remove " + m_fileList);
                                    //StringBuffer name= new StringBuffer(m_fileName.getText().toString());

                                    //String m_splt[]=m_fileName.getText().split("(");
                                    int rmVal = 0;
                                    int removeIndexFile = -1;
                                    for (File remove_file : m_fileList) {

                                        String name = m_fileName.getText();
                                        System.out.println("File name Clicked" + name);

                                        System.out.println("ArrayList:" + remove_file.getName());
                                        System.out.println("name:" + name.toString());

                                        int firstIndex = name.lastIndexOf("(");
                                        //int lastIndex = name.lastIndexOf(")");
                                        name = name.subSequence(0, firstIndex).toString();

                                        System.out.println("value:" + name);

                                        if (remove_file.getName().equalsIgnoreCase(name)) {

                                            System.out.println("Removed..................");
                                            removeIndexFile = rmVal;
                                            //m_fileList.remove(remove_file);
                                            //m_fileList.remove(rmVal);

                                        } else {
                                            System.out.println("Not Removed..................");
                                        }
                                        rmVal++;
                                    }
                                    if (removeIndexFile != -1) {
                                        System.out.println("Test..." + removeIndexFile);
                                        m_fileList.remove(removeIndexFile);
                                        // m_fileList.clear();
                                        m_attachLabel.getChildren().remove(m_fileName);
                                    }

                                    System.out.println("After remove " + m_fileList);
                                });

                            }
                        });
                        m_fileName.setOnMouseExited(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent e) {
                                m_fileName.setStyle("-fx-background-color:#F4F4F4;");
                                closeButton.setVisible(false);

                            }
                        });

                    }

                } else {
                    if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                        m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                        if (m_warningFlag.equalsIgnoreCase("true")) {
                            Draft_view_mailController.ALERT_AUDIOCLIP2.play();
                        }
                    }

                    Platform.runLater(() -> {
                        Notifications.create().text("Warning" + "File Not Exist").showWarning();
                    });
                    System.out.println("file not exist");
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Warning");
                    alert.setHeaderText(null);
                    alert.setContentText("File Not Exist");
                    alert.showAndWait();
                    isAttachment = false;
                }

            }
        } catch (Exception e) {
            System.out.println("Error" + e);
        }

    }
    double roundOffbytes;
    double roundOff;
    double roundOff1;
    double roundOffgb;

    public boolean checkFileSize() {

        boolean retVal = false;
        if (file.length() > max_attch_size_allowed) {
            String msg = "";
            int rem_siz = max_attch_size_allowed;
            int int_siz = rem_siz;
            if (int_siz < 1024) {
                msg = (rem_siz) + " Bytes ";
            } else if (int_siz >= 1024 && int_siz < (1024 * 1024)) {
                msg = rem_siz / 1024 + " KB ";
            } else if (int_siz >= (1024 * 1024) && int_siz < (1024 * 1024 * 1024)) {
                msg = rem_siz / 1024 / 1024 + " MB ";
            } else if (int_siz >= (1024 * 1024 * 1024)) {
                msg = rem_siz / 1024 / 1024 / 1024 + " GB ";
            }
            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_infoAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                    Draft_view_mailController.ALERT_AUDIOCLIP1.play();
                }
            }

            Platform.runLater(() -> {
                Notifications.create().text("Warning - Add Attachment" + "\nFile size is exceed.").showInformation();
            });
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Add Attachment");
            alert.setHeaderText(null);
            alert.setContentText("File size is exceed.You can't send more than" + msg);
            alert.showAndWait();
            retVal = false;

        } else {
            System.out.println("File can able to send");
            retVal = true;
            m_fileList.add(file);

        }
        return retVal;
    }
    MailSenderInfo obj = msghndlr.preCheck(sm_name);

    public void attachmentAuthentication() {
        if (obj.getAttachmentSendAuth().equals("YES")) {
            String str = null;
            String str2 = null;
            if (obj.getAttachmentMaxSize().length() == 3) {
                str2 = (String) obj.getAttachmentMaxSize().substring(0, 1);
                System.out.println("size  1is: " + str2);
            } else if (obj.getAttachmentMaxSize().length() == 4) {
                str2 = (String) obj.getAttachmentMaxSize().substring(0, 2);
                System.out.println("in mb): " + str2);
            }

            if (obj.getAttachmentMaxSize().length() == 3) {
                str = (String) obj.getAttachmentMaxSize().substring(1, 3);
                System.out.println("size is: " + str);
            } else if (obj.getAttachmentMaxSize().length() == 4) {
                str = (String) obj.getAttachmentMaxSize().substring(2, 4);
                System.out.println("mb " + str);
            }

            if (str.equalsIgnoreCase("kb")) {

                int numKB = Integer.parseInt(str2);

                max_attch_size_allowed = numKB * 1024;

            } else if (str.equalsIgnoreCase("mb")) {
                int numMB = Integer.parseInt(str2);

                max_attch_size_allowed = numMB * 1024 * 1024;

            } else if (str.equalsIgnoreCase("gb")) {
                int numGB = Integer.parseInt(str2);
                max_attch_size_allowed = numGB * 1024 * 1024 * 1024;
            }

            attch_file.setDisable(false);
        } else {

            attch_file.setDisable(true);
        }
    }

}
