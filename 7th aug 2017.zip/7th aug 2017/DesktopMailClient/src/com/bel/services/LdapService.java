/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.services;


//import org.springframework.context.ApplicationContext;
//import org.springframework.context.support.ClassPathXmlApplicationContext;
//import org.springframework.ldap.core.LdapTemplate;
//import org.springframework.ldap.filter.EqualsFilter;
//import org.springframework.ldap.filter.Filter;
//
///**
// *
// * @author Admin
// */
public class LdapService {
//
//    private LdapTemplate ldapTemplate;
//
//    public LdapService() {
//        System.out.println("LdapService constructor.....started");
//       
//        ApplicationContext context = new ClassPathXmlApplicationContext("/com/bel/xmlFile/ldap_access.xml");
//        System.out.println("LdapService constructor.....first line executed");
//        this.ldapTemplate = context.getBean("ldapTemplate", LdapTemplate.class);
//        System.out.println("LdapService constructor.....completed");
//    }
//
//    public boolean authenticateUserCredentials(String userName, String password) {
//        System.out.println("authenticateUserCredentials.....invoked");
//        Filter filter = new EqualsFilter("cn", userName);
//        boolean valid = ldapTemplate.authenticate("ou=HQ,dc=tcs,dc=mil,dc=in", filter.encode(), password);
//        return valid;
//    }/*
}
