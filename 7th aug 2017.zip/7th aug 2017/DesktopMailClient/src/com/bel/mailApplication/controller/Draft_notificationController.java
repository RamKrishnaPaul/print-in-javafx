package com.bel.mailApplication.controller;

import com.entity.MailDTO;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import static com.bel.mailApplication.controller.FXMLDocumentController.mail_id;
import static com.bel.mailApplication.controller.FXMLDocumentController.notificatio_draft_mail;
import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import mail.awan.beans.ReceiveMailInputDTO;
import mail.awan.messageHandler.MessageHandler;
/**
 * ******************************************************************
 * @File Name           : Draft_notificationController.
 * @Author              : MANOJ KUMAR MEGHWAL.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display window  for  Draft page mail Notification.
 * @Created Date        :20-MAY-2017
 * @Modification History: NA.
*******************************************************************
 */
public class Draft_notificationController implements Initializable {
     @FXML
    private Label from_name;
    @FXML
    private Label to_mail,m_dateTime;
    @FXML
    private JFXButton cancel_btn_notification;
    @FXML
    private JFXButton ok_btn_notification;
    @FXML
    private TextArea body;
     private String Read_Receipt;

    private String From;
    private String Subject;
    private String Content;
    private String m_date;
    MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
                 /**
     * ******************************************************************
     * @Function Name           :initialize
     * @Description             : Method to call initialization function.
     * @Input Parameter         : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
     * @Author                  : MANOJ KUMAR MEGHWAL..
     * @Created Date            :20-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        MailDTO outputDTO;
        try {
            int c = Integer.parseInt(mail_id);
            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID(c);
            inputDTO.setFolder("drafts");
            outputDTO = msghndlr.readSpecificeMail(inputDTO);            
            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
            Content = outputDTO.getContent();
            From = (String) headers.get("From");
            String MsgType = (String) headers.get("msgType");
            Subject = (String) headers.get("Subject");
            m_date = (String) headers.get("Date");


        } catch (Exception e) {
            System.out.println("View mmail working");
        }
        to_mail.setText(Subject);
        from_name.setText(From);
        m_dateTime.setText(m_date);
       // body.appendText(Content);
               }
 /**
     * ******************************************************************
     * @Function Name            :on_click_notification_cancel.
     * @Description              : Method to Close Window.
     * @Input Parameter          : ActionEvent -provided by-JavaFX.
     * @Output Parameter	 : NA.
      * @Author                  : MANOJ KUMAR MEGHWAL.
     * @Created Date             :20-MAY-2017.
     * @Modification History     :NA.
     * ******************************************************************
     */
    @FXML
    private void on_click_notification_cancel(ActionEvent event) {
     notificatio_draft_mail.close();

    }
 /**
     * ******************************************************************
     * @Function Name               :click_ok_btn_notification.
     * @Description                 : Method to Close Window.
     * @Input Parameter             : ActionEvent -provided by-JavaFX.
     * @Output Parameter            : NA.
      * @Author                     : MANOJ KUMAR MEGHWAL..
     * @Created Date                :20-MAY-2017.
     * @Modification History        :NA.
     * ******************************************************************
     */
    @FXML
    private void click_ok_btn_notification(ActionEvent event) {
        notificatio_draft_mail.close(); 
            
    }
    
}
