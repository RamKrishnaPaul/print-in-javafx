package com.bel.mailApplication.controller;

import com.entity.MailDTO;
import static com.bel.mailApplication.controller.FXMLDocumentController.mail_id;
import static com.bel.mailApplication.controller.FXMLDocumentController.notificatio_mail;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import mail.awan.beans.ReceiveMailInputDTO;
import mail.awan.messageHandler.MessageHandler;

/**
 * ******************************************************************
 * @File Name           : System_NotificationController.
 * @Author              : MANOJ KUMAR MEGHWAL.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display window  for  View In Box page mail Notification.
 * @Created Date        :20-MAY-2017
 * @Modification History: NA.
*******************************************************************
 */
public class System_NotificationController implements Initializable {

    @FXML
    private Label from_name;
    @FXML
    private Label to_mail,m_dateTime,m_to,m_headerLabel;
    @FXML
    private JFXButton cancel_btn_notification;
    @FXML
    private JFXButton ok_btn_notification;
//    @FXML
//    private TextArea body;
    private String Read_Receipt;
    private String To;
    private String Subject;
    private String Content;
    private String m_date;
      private  String MsgType;
    MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
             /**
     * ******************************************************************
     * @Function Name           :initialize
     * @Description             : Method to call initialization function.
     * @Input Parameter         : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
     * @Author                 : MANOJ KUMAR MEGHWAL..
     * @Created Date            :20-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        MailDTO outputDTO;
        try {
            int c = Integer.parseInt(mail_id);

            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID(c);
            inputDTO.setFolder("inbox");

            outputDTO = msghndlr.readSpecificeMail(inputDTO);
            System.out.println("UID: " + outputDTO.getMailUID());
            System.out.println("Attachment: " + outputDTO.getAttachment());
            System.out.println("Bcc Recepient: " + outputDTO.getBccRecipient());
            System.out.println("Cc Recepient: " + outputDTO.getCcRecipient());
            System.out.println("Content: " + outputDTO.getContent());
            System.out.println("From: " + outputDTO.getFrom());
            System.out.println("Msg Type: " + outputDTO.getMsgType());
            System.out.println("Subject: " + outputDTO.getSubject());
            System.out.println("To Recepient: " + outputDTO.getToRecipient());
            System.out.println("====================================================");
            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();
            Content = outputDTO.getContent();
           // From = (String) headers.get("From");
            MsgType = (String) headers.get("msgType");
            Subject = (String) headers.get("Subject");
            Read_Receipt = (String) headers.get("read_receipt");
            m_date = (String) headers.get("Date");
            To=outputDTO.getToRecipient();
            if(MsgType.equalsIgnoreCase("READRECEIPT"))
            {
                m_headerLabel.setText("READ RECEIPT");
            }

        } catch (Exception e) {
            System.out.println("View mmail working");
        }
        String f_split[]=Content.split("The mail system");
				 
		String s_split[]=f_split[1].split("expanded from");
		System.out.println(s_split[1]);
		 int final_value=s_split[1].indexOf("<");
		 System.out.println(final_value);
		 int final_value2=s_split[1].indexOf(">");
		 System.out.println(final_value2);
		 String m_last=s_split[1].substring(final_value+1, final_value2);
		 System.out.println(m_last);
                 
        to_mail.setText(Subject);
        from_name.setText(m_last);
        m_dateTime.setText(m_date);
        m_to.setText(To);
//        MailBody.setText(Content);
   //body.appendText(Content);
           
    }
     /**
     * ******************************************************************
     * @Function Name            :on_click_notification_cancel.
     * @Description              : Method to Close Window.
     * @Input Parameter          : ActionEvent -provided by-JavaFX.
     * @Output Parameter	 : NA.
      * @Author                  : MANOJ KUMAR MEGHWAL.
     * @Created Date             :20-MAY-2017.
     * @Modification History     :NA.
     * ******************************************************************
     */

    @FXML
    private void on_click_notification_cancel(ActionEvent event) {
     notificatio_mail.close();
     //   notificatio_mail.hide();
    }
/**
     * ******************************************************************
     * @Function Name               :click_ok_btn_notification.
     * @Description                 : Method to Close Window.
     * @Input Parameter             : ActionEvent -provided by-JavaFX.
     * @Output Parameter            : NA.
      * @Author                     : MANOJ KUMAR MEGHWAL..
     * @Created Date                :20-MAY-2017.
     * @Modification History        :NA.
     * ******************************************************************
     */
    @FXML
    private void click_ok_btn_notification(ActionEvent event) {
        notificatio_mail.close(); 
            //notificatio_mail.hide();
    }

}
