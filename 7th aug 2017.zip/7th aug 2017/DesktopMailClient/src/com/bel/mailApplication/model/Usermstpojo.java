/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.model;

/**
 *
 * @author Ram Krishna Paul
 */
public class Usermstpojo {

    private String username;
    private String emailid;
    private int addrdtlid;
    private int userid;
    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public int getAddrdtlid() {
        return addrdtlid;
    }

    public void setAddrdtlid(int addrdtlid) {
        this.addrdtlid = addrdtlid;
    }

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public Usermstpojo(String username) {
        this.username = username;

    }

    public Usermstpojo(String username, String emailid) {
        this.username = username;
        this.emailid = emailid;
    }
    public Usermstpojo(String... emailid) {
        this.username = emailid[0];
        this.emailid = emailid[1];
        this.password=emailid[2];
    }
   
    public Usermstpojo(String username, int addrdtlid, int userid) {
        this.username = username;
        this.addrdtlid = addrdtlid;
        this.userid = userid;
    }

    public Usermstpojo() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "usermstpojo {\n"
                + "\t username=" + username + ",\n"
                + "\t emailid=" + emailid + ",\n"
                + "\t addrdtlid=" + addrdtlid + ",\n"
                + "}";

    }

}
