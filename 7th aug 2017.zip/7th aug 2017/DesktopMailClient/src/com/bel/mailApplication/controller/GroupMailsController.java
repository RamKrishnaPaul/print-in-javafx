package com.bel.mailApplication.controller;


import mail.awan.messageHandler.MessageHandler;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import com.itextpdf.text.pdf.languages.ArabicLigaturizer;
import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.SelectionMode;
import javafx.stage.Stage;
import mail.awan.beans.MailSenderInfo;
import org.controlsfx.control.CheckListView;

/**
 * ******************************************************************
 * @File Name           : GroupMailsController.
 * @Author	        : Ram Krishna Paul.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose	        : Display window for List of Group Mails .
 * @Created Date	:11-MAY-2017
 * @Modification History:NA.
 * ******************************************************************
 */
public class GroupMailsController implements Initializable {
   MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
    @FXML
    private JFXButton btnaddGroupMails;
    @FXML
    public CheckListView<String> listGroupMails;
    public List<String>m_selectedGroupMail;
    @FXML
    public ObservableList<String> data;

               /**
     * ******************************************************************
     * @Function Name        :initialize
     * @Description          : Method to call initialization function.
     * @Input Parameter      : URL url, ResourceBundle rb.
     * @Output Parameter     : NA.
      * @Author              : Ram Krishna Paul.
     * @Created Date         :11-APR-2017.
     * @Modification History :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        listGroupMails.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        data = FXCollections.observableArrayList();

        MailSenderInfo obj = messageHandler.preCheck(sm_name);

        List<String> list = messageHandler.getAllMailGroupNames();

        for (String listofGroup : list) {
            System.out.println(data);
            data.addAll(listofGroup);
            listGroupMails.setItems(data);
            listGroupMails.getCheckModel().getCheckedItems().addListener(new ListChangeListener<String>() {
                @Override
                public void onChanged(ListChangeListener.Change<? extends String> c) {
                    m_selectedGroupMail = listGroupMails.getCheckModel().getCheckedItems();
                    System.out.println("selectedIntendedToOffice"+m_selectedGroupMail);
                }
            });
        }

    }
      /**
     * ******************************************************************
     * @Function Name        :clickbtnaddGroupMails
     * @Description          : Method to add GroupMAails to list.
     * @Input Parameter      : ActionEvent -provided by-JavaFX.
     * @Output Parameter     : NA.
     * @Author               : Ram Krishna Paul.
     * @Created Date         :10-APR-2017.
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    private void clickbtnaddGroupMails(ActionEvent event) {
   
   List<String> grouplist=new ArrayList<String>();
//        List<String> data = listGroupMails.getSelectionModel().getSelectedItems();
        for (String Groupemails : m_selectedGroupMail) {
            grouplist.add(Groupemails);
          
        }
        StringBuilder groupmailIdsList = new StringBuilder();
        for(String grupList:grouplist){
        groupmailIdsList.append(grupList);
            System.out.println("groupmailIdsList"+groupmailIdsList);
//                      lblIntendeTo.setText(groupmailIdsList.toString());
        }

        
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
    }

}
