/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.controller;

import static com.bel.mailApplication.controller.ComposePageContrller.classificationvaleforIntendedTo;
import static com.bel.mailApplication.controller.ComposePageContrller.precedencevaleforIntendedTo;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.SelectionMode;
import javafx.stage.Stage;
import mail.awan.beans.CheckClearenceDTO;
import mail.awan.beans.MailSenderInfo;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.CheckListView;

/**
 * ******************************************************************
 * @File Name : IntendedBCCController.
 * @Author : Ram Krishna Paul.
 * @Package : com.bel.mailApplication.controller
 * @Purpose : Display window for IntendedBCC.
 * @Created Date	:8-MAY-2017
 * @Modification History:NA.
 * ******************************************************************
 */
public class IntendedBCCController implements Initializable {

    @FXML
    private Button btnIntendedBCC;
    private ObservableList<String> data;
    @FXML
    public ObservableList<String> datagroup;
    @FXML
    public CheckListView<String> ListIntendedBCC;
    public List<String> selectedIntendedBccOffice = new ArrayList<String>();
    public List<String> m_selectedbccGroupMail = new ArrayList<String>();
    MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
    @FXML
    private CheckListView<String> bcclistGroupMails;

    /**
     * ******************************************************************
     * @Function Name :initialize
     * @Description : Method to call initialization function.
     * @Input Parameter : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul.
     * @Created Date :8-MAY-2017.
     * @Modification History :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ListIntendedBCC.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        data = FXCollections.observableArrayList();
        String officename = messageHandler.ldapUserOffice(sm_name);
        List<String> li = new ArrayList<String>();
        li = ComposePageContrller.databccList();
        System.out.println("list is " + li);
        String[] obj = li.toArray(new String[0]);
        System.out.println("list of object is" + obj);
//        String maxAtchSize = msghndlr.getMaxAttachmentSizeOfTcsUser(name, officename);
        CheckClearenceDTO dto = new CheckClearenceDTO();
        dto.setOffice(obj);
        dto.setMaxSecurityClassificationView(classificationvaleforIntendedTo);
        dto.setAttachmentSize(0);
        dto.setMaxMessagePrecedence(precedencevaleforIntendedTo);
        if (obj.length != 0) {
            List<String> list = messageHandler.checkClearence(dto);
            System.out.println("In FX Object: " + list);
            for (String OfficeUserNames : list) {
//            System.out.println("Clearance Check data: " + OfficeUserNames);
                data.addAll(OfficeUserNames);
                ListIntendedBCC.setItems(data);
                ListIntendedBCC.getCheckModel().getCheckedItems().addListener(new ListChangeListener<String>() {
                    @Override
                    public void onChanged(ListChangeListener.Change<? extends String> c) {
                        selectedIntendedBccOffice = ListIntendedBCC.getCheckModel().getCheckedItems();

                    }
                });
            }
        }
        groupmail();
    }

    /**
     * ******************************************************************
     * @Function Name :groupmail
     * @Description : Method to iterate groupmail.
     * @Input Parameter :null
     * @Output Parameter	: group list.
     * @Author : Ram Krishna Paul.
     * @Created Date :14-JULY-2017.
     * @Modification History :NA.
     * ******************************************************************
     */
    public void groupmail() {
        MailSenderInfo obj = messageHandler.preCheck(sm_name);
        datagroup = FXCollections.observableArrayList();
        List<String> list = messageHandler.getAllMailGroupNames();

        for (String listofGroup : list) {
            System.out.println(datagroup);
            datagroup.addAll(listofGroup);
            bcclistGroupMails.setItems(datagroup);
            bcclistGroupMails.getCheckModel().getCheckedItems().addListener(new ListChangeListener<String>() {
                @Override
                public void onChanged(ListChangeListener.Change<? extends String> c) {
                    m_selectedbccGroupMail = bcclistGroupMails.getCheckModel().getCheckedItems();
//                    System.out.println("selectedIntendedToOffice" + m_selectedGroupMail);
                }
            });
        }
    }

    /**
     * ******************************************************************
     * @Function Name :ClickAddIntendedBCC
     * @Description : Method to add IntendedBCC to list.
     * @Input Parameter : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul.
     * @Created Date :8-MAY-2017.
     * @Modification History :NA.
     * ******************************************************************
     */
    @FXML
    private void clickAddIntendedBCC(ActionEvent event) {
        List<String> dataemailIntendedBCC = ListIntendedBCC.getSelectionModel().getSelectedItems();
        for (String emailIntendedBCC : dataemailIntendedBCC) {
        }
        // System.out.println("selected office is" + officeselected);
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
    }
}
