package com.bel.mailApplication.progress;

import com.bel.mailApplication.model.ApproveTabList;
import javafx.collections.ObservableList;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
/**
 * @File Name : ProgressServicesApproveMail
 * @author : Ram Krishna Paul
 * @Description: For creating task of Approve mail
 * @Package : com.bel.mailApplication.progress
 * @Created : 17th june 2017
 * @Modification History: NA
 */
public class ProgressServicesApproveMail extends Service<ObservableList<ApproveTabList>> {

    @Override
    protected Task createTask() {
        return new GetProgrssTaskApproveMail();
    }
}
