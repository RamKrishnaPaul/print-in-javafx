/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.controller;
import static com.bel.mailApplication.controller.Draft_view_mailController.classificationvaleforIntendedTo;
import static com.bel.mailApplication.controller.Draft_view_mailController.precedencevaleforIntendedTo;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.SelectionMode;
import javafx.stage.Stage;
import mail.awan.beans.CheckClearenceDTO;
import mail.awan.beans.MailSenderInfo;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.CheckListView;

/**
 * FXML Controller class
 *
 * @author Root
 */
public class IntendedCCDraftController implements Initializable {

  @FXML
    private Button AddIntendedCC;
    private ObservableList<String> data;
    @FXML
    public ObservableList<String> datagroup;
    @FXML
    public CheckListView<String> ListIntendedCC;
    public List<String> selectedIntendedccOffice = new ArrayList<String>();
    public List<String> m_selectedccGroupMail = new ArrayList<String>();
    MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
    @FXML
    private CheckListView<String> cclistGroupMails;

    /**
     * ******************************************************************
     * @Function Name :initialize
     * @Description : Method to call initialization function.
     * @Input Parameter : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul.
     * @Created Date :10-MAY-2017.
     * @Modification History :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ListIntendedCC.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        data = FXCollections.observableArrayList();
        String officename = messageHandler.ldapUserOffice(sm_name);
        List<String> li = new ArrayList<String>();
        li = Draft_view_mailController.dataccList();
//        System.out.println("list is " + li);
        String[] obj = li.toArray(new String[0]);
//        System.out.println("list of object is" + obj);
//        String maxAtchSize = msghndlr.getMaxAttachmentSizeOfTcsUser(name, officename);
        CheckClearenceDTO dto = new CheckClearenceDTO();
        dto.setOffice(obj);
        dto.setMaxSecurityClassificationView(classificationvaleforIntendedTo);
        dto.setAttachmentSize(0);
        dto.setMaxMessagePrecedence(precedencevaleforIntendedTo);
        List<String> list = messageHandler.checkClearence(dto);
        System.out.println("In FX Object: " + list);
        for (String OfficeUserNames : list) {
//            System.out.println("Clearance Check data: " + OfficeUserNames);
            data.addAll(OfficeUserNames);
            ListIntendedCC.setItems(data);
            ListIntendedCC.getCheckModel().getCheckedItems().addListener(new ListChangeListener<String>() {
                @Override
                public void onChanged(ListChangeListener.Change<? extends String> c) {
                    selectedIntendedccOffice = ListIntendedCC.getCheckModel().getCheckedItems();

                }
            });
        }
        groupmail();
    }

    /**
     * ******************************************************************
     * @Function Name :groupmail
     * @Description : Method to iterate groupmail.
     * @Input Parameter :null
     * @Output Parameter	: group list.
     * @Author : Ram Krishna Paul.
     * @Created Date :14-JULY-2017.
     * @Modification History :NA.
     * ******************************************************************
     */
    public void groupmail() {
        MailSenderInfo obj = messageHandler.preCheck(sm_name);
        datagroup = FXCollections.observableArrayList();
        List<String> list = messageHandler.getAllMailGroupNames();

        for (String listofGroup : list) {
            System.out.println(datagroup);
            datagroup.addAll(listofGroup);
            cclistGroupMails.setItems(datagroup);
            cclistGroupMails.getCheckModel().getCheckedItems().addListener(new ListChangeListener<String>() {
                @Override
                public void onChanged(ListChangeListener.Change<? extends String> c) {
                    m_selectedccGroupMail = cclistGroupMails.getCheckModel().getCheckedItems();
                    System.out.println("selectedIntendedToOffice" + m_selectedccGroupMail);
                }
            });
        }
    }

    /**
     * ******************************************************************
     * @Function Name :SelectAddIntendedCC
     * @Description : Method to add IntendedCC to list.
     * @Input Parameter : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author : Ram Krishna Paul.
     * @Created Date :10-MAY-2017.
     * @Modification History :NA.
     * ******************************************************************
     */

    @FXML
    private void selectAddIntendedCC(ActionEvent event) {
        List<String> dataemailIntendedCC = ListIntendedCC.getSelectionModel().getSelectedItems();
        for (String emailIntendedCC : dataemailIntendedCC) {
        }
        // System.out.println("selected office is" + officeselected);
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
    }

    
}
