package com.bel.mailApplication.controller;

import static com.bel.mailApplication.controller.LoginFXMLController.securityStatusFlag;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import com.entity.MailDTO;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.ldap.entity.Tcs_Users;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import mail.awan.messageHandler.MessageHandler;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Tooltip;
import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.web.HTMLEditor;
import javafx.stage.StageStyle;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import mail.awan.beans.AlarmProfilesDTO;
import mail.awan.beans.AttachmentClearenceDTO;
import mail.awan.beans.GetAllPrecedenceConfigDTO;
import mail.awan.beans.GetAllSecurityClassConfigDTO;
import mail.awan.beans.GroupMailInfo;
import mail.awan.beans.MailSenderInfo;
import mail.awan.beans.ResultDTO;
import org.controlsfx.control.Notifications;

/**
 * @File Name : ComposePageContrller
 * @author : Ram Krishna Paul
 * @Description: For compose and drafting of mail
 * @Package : com.bel.mailApplication.controller
 * @Created : April 2017
 * @Modification History: NA
 */
public class ComposePageContrller implements Initializable {

    private static final AudioClip ALERT_AUDIOCLIP1 = new AudioClip(ComposePageContrller.class.getResource("/sounds/sound1.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP2 = new AudioClip(ComposePageContrller.class.getResource("/sounds/sound2.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP4 = new AudioClip(ComposePageContrller.class.getResource("/sounds/sound4.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP5 = new AudioClip(ComposePageContrller.class.getResource("/sounds/sound5.wav").toString());
    @FXML
    private Button removeAttachment;
    @FXML
    private ImageView imgviewAttachment;
    @FXML
    public ComboBox<String> combBoxMsgType;
    @FXML
    private TextArea txtMsgInstruction;
    @FXML
    private ImageView imgviewto;
    @FXML
    private JFXCheckBox chkReadReceipt;
    @FXML
    private JFXCheckBox chkEncryption;
    @FXML
    private ComboBox Combobox_policy;
    @FXML
    private Button removeTo;
    @FXML
    private ComboBox Combobox_category;
    @FXML
    private TextField txtPrivacy;
    @FXML
    private Button Compose_to_btn;
    @FXML
    private Label from_name;
    @FXML
    private TextField text_fld;
    @FXML
    private TextField attach_txt_fld;
    @FXML
    private Label to_mail;
    @FXML
    public static Stage comose_to = new Stage();
    @FXML
    private ComboBox txtSIC;
    @FXML
    private Button removeIntendedTo;
    @FXML
    private ImageView imgviewintendedto;
    @FXML
    private Button IntendeTo;
    @FXML
    public Label lblIntendeTo;
    @FXML
    private JFXButton removeCC;
    @FXML
    private ImageView imgviewCC;
    @FXML
    private Label lblcc;
    @FXML
    private Button btncc;
    @FXML
    private Button removeIntendedCC;
    @FXML
    private ImageView imgviewIntendedCC;
    @FXML
    private Button btnintendedcc;
    @FXML
    private Label lblintendedcc;
    @FXML
    private Button removeBCC;
    @FXML
    private ImageView imgviewBCC;
    @FXML
    private Button btnBCC;
    @FXML
    private Label lblBCC;
    @FXML
    private ImageView imgviewIntendedBCC;
    @FXML
    private Button removeIntendeBCC;
    @FXML
    private Button btnintendedBCC;
    @FXML
    private Label lblintendedBCC;
    @FXML
    public static List<String> dataIntendedBCC = new ArrayList<>();
    @FXML
    public Button btnSignedReceipt;
    @FXML
    private CheckBox checkSignedReceipt = new CheckBox("Enabled");

    private Boolean isAttachment = false;
    @FXML
    private ComboBox Combobox_precednce;
    @FXML
    private Label change_lable;
    @FXML
    private ComboBox Combobox_classification;
    @FXML
    private Button send_mail;
    @FXML
    private TextField txtSubject;
    @FXML
    private HTMLEditor msgBody;
    @FXML
    public Button attch_file;
    @FXML
    private Button btnMsgOptionType;
    @FXML
    private Button cancel_mail;
    @FXML
    public GridPane m_attachLabel;
    @FXML
    private Tooltip m_tooltipIntendedTo;
    private boolean Attachflag = false;
    private ObservableList<String> SicList = FXCollections.observableArrayList();
    @FXML
    private ScrollPane m_id;

    protected static List<String> dataListIntendedTO() {
        return dataIntentedeTo;
    }

    protected static List<String> dataccList() {
        return datacc;
    }

    protected static List<String> dataList() {
        return dataTO;
    }

    protected static List<String> databccList() {
        return databcc;

    }

    public static File file = null;

    public static List<String> dataIntentedeTo = new ArrayList<>();
    public static List<String> datacc = new ArrayList<>();
    public static String precedencevalue = "";
    public static String classificationvlue = "";
    public static List<String> dataIntendedCC = new ArrayList<>();
    public static List<String> databcc = new ArrayList<>();
    public static List<String> dataTO = new ArrayList<>();
    public static String precedencevaleforIntendedTo = "";
    public static String classificationvaleforIntendedTo = "";
    public List<String> m_precedenceList = new ArrayList<String>();
    public List<String> m_classificationValue = new ArrayList<String>();
//    public ObservableList<String> precedence_value = FXCollections.observableArrayList("Flash", "Emergency", "OpImmediate", "Priority", "Routine", "Deferred");
//    public ObservableList<String> Classification_value = FXCollections.observableArrayList("TopSecret", "Secret", "Confidential", "Restricted", "Unclassified");
    public ObservableList<String> precedence_value;
    public ObservableList<String> Classification_value;
    public ObservableList<String> MsgType = FXCollections.observableArrayList("Exercise", "Operation", "Project", "Drill");
    public ObservableList<String> Policy_value = FXCollections.observableArrayList("NATO", "National");
    public ObservableList<String> Category_value = FXCollections.observableArrayList("Restrictive", "Permissive", "Informative");
    public String intendedEmailList = "";
    public String intendedccEmailList = "";
    public String intendedbccEmailList = "";
    //  public  File[] m_fileList = new File[1];
    // public File[] m_fileList = new File[1];
    ArrayList<File> m_fileListFTP = new ArrayList<File>();
    ArrayList<File> m_fileList = new ArrayList<File>();
    File finalFilesArray[];
    File m_finalArrayFTP[];
    public final BooleanProperty selectbtnSignedReceipt = new SimpleBooleanProperty();
    public String username = sm_name;
    MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
    Tcs_Users user = msghndlr.getTcsUser(username, msghndlr.preCheck(username).getOfficeName());
    public String reviewer = user.getReviewer();
    public String approver = user.getApprover();
    public String msgTypee = "";
    public String txtmessageInstruction = "";
    public String email1 = "";
    public StringBuilder listdatacc = new StringBuilder();
    public String FinalEmailCC = "";

    public String FinalEmailIntendedbccmail = "";
    public StringBuilder listdatBcc = new StringBuilder();
    public String precedenceOfTcsUser;
    public String classification;
    public String subject;
    public String body;
    public String senderOfficeName = "";
    public String getMailID = "";
    public int max_attch_size_allowed;
    public String policyValue = "";
    public String categoryValue = "";
    public String SICVal = "";
    public StringBuilder toUser = new StringBuilder();
    public String FinalEmailIntendedBcc = "";

    public List<String> AttchmntSuccessList;
    public List<String> AttchmntFailurList;
    public String encval = "";
    public String finalEmailList = "";
    public String securityMark = "";
    public String sicvalue = "";
    public ArrayList<String> mailIds = new ArrayList<String>();
    IntendedToController intendedToController;
    MailSenderInfo obj = msghndlr.preCheck(username);
    AlarmProfilesDTO alarmProfilesDTO = msghndlr.getAlarmProfiles(sm_name);
    public String m_successAlarmFlag;
    public String m_errorAlarmFlag;
    public String m_infoAlarmFlag;
    public String m_warningFlag;

    /**
     * ******************************************************************
     * @Function Name : Compose_to
     * @Description : for choosing office for To users
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 15th March 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void compose_To(ActionEvent event) throws IOException {
        runTask();
        if (lblIntendeTo != null) {
            lblIntendeTo.setText(null);
            dataTO.clear();
            m_groupdata.clear();
            dataIntentedeTo.clear();
        }
        List<String> toVal = new ArrayList<>();
        Stage stageTo = new Stage();
        Parent rootTo;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/To_mail.fxml"));
        rootTo = (Parent) fXMLLoader.load();
        To_mail_Controller to_mail_Controller = fXMLLoader.getController();
        stageTo.setScene(new Scene(rootTo));
        stageTo.setTitle("Send Mail To");
        stageTo.initModality(Modality.APPLICATION_MODAL);
        stageTo.initOwner(Compose_to_btn.getScene().getWindow());
        stageTo.toFront();
        stageTo.showAndWait();
        stageTo.setResizable(false);
//        data = to_mail_Controller.add_list.getSelectionModel().getSelectedItems();

        // dataTO = to_mail_Controller.selectedToOffice;
        toVal = to_mail_Controller.selectedToOffice;
        dataTO.clear();

        if (toVal.size() != 0) {
            for (String str_To : toVal) {
                dataTO.add(str_To);
            }

            toUser = new StringBuilder();
            for (String userTo : dataTO) {
                toUser.append(userTo + ",");
            }

            to_mail.setText(toUser.toString());
            removeTo.setVisible(true);
            imgviewto.setVisible(true);

            ObservableList<String> sicList = FXCollections.observableArrayList();
            List<Map<Object, Object>> list = msghndlr.getnewSicList(dataTO);
            for (Map m_sicvalue : list) {
                Set set = m_sicvalue.entrySet();
                Iterator itr = set.iterator();
                while (itr.hasNext()) {
                    Map.Entry m = (Map.Entry) itr.next();

                    sicList.add((String) m.getKey());
                }
            }
            txtSIC.setItems(sicList);
        }
    }

    /**
     * ******************************************************************
     * @Function Name : ClickRemoveTo
     * @Description : for Removing To office name
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 15th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void clickRemoveTo(ActionEvent event) throws IOException {
        to_mail.setText(null);
        removeTo.setVisible(false);
        imgviewto.setVisible(false);
        lblIntendeTo.setText(null);
        imgviewintendedto.setVisible(false);
        removeIntendedTo.setVisible(false);
        dataTO.clear();
        m_groupdata.clear();
        dataIntentedeTo.clear();
        txtSIC.setDisable(false);
        txtSIC.setItems(SicList);
    }

    /**
     * ******************************************************************
     * @Function Name : textintendedto
     * @Description : for disabling and enabling of SIC value on selection of
     * intendedTo
     * @Input Parameter : null
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 15th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public void textintendedto() {

        if (lblIntendeTo.getText() == null || lblIntendeTo.getText().isEmpty()) {
            txtSIC.setDisable(false);
        } else {
            txtSIC.setDisable(true);
            txtSIC.setItems(null);
        }
    }

    /**
     * ******************************************************************
     * @Function Name : OpenIntendeTo
     * @Description : for adding intended to users
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 15th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public List<String> m_groupdata = new ArrayList<String>();

    public StringBuilder m_finalGroupMembers;
    String m_groupEmails = "";
    String groupEmails = "";

    @FXML
    public void openIntendeTo(ActionEvent event) throws IOException, InterruptedException {

        if (Combobox_precednce.getValue() == null) {
            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_warningFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP2.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Select Precedence and Security Label!").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Compose Mail-");
            alert.setHeaderText(null);
            alert.setContentText("Please Select Precedence and Security Label!");
            alert.showAndWait();

        } else if (Combobox_classification.getValue() == null) {
            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_warningFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP2.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Select Classification Label!").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Compose Mail-");
            alert.setHeaderText(null);
            alert.setContentText("Please Select Classification Label!");
            alert.showAndWait();

        } else {
            classificationvaleforIntendedTo = Combobox_classification.getSelectionModel().getSelectedItem().toString();
            precedencevaleforIntendedTo = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
            List<String> intendedToVal = new ArrayList<>();
            List<String> m_intendedgroupOffice = new ArrayList<>();
            Stage stageIntendedTo = new Stage();
            Parent rootIntendedTo;
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/IntendedTo.fxml"));
            rootIntendedTo = (Parent) fXMLLoader.load();
            intendedToController = fXMLLoader.getController();
            stageIntendedTo.setScene(new Scene(rootIntendedTo));
            stageIntendedTo.setTitle("Intended To");
            stageIntendedTo.initModality(Modality.APPLICATION_MODAL);
            stageIntendedTo.initOwner(IntendeTo.getScene().getWindow());
            stageIntendedTo.toFront();
            stageIntendedTo.showAndWait();
            stageIntendedTo.setResizable(false);
            stageIntendedTo.getIcons().add(new Image("/img/Mail-icon.png"));
            intendedToVal = intendedToController.selectedIntendedToOffice;
            m_intendedgroupOffice = intendedToController.m_selectedGroupMail;

            String m_intendetoval = "";
            StringBuilder str = null;
            Set<String> m_officename = null;
            /////////////////////////////////Group mail///////////////////////////////////////////////////////// 
            if (m_intendedgroupOffice.size() != 0) {
                m_groupdata.clear();
                for (String m_userGroup : m_intendedgroupOffice) {
                    m_groupdata.add(m_userGroup);
                }
                StringBuilder m_listdataGroup = new StringBuilder();;

                for (String m_emailGroup : m_groupdata) {
                    m_listdataGroup.append(m_emailGroup + ",");
                    groupEmails += m_emailGroup + ",";
                }
                StringBuilder finalGroupEmail = m_listdataGroup;
                if (finalGroupEmail != null || !finalGroupEmail.equals("")) {
                    m_groupEmails = finalGroupEmail.substring(0, finalGroupEmail.length() - 1);
                    groupEmails = m_groupEmails;
                } else {
                    groupEmails = m_groupEmails;
                }

                List<String> m_toGroup = new ArrayList<String>();
                for (String mailGroupName : m_groupdata) {
                    GroupMailInfo groupMailInfo = msghndlr.getMailGroup(mailGroupName);
                    List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                    m_officename = (Set<String>) groupMailInfo.getOfficeNames();

                    String strr = "";
                    str = new StringBuilder(strr);
                    for (String memberMailId : memberMailIdsList) {
                        str.append(memberMailId + ",");
                    }
                    for (String m_groupOffice : m_officename) {
                        m_toGroup.add(m_groupOffice);
                    }
                    String m_fgroupemailoffice = "";
                    StringBuilder group = new StringBuilder();
                    for (String m_finalGroup : m_toGroup) {
                        group.append(m_finalGroup + ",");
                        m_fgroupemailoffice += m_finalGroup + ",";
                    }
                }
                Set<String> m_fTo = new HashSet<String>(m_toGroup);
                m_fTo.addAll(dataTO);

                List<String> finalSortedList = new ArrayList<>(m_fTo);
//                System.out.println("finalSortedList" + finalSortedList);
                StringBuilder m_finalOfficeTo = new StringBuilder();
                String m_finalTo = "";
                for (String str1 : finalSortedList) {
                    m_finalOfficeTo.append(str1 + ",");
                    m_finalTo += str1 + ",";
                }
                if (finalSortedList.size() > 0) {
                    dataTO = finalSortedList;
                }
//                System.out.println("m_finalTo" + m_finalTo);
                to_mail.setText(m_finalTo);
                removeTo.setVisible(true);
                imgviewto.setVisible(true);
                m_toGroup.clear();
//                dataTO.clear();

            }
            /////////////////////////////////////////////Group mail//////////////////////////////////////////////   
            if (intendedToVal.size() != 0) {
                dataIntentedeTo.clear();
                for (String str_IntendedTo : intendedToVal) {
                    dataIntentedeTo.add(str_IntendedTo);
                }
                StringBuilder mailIdsList = new StringBuilder();
                for (String email : dataIntentedeTo) {
                    mailIdsList.append(email + ",");
                    email1 += email + ",";
                }
                StringBuilder finalEmail = new StringBuilder(mailIdsList);
                String intendedTo = "";
                if (finalEmail != null || !finalEmail.equals("")) {
                    intendedTo = finalEmail.substring(0, finalEmail.length() - 1);
                    m_intendetoval = intendedTo;
                } else {
                    m_intendetoval = intendedTo;
                }
            }
            intendedEmailList = m_intendetoval;
            lblIntendeTo.setText(groupEmails + " " + intendedEmailList);

            removeIntendedTo.setVisible(true);
            imgviewintendedto.setVisible(true);
            m_tooltipIntendedTo.setText(intendedEmailList);
            if (str != null) {
                m_tooltipIntendedTo.setText(str.toString().substring(0, str.toString().length() - 1));
            }
        }
        textintendedto();
    }

    /**
     * ******************************************************************
     * @Function Name : ClickRemoveIntendedTo
     * @Description : for removing intended to users
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date :10th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void clickRemoveIntendedTo(ActionEvent event) {
        m_groupdata.clear();
        dataIntentedeTo.clear();

        lblIntendeTo.setText(null);
        removeIntendedTo.setVisible(false);
        imgviewintendedto.setVisible(false);
        txtSIC.setDisable(false);
        txtSIC.setItems(SicList);

    }

    /**
     * ******************************************************************
     * @Function Name : ClickBtnCC
     * @Description : for adding cc office name
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date :10th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void clickBtnCC(ActionEvent event) throws IOException {
        if (lblintendedcc != null) {
            lblintendedcc.setText(null);
            datacc.clear();
            dataIntendedCC.clear();
            m_groupintendedccdata.clear();
        } //        if (lblIntendeTo.getText() == null || lblIntendeTo.getText().isEmpty()) {
        //            ComposePageContrller.ALERT_AUDIOCLIP2.play();
        //            Platform.runLater(() -> {
        //                Notifications.create().text("Compose Mail-" + "\nPlease Intended To").showWarning();
        //            });
        //            Alert alert = new Alert(Alert.AlertType.WARNING);
        //            alert.initStyle(StageStyle.UTILITY);
        //            alert.setTitle("Compose Mail");
        //            alert.setHeaderText(null);
        //            alert.setContentText("Please Select Intended To ");
        //            alert.showAndWait();
        //
        //        } 

        List<String> ccVal = new ArrayList<>();
        Stage stageCC = new Stage();
        Parent root1;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/CCFXML.fxml"));
        root1 = (Parent) fXMLLoader.load();
        CCFXMLController cCFXMLController = fXMLLoader.getController();
        stageCC.setScene(new Scene(root1));
        stageCC.setTitle("CC");
        stageCC.initModality(Modality.APPLICATION_MODAL);
        stageCC.initOwner(btncc.getScene().getWindow());
        stageCC.toFront();
        stageCC.showAndWait();
        stageCC.setResizable(false);
        stageCC.getIcons().add(new Image("/img/Mail-icon.png"));
        ccVal = cCFXMLController.selectedccOffice;
        datacc.clear();
        for (String str_CC : ccVal) {
            datacc.add(str_CC);
        }
        listdatacc = new StringBuilder();
        for (String recDataFromCC : datacc) {
            listdatacc.append(recDataFromCC + ",");
        }
        System.out.println("listdatacc" + listdatacc.toString());
        lblcc.setText(listdatacc.toString());
        removeCC.setVisible(true);
        imgviewCC.setVisible(true);

    }

    /**
     * ******************************************************************
     * @Function Name : ClickRemoveCC
     * @Description : for removing of cc office name
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 10th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void clickRemoveCC(ActionEvent event) {

        datacc.clear();
        m_groupintendedccdata.clear();
        dataIntendedCC.clear();
        lblcc.setText(null);
        removeCC.setVisible(false);
        imgviewCC.setVisible(false);
        removeIntendedCC.setVisible(false);
        imgviewIntendedCC.setVisible(false);
        lblintendedcc.setText(null);
    }

    /**
     * ******************************************************************
     * @Function Name : onClickIntendedCC
     * @Description : for adding intended CC users
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 10th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public List<String> m_groupintendedccdata = new ArrayList<String>();

    String m_groupCCEmails = "";
    String groupccEmails = "";
    @FXML
    private Tooltip m_tooltipIntendedcc;

    @FXML
    public void onClickIntendedCC(ActionEvent event) throws IOException {
//        if (lblcc.getText() == null || lblcc.getText().isEmpty()) {
//            ComposePageContrller.ALERT_AUDIOCLIP2.play();
//            Platform.runLater(() -> {
//                Notifications.create().text("Compose Mail-" + "\nPlease Select CC").showWarning();
//            });
//            Alert alert = new Alert(Alert.AlertType.WARNING);
//            alert.initStyle(StageStyle.UTILITY);
//            alert.setTitle("Compose Mail");
//            alert.setHeaderText(null);
//            alert.setContentText("Please Select CC ");
//            alert.showAndWait();
//
//        }
        if (Combobox_precednce.getValue() == null) {
            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_warningFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP2.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Select Precedence and Security Label!").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Compose Mail-");
            alert.setHeaderText(null);
            alert.setContentText("Please Select Precedence and Security Label!");
            alert.showAndWait();

        } else if (Combobox_classification.getValue() == null) {
            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_warningFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP2.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Select Classification Label!").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Compose Mail-");
            alert.setHeaderText(null);
            alert.setContentText("Please Select Classification Label!");
            alert.showAndWait();

        } else {
            classificationvaleforIntendedTo = Combobox_classification.getSelectionModel().getSelectedItem().toString();
            precedencevaleforIntendedTo = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
            List<String> intendedccVal = new ArrayList<>();
            List<String> m_intendedgroupccVal = new ArrayList<>();
            Stage stageIntendedCC = new Stage();
            Parent rootintendedCC;
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/IntendedCCFXML.fxml"));
            rootintendedCC = (Parent) fXMLLoader.load();
            IntendedCCController intendedCCController = fXMLLoader.getController();
            stageIntendedCC.setScene(new Scene(rootintendedCC));
            stageIntendedCC.setTitle("Intended CC");
            stageIntendedCC.initModality(Modality.APPLICATION_MODAL);
            stageIntendedCC.initOwner(btnintendedcc.getScene().getWindow());
            stageIntendedCC.toFront();
            stageIntendedCC.showAndWait();
            stageIntendedCC.setResizable(false);
//            dataIntendedCC = intendedCCController.ListIntendedCC.getSelectionModel().getSelectedItems();
            intendedccVal = intendedCCController.selectedIntendedccOffice;
            m_intendedgroupccVal = intendedCCController.m_selectedccGroupMail;
            System.out.println("m_intendedgroupccVal is" + m_intendedgroupccVal.toString());
            String m_intendedccval = "";
            StringBuilder m_strintendedcc = null;
            Set<String> m_ccofficename = null;
            /////////////////////////////////Group mail///////////////////////////////////////////////////////// 
            if (m_intendedgroupccVal.size() != 0) {
                m_groupintendedccdata.clear();
                for (String m_userGroup : m_intendedgroupccVal) {
                    m_groupintendedccdata.add(m_userGroup);
                }
                StringBuilder m_listdataGroup = new StringBuilder();;

                for (String m_emailGroup : m_groupintendedccdata) {
                    m_listdataGroup.append(m_emailGroup + ",");
                    groupccEmails += m_emailGroup + ",";
                }
                StringBuilder finalGroupEmail = m_listdataGroup;
                if (finalGroupEmail != null || !finalGroupEmail.equals("")) {
                    m_groupCCEmails = finalGroupEmail.substring(0, finalGroupEmail.length() - 1);
                    groupccEmails = m_groupCCEmails;
                } else {
                    groupccEmails = m_groupCCEmails;
                }

                List<String> m_ccGroup = new ArrayList<String>();
                for (String mailGroupName : m_groupintendedccdata) {
                    GroupMailInfo groupMailInfo = msghndlr.getMailGroup(mailGroupName);
                    List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                    m_ccofficename = (Set<String>) groupMailInfo.getOfficeNames();

                    String strr = "";
                    m_strintendedcc = new StringBuilder(strr);
                    for (String memberMailId : memberMailIdsList) {
                        m_strintendedcc.append(memberMailId + ",");
                    }
                    for (String m_groupOffice : m_ccofficename) {
                        m_ccGroup.add(m_groupOffice);
                    }
                    String m_fgroupemailoffice = "";
                    StringBuilder group = new StringBuilder();
                    for (String m_finalGroup : m_ccGroup) {
                        group.append(m_finalGroup + ",");
                        m_fgroupemailoffice += m_finalGroup + ",";
                    }
                }
                Set<String> m_fTo = new HashSet<String>(m_ccGroup);
                m_fTo.addAll(datacc);

                List<String> finalSortedList = new ArrayList<>(m_fTo);
                System.out.println("finalSortedList" + finalSortedList);
                StringBuilder m_finalOfficeCC = new StringBuilder();
                String m_finalcc = "";
                for (String str1 : finalSortedList) {
                    m_finalOfficeCC.append(str1 + ",");
                    m_finalcc += str1 + ",";
                }
                if (finalSortedList.size() > 0) {
                    datacc = finalSortedList;
                }
//                System.out.println("m_finalTo" + m_finalTo);
                lblcc.setText(m_finalcc);
                m_ccGroup.clear();
                removeCC.setVisible(true);
                imgviewCC.setVisible(true);
            }
            /////////////////////////////////////////////Group mail//////////////////////////////////////////////               

            if (intendedccVal.size() != 0) {
                dataIntendedCC.clear();
                for (String str_Intendedcc : intendedccVal) {
                    dataIntendedCC.add(str_Intendedcc);
                }
                StringBuilder emailIntendedCC = new StringBuilder();
                for (String emailintendedCC : dataIntendedCC) {
                    emailIntendedCC.append(emailintendedCC + ",");
                    FinalEmailCC += emailintendedCC + ",";
                }
                StringBuilder finalEmail = new StringBuilder(emailIntendedCC);
                String intendedcc = "";
                if (finalEmail != null || !finalEmail.equals("")) {
                    intendedcc = finalEmail.substring(0, finalEmail.length() - 1);
                    m_intendedccval = intendedcc;
                } else {
                    m_intendedccval = intendedcc;
                }
            }
            intendedccEmailList = m_intendedccval;
            lblintendedcc.setText(groupccEmails + " " + intendedccEmailList);

            removeIntendedCC.setVisible(true);
            imgviewIntendedCC.setVisible(true);
            m_tooltipIntendedcc.setText(intendedccEmailList);
            if (m_strintendedcc != null) {
                m_tooltipIntendedcc.setText(m_strintendedcc.toString().substring(0, m_strintendedcc.toString().length() - 1));
            }
        }
    }

    /**
     * ******************************************************************
     * @Function Name : ClickremoveIntendedCC
     * @Description : for removing of intended CC users
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 15th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void clickremoveIntendedCC(ActionEvent event) throws IOException, Exception {
        m_groupintendedccdata.clear();
        dataIntendedCC.clear();
        lblintendedcc.setText(null);
        removeIntendedCC.setVisible(false);
        imgviewIntendedCC.setVisible(false);
    }

    /**
     * ******************************************************************
     * @Function Name : onClickbtnBCC
     * @Description : for adding BCC office
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 15th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void onClickbtnBCC(ActionEvent event) throws IOException {
        if (lblintendedBCC != null) {
            lblintendedBCC.setText(null);
            databcc.clear();
            dataIntendedBCC.clear();
        }
        List<String> bccVal = new ArrayList<>();
        Stage stageBCC = new Stage();
        Parent rootBCC;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/BCC.fxml"));
        rootBCC = (Parent) fXMLLoader.load();
        BCCController bCCController = fXMLLoader.getController();
        stageBCC.setScene(new Scene(rootBCC));
        stageBCC.setTitle("BCC");
        stageBCC.initModality(Modality.APPLICATION_MODAL);
        stageBCC.initOwner(btnBCC.getScene().getWindow());
        stageBCC.toFront();
        stageBCC.showAndWait();
        stageBCC.setResizable(false);
//            databcc = bCCController.ListBCC.getSelectionModel().getSelectedItems();
        bccVal = bCCController.selectedBccOffice;
        databcc.clear();
        for (String str_bcc : bccVal) {
            databcc.add(str_bcc);
        }
        listdatBcc = new StringBuilder();

        for (String userBcc : databcc) {
            listdatBcc.append(userBcc + ",");
        }
        lblBCC.setText(listdatBcc.toString());
        imgviewBCC.setVisible(true);
        removeBCC.setVisible(true);
//        }
    }

    /**
     * ******************************************************************
     * @Function Name : ClickremoveBCC
     * @Description : for removing BCC office
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void clickremoveBCC(ActionEvent event) throws IOException {
        databcc.clear();
        m_groupintendedbccdata.clear();
        dataIntendedBCC.clear();
        lblBCC.setText(null);
        imgviewBCC.setVisible(false);
        removeBCC.setVisible(false);
        imgviewIntendedBCC.setVisible(false);
        removeIntendeBCC.setVisible(false);
        lblintendedBCC.setText(null);
    }

    /**
     * ******************************************************************
     * @Function Name : clickbtnintendedBCC
     * @Description : for adding BCC users
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public List<String> m_groupintendedbccdata = new ArrayList<String>();

    String m_groupBCCEmails = "";
    String groupbccEmails = "";
    @FXML
    private Tooltip m_tooltipIntendedbcc;

    @FXML
    public void clickbtnintendedBCC(ActionEvent event) throws IOException {
//        if (lblBCC.getText() == null || lblBCC.getText().isEmpty()) {
//            ComposePageContrller.ALERT_AUDIOCLIP2.play();
//            Platform.runLater(() -> {
//                Notifications.create().text("Compose Mail-" + "\nPlease Select BCC").showWarning();
//            });
//            Alert alert = new Alert(Alert.AlertType.WARNING);
//            alert.initStyle(StageStyle.UTILITY);
//            alert.setTitle("Compose Mail");
//            alert.setHeaderText(null);
//            alert.setContentText("Please Select BCC ");
//            alert.showAndWait();

        if (Combobox_precednce.getValue() == null) {
            m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
            if (m_warningFlag.equalsIgnoreCase("true")) {
                ComposePageContrller.ALERT_AUDIOCLIP2.play();
            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Select Precedence and Security Label!").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning-Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select Precedence and Security Label!");
            alert.showAndWait();

        } else if (Combobox_classification.getValue() == null) {
            m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
            if (m_warningFlag.equalsIgnoreCase("true")) {
                ComposePageContrller.ALERT_AUDIOCLIP2.play();
            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Select Classification Label!").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning-Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Select Classification Label!");
            alert.showAndWait();

        } else {
            classificationvaleforIntendedTo = Combobox_classification.getSelectionModel().getSelectedItem().toString();
            precedencevaleforIntendedTo = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
            List<String> intendedbccVal = new ArrayList<>();
            List<String> m_intendedgroupbccVal = new ArrayList<>();
            Stage stageIntedBCC = new Stage();
            Parent rootIntendedBCC;
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/IntendedBCC.fxml"));
            rootIntendedBCC = (Parent) fXMLLoader.load();
            IntendedBCCController intendedBCCController = fXMLLoader.getController();
            stageIntedBCC.setScene(new Scene(rootIntendedBCC));
            stageIntedBCC.setTitle("Intended BCC");
            stageIntedBCC.initModality(Modality.APPLICATION_MODAL);
            stageIntedBCC.initOwner(btnintendedBCC.getScene().getWindow());
            stageIntedBCC.toFront();
            stageIntedBCC.showAndWait();
            stageIntedBCC.setResizable(false);
//            dataIntendedBCC = intendedBCCController.ListIntendedBCC.getSelectionModel().getSelectedItems();
            intendedbccVal = intendedBCCController.selectedIntendedBccOffice;
            m_intendedgroupbccVal = intendedBCCController.m_selectedbccGroupMail;
            String m_intendedbccval = "";
            StringBuilder m_strintendedbcc = null;
            Set<String> m_bccofficename = null;
            /////////////////////////////////Group mail///////////////////////////////////////////////////////// 
            if (m_intendedgroupbccVal.size() != 0) {
                m_groupintendedbccdata.clear();
                for (String m_userGroup : m_intendedgroupbccVal) {
                    m_groupintendedbccdata.add(m_userGroup);
                }
                StringBuilder m_listdatabccGroup = new StringBuilder();

                for (String m_emailGroup : m_groupintendedbccdata) {
                    m_listdatabccGroup.append(m_emailGroup + ",");
                    groupbccEmails += m_emailGroup + ",";
                }
                StringBuilder finalGroupEmail = m_listdatabccGroup;
                if (finalGroupEmail != null || !finalGroupEmail.equals("")) {
                    m_groupBCCEmails = finalGroupEmail.substring(0, finalGroupEmail.length() - 1);
                    groupbccEmails = m_groupBCCEmails;
                } else {
                    groupbccEmails = m_groupBCCEmails;
                }

                List<String> m_bccGroup = new ArrayList<String>();
                for (String mailGroupName : m_groupintendedbccdata) {
                    GroupMailInfo groupMailInfo = msghndlr.getMailGroup(mailGroupName);
                    List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                    m_bccofficename = (Set<String>) groupMailInfo.getOfficeNames();

                    String strr = "";
                    m_strintendedbcc = new StringBuilder(strr);
                    for (String memberMailId : memberMailIdsList) {
                        m_strintendedbcc.append(memberMailId + ",");
                    }
                    for (String m_groupOffice : m_bccofficename) {
                        m_bccGroup.add(m_groupOffice);
                    }
                    String m_fgroupemailbccoffice = "";
                    StringBuilder group = new StringBuilder();
                    for (String m_finalGroup : m_bccGroup) {
                        group.append(m_finalGroup + ",");
                        m_fgroupemailbccoffice += m_finalGroup + ",";
                    }
                }
                Set<String> m_fbcc = new HashSet<String>(m_bccGroup);
                m_fbcc.addAll(databcc);

                List<String> finalSortedListbcc = new ArrayList<>(m_fbcc);
                System.out.println("finalSortedList" + finalSortedListbcc);
                StringBuilder m_finalOfficeBCC = new StringBuilder();
                String m_finalbcc = "";
                for (String str1 : finalSortedListbcc) {
                    m_finalOfficeBCC.append(str1 + ",");
                    m_finalbcc += str1 + ",";
                }
                if (finalSortedListbcc.size() > 0) {
                    databcc = finalSortedListbcc;
                }
//                System.out.println("m_finalTo" + m_finalTo);
                lblBCC.setText(m_finalbcc);
                imgviewBCC.setVisible(true);
                removeBCC.setVisible(true);
                m_bccGroup.clear();
            }
            /////////////////////////////////////////////Group mail//////////////////////////////////////////////               

            if (intendedbccVal.size() != 0) {
                dataIntendedBCC.clear();
                for (String str_Intendedbcc : intendedbccVal) {
                    dataIntendedBCC.add(str_Intendedbcc);
                }
                StringBuilder emailIntendedBCC = new StringBuilder();
                for (String IntendedBCC : dataIntendedBCC) {
                    emailIntendedBCC.append(IntendedBCC + ",");
                    FinalEmailIntendedBcc += IntendedBCC + ",";
                }
                StringBuilder finalEmail = new StringBuilder(emailIntendedBCC);
                String intendedbcc = "";
                if (finalEmail != null || !finalEmail.equals("")) {
                    intendedbcc = finalEmail.substring(0, finalEmail.length() - 1);
                    m_intendedbccval = intendedbcc;
                } else {
                    m_intendedbccval = intendedbcc;
                }
            }
            intendedbccEmailList = m_intendedbccval;
            lblintendedBCC.setText(groupbccEmails + " " + intendedbccEmailList);

            imgviewIntendedBCC.setVisible(true);
            removeIntendeBCC.setVisible(true);
            m_tooltipIntendedbcc.setText(intendedbccEmailList);
            if (m_strintendedbcc != null) {
                m_tooltipIntendedbcc.setText(m_strintendedbcc.toString().substring(0, m_strintendedbcc.toString().length() - 1));
            }
        }
    }

    /**
     * ******************************************************************
     * @Function Name : ClickremoveINntendedBCC
     * @Description : for removing Intended BCC users
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void clickremoveINntendedBCC(ActionEvent event) throws IOException, Exception {
        m_groupintendedbccdata.clear();
        dataIntendedBCC.clear();
        lblintendedBCC.setText(null);
        imgviewIntendedBCC.setVisible(false);
        removeIntendeBCC.setVisible(false);
    }

    /**
     * ******************************************************************
     * @Function Name : open
     * @Description : for opening of signed receipt window
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public void open() throws IOException {
        Stage stageSignedReceipt = new Stage();
        Parent rootSignedReceipt;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/SignedReceipt.fxml"));
        rootSignedReceipt = (Parent) fXMLLoader.load();
        SignedReceiptController singleReceiptController = fXMLLoader.getController();
        stageSignedReceipt.setScene(new Scene(rootSignedReceipt));
        stageSignedReceipt.setTitle("Signed Receipt");
        stageSignedReceipt.initModality(Modality.APPLICATION_MODAL);
        stageSignedReceipt.initOwner(btnSignedReceipt.getScene().getWindow());
        stageSignedReceipt.toFront();
        stageSignedReceipt.showAndWait();
        stageSignedReceipt.setResizable(false);
    }

    /**
     * ******************************************************************
     * @Function Name : checkboxx
     * @Description : for checking and un-checking signed receipt checkBox
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public void checkboxx() {
        selectbtnSignedReceipt.set(false);
        selectbtnSignedReceipt.bind(checkSignedReceipt.selectedProperty());
        if (!selectbtnSignedReceipt.get()) {
            if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP5.play();
                }
            }

            Platform.runLater(() -> {
                Notifications.create().text("Warning" + "\\nplease check signed receipt first!").showError();
            });
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning");
            alert.setHeaderText(null);
            alert.setContentText("please check signed receipt first!");
            alert.showAndWait();
        }
        if (selectbtnSignedReceipt.get()) {

        }
        btnSignedReceipt.setOnAction(e -> {
            if (checkSignedReceipt.selectedProperty().get()) {
                try {
                    open();
                } catch (IOException ex) {
                    System.out.println("ex" + ex);
                }
            } else {
                if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                    m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                    if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                        ComposePageContrller.ALERT_AUDIOCLIP5.play();
                    }
                }
                Platform.runLater(() -> {
                    Notifications.create().text("Warning" + "\nplease check signed receipt first!").showError();
                });
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.initStyle(StageStyle.UTILITY);
                alert.setTitle("Warning ");
                alert.setHeaderText(null);
                alert.setContentText("please check signed receipt first!");
                alert.showAndWait();
            }
        });
    }

    /**
     * ******************************************************************
     * @Function Name : selectbtnSignedReceipt
     * @Description : for opening of signed receipt
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    private void selectbtnSignedReceipt(ActionEvent event) {
        checkboxx();
    }

    /**
     * ******************************************************************
     * @Function Name : attach_action_btn
     * @Description : for adding attachment in compose mail
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void attach_action_btn(ActionEvent event) throws Exception {

        try {
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Open File");

            FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("All files (*.*)", "*.*");
            // FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Files (*.txt,*.zip,*.rar,*.jpg,*.html,*.docx,*.pdf,*.pptx,*.png,*.gif,*.xlsx)", ".txt", "*.rar", "*.zip", "*.jpg", "*.html", "*.docx", "*.pdf", "*.pptx", "*.png", "*.gif", "*.xlsx");
            //FileChooser.ExtensionFilter extFilter1 = new FileChooser.ExtensionFilter("files (*.txt)", "*.txt");
            chooser.getExtensionFilters().add(extFilter);
            // chooser.getExtensionFilters().remove(extFilter1);

            //  chooser.setSelectedExtensionFilter(extFilter1);
            file = chooser.showOpenDialog(null);
            if (file.getName().endsWith("exe") || file.getName().endsWith("jar") || file.getName().endsWith("bat")) {
                System.out.println("Not able to attach");
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.initStyle(StageStyle.UTILITY);
                alert.setTitle("Warning-Attach File");
                alert.setHeaderText(null);
                alert.setContentText("Executable Files are  Not Allowed to Attach");
                alert.showAndWait();
            } else {
                System.out.println("file selected" + file);
                if (file.exists()) {
                    double bytes = file.length();
                    double kilobytes = (bytes / 1024);
                    double megabytes = (kilobytes / 1024);
                    double gigabyes = (megabytes / 1024);
                    double roundOffbytes = Math.floor(bytes * 100) / 100;
                    double roundOff = Math.floor(kilobytes * 100) / 100;
                    double roundOff1 = Math.floor(megabytes * 100) / 100;
                    double roundOffgb = Math.floor(gigabyes * 100) / 100;

                    Label m_fileName = new Label();

                    String filename = file.getName();

                    if (file.length() < 1024) {
                        m_fileName.setText(filename + "(" + roundOffbytes + " bytes" + ")");

                    } else if (file.length() >= 1024 && file.length() < (1024 * 1024)) {
                        m_fileName.setText(filename + "(" + roundOff + " KB" + ")");
                        //m_attachLabel.addRow(i, m_fileName);
                    } else if (file.length() >= (1024 * 1024) && file.length() < (1024 * 1024 * 1024)) {
                        m_fileName.setText(filename + "(" + roundOff1 + " MB" + ")");
                        // m_attachLabel.addRow(i, m_fileName);
                    } else if (file.length() >= (1024 * 1024 * 1024)) {
                        m_fileName.setText(filename + "(" + roundOffgb + " GB" + ")");
                        //m_attachLabel.addRow(i, m_fileName);
                    }
                    int i = 0;
                    isAttachment = checkFileSize();
                    if (isAttachment == true) {
                        Button closeButton = new Button("X");
                        closeButton.setStyle("-fx-font-size:5pt;-fx-background-color:white;-fx-text-fill:red;-fx-font-weight:bold;");
                        m_attachLabel.addRow(i, m_fileName);
                        m_fileName.setOnMouseEntered(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent e) {
                                m_fileName.setStyle("-fx-font-weight:BOLD;-fx-text-fill:#090E00;-fx-background-color:#EEF6FF;-fx-font-size:13");

                                closeButton.setVisible(true);
                                m_fileName.setGraphic(closeButton);
                                m_fileName.setContentDisplay(ContentDisplay.TOP.RIGHT);
                                closeButton.setOnMouseClicked(e1 -> {
                                    System.out.println("Before remove " + m_fileList);
                                    //StringBuffer name= new StringBuffer(m_fileName.getText().toString());

                                    //String m_splt[]=m_fileName.getText().split("(");
                                    int rmVal = 0;
                                    int removeIndexFile = -1;
                                    for (File remove_file : m_fileList) {

                                        String name = m_fileName.getText();
                                        System.out.println("File name Clicked" + name);

                                        System.out.println("ArrayList:" + remove_file.getName());
                                        System.out.println("name:" + name.toString());

                                        int firstIndex = name.lastIndexOf("(");
                                        //int lastIndex = name.lastIndexOf(")");
                                        name = name.subSequence(0, firstIndex).toString();

                                        System.out.println("value:" + name);

                                        if (remove_file.getName().equalsIgnoreCase(name)) {

                                            System.out.println("Removed..................");
                                            removeIndexFile = rmVal;
                                            //m_fileList.remove(remove_file);
                                            //m_fileList.remove(rmVal);

                                        } else {
                                            System.out.println("Not Removed..................");
                                        }
                                        rmVal++;
                                    }
                                    if (removeIndexFile != -1) {
                                        System.out.println("Test..." + removeIndexFile);
                                        m_fileList.remove(removeIndexFile);
                                       // m_fileList.clear();
                                        m_attachLabel.getChildren().remove(m_fileName);
                                    }

                                    System.out.println("After remove " + m_fileList);
                                });

                            }
                        });
                        m_fileName.setOnMouseExited(new EventHandler<MouseEvent>() {
                            @Override
                            public void handle(MouseEvent e) {
                                m_fileName.setStyle("-fx-background-color:#F4F4F4;");
                                closeButton.setVisible(false);

                            }
                        });

                    }

                } else {
                    if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                        m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                        if (m_warningFlag.equalsIgnoreCase("true")) {
                            ComposePageContrller.ALERT_AUDIOCLIP2.play();
                        }
                    }

                    Platform.runLater(() -> {
                        Notifications.create().text("Warning" + "File Not Exist").showWarning();
                    });
                    System.out.println("file not exist");
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Warning");
                    alert.setHeaderText(null);
                    alert.setContentText("File Not Exist");
                    alert.showAndWait();
                    isAttachment = false;
                }

            }
        } catch (Exception e) {
            System.out.println("Error" + e);
        }

    }

    /**
     * ******************************************************************
     * @Function Name : getSubList
     * @Description : for getting the precedence value according to users
     * access.
     * @Input Parameter : int start, int end
     * @Output Parameter	:toBeDisplayedList
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public ObservableList<String> getSubList(int start, int end) {

        final ObservableList<String> toBeDisplayedList = FXCollections.<String>observableArrayList();
        toBeDisplayedList.addAll(precedence_value.subList(start, end));
        return toBeDisplayedList;
    }

    public ObservableList<String> getPescedenceValue() {
        final ObservableList<String> PescedenceValueList = FXCollections.<String>observableArrayList();
        List<GetAllPrecedenceConfigDTO> allPrecedenceConfig = msghndlr.getAllPrecedenceConfig();
        for (GetAllPrecedenceConfigDTO data : allPrecedenceConfig) {
            PescedenceValueList.add(data.getPrecvalue());
        }
        return PescedenceValueList;

    }

    public ObservableList<String> getClassificationValue() {
        final ObservableList<String> classificationValueList = FXCollections.<String>observableArrayList();
        List<GetAllSecurityClassConfigDTO> allPrecedenceConfig = msghndlr.getAllSecurityClassConfig();
        for (GetAllSecurityClassConfigDTO data : allPrecedenceConfig) {
            classificationValueList.add(data.getSecclassvalue());
        }
        return classificationValueList;
    }

    /**
     * ******************************************************************
     * @Function Name : maxprecedence
     * @Description : for populating precedence value in compose window
     * @Input Parameter : NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public void maxprecedence() {
        String office = msghndlr.ldapUserOffice(sm_name);
        System.out.println("officename" + msghndlr.ldapUserOffice(sm_name));
        precedenceOfTcsUser = msghndlr.getPrecedenceOfTcsUser(office, sm_name);
        int index = 0;

        Iterator itr = precedence_value.iterator();
        int lngth = precedence_value.size();
        while (itr.hasNext()) {
            String name = (String) itr.next();
            Combobox_precednce.setItems(precedence_value);
            if (precedenceOfTcsUser.equals(name)) {
                index = precedence_value.indexOf(precedenceOfTcsUser);
            }
            Combobox_precednce.setItems(getSubList(index, lngth));

        }

    }

    /**
     * ******************************************************************
     * @Function Name : onPrecedenceSelectaction
     * @Description : NA
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void onPrecedenceSelectaction(ActionEvent event) throws Exception {

    }

    /**
     * ******************************************************************
     * @Function Name : getSubList1
     * @Description : for getting the security classification value according to
     * users access.
     * @Input Parameter : int start, int end
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public ObservableList<String> getSubList1(int start, int end) {

        final ObservableList<String> toBeDisplayedList = FXCollections.<String>observableArrayList();
        toBeDisplayedList.addAll(Classification_value.subList(start, end));
        return toBeDisplayedList;
    }

    /**
     * ******************************************************************
     * @Function Name : classificationselect
     * @Description : For populating security classification value in compose
     * window
     * @Input Parameter :NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public void classificationselect() {
        String office = msghndlr.ldapUserOffice(sm_name);
        classification = msghndlr.getMaxSecurityClassificationSendOfTcsUser(office, sm_name);
        int index = 0;

        Iterator itr = Classification_value.iterator();
        int lngth = Classification_value.size();
        while (itr.hasNext()) {
            String classificationval = (String) itr.next();
            Combobox_classification.setItems(Classification_value);
            if (classification.equals(classificationval)) {
                index = Classification_value.indexOf(classification);
            }
            Combobox_classification.setItems(getSubList1(index, lngth));
        }
    }

    /**
     * ******************************************************************
     * @Function Name : on_selection_classification
     * @Description : changing the color label according to security
     * classification value selected by user in compose window.
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 17th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void on_selection_classification(ActionEvent event) throws IOException {
        System.out.println("inside classification");
        if (Combobox_classification.getSelectionModel().getSelectedItem().toString().equalsIgnoreCase("TopSecret")) {
            change_lable.setText("TOPSECRET");
            change_lable.setTextFill(Color.web("white"));
            change_lable.setStyle("-fx-background-color: red;");
        } else if (Combobox_classification.getSelectionModel().getSelectedItem().toString().equalsIgnoreCase("Secret")) {
            change_lable.setText("SECRET");
            change_lable.setTextFill(Color.web("white"));
            change_lable.setStyle("-fx-background-color: orange;");
        } else if (Combobox_classification.getSelectionModel().getSelectedItem().toString().equalsIgnoreCase("Confidential")) {
            change_lable.setText("CONFIDENTIAL");
            change_lable.setTextFill(Color.web("white"));
            change_lable.setStyle("-fx-background-color: blue;");
        } else if (Combobox_classification.getSelectionModel().getSelectedItem().toString().equalsIgnoreCase("Restricted")) {
            change_lable.setText("RESTRICTED");
            change_lable.setTextFill(Color.web("Black"));
            change_lable.setStyle("-fx-background-color: yellow;");
        } else if (Combobox_classification.getSelectionModel().getSelectedItem().toString().equalsIgnoreCase("Unclassified")) {
            change_lable.setText("UNCLASSIFIED");
            change_lable.setTextFill(Color.web("black"));
            change_lable.setStyle("-fx-background-color: white;");
        }
    }

    /**
     * ******************************************************************
     * @Function Name : sendmailPrecheck
     * @Description : for checking or validating before sending mail.
     * @Input Parameter : NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 12th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public void sendmailPrecheck() {
        senderOfficeName = obj.getOfficeName();
        getMailID = obj.getMailId();
        System.out.println("groupmails are" + obj.getGroupMailNames().toString());
        System.out.println("size is" + obj.getAttachmentMaxSize());
    }

    /**
     * ******************************************************************
     * @Function Name : checkboxrecept
     * @Description : for getting value from checkBox read receipt
     * @Input Parameter : NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date :13th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public boolean checkboxrecept() {

        boolean isSelect = chkReadReceipt.isSelected();
        if (isSelect) {
            chkReadReceipt.setSelected(true);
        } else {
            chkReadReceipt.setSelected(false);
        }
        return isSelect;

    }

    /**
     * ******************************************************************
     * @Function Name : encryptionCheck
     * @Description : for getting value from checkBox encryption.
     * @Input Parameter : NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 13th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public boolean encryptionCheck() {
        boolean isSelect = chkEncryption.isSelected();
        if (isSelect) {
            chkEncryption.setSelected(true);
        } else {
            chkEncryption.setSelected(false);
        }
        return isSelect;

    }

    /**
     * ******************************************************************
     * @Function Name : stripHTMLTags
     * @Description : for extracting exact mail body from html tags.
     * @Input Parameter : String htmlText
     * @Output Parameter	: sb.toString().trim()
     * @Author : Ram Krishna Paul
     * @Created Date : 13th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    private String stripHTMLTags(String htmlText) {

        Pattern pattern = Pattern.compile("<[^>]*>");
        Matcher matcher = pattern.matcher(htmlText);
        final StringBuffer sb = new StringBuffer(htmlText.length());
        while (matcher.find()) {
            matcher.appendReplacement(sb, " ");
        }
        matcher.appendTail(sb);
        return sb.toString().trim();
    }

    /**
     * ******************************************************************
     * @Function Name : SIC
     * @Description : for getting SIC value in compose window.
     * @Input Parameter : NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 19th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void clickSIC(ActionEvent event) throws IOException {
        System.out.println("inside SIC");
//        List<SICDTO> SICval = msghndlr.getSICList();
//        for (SICDTO data : SICval) {
//            String sicName = data.getOu();
//            SicList.add(sicName);
//        }

//        List<String> officeNamesList = new ArrayList<String>();
//        officeNamesList.add(dataTO.toString());
//        officeNamesList.add("1CorpHQ");
//        List<String> sicList = new ArrayList<String>();
//
//        List<Map<Object, Object>> list = msghndlr.getnewSicList(dataTO);
//        for (Map hm : list) {
//            Set set = hm.entrySet();
//            Iterator itr = set.iterator();
//            while (itr.hasNext()) {
//                Map.Entry m = (Map.Entry) itr.next();
//
//                sicList.add((String) m.getKey());
//                System.out.println(m.getKey() + " ||||| " + m.getValue());
//            }
//        }
//        txtSIC.setItems(SicList);
    }

    /**
     * ******************************************************************
     * @Function Name : clickBtnSendMail
     * @Description : for sending mail
     * @Input Parameter : ActionEvent provided by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 27th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public Boolean clickBtnSendMail(ActionEvent event) throws Exception {
        String retVal = "false";
//        if (dataTO == null || dataTO.isEmpty()) {
//            ComposePageContrller.ALERT_AUDIOCLIP2.play();
//            Platform.runLater(() -> {
//                Notifications.create().text("Compose Mail" + "\nPlease select To Office !").showWarning();
//            });
//            Alert alert = new Alert(Alert.AlertType.WARNING);
//            alert.initStyle(StageStyle.UTILITY);
//            alert.setTitle("Confirmation - Compose Mail");
//            alert.setHeaderText(null);
//            alert.setContentText("Please select To Office !");
//            alert.showAndWait();
//            return false;
//        }
        if (Combobox_precednce.getValue() == null) {
            if (msghndlr.getAlarmProfiles(sm_name).getWarningAlarm() != null) {
                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getWarningAlarm();
                if (m_warningFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP2.play();
                }
            }

            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Choose the Precedence");
            alert.showAndWait();
            return false;

        }
        if (Combobox_classification.getValue() == null) {
            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_warningFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP2.play();
                }
            }

            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Enter Security Label Value for the mail ").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Enter Security Label Value for the mail ");
            alert.showAndWait();
            return false;
        }
        if (txtSubject.getText() == null || txtSubject.getText().isEmpty()) {
//            m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
//            if (m_warningFlag.equalsIgnoreCase("true")) {
                if (msghndlr.getAlarmProfiles(sm_name).getWarningAlarm() != null) {
                    m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getWarningAlarm();
                    if (m_warningFlag.equalsIgnoreCase("true")) {
                        ComposePageContrller.ALERT_AUDIOCLIP2.play();
                    }
               // }

            }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Enter Subject for the mail ").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Enter Subject for the mail ");
            alert.showAndWait();
            return false;

        }

        if (Combobox_policy.getValue() == null) {
//            m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
//            if (m_warningFlag.equalsIgnoreCase("true")) {
                if (msghndlr.getAlarmProfiles(sm_name).getWarningAlarm() != null) {
                    m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getWarningAlarm();
                    if (m_warningFlag.equalsIgnoreCase("true")) {
                        ComposePageContrller.ALERT_AUDIOCLIP2.play();
                    }
                }

          //  }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease choose the Policy").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please choose the Policy");
            alert.showAndWait();

        }
        if (Combobox_category.getValue() == null) {
//            m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
//            if (m_warningFlag.equalsIgnoreCase("true")) {
                if (msghndlr.getAlarmProfiles(sm_name).getWarningAlarm() != null) {
                    m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getWarningAlarm();
                    if (m_warningFlag.equalsIgnoreCase("true")) {
                        ComposePageContrller.ALERT_AUDIOCLIP2.play();
                    }
                }
          //  }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease choose the Category").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please choose the Category");
            alert.showAndWait();

        }
        subject = txtSubject.getText();
        body = msgBody.getHtmlText();
        precedencevalue = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
        classificationvlue = Combobox_classification.getSelectionModel().getSelectedItem().toString();
        policyValue = Combobox_policy.getSelectionModel().getSelectedItem().toString();
        categoryValue = Combobox_category.getSelectionModel().getSelectedItem().toString();
        if (txtSIC.getSelectionModel().getSelectedItem() != null) {
            SICVal = txtSIC.getSelectionModel().getSelectedItem().toString();
        } else {
            SICVal = null;
        }
        if (combBoxMsgType.getSelectionModel().getSelectedItem() != null) {
            msgTypee = combBoxMsgType.getSelectionModel().getSelectedItem();
        } else {
            msgTypee = null;
        }
        if (txtMsgInstruction.getText() != null) {
            txtmessageInstruction = txtMsgInstruction.getText();
        } else {
            txtmessageInstruction = null;
        }

        HashMap<Object, Object> headers = new HashMap<Object, Object>();

        String FinalIntendedTO = "";
        if (dataIntentedeTo != null) {
            for (int i = 0; i < dataIntentedeTo.size(); i++) {
                String temp = dataIntentedeTo.get(i).toString();
                if (i >= 0 && i < dataIntentedeTo.size() - 1) {
                    FinalIntendedTO = FinalIntendedTO + temp + ",";
                } else {
                    FinalIntendedTO = FinalIntendedTO + temp;
                }
            }

        }

        ///for final to value to send mail
        String FinalTO = "";
        String tempTo = "";
        int sizeto = dataTO.size();
        for (int i = 0; i < sizeto; i++) {

            tempTo = dataTO.get(i).toString();

            if (i >= 0 && i < dataTO.size() - 1) {
                FinalTO = FinalTO + tempTo + ",";
            } else {
                FinalTO = FinalTO + tempTo;
            }
        }
        /// for final cc value to send mail

        String FinalCC = "";
        String tempCC = "";
        int sizecc = datacc.size();
        for (int j = 0; j < sizecc; j++) {

            tempCC = datacc.get(j).toString();

            if (j >= 0 && j < datacc.size() - 1) {
                FinalCC = FinalCC + tempCC + ",";
            } else {
                FinalCC = FinalCC + tempCC;
            }
        }
        // for final bcc value to send mail
        String FinalBCC = "";
        String tempBCC = "";
        int sizebcc = databcc.size();
        for (int k = 0; k < sizebcc; k++) {

            tempBCC = databcc.get(k).toString();

            if (k >= 0 && k < databcc.size() - 1) {
                FinalBCC = FinalBCC + tempBCC + ",";
            } else {
                FinalBCC = FinalBCC + tempBCC;
            }
        }

        boolean readFlag = checkboxrecept();

        String readVal = "";
        if (readFlag) {
            readVal = "true";
        } else {
            readVal = "false";
        }

        boolean encryptFlag = encryptionCheck();

        if (encryptFlag) {
            encval = "true";
        } else {
            encval = "false";
        }

        String tempStr = "";
        String htmlText = msgBody.getHtmlText();

        tempStr = stripHTMLTags(htmlText);
        if (tempStr == null || tempStr.isEmpty()) {
//            m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
//            if (m_warningFlag.equalsIgnoreCase("true")) {
                if (msghndlr.getAlarmProfiles(sm_name).getWarningAlarm() != null) {
                    m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getWarningAlarm();
                    if (m_warningFlag.equalsIgnoreCase("true")) {
                        ComposePageContrller.ALERT_AUDIOCLIP2.play();
                    }
                }
          //  }
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nPlease Enter Message Body for the mail").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("Please Enter Message Body for the mail ");
            alert.showAndWait();
            return false;
        }
        if (txtPrivacy.getText() == null || txtPrivacy.getText().isEmpty() || txtPrivacy.getText() == "") {
            securityMark = "";

        } else {

            securityMark = txtPrivacy.getText();
        }

        MailDTO input = new MailDTO();
        input.setSubject(subject);
        input.setContent(body);
        input.setFrom(sm_name + "@tcs.mil.in");
        headers.put("toOffice", FinalTO);
        headers.put("ccOffice", FinalCC);
        headers.put("bccOffice", FinalBCC);
        headers.put("originalReceiver", FinalIntendedTO);
        headers.put("originalCc", intendedccEmailList);
        headers.put("originalBcc", intendedbccEmailList);
        headers.put("read_receipt", readVal);
        headers.put("sic", SICVal);
        headers.put("signed_receipt", "");
        headers.put("signed_receipt_receiptfrom", "");
        headers.put("signed_receipt_receiptto", "");
        headers.put("encryption", encval);
        headers.put("precedence", precedencevalue);
        headers.put("security_policy", policyValue);
        headers.put("security_level", classificationvlue);
        headers.put("security_privacy_mark", securityMark);
        headers.put("security_category", categoryValue);
        headers.put("messageType", msgTypee);
        headers.put("msgType", "DRAFT");
        headers.put("messageInstructions", txtmessageInstruction);
        headers.put("groupMailIdTo", m_groupEmails);
        headers.put("groupMailIdCc", m_groupCCEmails);
        headers.put("groupMailIdBcc", m_groupBCCEmails);

        input.setToRecipient("");
        input.setCcRecipient("");
        input.setBccRecipient("");
        input.setAttachment("");
        input.setMsgType("");
        input.setHeaderMap(headers);
        if (m_groupEmails != "" && FinalCC != "" && intendedccEmailList == "" && FinalBCC != "" && intendedbccEmailList == "") {

            //m_groupEmails != null && intendedccEmailList == null && intendedbccEmailList == null) {
            ComposePageContrller.ALERT_AUDIOCLIP2.play();
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nplease select intended CC & BCC recepient").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("please select intended CC & BCC recepient");
            alert.showAndWait();
            return false;
        } else if (m_groupEmails != "" && FinalCC != "" && intendedccEmailList == "") {
            ComposePageContrller.ALERT_AUDIOCLIP2.play();
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nplease select intended CC recepient").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("please select intended CC recepient");
            alert.showAndWait();
            return false;
        } else if (m_groupEmails != "" && FinalBCC != "" && intendedbccEmailList == "") {
            ComposePageContrller.ALERT_AUDIOCLIP2.play();
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\nplease select intended BCC recepient").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("please select intended BCC recepient");
            alert.showAndWait();
            return false;
        }

        if (FinalIntendedTO == "" && FinalCC != "" && m_groupCCEmails != "" && FinalBCC != "" && m_groupBCCEmails != "") {
            ComposePageContrller.ALERT_AUDIOCLIP2.play();
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\ngroup address can not be added, as based " + "\n on to address the mail will be either profiled or SIC").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("group address can not be added, as based " + "\n on to address the mail will be either profiled or SIC");
            alert.showAndWait();
            return false;
        } else if (FinalIntendedTO == "" && FinalCC != "" && m_groupCCEmails != "") {
            ComposePageContrller.ALERT_AUDIOCLIP2.play();
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\ngroup address can not be added, as based " + "\n on to address the mail will be either profiled or SIC").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("group address can not be added, as based " + "\n on to address the mail will be either profiled or SIC");
            alert.showAndWait();
            return false;
        } else if (FinalIntendedTO == "" && FinalBCC != "" && m_groupBCCEmails != "") {
            ComposePageContrller.ALERT_AUDIOCLIP2.play();
            Platform.runLater(() -> {
                Notifications.create().text("Compose Mail-" + "\ngroup address can not be added, as based " + "\n on to address the mail will be either profiled or SIC").showWarning();
            });
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Compose Mail");
            alert.setHeaderText(null);
            alert.setContentText("group address can not be added, as based " + "\n on to address the mail will be either profiled or SIC");
            alert.showAndWait();
            return false;
        }
//        boolean inteto = true;
//        if (dataIntentedeTo == null || dataIntentedeTo.isEmpty()) {
//            ComposePageContrller.ALERT_AUDIOCLIP2.play();
//            Platform.runLater(() -> {
//                Notifications.create().text("Compose Mail-" + "\nAre you sure want to send mail without Intended To Users !").showWarning();
//            });
//            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
//            alert.setTitle("Confirmation - Compose Mail");
//            alert.setHeaderText(null);
//            alert.setContentText("Are you sure want to send mail without Intended To Users !");
//            Optional<ButtonType> result = alert.showAndWait();
//            if (result.get() == ButtonType.OK) {
//                inteto = true;
//            } else if (result.get() == ButtonType.CANCEL) {
//                inteto = false;
//                return false;
//            }
//        }
        if (isAttachment) {

            // if (lblattachfile.getText().length() > 0) {
            mailIds.clear();
            StringTokenizer stMailId = new StringTokenizer(intendedEmailList, ",");
            while (stMailId.hasMoreTokens()) {
                mailIds.add(stMailId.nextToken());
            }
            System.out.println("Mail Ids List: " + mailIds.toString());
            AttachmentClearenceDTO dto = new AttachmentClearenceDTO();
            if (file.length() != 0) {
                dto.setAttachmentSize((long) file.length());
            } else {
                dto.setAttachmentSize((long) 0);
            }
            dto.setUserMailIds(mailIds.toArray(new String[0]));
            Attachflag = true;

            ResultDTO dtoAttachClearance = (ResultDTO) msghndlr.checkAttachmentClearence(dto);
            AttchmntFailurList = dtoAttachClearance.getFailure();
            String filureListofAttach = "";
            for (int i = 0; i < AttchmntFailurList.size(); i++) {
                String temp = AttchmntFailurList.get(i).toString();
                if (i >= 0 && i < AttchmntFailurList.size() - 1) {
                    filureListofAttach = filureListofAttach + temp + ",";
                } else {
                    filureListofAttach = filureListofAttach + temp;
                }

            }

            if (AttchmntFailurList.size() > 0) {

                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.initStyle(StageStyle.UTILITY);
                alert.setTitle("Compose Mail - Attachment Clearence");
                alert.setHeaderText(null);
                alert.setContentText("The Following Users are not authorized to Receive Attachment in a mail -" + filureListofAttach);
                alert.showAndWait();
                return false;
            }
            // }
        }
     try {
            System.out.println("BEFORE SENDING FILES" + m_fileList);
            retVal = "false";
            finalFilesArray = new File[m_fileList.size()];
            for (int i = 0; i < m_fileList.size(); i++) {
                finalFilesArray[i] = m_fileList.get(i);
            }
            Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
            alert1.setTitle("Confirmation-Send Mail");
            alert1.setHeaderText(null);
            alert1.setContentText("Are you sure to Send Mail");
            Optional<ButtonType> result = alert1.showAndWait();
            if (finalFilesArray.length != 0) {

                headers.put("attachment", true);
            } else {
                headers.put("attachment", false);
            }
            if (result.get() == ButtonType.OK) {
                  if (securityStatusFlag) {
                Stage stageSecurity = new Stage();
                Parent rootSecurity;
                FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/Security.fxml"));
                rootSecurity = (Parent) fXMLLoader.load();
                SecurityController securityController = fXMLLoader.getController();
                stageSecurity.setScene(new Scene(rootSecurity));
                stageSecurity.setTitle("Security");
                stageSecurity.initModality(Modality.APPLICATION_MODAL);
//                stageTo.initOwner(OK.getScene().getWindow());
                stageSecurity.toFront();
                stageSecurity.getIcons().add(new Image("/img/Mail-icon.png"));
                stageSecurity.showAndWait();
                stageSecurity.setResizable(false);
                stageSecurity.setResizable(false);
                
                if (securityController.sendSecurityFlag) {
                    retVal = msghndlr.sendMailWthAtchmnt(input, finalFilesArray,securityStatusFlag); 
                }
                  }
                  else{
                      retVal = msghndlr.sendMailWthAtchmnt(input, finalFilesArray,securityStatusFlag);  
                  }
            }
        } catch (Exception e) {
            retVal = "false";
            System.err.println("exception is" + e);
        }

        if (retVal.equalsIgnoreCase("true")) {

            if (msghndlr.getAlarmProfiles(sm_name).getSuccessAlarm() != null) {
                m_successAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getSuccessAlarm();
                if (m_successAlarmFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP1.play();
                }
            }
//           
            Platform.runLater(() -> {
                Notifications.create().text("Send Mail-" + "\nMail Sent SuccessFully..").showInformation();
            });
            dataTO.clear();
            dataIntentedeTo.clear();
            datacc.clear();
            dataIntendedCC.clear();
            databcc.clear();
            dataIntendedBCC.clear();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Information-Send Mail");
            alert.setHeaderText(null);
            alert.setContentText("Mail Sent SuccessFully..");
            alert.showAndWait();

            final Node Source = (Node) event.getSource();
            final Stage stage = (Stage) Source.getScene().getWindow();
            stage.close();

        } else if (retVal.equalsIgnoreCase("false")) {
            if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP5.play();
                }
            }

            Platform.runLater(() -> {
                Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
            });
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Error-Send Mail");
            alert.setHeaderText(null);
            alert.setContentText("Failed to Send Mail..");
            alert.showAndWait();

        } else if (retVal.equalsIgnoreCase("StoredInOutBox")) {
            if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP5.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Send Mail-" + "\nStored In OutBox").showError();
            });
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Error-Send Mail");
            alert.setHeaderText(null);
            alert.setContentText("Stored In OutBox");
            alert.showAndWait();

        } else if (retVal.equalsIgnoreCase("No Sic List Found")) {
            if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP5.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
            });
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Error-Send Mail");
            alert.setHeaderText(null);
            alert.setContentText("No Sic List Found");
            alert.showAndWait();

        } else if (retVal.equalsIgnoreCase("No Profile found")) {
            if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP5.play();
                }
            }
            Platform.runLater(() -> {
                Notifications.create().text("Send Mail-" + "\nFailed To Send Mail").showError();
            });
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Error-Send Mail");
            alert.setHeaderText(null);
            alert.setContentText("No Profile found");
            alert.showAndWait();

        }
        return null;
    }
    int[] files;
    
  

    /**
     * ******************************************************************
     * @Function Name : checkFileSize
     * @Description : for checking attachment in compose window
     * @Input Parameter : NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 27th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    double roundOffbytes;
    double roundOff;
    double roundOff1;
    double roundOffgb;

    public boolean checkFileSize() {

        boolean retVal = false;
        if (file.length() > max_attch_size_allowed) {
            String msg = "";
            int rem_siz = max_attch_size_allowed;
            int int_siz = rem_siz;
            if (int_siz < 1024) {
                msg = (rem_siz) + " Bytes ";
            } else if (int_siz >= 1024 && int_siz < (1024 * 1024)) {
                msg = rem_siz / 1024 + " KB ";
            } else if (int_siz >= (1024 * 1024) && int_siz < (1024 * 1024 * 1024)) {
                msg = rem_siz / 1024 / 1024 + " MB ";
            } else if (int_siz >= (1024 * 1024 * 1024)) {
                msg = rem_siz / 1024 / 1024 / 1024 + " GB ";
            }
            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_infoAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP1.play();
                }
            }

            Platform.runLater(() -> {
                Notifications.create().text("Warning - Add Attachment" + "\nFile size is exceed.").showInformation();
            });
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Warning - Add Attachment");
            alert.setHeaderText(null);
            alert.setContentText("File size is exceed.You can't send more than" + msg);
            alert.showAndWait();
            retVal = false;
            m_fileListFTP.add(file);
             m_finalArrayFTP = new File[m_fileListFTP.size()];
            for (int i = 0; i < m_fileListFTP.size(); i++) {
                m_finalArrayFTP[i] = m_fileListFTP.get(i);
            }
            System.out.println("List of FTP files"+m_finalArrayFTP);
          List<String> flag = msghndlr.uploadFileToFTP(m_finalArrayFTP);
          
           
          
          
            
          msgBody.setHtmlText(flag.toString());
         Label l1=new Label();
         msgBody.setAccessibleText(flag.toString());
        
            System.out.println("FTP Upload FILE "+flag);
           
        } else {
            System.out.println("File can able to send");
            retVal = true;
            m_fileList.add(file);

        }
        return retVal;
    }

    /**
     * ******************************************************************
     * @Function Name : ClickremoveAttachment
     * @Description : for removing attachment in compose window
     * @Input Parameter : ActionEvent by javafx
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 19th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void clickremoveAttachment(ActionEvent event) throws IOException {
//        lblattachfile.setText("");
//        removeAttachment.setVisible(false);
//        imgviewAttachment.setVisible(false);
    }

    /**
     * ******************************************************************
     * @Function Name : AttachmentAuthentication
     * @Description : for authentication of and checking input attachment in
     * compose window
     * @Input Parameter :NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 19th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public void attachmentAuthentication() {
        if (obj.getAttachmentSendAuth().equals("YES")) {
            String str = null;
            String str2 = null;
            if (obj.getAttachmentMaxSize().length() == 3) {
                str2 = (String) obj.getAttachmentMaxSize().substring(0, 1);
                System.out.println("size  1is: " + str2);
            } else if (obj.getAttachmentMaxSize().length() == 4) {
                str2 = (String) obj.getAttachmentMaxSize().substring(0, 2);
                System.out.println("in mb): " + str2);
            }

            if (obj.getAttachmentMaxSize().length() == 3) {
                str = (String) obj.getAttachmentMaxSize().substring(1, 3);
                System.out.println("size is: " + str);
            } else if (obj.getAttachmentMaxSize().length() == 4) {
                str = (String) obj.getAttachmentMaxSize().substring(2, 4);
                System.out.println("mb " + str);
            }

            if (str.equalsIgnoreCase("kb")) {

                int numKB = Integer.parseInt(str2);

                max_attch_size_allowed = numKB * 1024;

            } else if (str.equalsIgnoreCase("mb")) {
                int numMB = Integer.parseInt(str2);

                max_attch_size_allowed = numMB * 1024 * 1024;

            } else if (str.equalsIgnoreCase("gb")) {
                int numGB = Integer.parseInt(str2);
                max_attch_size_allowed = numGB * 1024 * 1024 * 1024;
            }

            attch_file.setDisable(false);
        } else {

            attch_file.setDisable(true);
        }
    }

    /**
     * ******************************************************************
     * @Function Name : initialize
     * @Description : initialize method of compose window
     * @Input Parameter :NA
     * @Output Parameter	: NA
     * @Author : Ram Krishna Paul
     * @Created Date : 19th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        chkEncryption.setDisable(true);
        chkEncryption.setSelected(true);
        txtPrivacy.setPromptText("Mark1");
        btnGroup.setVisible(false);
        combBoxMsgType.setItems(MsgType);
        btnMsgOptionType.setVisible(false);
        removeTo.setVisible(false);
        imgviewto.setVisible(false);
        removeIntendedTo.setVisible(false);
        imgviewintendedto.setVisible(false);
        removeCC.setVisible(false);
        imgviewCC.setVisible(false);
        removeIntendedCC.setVisible(false);
        imgviewIntendedCC.setVisible(false);
        imgviewBCC.setVisible(false);
        removeBCC.setVisible(false);
        imgviewIntendedBCC.setVisible(false);
        removeIntendeBCC.setVisible(false);
        removeAttachment.setVisible(false);
        imgviewAttachment.setVisible(false);
        txtSIC.setDisable(false);
        m_precedenceList = getPescedenceValue();
        precedence_value = FXCollections.observableArrayList(m_precedenceList);
        m_classificationValue = getClassificationValue();
        Classification_value = FXCollections.observableArrayList(m_classificationValue);
        Combobox_policy.setItems(Policy_value);
        Combobox_policy.getSelectionModel().selectFirst();
        Combobox_category.setItems(Category_value);
        Combobox_category.getSelectionModel().selectFirst();
        from_name.setText(sm_name);
        sendmailPrecheck();
//        SIC();
        maxprecedence();
        classificationselect();
        attachmentAuthentication();
        inputImgandTable();
        dragdrop();

    }

    public void dragdrop() {
        m_id.setOnDragOver(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                Dragboard db = event.getDragboard();
                if (db.hasFiles()) {
                    System.out.println("tst HAS FILES" + db.getString());
                    event.acceptTransferModes(TransferMode.COPY);
                } else {
                    event.consume();
                }
            }
        });

        m_id.setOnDragDropped(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                Dragboard db = event.getDragboard();
                boolean success = false;
                if (db.hasFiles()) {
                    success = true;
                    String filePath = null;

                    for (File file : db.getFiles()) {

                        filePath = file.getAbsolutePath();
                        System.out.println("Darg Drop" + filePath);
                        long m_lengnth = file.length();
                        if (file.exists()) {
                            double bytes = file.length();
                            double kilobytes = (bytes / 1024);
                            double megabytes = (kilobytes / 1024);
                            double gigabyes = (megabytes / 1024);
                            double roundOffbytes = Math.floor(bytes * 100) / 100;
                            double roundOff = Math.floor(kilobytes * 100) / 100;
                            double roundOff1 = Math.floor(megabytes * 100) / 100;
                            double roundOffgb = Math.floor(gigabyes * 100) / 100;

                            Label m_fileName = new Label();

                            String filename = file.getName();

                            if (file.length() < 1024) {
                                m_fileName.setText(filename + "(" + roundOffbytes + " bytes" + ")");

                            } else if (file.length() >= 1024 && file.length() < (1024 * 1024)) {
                                m_fileName.setText(filename + "(" + roundOff + " KB" + ")");
                                //m_attachLabel.addRow(i, m_fileName);
                            } else if (file.length() >= (1024 * 1024) && file.length() < (1024 * 1024 * 1024)) {
                                m_fileName.setText(filename + "(" + roundOff1 + " MB" + ")");
                                // m_attachLabel.addRow(i, m_fileName);
                            } else if (file.length() >= (1024 * 1024 * 1024)) {
                                m_fileName.setText(filename + "(" + roundOffgb + " GB" + ")");
                                //m_attachLabel.addRow(i, m_fileName);
                            }

                            System.out.println("GET TEXT:" + m_fileName.getText());

                            int i = 0;

                            //boolean m_attach=attchmentfilCheck();
                            System.out.println("File length" + m_lengnth);
                            System.out.println("Max file length" + max_attch_size_allowed);
                            if (max_attch_size_allowed > m_lengnth) {
                                m_fileList.add(file);

                                // if (isAttachment == true) {
                                System.out.println("IS Attachment true");
                                Button closeButton = new Button("X");
                                closeButton.setStyle("-fx-font-size:5pt;-fx-background-color:white;-fx-text-fill:red;-fx-font-weight:bold;");
                                m_attachLabel.addRow(i, m_fileName);
                                System.out.println("Added the row");
                                m_fileName.setOnMouseEntered(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent e) {
                                        m_fileName.setStyle("-fx-font-weight:BOLD;-fx-text-fill:#090E00;-fx-background-color:#EEF6FF;-fx-font-size:13");

                                        closeButton.setVisible(true);
                                        m_fileName.setGraphic(closeButton);
                                        m_fileName.setContentDisplay(ContentDisplay.TOP.RIGHT);
                                        closeButton.setOnMouseClicked(e1 -> {
                                            System.out.println("Before remove " + m_fileList);
                                            //StringBuffer name= new StringBuffer(m_fileName.getText().toString());

                                            //String m_splt[]=m_fileName.getText().split("(");
                                            int rmVal = 0;
                                            int removeIndexFile = -1;
                                            for (File remove_file : m_fileList) {

                                                String name = m_fileName.getText();
                                                System.out.println("File name Clicked" + name);

                                                System.out.println("ArrayList:" + remove_file.getName());
                                                System.out.println("name:" + name.toString());

                                                int firstIndex = name.lastIndexOf("(");
                                                //int lastIndex = name.lastIndexOf(")");
                                                name = name.subSequence(0, firstIndex).toString();

                                                System.out.println("value:" + name);

                                                if (remove_file.getName().equalsIgnoreCase(name)) {

                                                    System.out.println("Removed..................");
                                                    removeIndexFile = rmVal;
                                                    //m_fileList.remove(remove_file);
                                                    //m_fileList.remove(rmVal);

                                                } else {
                                                    System.out.println("Not Removed..................");
                                                }
                                                rmVal++;
                                            }
                                            if (removeIndexFile != -1) {
                                                System.out.println("Test..." + removeIndexFile);
                                                m_fileList.remove(removeIndexFile);
                                                m_attachLabel.getChildren().remove(m_fileName);
                                            }

                                            System.out.println("After remove " + m_fileList);
                                        });

                                    }
                                });
                                m_fileName.setOnMouseExited(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent e) {
                                        m_fileName.setStyle("-fx-background-color:#F4F4F4;");
                                        closeButton.setVisible(false);

                                    }
                                });

                            } else {
                                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                                alert.initStyle(StageStyle.UTILITY);
                                alert.setTitle("Warning - Add Attachment");
                                alert.setHeaderText(null);
                                alert.setContentText("File size is exceed.You can't send");
                                alert.showAndWait();
                                m_fileListFTP.add(file);
                                m_finalArrayFTP = new File[m_fileListFTP.size()];
                                for (int k = 0; k < m_fileListFTP.size(); k++) {
                                    m_finalArrayFTP[k] = m_fileListFTP.get(k);
                                }
                                System.out.println("List of FTP files" + m_finalArrayFTP);
                                List<String> flag = msghndlr.uploadFileToFTP(m_finalArrayFTP);

                                msgBody.setHtmlText(flag.toString());
                                System.out.println("FTP Upload FILE " + flag);
                              
                            }

                        } else {
                            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                                m_warningFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                                if (m_warningFlag.equalsIgnoreCase("true")) {
                                    ComposePageContrller.ALERT_AUDIOCLIP2.play();
                                }
                            }

                            Platform.runLater(() -> {
                                Notifications.create().text("Warning" + "File Not Exist").showWarning();
                            });
                            System.out.println("file not exist");
                            Alert alert = new Alert(Alert.AlertType.WARNING);
                            alert.initStyle(StageStyle.UTILITY);
                            alert.setTitle("Warning");
                            alert.setHeaderText(null);
                            alert.setContentText("File Not Exist");
                            alert.showAndWait();
                            isAttachment = false;
                        }
                    }

                }
                event.setDropCompleted(success);
                event.consume();
            }
        });
    }

    /**
     * ******************************************************************
     * @Function Name : InputImgandTable
     * @Description : for importing html table and image in mail body.
     * @Input Parameter :NA
     * @Output Parameter	: NA
     * @Author : Manoj Kumar Meghwal
     * @Created Date : 19th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    public void inputImgandTable() {
        Node node = msgBody.lookup(".top-toolbar");
        if (node instanceof ToolBar) {
            ToolBar bar = (ToolBar) node;
            Button smurfButton = new Button("Insert Table");
            Label row = new Label();
            row.setText("Row:");
            TextField rowField = new TextField("0");
            rowField.setPrefWidth(30);
            Label column = new Label();
            column.setText("Column:");
            TextField columnField = new TextField("0");
            columnField.setPrefWidth(30);
            Button insertImage = new Button("Insert Image");
            bar.getItems().addAll(smurfButton, row, rowField, column, columnField, insertImage);
            smurfButton.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent arg0) {
                    StringBuilder tableContent = new StringBuilder();
                    tableContent.append("<table style='border-collapse:collapse; border: 1px solid black;'>");
                    for (int i = 0; i < Integer.parseInt(rowField.getText()); i++) {
                        tableContent.append("<tr >");
                        for (int j = 0; j < Integer.parseInt(columnField.getText()); j++) {
                            tableContent.append("<td width='100px' height='30px' style='border-collapse:collapse; border: 1px solid black;'>").append("</td>");
                        }
                        tableContent.append("</tr >");
                    }
                    tableContent.append("</table ><br>");
                    msgBody.setHtmlText(msgBody.getHtmlText() + tableContent);
                }
            });
            insertImage.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent arg0) {
                    FileChooser fileChooser = new FileChooser();
                    fileChooser.setTitle("Select Image");
                    FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("All images", new String[]{"*.JPEG", "*.PNG", "*.png", "*.jpg", "*.JPG", "*.gif"});
                    fileChooser.getExtensionFilters().add(extFilter);
                    File file = fileChooser.showOpenDialog(new Stage());
                    try {
                        byte[] bytes = loadFile(file);
                        byte[] encoded = Base64.getEncoder().encode(bytes);
                        String encodedString = new String(encoded);
                        System.out.println("encodedString" + encodedString);
                        msgBody.setHtmlText(
                                msgBody.getHtmlText()
                                + "<img src='data:image/png;base64," + encodedString + "'>");
                    } catch (IOException ex) {
                        Logger.getLogger(ComposePageContrller.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
        }
    }

    /**
     * ******************************************************************
     * @Function Name : loadFile
     * @Description : for importing image in mail body.
     * @Input Parameter :File file
     * @Output Parameter	:return bytes
     * @Author : Manoj Kumar Meghwal
     * @Created Date :18 May 2017
     * @Modification History: NA
     * ******************************************************************
     */
    private static byte[] loadFile(File file) throws IOException {
        InputStream is = new FileInputStream(file);

        long length = file.length();
        if (length > Integer.MAX_VALUE) {
            // File is too large
        }
        byte[] bytes = new byte[(int) length];

        int offset = 0;
        int numRead = 0;
        while (offset < bytes.length
                && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
            offset += numRead;
        }

        if (offset < bytes.length) {
            throw new IOException("Could not completely read file " + file.getName());
        }

        is.close();
        return bytes;
    }

    /**
     * ******************************************************************
     * @Function Name : clickbtnMsgOptionType
     * @Description : for opening of message option window in compose window.
     * @Input Parameter :ActionEvent
     * @Output Parameter	:NA
     * @Author : Ram Krishna Paul
     * @Created Date : 20th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void clickbtnMsgOptionType(ActionEvent event) throws Exception {
        Stage stageMsgOption = new Stage();
        Parent rootMsgOption;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/MessageOption.fxml"));
        rootMsgOption = (Parent) fXMLLoader.load();
        stageMsgOption.setScene(new Scene(rootMsgOption));
        stageMsgOption.setTitle("Message Option");
        stageMsgOption.initModality(Modality.APPLICATION_MODAL);
        stageMsgOption.initOwner(btnintendedBCC.getScene().getWindow());
        stageMsgOption.toFront();
        stageMsgOption.showAndWait();
        stageMsgOption.setResizable(false);
    }

    /**
     * ******************************************************************
     * @Function Name : ClickSaveComposeMail
     * @Description : for saving of compose mail in compose window.
     * @Input Parameter :ActionEvent
     * @Output Parameter	:NA
     * @Author : Ram Krishna Paul
     * @Created Date : 20th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public boolean clickSaveComposeMail(ActionEvent event) throws Exception {
        boolean retVal = false;
        String messageTypee = "";
        String sicval = "";
        String tempBody = "";
        if (Combobox_precednce.getSelectionModel().getSelectedItem() != null) {
            precedencevalue = Combobox_precednce.getSelectionModel().getSelectedItem().toString();
        } else {
            precedencevalue = "";
        }

        if (Combobox_classification.getSelectionModel().getSelectedItem() != null) {
            classificationvlue = Combobox_classification.getSelectionModel().getSelectedItem().toString();
        } else {
            classificationvlue = "";
        }
        if (Combobox_policy.getSelectionModel().getSelectedItem() != null) {
            policyValue = Combobox_policy.getSelectionModel().getSelectedItem().toString();
        } else {
            policyValue = "";
        }
        if (Combobox_category.getSelectionModel().getSelectedItem() != null) {
            categoryValue = Combobox_category.getSelectionModel().getSelectedItem().toString();
        } else {
            categoryValue = "";
        }
        if (txtPrivacy.getText() != null) {
            securityMark = txtPrivacy.getText();
        }
        if (txtSubject.getText() != null) {
            subject = txtSubject.getText();
        }
        if (msgBody.getHtmlText() != null) {
            body = msgBody.getHtmlText();
            tempBody = stripHTMLTags(body);
        }
        if (txtSIC.getSelectionModel().getSelectedItem() != null) {
            sicval = Combobox_category.getSelectionModel().getSelectedItem().toString();
        } else {
            sicval = "";
        }
        if (txtMsgInstruction.getText() != null) {
            txtmessageInstruction = txtMsgInstruction.getText();
        }
        if (combBoxMsgType.getSelectionModel().getSelectedItem() != null) {
            messageTypee = combBoxMsgType.getSelectionModel().getSelectedItem().toString();
        } else {
            messageTypee = "";
        }
        boolean readFlag = checkboxrecept();
        System.out.println("ReadFlag=" + readFlag);
        String readVal = "";
        if (readFlag) {
            readVal = "true";
            System.out.println("readVal1=" + readVal);
        } else {
            readVal = "false";
            System.out.println("readVal2=" + readVal);
        }

//        headers.put("read_receipt", readVal);
        boolean encryptFlag = encryptionCheck();

        if (encryptFlag) {
            encval = "true";
        } else {
            encval = "false";
        }
        //saveMailToDraft
        MailDTO input = new MailDTO();
        input.setToRecipient("");
        input.setSubject(subject);
        input.setContent(tempBody);
        input.setFrom(sm_name + "@tcs.mil.in");
        HashMap<Object, Object> headers = new HashMap<Object, Object>();
        headers.put("toOffice", toUser.toString());
        headers.put("ccOffice", listdatacc.toString());
        headers.put("bccOffice", listdatBcc.toString());
        headers.put("originalReceiver", intendedEmailList);
        headers.put("originalCc", intendedccEmailList);
        headers.put("originalBcc", intendedbccEmailList);
        headers.put("Read_Receipt", readVal);
        headers.put("sic", sicval);
        headers.put("signed_receipt", "");
        headers.put("signed_receipt_receiptto", "");
        headers.put("signed_receipt_receiptfrom", "");
        headers.put("encryption", encval);
        headers.put("precedence", precedencevalue);
        headers.put("security_policy", policyValue);
        headers.put("security_category", categoryValue);
        headers.put("security_privacy_mark", securityMark);
        headers.put("security_level", classificationvlue);
        headers.put("messageInstructions", txtmessageInstruction);
        headers.put("messageType", messageTypee);
        headers.put("msgType", "");

        input.setAttachment("");
        input.setBccRecipient("");
        input.setCcRecipient("");
        input.setMsgType("");
        input.setHeaderMap(headers);
        try {
            finalFilesArray = new File[m_fileList.size()];
            for (int i = 0; i < m_fileList.size(); i++) {
                finalFilesArray[i] = m_fileList.get(i);
            }
            retVal = true;
            retVal = msghndlr.saveMailToDraft(input, finalFilesArray);
        } catch (Exception e) {
            retVal = false;
            System.err.println("exception is" + e);
        }
        if (retVal == true) {
            if (msghndlr.getAlarmProfiles(sm_name).getInfoAlarm() != null) {
                m_infoAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getInfoAlarm();
                if (m_infoAlarmFlag.equalsIgnoreCase("true")) {

                    ComposePageContrller.ALERT_AUDIOCLIP1.play();
                }
            }

            Platform.runLater(() -> {
                Notifications.create().text("Save Mail-" + "\nMail Save SuccessFully to Draft..").showInformation();
            });
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Information-Save Mail");
            alert.setHeaderText(null);
            alert.setContentText("Mail Save SuccessFully to Draft..");
            alert.showAndWait();

            final Node Source = (Node) event.getSource();
            final Stage stage = (Stage) Source.getScene().getWindow();
            stage.close();
        } else {
            if (msghndlr.getAlarmProfiles(sm_name).getErrorAlarm() != null) {
                m_errorAlarmFlag = msghndlr.getAlarmProfiles(sm_name).getErrorAlarm();
                if (m_errorAlarmFlag.equalsIgnoreCase("true")) {
                    ComposePageContrller.ALERT_AUDIOCLIP5.play();
                }
            }

            Platform.runLater(() -> {
                Notifications.create().text("Save Mail-" + "\nFailed To Save Mail").showError();
            });
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UTILITY);
            alert.setTitle("Error-Save Mail");
            alert.setHeaderText(null);
            alert.setContentText("Failed to Save Mail..");
            alert.showAndWait();
        }

        return retVal;
    }

    /**
     * ******************************************************************
     * @Function Name : click_cancel_mail
     * @Description : for Canceling of compose mail in compose window.
     * @Input Parameter :ActionEvent
     * @Output Parameter	:NA
     * @Author : Ram Krishna Paul
     * @Created Date : 20th April 2017
     * @Modification History: NA
     * ******************************************************************
     */
    @FXML
    public void click_cancel_mail(ActionEvent event) throws Exception {
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
    }
    @FXML
    private Button btnGroup;
//    public static List<String> m_groupdata;
////    public StringBuilder m_listdataGroup = new StringBuilder();
//    public String groupEmails = "";
//    public StringBuilder m_finalGroupMembers;

    @FXML
    public void clickBtnGroup(ActionEvent event) throws Exception {
        Stage stageGroup = new Stage();
        Parent root1;
        FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/com/bel/mailApplication/scene/GroupMails.fxml"));
        root1 = (Parent) fXMLLoader.load();
        GroupMailsController groupMailsController = fXMLLoader.getController();
        stageGroup.setScene(new Scene(root1));
        stageGroup.setTitle("Groups");
        stageGroup.initModality(Modality.APPLICATION_MODAL);
        stageGroup.initOwner(btnGroup.getScene().getWindow());
        stageGroup.toFront();
        stageGroup.showAndWait();
        stageGroup.getIcons().add(new Image("/img/Mail-icon.png"));
//        m_groupdata = groupMailsController.m_selectedGroupMail;
//        m_listdataGroup = new StringBuilder();
//        for (String m_userGroup : m_groupdata) {
//            m_listdataGroup.append(m_userGroup + ",");
//        }
//        StringBuilder finalGroupEmail = m_listdataGroup;
//        groupEmails = finalGroupEmail.substring(0, finalGroupEmail.length() - 1);
//
//        lblIntendeTo.setText(groupEmails);
//        System.out.println("groupEmails" + groupEmails);
//
//        GroupMailInfo groupMailInfo = msghndlr.getMailGroup(groupEmails);
//        List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
//        String strr = "";
//        StringBuilder str = new StringBuilder(strr);
//        for (String memberMailId : memberMailIdsList) {
//            str.append(memberMailId + ",");
//        }
//        m_tooltipIntendedTo.setText(str.toString().substring(0, str.toString().length() - 1));

    }
    
      //for send mailprogress
     private void runTask() {

        final double wndwWidth = 300.0d;
        Label updateLabel = new Label("Running tasks...");
        updateLabel.setPrefWidth(wndwWidth);
        ProgressIndicator progress = new ProgressIndicator();
        progress.setPrefWidth(wndwWidth);

        VBox updatePane = new VBox();
        updatePane.setPadding(new Insets(10));
        updatePane.setSpacing(5.0d);
        updatePane.getChildren().addAll(updateLabel, progress);

        Stage taskUpdateStage = new Stage(StageStyle.UTILITY);
        taskUpdateStage.setScene(new Scene(updatePane));
        taskUpdateStage.show();

        Task longTask = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                int max = 10;
                for (int i = 1; i <= max; i++) {
                    if (isCancelled()) {
                        break;
                    }
                    updateProgress(i, max);
                    updateMessage("Task part " + String.valueOf(i) + " complete");

                    Thread.sleep(100);
                }
                return null;
            }
        };

        longTask.setOnSucceeded(new EventHandler<WorkerStateEvent>() {
            @Override
            public void handle(WorkerStateEvent t) {
                taskUpdateStage.hide();
            }
        });
        progress.progressProperty().bind(longTask.progressProperty());
        updateLabel.textProperty().bind(longTask.messageProperty());

        taskUpdateStage.show();
        taskUpdateStage.toFront();
        new Thread(longTask).start();
    }

}
