package com.bel.mailApplication.controller;

import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import static com.bel.mailApplication.controller.Approve_view_pageController.classificationvaleforIntendedTo;
import static com.bel.mailApplication.controller.Approve_view_pageController.precedencevaleforIntendedTo;
import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.SelectionMode;
import javafx.stage.Stage;
import mail.awan.beans.CheckClearenceDTO;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.CheckListView;
/**
 * ******************************************************************
 * @File Name           : IntendedToModifyApproveController.
 * @Author              : Ram Krishna Paul.
 * @Package             : com.bel.mailApplication.controller
 * @Purpose             : Display window  for  IntendedToModifyApprove List.
 * @Created Date	:8-MAY-2017
 * @Modification History:NA. 
*******************************************************************
 */
public class IntendedToModifyApproveController implements Initializable {
    @FXML
    private Button AddIntendedTo;
    
    @FXML
    public CheckListView EmailIntendedTo;
    @FXML
    private ObservableList<String> data;
    @FXML
    private ObservableList<String> userNames;
    public List<String>selectedIntendedToOffice;
    public static String ListOfGrupMails="";
    public static List<String> dataGroupmails;
    public String GroupEmails;
     MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
                /**
     * ******************************************************************
     * @Function Name           :initialize
     * @Description             : Method to call initialization function.
     * @Input Parameter         : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
      * @Author                 : Ram Krishna Paul.
     * @Created Date            :8-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        EmailIntendedTo.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        data = FXCollections.observableArrayList();
        String officename = msghndlr.ldapUserOffice(sm_name);
        List<String> li = new ArrayList<String>();
        li = Approve_view_pageController.dataList();
        String[] obj = li.toArray(new String[0]);
        CheckClearenceDTO dto = new CheckClearenceDTO();
        dto.setOffice(obj);
        dto.setMaxSecurityClassificationView(classificationvaleforIntendedTo);
        dto.setAttachmentSize(0);
        dto.setMaxMessagePrecedence(precedencevaleforIntendedTo);
        List<String> list = msghndlr.checkClearence(dto);
        for (String OfficeUserNames : list) {
            data.addAll(OfficeUserNames);
            EmailIntendedTo.setItems(data);
                      EmailIntendedTo.getCheckModel().getCheckedItems().addListener(new ListChangeListener<String>() {
                @Override
                public void onChanged(ListChangeListener.Change<? extends String> c) {
                    selectedIntendedToOffice = EmailIntendedTo.getCheckModel().getCheckedItems();
                    System.out.println("selectedIntendedToOffice"+selectedIntendedToOffice);
                }
            }); 
        }
    }
    /**
     * ******************************************************************
     * @Function Name           :Add_AddIntendedTo
     * @Description             : Method to add IntendedTo to list.
     * @Input Parameter         : ActionEvent -provided by-JavaFX.
     * @Output Parameter	: NA.
     * @Author                  : Ram Krishna Paul.
     * @Created Date            :8-MAY-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @FXML
    public void add_AddIntendedTo(ActionEvent event) throws IOException {
        String Emailselected;
        // alloffice = add_list.getItems();
        List<String> data = EmailIntendedTo.getSelectionModel().getSelectedItems();
        for (String email1 : data) { 
        }
        final Node Source = (Node) event.getSource();
        final Stage stage = (Stage) Source.getScene().getWindow();
        stage.close();
    }
 
   
    
}
