
package com.bel.mailApplication.controller;
import com.entity.MailDTO;
import static com.bel.mailApplication.controller.FXMLDocumentController.mail_id;
import static com.bel.mailApplication.controller.FXMLDocumentController.read_mail;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import java.awt.FileDialog;
import java.awt.Frame;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.web.HTMLEditor;
import javafx.stage.StageStyle;
import mail.awan.beans.GroupMailInfo;
import mail.awan.beans.ReceiveMailInputDTO;
import mail.awan.messageHandler.MessageHandler;
/**
 * ******************************************************************
 * @File Name : View_inboxmail_pageController.java
 * @Author	: Ravikiran Bhat.
 * @Package : com.bel.mailApplication.controller
 * @Purpose	: Display View In box Mail Page
 * @Created Date	:27-APR-2017
 * @Modification History: 
*******************************************************************
 */

public class View_inboxmail_pageController implements Initializable {

    @FXML
    private Label headinglabl;
    @FXML
    private Label send_label;
    @FXML
    private JFXButton btnBCC;
    @FXML
    private Label lblBCC;
    @FXML
    private Label from_name;
    @FXML
    private JFXButton Compose_to_btn;
    @FXML
    private Label to_mail;
    @FXML
    private JFXButton IntendeTo;
    @FXML
    private Label lblIntendeTo;
    @FXML
    private JFXButton btncc;
    @FXML
    private Label lblcc;

    @FXML
    private JFXButton btnintendedcc;
    @FXML
    private Label lblintendedcc;
    @FXML
    private JFXButton btnintendedBCC;
    @FXML
    private Label lblintendedBCC;
    @FXML
    private TextField sub_textfield;
    @FXML
    private ComboBox txtSIC;
    @FXML
    private HTMLEditor html_editor;
    @FXML
    private ComboBox combBoxMsgType;
    @FXML
    private TextArea txtMsgInstruction;
    @FXML
    private Label lblattachfile;
    @FXML
    private ComboBox<String> Combobox_precednce;
    @FXML
    private ComboBox<String> Combobox_policy;
    @FXML
    private ComboBox<String> Combobox_classification;
    @FXML
    private TextField txtPrivacy;
    @FXML
    private ComboBox<String> Combobox_category;
    @FXML
    private JFXCheckBox chk_bx_read_reqst;
    @FXML
    private JFXCheckBox chk_bx_single_reqst;
    @FXML
    private JFXCheckBox chk_bx_encryption;
    @FXML
    private JFXButton btn_modify;
    @FXML
    private Button cancel_mail;
    @FXML
    private Label change_lable;
    @FXML
    private Tooltip m_tooltipIntendedTo;
    @FXML
    private Tooltip m_tooltipIntendedCC;
    @FXML
    private Tooltip m_tooltipIntendedBCC;
    @FXML
    private MenuItem m_downloadAttachFile;

    String attach_file = "";
    MessageHandler msghndlr = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
     String groupMailIdTo="" ;
    String GroupMailIdCc="" ;
    String GroupMailIdBcc="" ;
    @FXML
    private GridPane m_attachLabel;
    int i = 0;
    int j = 0;

    String fromOffice = "";
    String bccOfficeDU = "";
    String OriginalReceiver = "";
    String ccOffice = "";
    String bccOffice = "";
    String Read_Receipt = "";
    String sic = "";
    String precedence = "";
    String OriginalSender = "";
    String OriginalBcc = "";
    String receiverOfficeDesignatedUser = "";
    String encryption = "";
    String signed_receipt_receiptfrom = "";
    String ccOfficeDU = "";
    String security_category = "";
    String Approver = "";
    String To = "";
    String DSN = "";
    String ContentType = "";
    String DSNTo = "";
    String ReturnPath = "";
    String XOriginalTo = "";
    String security_policy = "";
    String OriginalCc = "";
    String DeliveredTo = "";
    String Received = "";
    String From = "";
    String MsgType = "";
    String messageType = "";
    String msgInstruction = "";
    String Reviewer = "";
    String Date = "";
    String Subject = "";
    String MIME_Version = "";
    String security_level = "";
    String signed_receipt = "";
    String mailMsgType = "";
    String RecDate = "";
    String security_privacy_mark="";
    /**
     * ******************************************************************
     * @Function Name :initialization
     * @Description : Method to initialize when loading page.
     * @Input Parameter : NA.
     * @Output Parameter	: NA.
     * @Author : Ravikiran Bhat.
     * @Created Date :27-APR-2017
     * @Modification History:
     * ******************************************************************
     */
      public void initialization()
      {
//        ContextMenu menu=new ContextMenu();
//        menu.getItems().addAll(m_attachmentDownload, m_attachmentRemove);
         txtMsgInstruction.setEditable(false);
       
        sub_textfield.setEditable(false);
        btnBCC.setDisable(true);

        Compose_to_btn.setDisable(true);

        IntendeTo.setDisable(true);

        btncc.setDisable(true);

        txtPrivacy.setEditable(false);
        btnintendedcc.setDisable(true);

        btnintendedBCC.setDisable(true);

        chk_bx_read_reqst.setDisable(true);
        chk_bx_single_reqst.setDisable(true);
        txtSIC.setEditable(false);
        chk_bx_encryption.setDisable(true);
        txtPrivacy.setEditable(false);

        
        html_editor.setDisable(true);
        
        MailDTO outputDTO;
        try {
            double c = Double.parseDouble(mail_id);

            ReceiveMailInputDTO inputDTO = new ReceiveMailInputDTO();
            inputDTO.setMsgUID((int)c);
            inputDTO.setFolder("inbox");

            outputDTO = msghndlr.readSpecificeMail(inputDTO);
             if(outputDTO.getHeaderMap().get("uid")!=null)
            System.out.println("UID: " + outputDTO.getHeaderMap().get("uid"));
     
            HashMap<Object, Object> headers = (HashMap<Object, Object>) outputDTO.getHeaderMap();

            String fromOffice = (String) headers.get("fromOffice");
            
            
            System.out.println(fromOffice);
            String bccOfficeDU = (String) headers.get("bccOfficeDU");
            System.out.println(bccOfficeDU);
            String replyRequested = (String) headers.get("replyRequested");
            String split[];
            if (headers.get("attachedFileName") != null) {
                attach_file = (String) headers.get("attachedFileName");
                        String Split[]=attach_file.split(",");
             while(i<Split.length){
            for(j=0;j<Split.length;j++){
            Label labl=new Label();
           
             labl.setText(Split[j]+" ");   
          //   labl.setContextMenu(menu);
              m_attachLabel.add(labl,i,0);
        
          i++;
           labl.setOnMouseEntered(new EventHandler<MouseEvent>() {
          @Override
          public void handle(MouseEvent e) {
            labl.setStyle("-fx-font-weight:BOLD;-fx-text-fill:White;-fx-background-color:blue;-fx-font-size:13");

          }
        });   
        
        labl.setOnMouseExited(new EventHandler<MouseEvent>() {
          @Override
          public void handle(MouseEvent e) {
              labl.setStyle("-fx-background-color:#F4F4F4;");

          }
        });
        labl.setOnMousePressed((e) -> {

                            System.out.println("Attach FIle Name download:" + labl.getText());
                            file_download(labl.getText().trim());

                        });
           }
     }
            }

            if ((String) headers.get("sic") != null) {
                sic = (String) headers.get("sic");
            }
            if ((String) headers.get("precedence") != null) {
                precedence = (String) headers.get("precedence");
            }
            if ((String) headers.get("originalSender") != null) {
                OriginalSender = (String) headers.get("originalSender");
            }
            if ((String) headers.get("originalBcc") != null) {
                OriginalBcc = (String) headers.get("originalBcc");
            }
            if ((String) headers.get("receiverOfficeDesignatedUser") != null) {
                receiverOfficeDesignatedUser = (String) headers.get("receiverOfficeDesignatedUser");
            }
            if ((String) headers.get("encryption") != null) {
                encryption = (String) headers.get("encryption");
            }
            if ((String) headers.get("signed_receipt_receiptfrom") != null) {
                signed_receipt_receiptfrom = (String) headers.get("signed_receipt_receiptfrom");
            }
            if ((String) headers.get("ccOfficeDU") != null) {
                ccOfficeDU = (String) headers.get("ccOfficeDU");
            }
            if ((String) headers.get("security_category") != null) {
                security_category = (String) headers.get("security_category");
            }
            if ((String) headers.get("Approver") != null) {
                Approver = (String) headers.get("Approver");
            }
            if ((String) headers.get("toOffice") != null) {
                To = (String) headers.get("toOffice");
            }
            if ((String) headers.get("DSN") != null) {
                DSN = (String) headers.get("DSN");
            }
            if ((String) headers.get("Content-Type") != null) {
                ContentType = (String) headers.get("Content-Type");
            }
            if ((String) headers.get("DSNTo") != null) {
                DSNTo = (String) headers.get("DSNTo");
            }
            if ((String) headers.get("Return-Path") != null) {
                ReturnPath = (String) headers.get("Return-Path");
            }
            if ((String) headers.get("X-Original-To") != null) {
                XOriginalTo = (String) headers.get("X-Original-To");
            }
            if ((String) headers.get("originalReceiver") != null) {
                OriginalReceiver = (String) headers.get("originalReceiver");
            }
            System.out.println("Intended User" + OriginalReceiver);
            if ((String) headers.get("security_policy") != null) {
                security_policy = (String) headers.get("security_policy");
            }
            if ((String) headers.get("Received") != null) {
                Received = (String) headers.get("Received");
            }
            if ((String) headers.get("From") != null) {
                From = (String) headers.get("From");
            }
            if ((String) headers.get("MsgType") != null) {
                MsgType = (String) headers.get("MsgType");
            }
            if ((String) headers.get("messageType") != null) {
                messageType = (String) headers.get("messageType");
            }
            if ((String) headers.get("messageInstructions") != null) {
                msgInstruction = (String) headers.get("messageInstructions");
            }
            if ((String) headers.get("Reviewer") != null) {
                Reviewer = (String) headers.get("Reviewer");
            }
            if ((String) headers.get("Date") != null) {
                Date = (String) headers.get("Date");
            }
            if ((String) headers.get("Subject") != null) {
                Subject = (String) headers.get("Subject");
            }
            if ((String) headers.get("MIME-Version") != null) {
                MIME_Version = (String) headers.get("MIME-Version");
            }
            if ((String) headers.get("security_level") != null) {
                security_level = (String) headers.get("security_level");
            }
            if ((String) headers.get("signed_receipt") != null) {
                signed_receipt = (String) headers.get("signed_receipt");
            }
            if ((String) headers.get("mailMsgType") != null) {
                mailMsgType = (String) headers.get("mailMsgType");
            }
            if ((String) headers.get("read_receipt") != null) {
                Read_Receipt = (String) headers.get("read_receipt");
            }
            if((String) headers.get("security_privacy_mark")!=null){
            security_privacy_mark = (String) headers.get("security_privacy_mark");
            }
            if ((String) headers.get("originalCc") != null) {
                OriginalCc = (String) headers.get("originalCc");
            }
            if ((String) headers.get("Delivered-To") != null) {
                DeliveredTo = (String) headers.get("Delivered-To");
            }
//            String signed_receipt_receiptto = (String) headers.get("signed_receipt_receiptto");
            if ((String) headers.get("groupMailIdTo") != null) {
                groupMailIdTo = (String) headers.get("groupMailIdTo");
            }
            if ((String) headers.get("groupMailIdCc") != null) {
                GroupMailIdCc = (String) headers.get("groupMailIdCc");
            }
            if ((String) headers.get("groupMailIdBcc") != null) {
                GroupMailIdBcc = (String) headers.get("groupMailIdBcc");
            }
            if ((String) headers.get("ccOffice") != null) {
                ccOffice = (String) headers.get("ccOffice");
            }
            if ((String) headers.get("bccOffice") != null) {
                bccOffice = (String) headers.get("bccOffice");
            }
            if ((String) headers.get("Date") != null) {
                RecDate = (String) headers.get("Date");
            }

            ObservableList<String> Policy_value = FXCollections.observableArrayList(security_policy);
            ObservableList<String> Category_value = FXCollections.observableArrayList(security_level);
            ObservableList<String> combobox_category = FXCollections.observableArrayList(security_category);
            ObservableList<String> combobox_precednc = FXCollections.observableArrayList(precedence);
            from_name.setText(outputDTO.getFrom());
            to_mail.setText(To);
            lblcc.setText(ccOffice);
            lblBCC.setText(bccOffice);
     
            System.out.println("REVIEWER OROGINAL Reciver" + OriginalReceiver);
            lblIntendeTo.setText(OriginalReceiver + " " + groupMailIdTo);
            lblintendedcc.setText(OriginalCc + " " + GroupMailIdCc);
            lblintendedBCC.setText(OriginalBcc + " " + GroupMailIdBcc);
            if (groupMailIdTo.length() != 0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(groupMailIdTo);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedTo.setText(str.toString());
            }
            if (GroupMailIdCc.length() != 0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(GroupMailIdCc);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedCC.setText(str.toString());
            }
            if (GroupMailIdBcc.length() != 0) {

                GroupMailInfo groupMailInfo = msghndlr.getMailGroup(GroupMailIdBcc);
                List<String> memberMailIdsList = groupMailInfo.getMemberMailIds();
                String strr = "";
                StringBuilder str = new StringBuilder(strr);
                for (String memberMailId : memberMailIdsList) {
                    str.append(memberMailId + ",");
                }
//                System.out.println("str" + str);
                m_tooltipIntendedBCC.setText(str.toString());
            }
                       
            txtSIC.setPromptText(sic);

            sub_textfield.setText(outputDTO.getSubject());
            html_editor.setHtmlText(outputDTO.getContent());

            html_editor.setAccessibleText(outputDTO.getContent());
            Combobox_classification.setPromptText(security_level);
            txtPrivacy.setText(security_privacy_mark);
    
            Combobox_precednce.setPromptText(precedence);
            Combobox_category.setPromptText(security_category);
            Combobox_policy.setPromptText(security_policy);
            txtMsgInstruction.setText(msgInstruction);
            combBoxMsgType.setPromptText(messageType);
            System.out.println("Reviewer read reciept test:" + Read_Receipt);
            if (Read_Receipt.equalsIgnoreCase("true")) {
                System.out.println("Reviewer read reciept true");
                chk_bx_read_reqst.setSelected(true);
            }
            if (security_level.equalsIgnoreCase("TopSecret")) {
                change_lable.setText("TOP-SECRET");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: red;");
            } else if (security_level.equalsIgnoreCase("Secret")) {
                change_lable.setText("SECRET");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: orange;");
            } else if (security_level.equalsIgnoreCase("Confidential")) {
                System.out.println("Entered the confidential..........");
                change_lable.setText("CONFIDENTIAL");
                change_lable.setTextFill(Color.web("white"));
                change_lable.setStyle("-fx-background-color: blue;");
            } else if (security_level.equalsIgnoreCase("Restricted")) {
                change_lable.setText("RESTRICTED");
                change_lable.setTextFill(Color.web("Black"));
                change_lable.setStyle("-fx-background-color: yellow;");
            } else if (security_level.equalsIgnoreCase("Unclassified")) {
                change_lable.setText("UNCLASSIFIED");
                change_lable.setTextFill(Color.web("black"));
                change_lable.setStyle("-fx-background-color: white;");
            }

        } catch (Exception e) {
            System.out.println("View mmail working");
        }
      }
           /**
     * ******************************************************************
     * @Function Name :initialize
     * @Description : Method to call initialization function.
     * @Input Parameter : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
      * @Author : Ravikiran Bhat.
     * @Created Date :27-APR-2017
     * @Modification History:
     * ******************************************************************
     */

    @Override
    public void initialize(URL url, ResourceBundle rb) {
 
   initialization();

    }

    @FXML
    private void onClickbtnBCC(ActionEvent event) {
    }

    @FXML
    private void compose_to(ActionEvent event) {
    }

    @FXML
    private void openIntendeTo(ActionEvent event) {
    }

    @FXML
    private void clickBtnCC(ActionEvent event) {
    }

    @FXML
    private void onClickIntendedCC(ActionEvent event) {
    }

    @FXML
    private void clickbtnintendedBCC(ActionEvent event) {
    }

    @FXML
    private void onPrecedenceSelectaction(ActionEvent event) {
    }

    @FXML
    private void on_selection_classification(ActionEvent event) {
    }

    @FXML
    private void on_click_modify(ActionEvent event) {
    }
   /**
     * ******************************************************************
     * @Function Name :on_click_cancel
     * @Description : Method to close mail page.
     * @Input Parameter : ActionEvent-provided by JavaFX.
     * @Output Parameter	: NA.
    * @Author : Ravikiran Bhat.
     * @Created Date :27-APR-2017
     * @Modification History:
     * ******************************************************************
     */
    @FXML
    private void on_click_cancel(ActionEvent event) {

        read_mail.close();
    }
   /**
     * ******************************************************************
     * @Function Name :on_attach_file.
     * @Description : Method to close mail page.
     * @Input Parameter : MouseEvent-Provided by -JavaFX.
     * @Output Parameter	: NA.
    * @Author : Ravikiran Bhat.
     * @Created Date :27-APR-2017
     * @Modification History:15-MAY-2017,16-MAY-2017.
     * ******************************************************************
     */
    public void file_download(String file_name)
    {               
  
            FileDialog fd2 = new FileDialog(new Frame(), "SAVE FILE", FileDialog.SAVE);
            fd2.setFile(file_name);
          
         
            fd2.setVisible(true);
            String dir = fd2.getDirectory();
           fd2.setAlwaysOnTop(true);
            if (dir != null) {

            //    File downloadFile = msghndlr.downloadFile(attach_file.substring(0, attach_file.length() - 1));
            
              File downloadFile = msghndlr.downloadFile(file_name);
                if (downloadFile != null) {

                    FileInputStream instream = null;
                    try {
                        instream = new FileInputStream(downloadFile);
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }

                    String dest_path = dir + downloadFile;
                 //   String final_dest_path = dest_path.split("_")[0];
                    OutputStream out = null;
                    try {

                        out = new FileOutputStream(dest_path);

                    } catch (Exception e1) {

                        e1.printStackTrace();
                    }
                    byte[] buffer = new byte[4096];
                    int bytesRead = -1;
                    try {
                        while ((bytesRead = instream.read(buffer)) != -1) {
                            out.write(buffer, 0, bytesRead);
                            System.out.println("FILE contents"+out);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        instream.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        out.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                     }
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Download File");
                    alert.setHeaderText(null);
                    alert.setContentText("File Downloaded SuccessFully");
                    alert.showAndWait();
                  
                } else {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.initStyle(StageStyle.UTILITY);
                    alert.setTitle("Download File");
                    alert.setHeaderText(null);
                    alert.setContentText("Unable to download file, try later");
                    alert.showAndWait();
                }

            } else {
                System.out.println("Directory is not selected:");
            }
       
    }
//    @FXML
//    private void onDownloadAttachFile(ActionEvent event) throws Exception{
//       System.out.println("Attache file Clicked");
//        if(lblattachfile.getText()!=null)
//        {
//                         FileDialog fd2 = new FileDialog(new Frame(), "SAVE", FileDialog.SAVE);
//            fd2.setVisible(true);
//            String dir = fd2.getDirectory();
//
//            if(dir!= null)
//            {
//                System.out.println("Directory is selected:"+dir);
//
//
//               // File downloadFile = msghndlr.downloadFile(attach_file.substring(0, attach_file.length()-1));
//               File downloadFile = msghndlr.downloadFile(attach_file);
//                if(downloadFile != null)
//                {
//                    
//                    FileInputStream instream = null;
//                    try {
//                        instream = new FileInputStream(downloadFile);
//                    } catch (FileNotFoundException e) {
//                        e.printStackTrace();
//                    }
//
//                    String dest_path = dir+downloadFile;
//                    //String final_dest_path = dest_path.split("_") [0];
//                    OutputStream out=null;
//                    try {
//
//                        out = new FileOutputStream(dest_path);
//
//
//
//                    } catch (FileNotFoundException e1) {
//
//                        e1.printStackTrace();
//                    }
//                       byte[] buffer = new byte[4096];
//                    int bytesRead = -1;
//                    try {
//                        while ((bytesRead = instream.read(buffer)) != -1) {
//                            out.write(buffer, 0, bytesRead);
//                        }
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                    try {
//                        instream.close();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                    try {
//                        out.close();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                      Alert alert = new Alert(Alert.AlertType.INFORMATION);
//                        alert.initStyle(StageStyle.UTILITY);
//                        alert.setTitle("Download File");
//                        alert.setHeaderText(null);
//                        alert.setContentText("File Downloaded SuccessFully");
//                        alert.showAndWait();
//                }
//                else
//                {
//                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
//                    alert.initStyle(StageStyle.UTILITY);
//                    alert.setTitle("Download File");
//                    alert.setHeaderText(null);
//                    alert.setContentText("Unable to download file, try later");
//                    alert.showAndWait();
//                }
//
//
//            }
//            else
//            {
//                System.out.println("Directory is not selected:");
//            }
//        }
//        else
//        {
//            System.out.println("not downloading");
//        }
//    }

}
