/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.model;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author Root
 */
public class SentMailList {
    
    private final SimpleStringProperty from;
    private final SimpleStringProperty subject;
    private final SimpleStringProperty date;
    private final SimpleStringProperty mail_id;
    private final SimpleStringProperty sec_symbl;
    private final SimpleStringProperty preceColor;
    private final SimpleBooleanProperty Currentreadstatus;
    private final SimpleStringProperty m_attachmentTrue;

    public SentMailList(String from, String subject, String date, String mail_id, String sec_symbl, String preceColor, boolean Currentreadstatus, String m_attachmentTrue) {
        this.from = new SimpleStringProperty(from);
        this.subject = new SimpleStringProperty(subject);
        this.date = new SimpleStringProperty(date);
        this.mail_id = new SimpleStringProperty(mail_id);
        this.sec_symbl = new SimpleStringProperty(sec_symbl);
        this.preceColor = new SimpleStringProperty(preceColor);
        this.Currentreadstatus = new SimpleBooleanProperty(Currentreadstatus);
        this.m_attachmentTrue = new SimpleStringProperty(m_attachmentTrue);

    }
    public String getM_attachmentTrue() {
        return m_attachmentTrue.get();
    }

//    public void setM_attachmentTrue(String m_attachmentTrue) {
//        this.m_attachmentTrue = new SimpleStringProperty(m_attachmentTrue); firstName.set(fName);
//    }
    public void setM_attachmentTrue(String attach) {
        m_attachmentTrue.set(attach);
        
    }
    
    public boolean getCurrentreadstatus() {
        return Currentreadstatus.getValue();
    }
    
    public void setCurrentreadstatus(boolean status) {
//        this.Currentreadstatus = new SimpleBooleanProperty(Currentreadstatus);
        this.Currentreadstatus.set(status);
    }
    
    public String getPreceColor() {
        return preceColor.get();
    }
    
    public void setPreceColor(String color) {
//        this.preceColor = new SimpleStringProperty(preceColor);
        preceColor.set(color);
    }
    
    public String getSec_symbl() {
        return sec_symbl.get();
    }
    
    public void setSec_symbl(String secsymbl) {
//        this.sec_symbl = new SimpleStringProperty(sec_symbl);
        sec_symbl.set(secsymbl);
    }
    
    public String getMail_id() {
        return mail_id.get();
    }
    
    public void setMail_id(String mailid) {
//        this.mail_id = new SimpleStringProperty(mail_id);
        mail_id.set(mailid);
    }
    
    public String getFrom() {
        return from.get();
    }
    
    public void setFrom(String froms) {
//        this.from = new SimpleStringProperty(from);firstName.set(fName);
        from.set(froms);
    }
    
    public String getSubject() {
        return subject.get();
    }
    
    public void setSubject(String subj) {
//        this.subject = new SimpleStringProperty(subject);
        subject.set(subj);
    }
    
    public String getDate() {
        return date.get();
    }
    
    public void setDate(String dates) {
//        this.date = new SimpleStringProperty(date);
        date.set(dates);
    }
    
//    public SentMailList(String from) {
//        this.from = new SimpleStringProperty(from); 
//    }
    
}
