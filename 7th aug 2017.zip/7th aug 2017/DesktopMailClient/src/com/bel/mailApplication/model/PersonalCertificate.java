/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bel.mailApplication.model;


public class PersonalCertificate {
    String serialNumber;
    String issuedTo;
    String issuedBy;
    String expirationDate;
    public String getSerialNumber() {
        return serialNumber;
    }

    public PersonalCertificate(String serialNumber, String issuedTo, String issuedBy, String expirationDate) {
        this.serialNumber = serialNumber;
        this.issuedTo = issuedTo;
        this.issuedBy = issuedBy;
        this.expirationDate = expirationDate;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getIssuedTo() {
        return issuedTo;
    }

    public void setIssuedTo(String issuedTo) {
        this.issuedTo = issuedTo;
    }

    public String getIssuedBy() {
        return issuedBy;
    }

    public void setIssuedBy(String issuedBy) {
        this.issuedBy = issuedBy;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

}
