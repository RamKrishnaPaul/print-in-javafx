package com.bel.mailApplication.progress;

import com.bel.mailApplication.model.InBoxTabList;
import javafx.collections.ObservableList;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
/**
 * @File Name : ProgressServices
 * @author : Ram Krishna Paul
 * @Description: For creating task of inbox mail
 * @Package : com.bel.mailApplication.progress
 * @Created : 17th june 2017
 * @Modification History: NA
 */
public class ProgressServices extends Service<ObservableList<InBoxTabList>> {

    @Override
    protected Task createTask() {
        return new GetProgrssTask();
    }
}
