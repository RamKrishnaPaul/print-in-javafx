package com.bel.mailApplication.controller;
import static com.bel.mailApplication.controller.FXMLDocumentController.itm;
import static com.bel.mailApplication.controller.FXMLDocumentController.modify_add_bk;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_name;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import static com.bel.mailApplication.controller.LoginFXMLController.sm_pass;
import com.ldap.entity.Address_Book;
import java.util.List;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.media.AudioClip;
import mail.awan.beans.AlarmProfilesDTO;
import mail.awan.beans.ContactsOfAddrBkDTO;
import mail.awan.beans.LdapDTO;
import mail.awan.messageHandler.MessageHandler;
import org.controlsfx.control.Notifications;
/**
 * ******************************************************************
 * @File Name             : EditAddressbook_controllerController.
 * @Author                : Ravikiran Bhat.
 * @Package               : com.bel.mailApplication.controller
 * @Purpose               : Display window  for Edit  address book.
 * @Created Date	  :6-APR-2017
 * @Modification History  : NA.
*******************************************************************
 */
public class EditAddressbook_controllerController implements Initializable {
    @FXML
    private Button btnrmove;
    @FXML
    private Button btnAdd;
    @FXML
    private Label lblexistinguser;
    @FXML
    private ListView<String> Existing_user;
    @FXML
    private ListView<String> Nonexisting_user;
    @FXML
    private TextField New_add_bk_txtfld;
    @FXML
    private ObservableList<String> All_contact = FXCollections.observableArrayList();
    @FXML
    private ObservableList<String> contacts = FXCollections.observableArrayList();
    @FXML
    private  String Allglobal_contact = "";
    @FXML
    private String locl_contact = "";
     private static final AudioClip ALERT_AUDIOCLIP1 = new AudioClip(EditAddressbook_controllerController.class.getResource("/sounds/sound1.wav").toString());
    private static final AudioClip ALERT_AUDIOCLIP2 = new AudioClip(EditAddressbook_controllerController.class.getResource("/sounds/sound2.wav").toString());
    MessageHandler messageHandler = MessageHandler.getMessageHandlerInstance(sm_name, sm_pass);
    AlarmProfilesDTO alarmProfilesDTO = messageHandler.getAlarmProfiles(sm_name);
 public String m_successAlarmFlag;
    public String m_errorAlarmFlag;
    public String m_infoAlarmFlag;
    public String m_warningFlag;

    /**
     * ******************************************************************
     * @Function Name           :initialization
     * @Description             : Method to initialize when loading page.
     * @Input Parameter         : NA.
     * @Output Parameter	: NA.
     * @Author                  : Ravikiran Bhat.
     * @Created Date            :6-APR-2017
     * @Modification History    :NA.
     * ******************************************************************
     */
      public void initialization()
      {
           System.out.println(itm);
        New_add_bk_txtfld.setText(itm);
        try {

            ContactsOfAddrBkDTO dto3 = new ContactsOfAddrBkDTO();
            dto3.setCn(itm);   //address book name
            String officeName = messageHandler.ldapUserOffice(sm_name);
            dto3.setNode(officeName);   //office name
            dto3.setOwner(sm_name);     //login person name.

            List<String> str3 = messageHandler.getNonExistMember(dto3);

            for (String data : str3) {
                System.out.println(data);
                Allglobal_contact = data;
                Existing_user.setItems(All_contact);

                All_contact.add(Allglobal_contact);

            }
        } catch (Exception e) {
            System.out.println("Unable to display Contacts");
        }

        try {
                      ContactsOfAddrBkDTO dto = new ContactsOfAddrBkDTO();
            dto.setCn(itm);   //address book name
            String officeName = messageHandler.ldapUserOffice(sm_name);
            dto.setNode(officeName);   //office name
            dto.setOwner(sm_name);     //login person name.

            List<String> str = messageHandler.ContactsOfAddrBk(dto);
            //contacttable.getItems().clear();
            for (String data : str) {
                System.out.println(data);

                locl_contact = data;

                Nonexisting_user.setItems(contacts);

                contacts.add(locl_contact);

            }

        } catch (Exception e1) {

        }
      }
                      /**
     * ******************************************************************
     * @Function Name           :initialize
     * @Description             : Method to call initialization function.
     * @Input Parameter         : URL url, ResourceBundle rb.
     * @Output Parameter	: NA.
      * @Author                 : Ravikiran Bhat.
     * @Created Date            :6-MAY-2017
     * @Modification History    :NA.
     * ******************************************************************
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        initialization();
       
    }
               /**
     * ******************************************************************
     * @Function Name            :removeexistingdata
     * @Description              : Method to remove contact from list.
     * @Input Parameter          : ActionEvent-provided by -JavaFX.
     * @Output Parameter	 : NA.
      * @Author                  : Ravikiran Bhat.
     * @Created Date             :5-APR-2017
     * @Modification History     :NA.
     * ******************************************************************
     */
    @FXML
    private void removeexistingdata(ActionEvent event) {
        ObservableList<String> contactselected, allcontacts;
        ObservableList<String> existingcontacts;

        allcontacts = Nonexisting_user.getItems();
        existingcontacts = Existing_user.getItems();
        contactselected = Nonexisting_user.getSelectionModel().getSelectedItems();

        contactselected.forEach(existingcontacts::add);

        contactselected.forEach(allcontacts::remove);
    }
      /**
     * ******************************************************************
     * @Function Name           :addingexistingdata
     * @Description             : Method to add contact to list.
     * @Input Parameter         : ActionEvent-provided by -JavaFX.
     * @Output Parameter	: NA.
      * @Author                 : Ravikiran Bhat.
     * @Created Date            :6-APR-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */
    @FXML
    private void addingexistingdata(ActionEvent event) {

        ObservableList<String> contactselected, allcontacts;
        ObservableList<String> nonexistingcontacts;

        allcontacts = Existing_user.getItems();

        nonexistingcontacts = Nonexisting_user.getItems();

        contactselected = Existing_user.getSelectionModel().getSelectedItems();

        contactselected.forEach(nonexistingcontacts::add);
        contactselected.forEach(allcontacts::remove);
    }
      /**
     * ******************************************************************
     * @Function Name            :onclickSaveAddBook
     * @Description              : Method to Modify address book.
     * @Input Parameter          : ActionEvent-provided by -JavaFX.
     * @Output Parameter	 : NA.
      * @Author                  : Ravikiran Bhat.
     * @Created Date             :6-APR-2017.
     * @Modification History     :NA.
     * ******************************************************************
     */
    @FXML
    private void onclickSaveAddBook(ActionEvent event) {

        System.out.println("Entered onclickSaveAddBook");
        if (New_add_bk_txtfld.getText() == null) {
            
            
            Alert alert1 = new Alert(Alert.AlertType.WARNING);
            alert1.setTitle("Create Address book Information ");
            alert1.setHeaderText("Please Add New address book Name ");
            alert1.getAlertType();
            alert1.showAndWait();
            
               

        } else {
             System.out.println("Entered contacts");
            String New_Address_book_name = New_add_bk_txtfld.getText();
                          Nonexisting_user.getSelectionModel().selectAll();
          
           System.out.println("Selected Contacts:-"+contacts);
            System.out.println(New_Address_book_name);

            try {

                String officeName = messageHandler.ldapUserOffice(sm_name);

                LdapDTO dto = new LdapDTO();
                dto.setCn(New_Address_book_name);                // addr book name to be modified
                //dto.setMember(contacts);
                dto.setMembers(contacts);
                // add members to that address book

                dto.setOwner(sm_name);                  // login person office name
                dto.setNode(officeName);  // login person username

                Address_Book address_book = new Address_Book();
                messageHandler.modifyAdrressBook(dto);
                if(messageHandler.getAlarmProfiles(sm_name).getInfoAlarm()!=null){
            m_infoAlarmFlag = messageHandler.getAlarmProfiles(sm_name).getInfoAlarm();
                 if (m_infoAlarmFlag.equalsIgnoreCase("true")) {
                      EditAddressbook_controllerController.ALERT_AUDIOCLIP1.play();
                 }
}

                    Platform.runLater(() -> {
                    Notifications.create().text("Create Address book Information" + "\nAddress book Modified Successfully").showInformation();
                });
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information-Modify address book");
                alert.setHeaderText(New_Address_book_name+" :- "+"Address book Modified Successfully");
                alert.getAlertType();
                alert.show();

            } catch (NullPointerException e) {
                System.out.println("Unable To add Address book");
            }
     
        }

        modify_add_bk.close();
    }
           /**
     * ******************************************************************
     * @Function Name           :On_click_cancel_btn.
     * @Description             : Method to close address book window.
     * @Input Parameter         : ActionEvent-provided by -JavaFX.
     * @Output Parameter	: NA.
      * @Author                 : Ravikiran Bhat.
     * @Created Date            :6-APR-2017.
     * @Modification History    :NA.
     * ******************************************************************
     */

    @FXML
    private void on_click_cancel_btn(ActionEvent event) {
        System.out.println("Cancel button");
        modify_add_bk.close();
    }

}
